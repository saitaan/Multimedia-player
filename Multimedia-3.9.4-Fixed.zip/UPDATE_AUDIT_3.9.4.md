# Multimedia 3.9.4 update audit

Applied in this batch:
- User-facing `CleanPlayer` branding removed from app source/resources; app name is `Multimedia`.
- Removed remaining TriggerPulse references (already absent in 3.9.3, verified again).
- Added the missing `GpuEffectController` and wired it to Media3 `setVideoEffects()` using real `Contrast` and `HslAdjustment` frame effects.
- Synchronized HDR/GPU Boost state between the YouTube player button and Settings; both `isVideoSharpnessEnabled` and `isSuperResEnabled` are persisted together.
- Settings toggles for Auto-EQ, silence trimming, lyrics/translation, speech-to-text, auto-LRC, and word-sync now persist their state.
- Lyrics track isolation remains path/title keyed; stale async requests are invalidated on track change.
- Version bumped to 3.9.4 / versionCode 39.

Not claimed:
- This does not turn the conservative GPU effects into neural/AI super-resolution.
- Full Android Gradle build is not claimed because the sandbox lacks the required Android SDK/remote Gradle distribution.

Fixed in 3.9.4 Final Compilation Fix:
- Fixed `KaraokeAudioProcessor.kt`: Removed non-existent `StreamMetadata` parameter from `onFlush()`.
- Fixed `KaraokeRenderersFactory.kt`: Corrected method call to `setEnableAudioTrackPlaybackParams()`.
- Added missing `import android.graphics.drawable.GradientDrawable` in `MainActivity.kt`.
- Added missing `GpuCapabilityDetector.kt` implementation.
- Fixed `PlayerActivity.kt`: Replaced phantom `LibVlcAdjustDialog` with `showCustomColorTunerDialog()`.
