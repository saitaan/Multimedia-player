package com.cleanplayer.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Invidious Dynamic Pool Bridge
 */
class InvidiousBridge : VideoExtractorBridge {

    override val engineId: String = "invidious"
    override val displayName: String = "Invidious Dynamic Pool"
    override val description: String = "Open-source federated proxy with multi-server failover"

    companion object {
        val INVIDIOUS_INSTANCES = listOf(
            "https://inv.nadeko.net",
            "https://invidious.nerdvpn.de",
            "https://invidious.jing.rocks",
            "https://invidious.privacydev.net",
            "https://yewtu.be",
            "https://invidious.projectsegfau.lt",
            "https://invidious.flokinet.to",
            "https://invidious.drgns.space",
            "https://iv.ggtyler.dev",
            "https://invidious.asir.dev"
        )

        @Volatile
        var dynamicInstances: List<String> = emptyList()

        @Volatile
        private var lastWorkingInstance: String? = null
        private val failedInstances = ConcurrentHashMap<String, Long>()
        private const val COOLDOWN_MS = 5 * 60 * 1000L

        fun refreshInstancesAsync() {
            java.util.concurrent.Executors.newSingleThreadExecutor().execute {
                try {
                    val conn = URL("https://api.invidious.io/instances.json?sort_by=health,type").openConnection() as HttpURLConnection
                    conn.connectTimeout = 3000
                    conn.readTimeout = 3000
                    if (conn.responseCode == 200) {
                        val resp = conn.inputStream.bufferedReader().use { it.readText() }
                        val arr = org.json.JSONArray(resp)
                        val liveList = mutableListOf<String>()
                        for (i in 0 until arr.length()) {
                            val item = arr.optJSONArray(i)
                            if (item != null && item.length() >= 2) {
                                val meta = item.optJSONObject(1)
                                if (meta != null && meta.optString("type") == "https") {
                                    val uri = meta.optString("uri")
                                    if (uri.isNotBlank()) liveList.add(uri)
                                }
                            }
                        }
                        if (liveList.isNotEmpty()) {
                            dynamicInstances = liveList.take(15)
                        }
                    }
                } catch (e: Exception) {
                }
            }
        }
    }

    override fun extract(videoId: String, authToken: String?): VideoExtractionResult? {
        val now = System.currentTimeMillis()

        failedInstances.entries.removeIf { now - it.value > COOLDOWN_MS }

        val candidateList = mutableListOf<String>()
        val last = lastWorkingInstance
        if (last != null && !failedInstances.containsKey(last)) {
            candidateList.add(last)
        }
        val allSources = if (dynamicInstances.isNotEmpty()) dynamicInstances else INVIDIOUS_INSTANCES
        for (inst in allSources) {
            if (!candidateList.contains(inst) && !failedInstances.containsKey(inst)) {
                candidateList.add(inst)
            }
        }
        if (candidateList.isEmpty()) {
            candidateList.addAll(INVIDIOUS_INSTANCES)
        }

        for (instance in candidateList) {
            try {
                val endpoint = "$instance/api/v1/videos/$videoId"
                val conn = URL(endpoint).openConnection() as HttpURLConnection
                conn.connectTimeout = 2500
                conn.readTimeout = 2500
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) CleanPlayer")

                if (conn.responseCode == 200) {
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(resp)

                    val formatList = mutableListOf<VideoStreamFormat>()
                    val formats = json.optJSONArray("formatStreams") ?: json.optJSONArray("adaptiveFormats")
                    if (formats != null) {
                        for (i in 0 until formats.length()) {
                            val fmt = formats.getJSONObject(i)
                            val rawUrl = fmt.optString("url")
                            val type = fmt.optString("type", "")
                            if (type.isNotEmpty() && !type.contains("video/mp4") && !type.contains("video/webm")) continue

                            val sizeStr = fmt.optString("size", "")
                            val labelStr = fmt.optString("qualityLabel", fmt.optString("quality", ""))
                            val height = when {
                                sizeStr.contains("x") -> sizeStr.substringAfter("x").toIntOrNull() ?: 0
                                labelStr.contains("p") -> labelStr.replace("p", "").toIntOrNull() ?: 0
                                else -> fmt.optInt("resolution", 0)
                            }
                            val label = if (labelStr.isNotBlank()) labelStr else if (height > 0) "${height}p" else "360p"
                            val resolvedHeight = if (height > 0) height else 360

                            if (rawUrl.isNotEmpty()) {
                                val fullUrl = if (rawUrl.startsWith("http")) rawUrl else "$instance$rawUrl"
                                formatList.add(VideoStreamFormat(label, resolvedHeight, fullUrl))
                            }
                        }
                    }

                    val hlsUrl = json.optString("hlsUrl").takeIf { it.isNotBlank() }
                    val dashUrl = json.optString("dashUrl").takeIf { it.isNotBlank() }

                    if (formatList.isNotEmpty() || !hlsUrl.isNullOrEmpty() || !dashUrl.isNullOrEmpty()) {
                        formatList.sortByDescending { it.resolution }
                        val best = formatList.firstOrNull()?.url ?: (hlsUrl ?: dashUrl ?: "")
                        val host = try { URL(instance).host } catch (e: Exception) { "invidious" }

                        lastWorkingInstance = instance
                        failedInstances.remove(instance)

                        return VideoExtractionResult(
                            bestStreamUrl = best,
                            formats = formatList,
                            dashManifestUrl = dashUrl,
                            hlsManifestUrl = hlsUrl,
                            engineName = "Invidious [$host]",
                            isUnthrottled = true
                        )
                    }
                } else {
                    failedInstances[instance] = now
                }
            } catch (e: Exception) {
                failedInstances[instance] = now
            }
        }
        return null
    }
}
