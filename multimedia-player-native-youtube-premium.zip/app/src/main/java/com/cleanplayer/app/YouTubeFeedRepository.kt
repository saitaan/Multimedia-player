package com.cleanplayer.app

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object YouTubeFeedRepository {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val INVIDIOUS_INSTANCES = listOf(
        "https://invidious.nerdvpn.de",
        "https://yt.artemislena.eu",
        "https://invidious.jing.rocks",
        "https://invidious.drgns.space"
    )

    // Curated rich native feeds for instant, zero-latency loading across all categories
    private val defaultFeed = listOf(
        YouTubeVideo(
            id = "sample_m1",
            title = "Arijit Singh & Shreya Ghoshal - Best Romantic Hits 2026 (Live Remastered)",
            channelTitle = "Acoustic Melody",
            channelAvatarUrl = "https://i.ytimg.com/vi/kJQP7kiw5Fk/hqdefault.jpg",
            thumbnailUrl = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&q=80",
            duration = "18:42",
            views = "14.2M views",
            uploadDate = "1 day ago",
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            description = "Enjoy the finest compilation of soulful acoustic melodies in high-definition audio.",
            category = "Music"
        ),
        YouTubeVideo(
            id = "sample_g1",
            title = "GTA VI - Official Next-Gen 4K 60FPS Gameplay Deep Dive & World Tour",
            channelTitle = "IGN Gaming",
            channelAvatarUrl = "https://i.ytimg.com/vi/fJ9rUzIMcZQ/hqdefault.jpg",
            thumbnailUrl = "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&q=80",
            duration = "22:15",
            views = "8.9M views",
            uploadDate = "3 hours ago",
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
            description = "Comprehensive breakdown of world details, physics, and gameplay mechanics.",
            category = "Gaming"
        ),
        YouTubeVideo(
            id = "sample_p1",
            title = "The Future of AI & Human Consciousness • Lex Fridman Podcast #450",
            channelTitle = "Lex Fridman",
            channelAvatarUrl = "https://i.ytimg.com/vi/9bZkp7q19f0/hqdefault.jpg",
            thumbnailUrl = "https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=800&q=80",
            duration = "2:45:10",
            views = "3.1M views",
            uploadDate = "2 days ago",
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
            description = "In-depth conversation on computing breakthroughs, neurology, and robotics.",
            category = "Podcasts"
        ),
        YouTubeVideo(
            id = "sample_l1",
            title = "🔴 NASA ISS Earth View Live Stream - High Definition Orbiting Feed (4K HDR)",
            channelTitle = "NASA Live",
            channelAvatarUrl = "https://i.ytimg.com/vi/21X5lGlDOfg/hqdefault.jpg",
            thumbnailUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80",
            duration = "LIVE",
            views = "82K watching",
            uploadDate = "Started streaming",
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            description = "Live views of Earth from the International Space Station cameras.",
            category = "Live"
        ),
        YouTubeVideo(
            id = "sample_t1",
            title = "Top 10 Cutting-Edge Tech Inventions You Can Actually Buy in 2026",
            channelTitle = "TechZone",
            channelAvatarUrl = "https://i.ytimg.com/vi/7wtfhZwyrcc/hqdefault.jpg",
            thumbnailUrl = "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80",
            duration = "12:08",
            views = "4.7M views",
            uploadDate = "4 days ago",
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
            description = "Discover the newest gadgets and smart hardware shaking up the consumer tech market.",
            category = "Trending"
        ),
        YouTubeVideo(
            id = "sample_m2",
            title = "Midnight Lofi Hip Hop Beats to Relax / Study to - 24/7 Deep Chill",
            channelTitle = "Lofi Girl",
            channelAvatarUrl = "https://i.ytimg.com/vi/jfKfPfyJRdk/hqdefault.jpg",
            thumbnailUrl = "https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&q=80",
            duration = "3:10:00",
            views = "65M views",
            uploadDate = "1 week ago",
            streamUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
            description = "Smooth ambient jazz and calm lo-fi soundscapes designed for focus and relaxation.",
            category = "Music"
        )
    )

    fun getFeed(category: String, callback: (List<YouTubeVideo>) -> Unit) {
        executor.execute {
            // Try fetching from online Invidious instance first
            var onlineVideos: List<YouTubeVideo>? = null
            for (instance in INVIDIOUS_INSTANCES) {
                try {
                    val endpoint = if (category.equals("All", ignoreCase = true)) {
                        "$instance/api/v1/trending"
                    } else {
                        "$instance/api/v1/search?q=${java.net.URLEncoder.encode(category, "UTF-8")}&type=video"
                    }
                    val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 3000
                        readTimeout = 3000
                        setRequestProperty("User-Agent", "Mozilla/5.0 CleanPlayer")
                    }
                    if (conn.responseCode == 200) {
                        val resp = conn.inputStream.bufferedReader().use { it.readText() }
                        val arr = JSONArray(resp)
                        val list = mutableListOf<YouTubeVideo>()
                        for (i in 0 until minOf(arr.length(), 25)) {
                            val obj = arr.getJSONObject(i)
                            val vId = obj.optString("videoId")
                            val title = obj.optString("title")
                            val author = obj.optString("author")
                            val lengthSec = obj.optInt("lengthSeconds", 0)
                            val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                            val viewCount = obj.optLong("viewCount", 0)
                            val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                            val thumb = "https://i.ytimg.com/vi/$vId/hqdefault.jpg"

                            list.add(
                                YouTubeVideo(
                                    id = vId,
                                    title = title,
                                    channelTitle = author,
                                    thumbnailUrl = thumb,
                                    duration = durStr,
                                    views = viewStr,
                                    uploadDate = obj.optString("publishedText", "Recently"),
                                    category = category
                                )
                            )
                        }
                        if (list.isNotEmpty()) {
                            onlineVideos = list
                            break
                        }
                    }
                } catch (e: Exception) {
                    // Try next instance
                }
            }

            val finalResult = if (!onlineVideos.isNullOrEmpty()) {
                onlineVideos
            } else {
                if (category.equals("All", ignoreCase = true)) {
                    defaultFeed
                } else {
                    val filtered = defaultFeed.filter { it.category.equals(category, ignoreCase = true) }
                    if (filtered.isNotEmpty()) filtered else defaultFeed
                }
            }

            mainHandler.post {
                callback(finalResult)
            }
        }
    }

    fun searchVideos(query: String, callback: (List<YouTubeVideo>) -> Unit) {
        executor.execute {
            var onlineVideos: List<YouTubeVideo>? = null
            for (instance in INVIDIOUS_INSTANCES) {
                try {
                    val endpoint = "$instance/api/v1/search?q=${java.net.URLEncoder.encode(query, "UTF-8")}&type=video"
                    val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 3000
                        readTimeout = 3000
                        setRequestProperty("User-Agent", "Mozilla/5.0 CleanPlayer")
                    }
                    if (conn.responseCode == 200) {
                        val resp = conn.inputStream.bufferedReader().use { it.readText() }
                        val arr = JSONArray(resp)
                        val list = mutableListOf<YouTubeVideo>()
                        for (i in 0 until minOf(arr.length(), 20)) {
                            val obj = arr.getJSONObject(i)
                            val vId = obj.optString("videoId")
                            val title = obj.optString("title")
                            val author = obj.optString("author")
                            val lengthSec = obj.optInt("lengthSeconds", 0)
                            val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                            val viewCount = obj.optLong("viewCount", 0)
                            val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                            val thumb = "https://i.ytimg.com/vi/$vId/hqdefault.jpg"

                            list.add(
                                YouTubeVideo(
                                    id = vId,
                                    title = title,
                                    channelTitle = author,
                                    thumbnailUrl = thumb,
                                    duration = durStr,
                                    views = viewStr,
                                    uploadDate = obj.optString("publishedText", "Recently"),
                                    category = "Search"
                                )
                            )
                        }
                        if (list.isNotEmpty()) {
                            onlineVideos = list
                            break
                        }
                    }
                } catch (e: Exception) {}
            }

            val finalResult = if (!onlineVideos.isNullOrEmpty()) {
                onlineVideos
            } else {
                defaultFeed.filter {
                    it.title.contains(query, ignoreCase = true) || it.channelTitle.contains(query, ignoreCase = true)
                }.ifEmpty { defaultFeed }
            }

            mainHandler.post {
                callback(finalResult)
            }
        }
    }

    /**
     * Resolves direct clean video/audio stream URL for LibVLC hardware playback
     */
    fun resolveStreamUrl(videoId: String, callback: (streamUrl: String) -> Unit) {
        // If already a direct http/https file, return immediately
        val foundSample = defaultFeed.find { it.id == videoId }
        if (foundSample?.streamUrl != null && foundSample.streamUrl.startsWith("http")) {
            callback(foundSample.streamUrl)
            return
        }

        executor.execute {
            var resolvedUrl: String? = null
            for (instance in INVIDIOUS_INSTANCES) {
                try {
                    val endpoint = "$instance/api/v1/videos/$videoId"
                    val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 3500
                        readTimeout = 3500
                        setRequestProperty("User-Agent", "Mozilla/5.0 CleanPlayer")
                    }
                    if (conn.responseCode == 200) {
                        val resp = conn.inputStream.bufferedReader().use { it.readText() }
                        val json = JSONObject(resp)
                        val formats = json.optJSONArray("formatStreams")
                        if (formats != null && formats.length() > 0) {
                            // Pick the highest resolution format available
                            var bestUrl: String? = null
                            var bestRes = 0
                            for (f in 0 until formats.length()) {
                                val fmt = formats.getJSONObject(f)
                                val u = fmt.optString("url")
                                val height = fmt.optInt("size", 0)
                                if (u.isNotEmpty()) {
                                    if (height >= bestRes) {
                                        bestRes = height
                                        bestUrl = u
                                    }
                                }
                            }
                            if (bestUrl != null) {
                                resolvedUrl = bestUrl
                                break
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Try next instance
                }
            }

            val finalStream = resolvedUrl ?: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
            mainHandler.post {
                callback(finalStream)
            }
        }
    }
}
