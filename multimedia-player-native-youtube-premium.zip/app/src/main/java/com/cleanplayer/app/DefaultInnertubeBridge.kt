package com.cleanplayer.app

/**
 * Direct InnerTube Engine Bridge using Client Spoofing (Android VR, iOS, TV HTML5),
 * Dynamic Signature Deciphering, and PoToken Challenge Resolution.
 */
class DefaultInnertubeBridge : VideoExtractorBridge {

    override val engineId: String = "innertube"
    override val displayName: String = "Direct InnerTube Engine"
    override val description: String = "Direct YouTube API with client spoofing & PoToken bypass"

    override fun extract(videoId: String, authToken: String?): VideoExtractionResult? {
        val result = InnertubeExtractor.extract(videoId, authToken) ?: return null
        if (result.formats.isEmpty() && result.dashManifestUrl == null && result.hlsManifestUrl == null) {
            return null
        }
        return VideoExtractionResult(
            bestStreamUrl = result.bestStreamUrl,
            formats = result.formats,
            dashManifestUrl = result.dashManifestUrl,
            hlsManifestUrl = result.hlsManifestUrl,
            engineName = "InnerTube [${result.clientUsed}]",
            isUnthrottled = true
        )
    }
}
