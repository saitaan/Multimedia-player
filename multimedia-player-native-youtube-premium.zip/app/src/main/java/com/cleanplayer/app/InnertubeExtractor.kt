package com.cleanplayer.app

import android.os.Looper

import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.regex.Pattern

/**
 * High-Performance Innertube API Extraction Engine
 * Direct integration with YouTube's InnerTube API endpoints with Client Spoofing,
 * Dynamic JavaScript base.js Signature Deciphering, and Native Media3 DASH/HLS Extraction.
 */
object InnertubeExtractor {

    private const val INNERTUBE_PLAYER_URL = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false"
    private const val YOUTUBE_WEB_URL = "https://www.youtube.com"

    // Supported Client Configurations for Client Spoofing
    data class ClientConfig(
        val clientName: String,
        val clientVersion: String,
        val userAgent: String,
        val androidSdkVersion: Int? = null,
        val deviceModel: String? = null
    )

    private val CLIENT_MATRIX = listOf(
        // 1. Android VR (Zero poToken requirement, unthrottled direct format streams)
        ClientConfig(
            clientName = "ANDROID_VR",
            clientVersion = "1.61.48",
            userAgent = "com.google.android.apps.youtube.vr.oculus/1.61.48 (Linux; U; Android 12; Quest 2) gzip",
            androidSdkVersion = 32,
            deviceModel = "Quest 2"
        ),
        // 2. iOS Official (Direct unthrottled formats)
        ClientConfig(
            clientName = "IOS",
            clientVersion = "19.29.1",
            userAgent = "com.google.ios.youtube/19.29.1 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X; en_US)",
            deviceModel = "iPhone16,2"
        ),
        // 3. TV HTML5 Embedded (High-bitrate DASH/HLS)
        ClientConfig(
            clientName = "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
            clientVersion = "2.0",
            userAgent = "Mozilla/5.0 (SMART-TV; Linux; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/4.0 Chrome/76.0.3809.146 TV Safari/537.36"
        ),
        // 4. Android Official
        ClientConfig(
            clientName = "ANDROID",
            clientVersion = "19.29.35",
            userAgent = "com.google.android.youtube/19.29.35 (Linux; U; Android 14; en_US; Pixel 8 Pro) gzip",
            androidSdkVersion = 34
        )
    )

    data class ExtractionResult(
        val bestStreamUrl: String,
        val formats: List<VideoStreamFormat>,
        val dashManifestUrl: String? = null,
        val hlsManifestUrl: String? = null,
        val clientUsed: String
    )

    // Dynamic Cipher Operation definitions
    sealed class CipherOp {
        object Reverse : CipherOp()
        data class Swap(val index: Int) : CipherOp()
        data class Slice(val count: Int) : CipherOp()
    }

    // In-memory cache of dynamically parsed decipher operations from player base.js
    private var cachedCipherOperations: List<CipherOp>? = null
    private var lastCipherFetchTimeMs: Long = 0L

    /**
     * Executes direct InnerTube API query with client spoofing rotation
     */
    fun extract(videoId: String, authToken: String? = null): ExtractionResult? {
        for (client in CLIENT_MATRIX) {
            try {
                val result = queryInnertubePlayer(videoId, client, authToken)
                if (result != null && (result.formats.isNotEmpty() || result.dashManifestUrl != null || result.hlsManifestUrl != null)) {
                    return result
                }
            } catch (e: Exception) {
                // Try next client in rotation
            }
        }
        return null
    }

    private fun queryInnertubePlayer(videoId: String, client: ClientConfig, authToken: String?): ExtractionResult? {
        val (visitorData, poToken) = PoTokenResolver.getPoTokenContext()

        val url = URL(INNERTUBE_PLAYER_URL)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 8000
            readTimeout = 8000
            doOutput = true
            PoTokenResolver.applyHeaders(this, client.userAgent, client.clientName, getClientCode(client.clientName), client.clientVersion, authToken)
        }

        // Build InnerTube Context payload with dynamic PoToken & VisitorData to pass YouTube anti-bot checks
        val payload = JSONObject().apply {
            put("videoId", videoId)
            put("contentCheckOk", true)
            put("racyCheckOk", true)
            val contextObj = JSONObject()
            val clientObj = JSONObject().apply {
                put("clientName", client.clientName)
                put("clientVersion", client.clientVersion)
                put("hl", "en")
                put("gl", "US")
                client.androidSdkVersion?.let { put("androidSdkVersion", it) }
                client.deviceModel?.let { put("deviceModel", it) }
                put("visitorData", visitorData)
            }
            contextObj.put("client", clientObj)
            val serviceIntegrity = JSONObject().apply {
                put("poToken", poToken)
            }
            contextObj.put("serviceIntegrityDimensions", serviceIntegrity)
            put("context", contextObj)
        }

        OutputStreamWriter(conn.outputStream).use { it.write(payload.toString()) }

        if (conn.responseCode != 200) return null

        val responseText = conn.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(responseText)

        val streamingData = json.optJSONObject("streamingData") ?: return null
        val hlsManifestUrl = streamingData.optString("hlsManifestUrl").takeIf { it.isNotBlank() }
        val dashManifestUrl = streamingData.optString("dashManifestUrl").takeIf { it.isNotBlank() }

        val formatList = mutableListOf<VideoStreamFormat>()

        // 1. Process Muxed Formats (Direct video + audio)
        val formats = streamingData.optJSONArray("formats")
        if (formats != null) {
            parseFormatArray(formats, formatList)
        }

        // 2. Process Adaptive Formats (HD video streams 1080p, 720p, 480p)
        val adaptiveFormats = streamingData.optJSONArray("adaptiveFormats")
        if (adaptiveFormats != null) {
            parseFormatArray(adaptiveFormats, formatList)
        }

        if (formatList.isEmpty()) {
            if (!dashManifestUrl.isNullOrEmpty()) {
                formatList.add(VideoStreamFormat("Auto (DASH Adaptive)", 1080, dashManifestUrl))
            } else if (!hlsManifestUrl.isNullOrEmpty()) {
                formatList.add(VideoStreamFormat("Auto (HLS Master)", 1080, hlsManifestUrl))
            }
        }

        if (formatList.isEmpty() && dashManifestUrl == null && hlsManifestUrl == null) return null

        val distinctFormats = formatList
            .filter { it.url.isNotBlank() }
            .distinctBy { it.qualityLabel }
            .sortedByDescending { it.resolution }

        // Prioritize direct format streams over raw DASH manifest (which requires YouTube cookies/poToken)
        val bestDirectUrl = distinctFormats.firstOrNull { it.url.isNotBlank() }?.url
        val bestUrl = if (!bestDirectUrl.isNullOrBlank()) {
            bestDirectUrl
        } else {
            hlsManifestUrl ?: (dashManifestUrl ?: "")
        }

        return ExtractionResult(
            bestStreamUrl = bestUrl,
            formats = distinctFormats,
            dashManifestUrl = dashManifestUrl,
            hlsManifestUrl = hlsManifestUrl,
            clientUsed = client.clientName
        )
    }

    private fun parseFormatArray(arr: JSONArray, outList: MutableList<VideoStreamFormat>) {
        for (i in 0 until arr.length()) {
            val f = arr.getJSONObject(i)
            val mimeType = f.optString("mimeType", "")
            if (!mimeType.contains("video/mp4") && !mimeType.contains("video/webm")) continue

            val height = f.optInt("height", 0)
            val qualityLabel = f.optString("qualityLabel", if (height > 0) "${height}p" else "Auto")
            var streamUrl = f.optString("url", "")

            // Check if URL is protected by cipher / signatureCipher
            if (streamUrl.isEmpty()) {
                val cipher = f.optString("cipher", f.optString("signatureCipher", ""))
                if (cipher.isNotEmpty()) {
                    streamUrl = decipherCipher(cipher)
                }
            }

            if (streamUrl.isNotEmpty() && height > 0) {
                outList.add(VideoStreamFormat(qualityLabel, height, streamUrl))
            }
        }
    }

    /**
     * Deciphers encrypted signature cipher URL query using dynamically extracted rules
     */
    private fun decipherCipher(cipher: String): String {
        try {
            val params = cipher.split("&").associate {
                val parts = it.split("=", limit = 2)
                if (parts.size == 2) URLDecoder.decode(parts[0], "UTF-8") to URLDecoder.decode(parts[1], "UTF-8")
                else parts[0] to ""
            }

            val rawUrl = params["url"] ?: return ""
            val sig = params["s"] ?: return rawUrl
            val sp = params["sp"] ?: "sig"

            val decipheredSig = decipherSignatureDynamic(sig)

            return if (rawUrl.contains("?")) {
                "$rawUrl&$sp=${URLEncoder.encode(decipheredSig, "UTF-8")}"
            } else {
                "$rawUrl?$sp=${URLEncoder.encode(decipheredSig, "UTF-8")}"
            }
        } catch (e: Exception) {
            return ""
        }
    }

    /**
     * Dynamic Signature Deciphering: Fetches and applies dynamic JavaScript transformation rules from base.js
     */
    private fun decipherSignatureDynamic(sig: String): String {
        val rules = getOrFetchDynamicCipherRules()

        var current = sig.toCharArray()
        for (op in rules) {
            when (op) {
                is CipherOp.Reverse -> current.reverse()
                is CipherOp.Swap -> {
                    if (current.isNotEmpty()) {
                        val idx = (op.index % current.size + current.size) % current.size
                        val tmp = current[0]
                        current[0] = current[idx]
                        current[idx] = tmp
                    }
                }
                is CipherOp.Slice -> {
                    if (op.count in 1 until current.size) {
                        current = current.drop(op.count).toCharArray()
                    }
                }
            }
        }
        return String(current)
    }

    /**
     * Retrieves cached cipher operations or dynamically parses them from YouTube player JS
     */
    private val cipherExecutor = java.util.concurrent.Executors.newSingleThreadExecutor()

    fun prefetchPlayerCipherAsync() {
        cipherExecutor.execute {
            try {
                val baseJsContent = fetchPlayerBaseJs()
                if (!baseJsContent.isNullOrBlank()) {
                    val parsedOps = parseDecipherRulesFromJs(baseJsContent)
                    if (parsedOps.isNotEmpty()) {
                        cachedCipherOperations = parsedOps
                        lastCipherFetchTimeMs = System.currentTimeMillis()
                    }
                }
            } catch (e: Exception) {}
        }
    }

    @Synchronized
    private fun getOrFetchDynamicCipherRules(): List<CipherOp> {
        val now = System.currentTimeMillis()
        val cached = cachedCipherOperations
        if (cached != null && (now - lastCipherFetchTimeMs < 3600_000L)) {
            return cached
        }

        // Strictly prevent NetworkOnMainThreadException / ANR if invoked from UI thread
        if (Looper.myLooper() == Looper.getMainLooper()) {
            prefetchPlayerCipherAsync()
            return defaultFallbackCipherRules()
        }

        try {
            // Attempt to dynamically fetch player base.js from YouTube on background thread
            val baseJsContent = fetchPlayerBaseJs()
            if (!baseJsContent.isNullOrBlank()) {
                val parsedOps = parseDecipherRulesFromJs(baseJsContent)
                if (parsedOps.isNotEmpty()) {
                    cachedCipherOperations = parsedOps
                    lastCipherFetchTimeMs = now
                    return parsedOps
                }
            }
        } catch (e: Exception) {
            // Fallback to default heuristic rule sequence
        }

        return defaultFallbackCipherRules()
    }

    private fun defaultFallbackCipherRules(): List<CipherOp> {
        val fallbackOps = listOf(
            CipherOp.Reverse,
            CipherOp.Swap(2),
            CipherOp.Slice(1),
            CipherOp.Swap(17)
        )
        cachedCipherOperations = fallbackOps
        lastCipherFetchTimeMs = System.currentTimeMillis()
        return fallbackOps
    }

    private fun fetchPlayerBaseJs(): String? {
        try {
            // 1. Get YouTube HTML to find current base.js url
            val ytConn = (URL(YOUTUBE_WEB_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 3000
                readTimeout = 3000
                setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
            }
            val html = ytConn.inputStream.bufferedReader().use { it.readText() }

            val jsPathMatcher = Pattern.compile(""""([^"]*player_ias[^"]*base\\.js)"""").matcher(html)
            val jsUrl = if (jsPathMatcher.find()) {
                val path = jsPathMatcher.group(1).replace("\\/", "/")
                if (path.startsWith("http")) path else "https://www.youtube.com$path"
            } else {
                "https://www.youtube.com/s/player/current/player_ias.vflset/en_US/base.js"
            }

            val jsConn = (URL(jsUrl).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
            }
            if (jsConn.responseCode == 200) {
                return jsConn.inputStream.bufferedReader().use { it.readText() }
            }
        } catch (e: Exception) {
            // Handled by fallback
        }
        return null
    }

    /**
     * Parses the decipher function and its helper object operations from base.js source
     */
    private fun parseDecipherRulesFromJs(js: String): List<CipherOp> {
        val ops = mutableListOf<CipherOp>()
        try {
            // Regex matching main decipher function: a=a.split(""); <helper>.<func>(a, <arg>); return a.join("")
            val funcPattern = Pattern.compile("([a-zA-Z0-9$]+)\\s*=\\s*function\\(\\s*([a-zA-Z0-9$]+)\\s*\\)\\s*\\{\\s*\\2\\s*=\\s*\\2\\.split\\(\\s*\"\"\\s*\\);\\s*([^\\}]+)\\s*return\\s+\\2\\.join\\(\\s*\"\"\\s*\\)")
            val matcher = funcPattern.matcher(js)
            if (!matcher.find()) return ops

            val body = matcher.group(3) ?: return ops

            val callPattern = Pattern.compile("""([a-zA-Z0-9$]+)\.([a-zA-Z0-9$]+)\(\s*[a-zA-Z0-9$]+\s*(?:,\s*(\d+))?\s*\)""")
            val callMatcher = callPattern.matcher(body)

            while (callMatcher.find()) {
                val fnName = callMatcher.group(2)
                val arg = callMatcher.group(3)?.toIntOrNull() ?: 0

                // Find the helper definition in the JS object
                val defPattern = Pattern.compile(Pattern.quote(fnName) + "\\s*:\\s*function\\([^)]*\\)\\s*\\{([^{}]+)\\}")
                val defMatcher = defPattern.matcher(js)
                if (defMatcher.find()) {
                    val defBody = defMatcher.group(1) ?: ""
                    when {
                        defBody.contains("reverse") -> ops.add(CipherOp.Reverse)
                        defBody.contains("splice") || defBody.contains("slice") -> ops.add(CipherOp.Slice(arg))
                        defBody.contains("var c") || defBody.contains("%") -> ops.add(CipherOp.Swap(arg))
                    }
                }
            }
        } catch (e: Exception) {
            ops.clear()
        }
        return ops
    }

    private fun getClientCode(clientName: String): String {
        return when (clientName) {
            "ANDROID_VR" -> "28"
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER" -> "85"
            "TVHTML5" -> "7"
            "IOS" -> "5"
            "ANDROID_TESTSUITE" -> "89"
            "ANDROID" -> "3"
            else -> "28"
        }
    }
}
