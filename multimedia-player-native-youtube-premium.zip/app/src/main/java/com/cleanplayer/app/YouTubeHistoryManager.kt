package com.cleanplayer.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object YouTubeHistoryManager {

    private const val PREFS_NAME = "youtube_local_history_prefs"
    private const val KEY_HISTORY = "watch_history"
    private const val KEY_BOOKMARKS = "video_bookmarks"
    private const val MAX_HISTORY_ITEMS = 50

    fun addWatchHistory(context: Context, video: YouTubeVideo) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val currentList = getWatchHistory(context).toMutableList()
        currentList.removeAll { it.id == video.id }
        currentList.add(0, video)
        if (currentList.size > MAX_HISTORY_ITEMS) {
            currentList.removeAt(currentList.size - 1)
        }
        saveList(prefs, KEY_HISTORY, currentList)
    }

    fun getWatchHistory(context: Context): List<YouTubeVideo> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return loadList(prefs, KEY_HISTORY)
    }

    fun clearHistory(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_HISTORY).apply()
    }

    fun toggleBookmark(context: Context, video: YouTubeVideo): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val currentList = getBookmarks(context).toMutableList()
        val exists = currentList.any { it.id == video.id }
        if (exists) {
            currentList.removeAll { it.id == video.id }
        } else {
            currentList.add(0, video)
        }
        saveList(prefs, KEY_BOOKMARKS, currentList)
        return !exists
    }

    fun isBookmarked(context: Context, videoId: String): Boolean {
        return getBookmarks(context).any { it.id == videoId }
    }

    fun getBookmarks(context: Context): List<YouTubeVideo> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return loadList(prefs, KEY_BOOKMARKS)
    }

    private fun saveList(prefs: android.content.SharedPreferences, key: String, list: List<YouTubeVideo>) {
        val arr = JSONArray()
        for (v in list) {
            val obj = JSONObject().apply {
                put("id", v.id)
                put("title", v.title)
                put("channelTitle", v.channelTitle)
                put("channelAvatarUrl", v.channelAvatarUrl ?: "")
                put("thumbnailUrl", v.thumbnailUrl)
                put("duration", v.duration)
                put("views", v.views)
                put("uploadDate", v.uploadDate)
                put("category", v.category)
            }
            arr.put(obj)
        }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    private fun loadList(prefs: android.content.SharedPreferences, key: String): List<YouTubeVideo> {
        val raw = prefs.getString(key, null) ?: return emptyList()
        val result = mutableListOf<YouTubeVideo>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    YouTubeVideo(
                        id = obj.optString("id"),
                        title = obj.optString("title"),
                        channelTitle = obj.optString("channelTitle"),
                        channelAvatarUrl = obj.optString("channelAvatarUrl").takeIf { it.isNotEmpty() },
                        thumbnailUrl = obj.optString("thumbnailUrl"),
                        duration = obj.optString("duration", "00:00"),
                        views = obj.optString("views", "0 views"),
                        uploadDate = obj.optString("uploadDate", "Recently"),
                        category = obj.optString("category", "All")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }
}
