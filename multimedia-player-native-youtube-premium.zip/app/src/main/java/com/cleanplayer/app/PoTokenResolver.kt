package com.cleanplayer.app

import android.content.Context
import java.net.HttpURLConnection

/**
 * Proof of Origin Token (PoToken) Challenge Resolver & Authenticated Session Manager
 * Resolves anti-bot integrity challenges, passes legitimate MicroG credentials,
 * and eliminates invalid synthetic tokens that cause botguard rejections.
 */
object PoTokenResolver {

    /**
     * Checks whether an authentic user auth/poToken is available
     */
    fun getAuthenticPoToken(authToken: String?): String? {
        if (!authToken.isNullOrBlank() && !authToken.startsWith("fake_")) {
            return authToken
        }
        return null
    }

    /**
     * Configures HTTP connection with clean, unthrottled client headers.
     * Prevents web-cookie pollution on native mobile clients (ANDROID_VR, IOS, TESTSUITE).
     */
    fun applyHeaders(
        conn: HttpURLConnection,
        clientUserAgent: String,
        clientName: String,
        clientCode: String,
        clientVersion: String,
        authToken: String? = null
    ) {
        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
        conn.setRequestProperty("User-Agent", clientUserAgent)
        conn.setRequestProperty("X-YouTube-Client-Name", clientCode)
        conn.setRequestProperty("X-YouTube-Client-Version", clientVersion)
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")

        // Only embedded web players expect Origin/Referer headers
        if (clientName.contains("EMBEDDED") || clientName.contains("WEB")) {
            conn.setRequestProperty("Origin", "https://www.youtube.com")
            conn.setRequestProperty("Referer", "https://www.youtube.com/")
        }

        if (!authToken.isNullOrBlank()) {
            conn.setRequestProperty("Authorization", authToken)
        }
    }
}
