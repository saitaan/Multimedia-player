package com.cleanplayer.app

import android.accounts.Account
import android.accounts.AccountManager
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

object MicroGAuthManager {

    private const val PREFS_NAME = "microg_auth_prefs"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_ACCOUNT_NAME = "account_name"
    private const val KEY_ACCOUNT_EMAIL = "account_email"
    private const val KEY_AVATAR_URL = "avatar_url"

    private val MICROG_PACKAGES = listOf(
        "org.microg.gms.core",
        "com.mgoogle.android.gms",
        "com.google.android.gms"
    )

    fun isMicroGInstalled(context: Context): Boolean {
        val pm = context.packageManager
        for (pkg in MICROG_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, 0)
                return true
            } catch (e: PackageManager.NameNotFoundException) {
                // Continue checking
            }
        }
        return false
    }

    fun isLoggedIn(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    fun getAccountName(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCOUNT_NAME, "Google Account") ?: "Google Account"
    }

    fun getAccountEmail(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCOUNT_EMAIL, "guest@cleanplayer.app") ?: "guest@cleanplayer.app"
    }

    fun getAvatarUrl(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_AVATAR_URL, null)
    }

    fun saveAccount(context: Context, name: String, email: String, avatarUrl: String? = null) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_ACCOUNT_NAME, name)
            .putString(KEY_ACCOUNT_EMAIL, email)
            .putString(KEY_AVATAR_URL, avatarUrl)
            .apply()
    }

    fun signOut(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
    }

    /**
     * Checks device accounts or MicroG accounts and syncs if available
     */
    fun checkAndSyncDeviceAccounts(context: Context): Boolean {
        try {
            val am = AccountManager.get(context)
            val accounts: Array<Account> = am.getAccountsByType("com.google")
            if (accounts.isNotEmpty()) {
                val primary = accounts[0]
                val name = primary.name.substringBefore("@")
                saveAccount(context, name, primary.name, null)
                return true
            }
        } catch (e: Exception) {
            // Permission or missing GMS
        }
        return false
    }

    /**
     * Opens MicroG or System Add Account Settings
     */
    fun startSignInIntent(context: Context) {
        try {
            // 1. Try MicroG specific account intro
            val intent = Intent().apply {
                component = ComponentName("org.microg.gms.core", "org.microg.gms.auth.AccountIntroActivity")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                // 2. Fallback to Android Add Account Settings
                val addIntent = Intent("android.settings.ADD_ACCOUNT_SETTINGS").apply {
                    putExtra("account_types", arrayOf("com.google"))
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(addIntent)
            } catch (e2: Exception) {
                Toast.makeText(context, "Please install MicroG GmsCore to sign in", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Displays high quality YouTube Account BottomSheet / Dialog
     */
    fun showAccountDialog(context: Context, onStateChanged: () -> Unit) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_youtube_account, null, false)
        val dialog = AlertDialog.Builder(context)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tvName = dialogView.findViewById<TextView>(R.id.tvDialogAccountName)
        val tvEmail = dialogView.findViewById<TextView>(R.id.tvDialogAccountEmail)
        val tvStatus = dialogView.findViewById<TextView>(R.id.tvDialogMicroGStatus)
        val btnAction = dialogView.findViewById<Button>(R.id.btnDialogAccountAction)
        val btnSignOut = dialogView.findViewById<Button>(R.id.btnDialogSignOut)

        val isMicroG = isMicroGInstalled(context)
        tvStatus.text = if (isMicroG) "MicroG GmsCore: Detected & Connected" else "MicroG GmsCore: Standalone Mode"
        tvStatus.setTextColor(if (isMicroG) Color.parseColor("#4CAF50") else Color.parseColor("#FF9800"))

        if (isLoggedIn(context)) {
            tvName.text = getAccountName(context)
            tvEmail.text = getAccountEmail(context)
            btnAction.text = "Switch Account"
            btnSignOut.visibility = View.VISIBLE
        } else {
            tvName.text = "Guest User"
            tvEmail.text = "Sign in with MicroG for personalized feed & history"
            btnAction.text = "Sign In with MicroG"
            btnSignOut.visibility = View.GONE
        }

        btnAction.setOnClickListener {
            dialog.dismiss()
            startSignInIntent(context)
            onStateChanged()
        }

        btnSignOut.setOnClickListener {
            signOut(context)
            dialog.dismiss()
            Toast.makeText(context, "Signed out of Google Account", Toast.LENGTH_SHORT).show()
            onStateChanged()
        }

        dialog.show()
    }
}
