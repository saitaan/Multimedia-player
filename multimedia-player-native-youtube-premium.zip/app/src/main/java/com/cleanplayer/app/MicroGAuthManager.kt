package com.cleanplayer.app

import android.accounts.Account
import android.accounts.AccountManager
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

object MicroGAuthManager {

    private const val PREFS_NAME = "microg_auth_prefs"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_ACCOUNT_NAME = "account_name"
    private const val KEY_ACCOUNT_EMAIL = "account_email"
    private const val KEY_AVATAR_URL = "avatar_url"

    // Real MicroG packages only (never standard Google Play Services)
    private val MICROG_PACKAGES = listOf(
        "org.microg.gms.core",
        "app.revanced.android.gms"
    )

    fun isMicroGInstalled(context: Context): Boolean {
        val pm = context.packageManager
        for (pkg in MICROG_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, 0)
                return true
            } catch (e: PackageManager.NameNotFoundException) {
                // Continue checking
            }
        }
        return false
    }

    fun isLoggedIn(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    fun getAccountName(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCOUNT_NAME, "Guest User") ?: "Guest User"
    }

    fun getAccountEmail(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCOUNT_EMAIL, "guest@cleanplayer.app") ?: "guest@cleanplayer.app"
    }

    fun getAvatarUrl(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_AVATAR_URL, null)
    }

    fun saveAccount(context: Context, name: String, email: String, avatarUrl: String? = null) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_ACCOUNT_NAME, name)
            .putString(KEY_ACCOUNT_EMAIL, email)
            .putString(KEY_AVATAR_URL, avatarUrl)
            .apply()
    }

    fun signOut(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
    }

    fun startSignInIntent(context: Context) {
        try {
            val intent = Intent().apply {
                component = ComponentName("org.microg.gms.core", "org.microg.gms.auth.AccountIntroActivity")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val addIntent = Intent("android.settings.ADD_ACCOUNT_SETTINGS").apply {
                    putExtra("account_types", arrayOf("com.google"))
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(addIntent)
            } catch (e2: Exception) {
                Toast.makeText(context, "MicroG is optional: Videos play 100% ad-free without sign-in", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun showAccountDialog(context: Context, onStateChanged: () -> Unit) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_youtube_account, null, false)
        val dialog = AlertDialog.Builder(context)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tvName = dialogView.findViewById<TextView>(R.id.tvDialogAccountName)
        val tvEmail = dialogView.findViewById<TextView>(R.id.tvDialogAccountEmail)
        val tvStatus = dialogView.findViewById<TextView>(R.id.tvDialogMicroGStatus)
        val btnAction = dialogView.findViewById<Button>(R.id.btnDialogAccountAction)
        val btnSignOut = dialogView.findViewById<Button>(R.id.btnDialogSignOut)

        val isMicroG = isMicroGInstalled(context)
        if (isMicroG) {
            tvStatus.text = "MicroG GmsCore: Detected & Connected"
            tvStatus.setTextColor(Color.parseColor("#4CAF50"))
        } else {
            tvStatus.text = "Standalone Mode (100% Ad-Free & Active)"
            tvStatus.setTextColor(Color.parseColor("#00E5FF"))
        }

        if (isLoggedIn(context)) {
            tvName.text = getAccountName(context)
            tvEmail.text = getAccountEmail(context)
            btnAction.text = "Switch Account"
            btnSignOut.visibility = View.VISIBLE
        } else {
            tvName.text = "Guest User"
            tvEmail.text = if (isMicroG) "Sign in with MicroG for personal subscriptions" else "Playing in Standalone Mode (Sign-in optional)"
            btnAction.text = if (isMicroG) "Sign In with MicroG" else "Got It (Continue as Guest)"
            btnSignOut.visibility = View.GONE
        }

        btnAction.setOnClickListener {
            dialog.dismiss()
            if (isMicroG) {
                startSignInIntent(context)
                onStateChanged()
            } else {
                Toast.makeText(context, "Enjoying 100% Clean Ad-Free YouTube", Toast.LENGTH_SHORT).show()
            }
        }

        btnSignOut.setOnClickListener {
            signOut(context)
            dialog.dismiss()
            Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
            onStateChanged()
        }

        dialog.show()
    }
}
