package com.cleanplayer.app

import android.accounts.Account
import android.accounts.AccountManager
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

/**
 * ReVanced-Style GmsCore & Vanced MicroG Integration Manager
 * Manages Google Account authentication, OAuth token persistence, and GmsCore client detection.
 */
object MicroGAuthManager {

    private const val PREFS_NAME = "microg_auth_prefs"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_ACCOUNT_NAME = "account_name"
    private const val KEY_ACCOUNT_EMAIL = "account_email"
    private const val KEY_AVATAR_URL = "avatar_url"
    private const val KEY_AUTH_TOKEN = "oauth_token"
    private const val KEY_MICROG_FLAVOR = "microg_flavor"

    // Recognized MicroG and ReVanced GmsCore packages
    val MICROG_PACKAGES = listOf(
        "app.revanced.android.gms", // ReVanced GmsCore
        "com.mgoogle.android.gms",   // Vanced MicroG
        "org.microg.gms.core"        // Official MicroG GmsCore
    )

    // AccountManager account types exposed by MicroG implementations
    private val ACCOUNT_TYPES = listOf(
        "app.revanced.android.gms",
        "com.mgoogle",
        "org.microg.gms",
        "com.google"
    )

    fun getDetectedMicroGFlavor(context: Context): String? {
        val pm = context.packageManager
        for (pkg in MICROG_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, 0)
                return when (pkg) {
                    "app.revanced.android.gms" -> "ReVanced GmsCore"
                    "com.mgoogle.android.gms" -> "Vanced MicroG"
                    "org.microg.gms.core" -> "MicroG GmsCore"
                    else -> "MicroG"
                }
            } catch (e: PackageManager.NameNotFoundException) {
                // Check next
            }
        }
        return null
    }

    fun isMicroGInstalled(context: Context): Boolean {
        return getDetectedMicroGFlavor(context) != null
    }

    /**
     * Auto-detect accounts registered in Android AccountManager by MicroG
     */
    fun syncAccountsFromSystem(context: Context): Boolean {
        try {
            val am = AccountManager.get(context)
            for (type in ACCOUNT_TYPES) {
                val accounts = am.getAccountsByType(type)
                if (accounts.isNotEmpty()) {
                    val primaryAccount = accounts[0]
                    saveAccount(
                        context = context,
                        name = primaryAccount.name.substringBefore("@"),
                        email = primaryAccount.name,
                        avatarUrl = null
                    )
                    return true
                }
            }
        } catch (e: Exception) {
            // SecurityException or permission check
        }
        return false
    }

    fun isLoggedIn(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_IS_LOGGED_IN, false)) return true
        // Try auto-syncing if MicroG is installed
        return syncAccountsFromSystem(context)
    }

    fun getAccountName(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCOUNT_NAME, "Guest User") ?: "Guest User"
    }

    fun getAccountEmail(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCOUNT_EMAIL, "guest@cleanplayer.app") ?: "guest@cleanplayer.app"
    }

    fun getAvatarUrl(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_AVATAR_URL, null)
    }

    fun getOAuthToken(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_AUTH_TOKEN, null)
    }

    fun getAuthorizationHeader(context: Context): String? {
        val token = getOAuthToken(context) ?: return null
        return "Bearer $token"
    }

    fun saveAccount(context: Context, name: String, email: String, avatarUrl: String? = null, token: String? = null) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_ACCOUNT_NAME, name)
            .putString(KEY_ACCOUNT_EMAIL, email)
            .putString(KEY_AVATAR_URL, avatarUrl)
            .putString(KEY_AUTH_TOKEN, token)
            .apply()
    }

    fun signOut(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
    }

    /**
     * Attempts to open ReVanced GmsCore / MicroG Account Sign-In screen
     */
    fun startSignInIntent(context: Context) {
        val intentsToTry = listOf(
            // ReVanced GmsCore Account Intro
            Intent().apply {
                component = ComponentName("app.revanced.android.gms", "org.microg.gms.auth.AccountIntroActivity")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            },
            // Vanced MicroG Account Intro
            Intent().apply {
                component = ComponentName("com.mgoogle.android.gms", "org.microg.gms.auth.AccountIntroActivity")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            },
            // Official MicroG Account Intro
            Intent().apply {
                component = ComponentName("org.microg.gms.core", "org.microg.gms.auth.AccountIntroActivity")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            },
            // Android Account Settings fallback
            Intent("android.settings.ADD_ACCOUNT_SETTINGS").apply {
                putExtra("account_types", arrayOf("app.revanced.android.gms", "com.mgoogle", "com.google"))
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        )

        for (intent in intentsToTry) {
            try {
                context.startActivity(intent)
                return
            } catch (e: Exception) {
                // Try next
            }
        }

        Toast.makeText(context, "MicroG is optional: CleanPlayer operates in 100% Ad-Free standalone mode", Toast.LENGTH_LONG).show()
    }

    fun showAccountDialog(context: Context, onStateChanged: () -> Unit) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_youtube_account, null, false)
        val dialog = AlertDialog.Builder(context)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tvName = dialogView.findViewById<TextView>(R.id.tvDialogAccountName)
        val tvEmail = dialogView.findViewById<TextView>(R.id.tvDialogAccountEmail)
        val tvStatus = dialogView.findViewById<TextView>(R.id.tvDialogMicroGStatus)
        val btnAction = dialogView.findViewById<Button>(R.id.btnDialogAccountAction)
        val btnSignOut = dialogView.findViewById<Button>(R.id.btnDialogSignOut)

        syncAccountsFromSystem(context)

        val flavor = getDetectedMicroGFlavor(context)
        if (flavor != null) {
            tvStatus.text = "$flavor: Connected"
            tvStatus.setTextColor(Color.parseColor("#4CAF50"))
        } else {
            tvStatus.text = "Standalone Mode (100% Ad-Free Core Active)"
            tvStatus.setTextColor(Color.parseColor("#00E5FF"))
        }

        if (isLoggedIn(context)) {
            tvName.text = getAccountName(context)
            tvEmail.text = getAccountEmail(context)
            btnAction.text = "Switch / Manage Account"
            btnSignOut.visibility = View.VISIBLE
        } else {
            tvName.text = "Guest User"
            tvEmail.text = if (flavor != null) "Sign in via $flavor for personalized subscriptions & history" else "Playing in Standalone Mode (Sign-in optional)"
            btnAction.text = if (flavor != null) "Sign In with $flavor" else "Continue as Guest"
            btnSignOut.visibility = View.GONE
        }

        btnAction.setOnClickListener {
            dialog.dismiss()
            if (flavor != null) {
                startSignInIntent(context)
                onStateChanged()
            } else {
                Toast.makeText(context, "Enjoying CleanPlayer 100% Ad-Free Experience", Toast.LENGTH_SHORT).show()
            }
        }

        btnSignOut.setOnClickListener {
            signOut(context)
            dialog.dismiss()
            Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
            onStateChanged()
        }

        dialog.show()
    }
}
