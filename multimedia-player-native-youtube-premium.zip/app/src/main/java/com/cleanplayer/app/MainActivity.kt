package com.cleanplayer.app

import android.Manifest
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import androidx.core.widget.NestedScrollView
import android.widget.Button
import android.widget.ProgressBar
import android.widget.HorizontalScrollView
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.ImageButton
import android.widget.ImageView
import com.google.android.material.card.MaterialCardView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.widget.FrameLayout
import android.widget.RelativeLayout

class MainActivity : AppCompatActivity() {
    companion object {
        init {
            androidx.appcompat.app.AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        }
    }


    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnToolbarSearch: ImageButton
    private lateinit var btnToolbarSort: ImageButton
    private lateinit var btnToolbarOpen: ImageButton
    private lateinit var fabPlay: FloatingActionButton
    private lateinit var etSearch: EditText
    private lateinit var tabVideo: LinearLayout
    private lateinit var tabAudio: LinearLayout
    private lateinit var tabSettings: ScrollView
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var tabYouTube: FrameLayout
    private lateinit var layoutYtMainFeed: LinearLayout
    private lateinit var btnYtExitToLocal: ImageButton
    private lateinit var nsvYtFeed: NestedScrollView
    private lateinit var rvYouTubeFeed: RecyclerView
    private lateinit var rvYouTubeShorts: RecyclerView
    private lateinit var rvYouTubeFeedSecondary: RecyclerView
    private lateinit var youTubeShortsAdapter: YouTubeShortsAdapter
    private lateinit var srlYouTubeFeed: androidx.swiperefreshlayout.widget.SwipeRefreshLayout
    private lateinit var pbYtFeedLoading: ProgressBar
    private lateinit var layoutYtEmpty: LinearLayout
    private lateinit var btnYtRetry: Button
    private lateinit var btnYtSearch: ImageButton
    private lateinit var btnYtAccount: ImageButton
    private lateinit var btnYtCast: ImageButton
    private lateinit var btnYtNotifications: ImageButton
    private lateinit var layoutYtSearchBar: LinearLayout
    private lateinit var etYtSearchQuery: EditText
    private lateinit var btnYtCloseSearch: ImageButton
    private lateinit var chipYtAll: TextView
    private lateinit var chipYtMusic: TextView
    private lateinit var chipYtGaming: TextView
    private lateinit var chipYtPodcasts: TextView
    private lateinit var chipYtLive: TextView
    private lateinit var chipYtTrending: TextView
    private lateinit var chipYtNews: TextView
    private lateinit var youTubeFeedAdapter: YouTubeFeedAdapter
    private lateinit var youTubeFeedSecondaryAdapter: YouTubeFeedAdapter
    private var currentYtCategory: String = "All"
    private var isYtFeedLoaded = false
    private var lastActiveTabId = R.id.nav_video

    // YouTube Dedicated Bottom Nav
    private lateinit var btnYtNavHome: LinearLayout
    private lateinit var btnYtNavShorts: LinearLayout
    private lateinit var btnYtNavSubs: LinearLayout
    private lateinit var btnYtNavLibrary: LinearLayout

    // YouTube Portrait Detail Player (Matching Screenshot 5681.jpg)
    private lateinit var layoutYtPlayerDetail: LinearLayout
    private lateinit var playerViewYt: androidx.media3.ui.PlayerView
    private lateinit var btnYtCollapsePlayer: ImageButton
    private lateinit var btnYtFullscreen: ImageButton
    private lateinit var tvYtDetailTitle: TextView
    private lateinit var tvYtDetailSubtitle: TextView
    private lateinit var ivYtDetailAvatar: ImageView
    private lateinit var tvYtDetailChannel: TextView
    private lateinit var btnYtSubscribe: TextView
    private lateinit var layoutYtLikePill: LinearLayout
    private lateinit var tvYtDetailLikes: TextView
    private lateinit var layoutYtSharePill: LinearLayout
    private lateinit var layoutYtDownloadPill: LinearLayout
    private lateinit var layoutYtSavePill: LinearLayout
    private lateinit var layoutYtCommentsCard: LinearLayout
    private lateinit var tvYtDetailCommentsCount: TextView
    private lateinit var rvYtRelatedVideos: RecyclerView

    // YouTube Floating Miniplayer (Matching Screenshots 5682.jpg & 5680.jpg)
    private lateinit var cardYtMiniPlayer: MaterialCardView
    private lateinit var ivYtMiniThumb: ImageView
    private lateinit var tvYtMiniTitle: TextView
    private lateinit var tvYtMiniChannel: TextView
    private lateinit var btnYtMiniPlayPause: ImageButton
    private lateinit var btnYtMiniClose: ImageButton

    private var currentPlayingYtVideo: YouTubeVideo? = null
    private var isYtVideoPlaying: Boolean = false

    private lateinit var btnViewAllVideos: TextView
    private lateinit var btnViewFolders: TextView
    private lateinit var rvVideos: RecyclerView
    private lateinit var layoutFoldersContainer: LinearLayout
    private lateinit var rvFolders: RecyclerView
    private lateinit var layoutFolderDetailHeader: LinearLayout
    private lateinit var btnFolderBack: ImageButton
    private lateinit var tvFolderHeaderTitle: TextView
    private lateinit var tvFolderHeaderSubtitle: TextView
    private lateinit var rvFolderVideos: RecyclerView
    private lateinit var layoutEmptyVideo: LinearLayout
    private lateinit var btnBrowseVideo: Button

    private var isFolderViewActive: Boolean = false
    private var allFolders: List<MediaFolder> = emptyList()
    private var currentSelectedFolder: MediaFolder? = null
    private var folderAdapter: FolderAdapter? = null
    private var folderVideoAdapter: MediaAdapter? = null

    private lateinit var rvAudio: RecyclerView
    private lateinit var layoutEmptyAudio: LinearLayout
    private lateinit var btnBrowseAudio: Button

    // 1. Video Settings Views
    private lateinit var tvHighRefreshRateStatus: TextView
    private lateinit var btnToggleHighRefreshRate: Button
    private lateinit var tvDefaultOrientationStatus: TextView
    private lateinit var btnChangeOrientation: Button

    // Top Notch Mini-Player Views (matches 5203.jpg)
    private lateinit var cardNotchPlayer: MaterialCardView
    private lateinit var tvNotchTitle: TextView
    private lateinit var tvNotchArtist: TextView
    private lateinit var btnNotchClose: ImageButton
    private lateinit var btnNotchRepeat: ImageButton
    private lateinit var btnNotchPrev: ImageButton
    private lateinit var btnNotchPlayPause: ImageButton
    private lateinit var btnNotchNext: ImageButton
    private lateinit var btnNotchOpen: ImageButton
    private lateinit var tvNotchCurrent: TextView
    private lateinit var sbNotch: SeekBar
    private lateinit var tvNotchTotal: TextView
    private lateinit var tvVideoColorStatus: TextView
    private lateinit var btnChangeVideoColor: Button
    private lateinit var tvWideColorStatus: TextView
    private lateinit var btnToggleWideColor: Button
    private lateinit var tvDeblockingStatus: TextView
    private lateinit var btnToggleDeblocking: Button
    private lateinit var tvHwDecodeStatus: TextView
    private lateinit var btnChangeHw: Button
    private lateinit var tvBgPipStatus: TextView
    private lateinit var btnChangeBgPip: Button
    private lateinit var tvResumeModeStatus: TextView
    private lateinit var btnChangeResumeMode: Button
    private lateinit var tvDoubleTapStatus: TextView
    private lateinit var btnChangeDoubleTap: Button
    private lateinit var tvAspectRatioStatus: TextView
    private lateinit var btnChangeAspectRatio: Button
    private lateinit var tvAudioBoostStatus: TextView
    private lateinit var btnToggleAudioBoost: Button

    // 2. Integrated Dolby, Spatial & Equalizer Audio Suite Views
    private lateinit var tvMasterProfileStatus: TextView
    private lateinit var btnChangeMasterProfile: Button
    private lateinit var tvDolbySurroundStatus: TextView
    private lateinit var btnChangeDolbySurround: Button
    private lateinit var tvEqualizerStatus: TextView
    private lateinit var btnChangeEqualizer: Button
    private lateinit var tvDialogueBoostStatus: TextView
    private lateinit var btnToggleDialogueBoost: Button
    private lateinit var tvDigitalPassthroughStatus: TextView
    private lateinit var btnTogglePassthrough: Button
    private lateinit var tvAudioOutputStatus: TextView
    private lateinit var btnChangeAudioOutput: Button
    private lateinit var tvHeadsetPauseStatus: TextView
    private lateinit var btnToggleHeadsetPause: Button
    private lateinit var tvTimeStretchStatus: TextView
    private lateinit var btnToggleTimeStretch: Button

    // 3. Subtitle Settings Views
    private lateinit var btnToggleSubAutoload: Button
    private lateinit var tvSubSizeStatus: TextView
    private lateinit var btnChangeSubSize: Button
    private lateinit var tvSubColorStatus: TextView
    private lateinit var btnChangeSubColor: Button
    private lateinit var tvSubBackgroundStatus: TextView
    private lateinit var btnChangeSubBackground: Button
    private lateinit var tvSubStyleStatus: TextView
    private lateinit var btnToggleSubStyle: Button
    private lateinit var tvSubEncodingStatus: TextView
    private lateinit var btnChangeSubEncoding: Button

    // 4. Gestures Settings Views
    private lateinit var tvGestureVolumeStatus: TextView
    private lateinit var btnToggleGestureVolume: Button
    private lateinit var tvGestureBrightnessStatus: TextView
    private lateinit var btnToggleGestureBrightness: Button
    private lateinit var tvGestureSeekStatus: TextView
    private lateinit var btnToggleGestureSeek: Button
    private lateinit var tvFastSeekStatus: TextView
    private lateinit var btnToggleFastSeek: Button

    // 5. Interface Settings Views
    private lateinit var tvAppThemeStatus: TextView
    private lateinit var btnChangeAppTheme: Button

    // 6. Advanced Settings Views
    private lateinit var btnClearCache: Button
    private lateinit var btnClearResume: Button
    private lateinit var btnResetSettings: Button
    private lateinit var tvCacheSizeStatus: TextView

    private var allVideos = listOf<MediaItem>()
    private var allAudio = listOf<MediaItem>()
    private var videoAdapter: MediaAdapter? = null
    private var audioAdapter: MediaAdapter? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val title = PlayerHolder.resolveMediaTitle(this, it, null)
            val type = contentResolver.getType(it) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(it, title, isVideo, null)
        }
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        loadMediaFiles()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        PlayerHolder.loadPreferences(this)
        if (PlayerHolder.isMonochrome()) {
            setTheme(R.style.Theme_Multimedia_Monochrome)
        } else {
            setTheme(R.style.Theme_Multimedia)
        }
        super.onCreate(savedInstanceState)
        applyHighRefreshRate()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        setContentView(R.layout.activity_main)

        onBackPressedDispatcher.addCallback(this) {
            if (tabYouTube.visibility == View.VISIBLE) {
                if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                    collapseYouTubePlayer()
                } else if (cardYtMiniPlayer.visibility == View.VISIBLE) {
                    YouTubeExoPlayerManager.pause()
                    cardYtMiniPlayer.visibility = View.GONE
                    currentPlayingYtVideo = null
                    isYtVideoPlaying = false
                } else if (layoutYtSearchBar.visibility == View.VISIBLE) {
                    layoutYtSearchBar.visibility = View.GONE
                    loadYouTubeFeed(currentYtCategory)
                } else {
                    exitYouTubeToLocal()
                }
            } else if (isFolderViewActive && currentSelectedFolder != null) {
                closeFolderDetail()
            } else {
                finish()
            }
        }

        InnertubeExtractor.prefetchPlayerCipherAsync()
        initViews()
        setupBottomNav()
        setupSearch()
        setupVideoSettings()
        setupAudioSuiteSettings()
        setupSubtitleSettings()
        setupGestureSettings()
        setupInterfaceAndAdvancedSettings()
        applyThemeUI()
        checkAndRequestPermissions()

        val openFullPlayer = {
            val uri = PlayerHolder.currentUri
            if (uri != null) {
                openPlayer(uri, PlayerHolder.currentTitle, isVideo = !PlayerHolder.isAudioOnly, path = PlayerHolder.currentPath)
            }
        }
        cardNotchPlayer.setOnClickListener { openFullPlayer() }
        btnNotchOpen.setOnClickListener { openFullPlayer() }

        btnNotchPlayPause.setOnClickListener {
            PlayerHolder.mediaPlayer?.let { player ->
                if (player.isPlaying) {
                    player.pause()
                    btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_play)
                    MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = false)
                } else {
                    player.play()
                    btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_pause)
                    MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = true)
                }
            }
        }

        btnNotchPrev.setOnClickListener {
            PlayerHolder.playPrevious(this)
            updateNotchPlayerUI()
            audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
        }

        btnNotchNext.setOnClickListener {
            PlayerHolder.playNext(this)
            updateNotchPlayerUI()
            audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
        }

        btnNotchRepeat.setOnClickListener {
            val mode = PlayerHolder.toggleRepeatMode()
            updateNotchRepeatUI(mode)
        }

        btnNotchClose.setOnClickListener {
            PlayerHolder.release()
            MediaPlaybackService.stop(this)
            cardNotchPlayer.visibility = View.GONE
            audioAdapter?.setPlayingUri(null)
        }

        sbNotch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    tvNotchCurrent.text = formatTime(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                sb?.let {
                    PlayerHolder.mediaPlayer?.time = it.progress.toLong()
                }
            }
        })

        intent?.data?.let { uri ->
            val title = PlayerHolder.resolveMediaTitle(this, uri, null)
            val type = intent?.type ?: contentResolver.getType(uri) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(uri, title, isVideo, null)
        }
    }

    private val notchProgressHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val notchProgressRunnable = object : Runnable {
        override fun run() {
            PlayerHolder.mediaPlayer?.let { player ->
                if (cardNotchPlayer.visibility == View.VISIBLE) {
                    val current = player.time
                    val duration = player.length
                    if (duration > 0) {
                        sbNotch.max = duration.toInt()
                        sbNotch.progress = current.toInt()
                        tvNotchCurrent.text = formatTime(current)
                        tvNotchTotal.text = formatTime(duration)
                    }
                    val isPlaying = player.isPlaying
                    btnNotchPlayPause.setImageResource(
                        if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                }
            }
            notchProgressHandler.postDelayed(this, 1000)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (::playerViewYt.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            }
        } catch (e: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        YouTubeExoPlayerManager.onPlaybackStateChanged = { isPlaying ->
            isYtVideoPlaying = isPlaying
            btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
        }
        YouTubeExoPlayerManager.onSponsorSkipped = { label ->
            Toast.makeText(this, "Skipped $label segment [SponsorBlock]", Toast.LENGTH_SHORT).show()
        }
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        }
        updateSettingsUI()
        updateNotchPlayerUI()
        audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
        notchProgressHandler.post(notchProgressRunnable)

        PlayerHolder.onTrackChangedListener = { item ->
            runOnUiThread {
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(item.uri)
            }
        }
        PlayerHolder.onPlaybackStateChangedListener = { isPlaying ->
            runOnUiThread {
                btnNotchPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
                audioAdapter?.notifyDataSetChanged()
            }
        }

    }

    override fun onPause() {
        super.onPause()
        notchProgressHandler.removeCallbacks(notchProgressRunnable)
        PlayerHolder.onTrackChangedListener = null
        PlayerHolder.onPlaybackStateChangedListener = null
        // Media3 ExoPlayer handles background audio playback and PiP
    }

    private fun updateNotchRepeatUI(mode: Int) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        when (mode) {
            1 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat_one)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            2 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            else -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(secondaryColor)
            }
        }
    }

    private fun updateNotchPlayerUI() {
        val player = PlayerHolder.mediaPlayer
        if (player != null && PlayerHolder.currentUri != null) {
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = PlayerHolder.currentTitle
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = PlayerHolder.currentArtist
            val isPlaying = player.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = player.length
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                sbNotch.progress = player.time.toInt()
                tvNotchCurrent.text = formatTime(player.time)
                tvNotchTotal.text = formatTime(duration)
            }
        } else {
            cardNotchPlayer.visibility = View.GONE
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (hours > 0) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    private fun showSortDialog() {
        val sortOptions = arrayOf(
            getString(R.string.sort_name_asc),
            getString(R.string.sort_name_desc),
            getString(R.string.sort_date_newest),
            getString(R.string.sort_duration),
            getString(R.string.sort_size)
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle(R.string.sort_title)
            .setItems(sortOptions) { _, which ->
                when (which) {
                    0 -> {
                        allVideos = allVideos.sortedBy { it.title.lowercase() }
                        allAudio = allAudio.sortedBy { it.title.lowercase() }
                    }
                    1 -> {
                        allVideos = allVideos.sortedByDescending { it.title.lowercase() }
                        allAudio = allAudio.sortedByDescending { it.title.lowercase() }
                    }
                    2 -> {
                        allVideos = allVideos.sortedByDescending { it.id }
                        allAudio = allAudio.sortedByDescending { it.id }
                    }
                    3 -> {
                        allVideos = allVideos.sortedByDescending { it.durationMs }
                        allAudio = allAudio.sortedByDescending { it.durationMs }
                    }
                    4 -> {
                        allVideos = allVideos.sortedByDescending { it.sizeBytes }
                        allAudio = allAudio.sortedByDescending { it.sizeBytes }
                    }
                }
                videoAdapter?.updateList(allVideos)
                audioAdapter?.updateList(allAudio)
                updateFoldersData()
                Toast.makeText(this, "Sorted by ${sortOptions[which]}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        btnToolbarSearch = findViewById(R.id.btnToolbarSearch)
        btnToolbarSearch.setOnClickListener {
            val searchLayout = findViewById<View>(R.id.layoutSearch)
            searchLayout.visibility = if (searchLayout.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (searchLayout.visibility == View.VISIBLE) {
                etSearch.requestFocus()
            }
        }
        btnToolbarSort = findViewById(R.id.btnToolbarSort)
        btnToolbarSort.setOnClickListener { showSortDialog() }
        btnToolbarOpen = findViewById(R.id.btnToolbarOpen)
        fabPlay = findViewById(R.id.fabPlay)
        fabPlay.setOnClickListener {
            if (allVideos.isNotEmpty()) {
                val item = allVideos.first()
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } else if (allAudio.isNotEmpty()) {
                PlayerHolder.setPlaylistAndPlay(this, allAudio, 0)
                openPlayer(allAudio[0].uri, allAudio[0].title, isVideo = false, path = allAudio[0].filePath, artist = allAudio[0].artist)
            } else {
                Toast.makeText(this, "No media files found", Toast.LENGTH_SHORT).show()
            }
        }
        etSearch = findViewById(R.id.etSearch)
        tabVideo = findViewById(R.id.tabVideo)
        tabAudio = findViewById(R.id.tabAudio)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)
        tabYouTube = findViewById(R.id.tabYouTube)
        layoutYtMainFeed = findViewById(R.id.layoutYtMainFeed)
        btnYtExitToLocal = findViewById(R.id.btnYtExitToLocal)
        nsvYtFeed = findViewById(R.id.nsvYtFeed)
        rvYouTubeFeed = findViewById(R.id.rvYouTubeFeed)
        rvYouTubeShorts = findViewById(R.id.rvYouTubeShorts)
        rvYouTubeFeedSecondary = findViewById(R.id.rvYouTubeFeedSecondary)
        srlYouTubeFeed = findViewById(R.id.srlYouTubeFeed)
        pbYtFeedLoading = findViewById(R.id.pbYtFeedLoading)
        layoutYtEmpty = findViewById(R.id.layoutYtEmpty)
        btnYtRetry = findViewById(R.id.btnYtRetry)
        btnYtSearch = findViewById(R.id.btnYtSearch)
        btnYtAccount = findViewById(R.id.btnYtAccount)
        btnYtCast = findViewById(R.id.btnYtCast)
        btnYtNotifications = findViewById(R.id.btnYtNotifications)
        layoutYtSearchBar = findViewById(R.id.layoutYtSearchBar)
        etYtSearchQuery = findViewById(R.id.etYtSearchQuery)
        btnYtCloseSearch = findViewById(R.id.btnYtCloseSearch)
        chipYtAll = findViewById(R.id.chipYtAll)
        chipYtMusic = findViewById(R.id.chipYtMusic)
        chipYtGaming = findViewById(R.id.chipYtGaming)
        chipYtPodcasts = findViewById(R.id.chipYtPodcasts)
        chipYtLive = findViewById(R.id.chipYtLive)
        chipYtTrending = findViewById(R.id.chipYtTrending)
        chipYtNews = findViewById(R.id.chipYtNews)

        btnYtNavHome = findViewById(R.id.btnYtNavHome)
        btnYtNavShorts = findViewById(R.id.btnYtNavShorts)
        btnYtNavSubs = findViewById(R.id.btnYtNavSubs)
        btnYtNavLibrary = findViewById(R.id.btnYtNavLibrary)

        layoutYtPlayerDetail = findViewById(R.id.layoutYtPlayerDetail)
        playerViewYt = findViewById(R.id.playerViewYt)
        YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        YouTubeExoPlayerManager.onPlaybackStateChanged = { isPlaying ->
            isYtVideoPlaying = isPlaying
            btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
        }
        YouTubeExoPlayerManager.onSponsorSkipped = { label ->
            Toast.makeText(this, "Skipped $label segment [SponsorBlock]", Toast.LENGTH_SHORT).show()
        }
        btnYtCollapsePlayer = findViewById(R.id.btnYtCollapsePlayer)
        btnYtFullscreen = findViewById(R.id.btnYtFullscreen)
        tvYtDetailTitle = findViewById(R.id.tvYtDetailTitle)
        tvYtDetailSubtitle = findViewById(R.id.tvYtDetailSubtitle)
        ivYtDetailAvatar = findViewById(R.id.ivYtDetailAvatar)
        tvYtDetailChannel = findViewById(R.id.tvYtDetailChannel)
        btnYtSubscribe = findViewById(R.id.btnYtSubscribe)
        layoutYtLikePill = findViewById(R.id.layoutYtLikePill)
        tvYtDetailLikes = findViewById(R.id.tvYtDetailLikes)
        layoutYtSharePill = findViewById(R.id.layoutYtSharePill)
        layoutYtDownloadPill = findViewById(R.id.layoutYtDownloadPill)
        layoutYtSavePill = findViewById(R.id.layoutYtSavePill)
        layoutYtCommentsCard = findViewById(R.id.layoutYtCommentsCard)
        tvYtDetailCommentsCount = findViewById(R.id.tvYtDetailCommentsCount)
        rvYtRelatedVideos = findViewById(R.id.rvYtRelatedVideos)

        cardYtMiniPlayer = findViewById(R.id.cardYtMiniPlayer)
        ivYtMiniThumb = findViewById(R.id.ivYtMiniThumb)
        tvYtMiniTitle = findViewById(R.id.tvYtMiniTitle)
        tvYtMiniChannel = findViewById(R.id.tvYtMiniChannel)
        btnYtMiniPlayPause = findViewById(R.id.btnYtMiniPlayPause)
        btnYtMiniClose = findViewById(R.id.btnYtMiniClose)

        initNativeYouTubeEngine()

        btnViewAllVideos = findViewById(R.id.btnViewAllVideos)
        btnViewFolders = findViewById(R.id.btnViewFolders)
        rvVideos = findViewById(R.id.rvVideos)
        layoutFoldersContainer = findViewById(R.id.layoutFoldersContainer)
        rvFolders = findViewById(R.id.rvFolders)
        layoutFolderDetailHeader = findViewById(R.id.layoutFolderDetailHeader)
        btnFolderBack = findViewById(R.id.btnFolderBack)
        tvFolderHeaderTitle = findViewById(R.id.tvFolderHeaderTitle)
        tvFolderHeaderSubtitle = findViewById(R.id.tvFolderHeaderSubtitle)
        rvFolderVideos = findViewById(R.id.rvFolderVideos)
        layoutEmptyVideo = findViewById(R.id.layoutEmptyVideo)
        btnBrowseVideo = findViewById(R.id.btnBrowseVideo)

        rvFolders.layoutManager = LinearLayoutManager(this)
        rvFolderVideos.layoutManager = LinearLayoutManager(this)

        btnViewAllVideos.setOnClickListener {
            switchVideoViewMode(folders = false)
        }

        btnViewFolders.setOnClickListener {
            switchVideoViewMode(folders = true)
        }

        btnFolderBack.setOnClickListener {
            closeFolderDetail()
        }

        rvAudio = findViewById(R.id.rvAudio)
        layoutEmptyAudio = findViewById(R.id.layoutEmptyAudio)
        btnBrowseAudio = findViewById(R.id.btnBrowseAudio)

        // Video Settings
        tvHighRefreshRateStatus = findViewById(R.id.tvHighRefreshRateStatus)
        btnToggleHighRefreshRate = findViewById(R.id.btnToggleHighRefreshRate)
        tvDefaultOrientationStatus = findViewById(R.id.tvDefaultOrientationStatus)
        btnChangeOrientation = findViewById(R.id.btnChangeOrientation)

        // Notch Mini Player
        cardNotchPlayer = findViewById(R.id.cardNotchPlayer)
        tvNotchTitle = findViewById(R.id.tvNotchTitle)
        tvNotchArtist = findViewById(R.id.tvNotchArtist)
        btnNotchClose = findViewById(R.id.btnNotchClose)
        btnNotchRepeat = findViewById(R.id.btnNotchRepeat)
        btnNotchPrev = findViewById(R.id.btnNotchPrev)
        btnNotchPlayPause = findViewById(R.id.btnNotchPlayPause)
        btnNotchNext = findViewById(R.id.btnNotchNext)
        btnNotchOpen = findViewById(R.id.btnNotchOpen)
        tvNotchCurrent = findViewById(R.id.tvNotchCurrent)
        sbNotch = findViewById(R.id.sbNotch)
        tvNotchTotal = findViewById(R.id.tvNotchTotal)
        tvVideoColorStatus = findViewById(R.id.tvVideoColorStatus)
        btnChangeVideoColor = findViewById(R.id.btnChangeVideoColor)
        tvWideColorStatus = findViewById(R.id.tvWideColorStatus)
        btnToggleWideColor = findViewById(R.id.btnToggleWideColor)
        tvDeblockingStatus = findViewById(R.id.tvDeblockingStatus)
        btnToggleDeblocking = findViewById(R.id.btnToggleDeblocking)
        tvHwDecodeStatus = findViewById(R.id.tvHwDecodeStatus)
        btnChangeHw = findViewById(R.id.btnChangeHw)
        tvBgPipStatus = findViewById(R.id.tvBgPipStatus)
        btnChangeBgPip = findViewById(R.id.btnChangeBgPip)
        tvResumeModeStatus = findViewById(R.id.tvResumeModeStatus)
        btnChangeResumeMode = findViewById(R.id.btnChangeResumeMode)
        tvDoubleTapStatus = findViewById(R.id.tvDoubleTapStatus)
        btnChangeDoubleTap = findViewById(R.id.btnChangeDoubleTap)
        tvAspectRatioStatus = findViewById(R.id.tvAspectRatioStatus)
        btnChangeAspectRatio = findViewById(R.id.btnChangeAspectRatio)
        tvAudioBoostStatus = findViewById(R.id.tvAudioBoostStatus)
        btnToggleAudioBoost = findViewById(R.id.btnToggleAudioBoost)

        // Audio Suite Settings
        tvMasterProfileStatus = findViewById(R.id.tvMasterProfileStatus)
        btnChangeMasterProfile = findViewById(R.id.btnChangeMasterProfile)
        tvDolbySurroundStatus = findViewById(R.id.tvDolbySurroundStatus)
        btnChangeDolbySurround = findViewById(R.id.btnChangeDolbySurround)
        tvEqualizerStatus = findViewById(R.id.tvEqualizerStatus)
        btnChangeEqualizer = findViewById(R.id.btnChangeEqualizer)
        tvDialogueBoostStatus = findViewById(R.id.tvDialogueBoostStatus)
        btnToggleDialogueBoost = findViewById(R.id.btnToggleDialogueBoost)
        tvDigitalPassthroughStatus = findViewById(R.id.tvDigitalPassthroughStatus)
        btnTogglePassthrough = findViewById(R.id.btnTogglePassthrough)
        tvAudioOutputStatus = findViewById(R.id.tvAudioOutputStatus)
        btnChangeAudioOutput = findViewById(R.id.btnChangeAudioOutput)
        tvHeadsetPauseStatus = findViewById(R.id.tvHeadsetPauseStatus)
        btnToggleHeadsetPause = findViewById(R.id.btnToggleHeadsetPause)
        tvTimeStretchStatus = findViewById(R.id.tvTimeStretchStatus)
        btnToggleTimeStretch = findViewById(R.id.btnToggleTimeStretch)

        // Subtitle Settings
        btnToggleSubAutoload = findViewById(R.id.btnToggleSubAutoload)
        tvSubSizeStatus = findViewById(R.id.tvSubSizeStatus)
        btnChangeSubSize = findViewById(R.id.btnChangeSubSize)
        tvSubColorStatus = findViewById(R.id.tvSubColorStatus)
        btnChangeSubColor = findViewById(R.id.btnChangeSubColor)
        tvSubBackgroundStatus = findViewById(R.id.tvSubBackgroundStatus)
        btnChangeSubBackground = findViewById(R.id.btnChangeSubBackground)
        tvSubStyleStatus = findViewById(R.id.tvSubStyleStatus)
        btnToggleSubStyle = findViewById(R.id.btnToggleSubStyle)
        tvSubEncodingStatus = findViewById(R.id.tvSubEncodingStatus)
        btnChangeSubEncoding = findViewById(R.id.btnChangeSubEncoding)

        // Gesture Settings
        tvGestureVolumeStatus = findViewById(R.id.tvGestureVolumeStatus)
        btnToggleGestureVolume = findViewById(R.id.btnToggleGestureVolume)
        tvGestureBrightnessStatus = findViewById(R.id.tvGestureBrightnessStatus)
        btnToggleGestureBrightness = findViewById(R.id.btnToggleGestureBrightness)
        tvGestureSeekStatus = findViewById(R.id.tvGestureSeekStatus)
        btnToggleGestureSeek = findViewById(R.id.btnToggleGestureSeek)
        tvFastSeekStatus = findViewById(R.id.tvFastSeekStatus)
        btnToggleFastSeek = findViewById(R.id.btnToggleFastSeek)

        // Interface Settings
        tvAppThemeStatus = findViewById(R.id.tvAppThemeStatus)
        btnChangeAppTheme = findViewById(R.id.btnChangeAppTheme)

        // Advanced Settings
        btnClearCache = findViewById(R.id.btnClearCache)
        btnClearResume = findViewById(R.id.btnClearResume)
        btnResetSettings = findViewById(R.id.btnResetSettings)
        tvCacheSizeStatus = findViewById(R.id.tvCacheSizeStatus)

        rvVideos.layoutManager = LinearLayoutManager(this)
        rvAudio.layoutManager = LinearLayoutManager(this)

        val openFileAction = {
            filePickerLauncher.launch(arrayOf("video/*", "audio/*"))
        }

        btnToolbarOpen.setOnClickListener { openFileAction() }
        btnBrowseVideo.setOnClickListener { openFileAction() }
        btnBrowseAudio.setOnClickListener { openFileAction() }

        // Dynamic App Version binding
        val vName = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "3.5" } catch (e: Exception) { "3.5" }
        findViewById<TextView>(R.id.badgeAppVersion)?.text = "v$vName"
        findViewById<TextView>(R.id.tvAppVersionCode)?.text = "Version $vName (Master Edition) • Developer: Rajesh Shah"
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterMedia(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterMedia(query: String) {
        val q = query.trim().lowercase()
        val filteredVideos = if (q.isEmpty()) allVideos else allVideos.filter { it.title.lowercase().contains(q) }
        val filteredAudio = if (q.isEmpty()) allAudio else allAudio.filter {
            it.title.lowercase().contains(q) || (it.artist?.lowercase()?.contains(q) == true)
        }

        videoAdapter?.updateList(filteredVideos)
        audioAdapter?.updateList(filteredAudio)

        if (isFolderViewActive) {
            val filteredFolders = if (q.isEmpty()) allFolders else allFolders.filter { folder ->
                folder.folderName.lowercase().contains(q) || folder.videos.any { it.title.lowercase().contains(q) }
            }
            folderAdapter?.updateFolders(filteredFolders)
        }

        if (!isFolderViewActive) {
            rvVideos.visibility = if (filteredVideos.isNotEmpty()) View.VISIBLE else View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = if (filteredVideos.isEmpty()) View.VISIBLE else View.GONE
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            layoutEmptyVideo.visibility = if (allFolders.isEmpty()) View.VISIBLE else View.GONE
        }

        rvAudio.visibility = if (filteredAudio.isNotEmpty()) View.VISIBLE else View.GONE
        layoutEmptyAudio.visibility = if (filteredAudio.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_video -> {
                    showTab(video = true, audio = false, youtube = false, settings = false)
                    switchVideoViewMode(folders = false)
                    true
                }
                R.id.nav_audio -> {
                    showTab(video = false, audio = true, youtube = false, settings = false)
                    true
                }
                R.id.nav_youtube -> {
                    showTab(video = false, audio = false, youtube = true, settings = false)
                    true
                }
                R.id.nav_more -> {
                    showTab(video = false, audio = false, youtube = false, settings = true)
                    true
                }
                else -> false
            }
        }
    }

        private fun showTab(video: Boolean, audio: Boolean, youtube: Boolean, settings: Boolean) {
        tabVideo.visibility = if (video) View.VISIBLE else View.GONE
        tabAudio.visibility = if (audio) View.VISIBLE else View.GONE
        tabYouTube.visibility = if (youtube) View.VISIBLE else View.GONE
        tabSettings.visibility = if (settings) View.VISIBLE else View.GONE

        if (youtube) {
            toolbar.visibility = View.GONE
            findViewById<View>(R.id.topBarContainer)?.visibility = View.GONE
            bottomNav.visibility = View.GONE
            fabPlay.visibility = View.GONE
            window.statusBarColor = Color.parseColor("#0F0F0F")

            if (!isYtFeedLoaded) {
                loadYouTubeFeed(currentYtCategory)
            }
        } else {
            lastActiveTabId = when {
                audio -> R.id.nav_audio
                settings -> R.id.nav_more
                else -> R.id.nav_video
            }

            toolbar.visibility = View.VISIBLE
            findViewById<View>(R.id.topBarContainer)?.visibility = View.VISIBLE
            bottomNav.visibility = View.VISIBLE
            fabPlay.visibility = View.VISIBLE
            window.statusBarColor = Color.parseColor("#000000")

            applyThemeUI()
        }
    }

    private fun initNativeYouTubeEngine() {
        rvYouTubeFeed.layoutManager = LinearLayoutManager(this)
        rvYouTubeFeedSecondary.layoutManager = LinearLayoutManager(this)
        rvYouTubeShorts.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        youTubeFeedAdapter = YouTubeFeedAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        rvYouTubeFeed.adapter = youTubeFeedAdapter

        youTubeFeedSecondaryAdapter = YouTubeFeedAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        rvYouTubeFeedSecondary.adapter = youTubeFeedSecondaryAdapter

        youTubeShortsAdapter = YouTubeShortsAdapter(this, YouTubeFeedRepository.defaultShorts) { shortVideo ->
            playYouTubeVideoInApp(shortVideo)
        }
        rvYouTubeShorts.adapter = youTubeShortsAdapter

        srlYouTubeFeed.setColorSchemeColors(Color.parseColor("#FF0000"))
        srlYouTubeFeed.setProgressBackgroundColorSchemeColor(Color.parseColor("#1A1A1A"))
        srlYouTubeFeed.setOnRefreshListener {
            loadYouTubeFeed(currentYtCategory)
        }

        btnYtRetry.setOnClickListener {
            loadYouTubeFeed(currentYtCategory)
        }

        btnYtExitToLocal.setOnClickListener {
            exitYouTubeToLocal()
        }

        btnYtNavHome.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            nsvYtFeed.smoothScrollTo(0, 0)
        }

        btnYtNavShorts.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            if (YouTubeFeedRepository.defaultShorts.isNotEmpty()) {
                playYouTubeVideoInApp(YouTubeFeedRepository.defaultShorts[0])
            }
        }

        btnYtNavSubs.setOnClickListener {
            Toast.makeText(this, "Subscriptions updated", Toast.LENGTH_SHORT).show()
        }

        btnYtNavLibrary.setOnClickListener {
            exitYouTubeToLocal()
        }

        btnYtCast.setOnClickListener {
            Toast.makeText(this, "Searching for Cast devices on local Wi-Fi...", Toast.LENGTH_SHORT).show()
        }

        btnYtNotifications.setOnClickListener {
            Toast.makeText(this, "No new notifications", Toast.LENGTH_SHORT).show()
        }

        btnYtAccount.setOnClickListener {
            MicroGAuthManager.showAccountDialog(this) {
                updateMicroGAccountState()
                loadYouTubeFeed(currentYtCategory)
            }
        }

        btnYtSearch.setOnClickListener {
            if (layoutYtSearchBar.visibility == View.VISIBLE) {
                layoutYtSearchBar.visibility = View.GONE
            } else {
                layoutYtSearchBar.visibility = View.VISIBLE
                etYtSearchQuery.requestFocus()
            }
        }

        btnYtCloseSearch.setOnClickListener {
            layoutYtSearchBar.visibility = View.GONE
            etYtSearchQuery.text?.clear()
            loadYouTubeFeed(currentYtCategory)
        }

        etYtSearchQuery.setOnEditorActionListener { _, _, _ ->
            val query = etYtSearchQuery.text.toString().trim()
            if (query.isNotEmpty()) {
                performYouTubeSearch(query)
            }
            true
        }

        val chips = listOf(
            chipYtAll to "All",
            chipYtMusic to "Music",
            chipYtGaming to "Gaming",
            chipYtPodcasts to "Podcasts",
            chipYtLive to "Live",
            chipYtTrending to "Trending",
            chipYtNews to "News"
        )

        for ((chipView, cat) in chips) {
            chipView.setOnClickListener {
                for ((c, _) in chips) {
                    c.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                    c.setTextColor(Color.parseColor("#FFFFFF"))
                    c.setTypeface(null, android.graphics.Typeface.NORMAL)
                }
                chipView.setBackgroundResource(R.drawable.bg_youtube_chip_active)
                chipView.setTextColor(Color.parseColor("#000000"))
                chipView.setTypeface(null, android.graphics.Typeface.BOLD)

                currentYtCategory = cat
                loadYouTubeFeed(cat)
            }
        }

        setupYouTubeDetailPlayer()
        setupYouTubeMiniPlayer()
        updateMicroGAccountState()
    }

    private fun setupYouTubeDetailPlayer() {
        rvYtRelatedVideos.layoutManager = LinearLayoutManager(this)
        rvYtRelatedVideos.adapter = youTubeFeedSecondaryAdapter

        btnYtCollapsePlayer.setOnClickListener {
            collapseYouTubePlayer()
        }

        btnYtFullscreen.setOnClickListener {
            val v = currentPlayingYtVideo ?: return@setOnClickListener
            val intent = Intent(this, PlayerActivity::class.java).apply {
                putExtra("media_title", v.title)
                putExtra("media_artist", v.channelTitle)
                putExtra("media_path", YouTubeExoPlayerManager.currentStreamUrl ?: "")
                putExtra("is_video", true)
                putExtra("is_youtube", true)
                putExtra("youtube_video_id", v.id)
                putExtra("youtube_thumbnail", v.thumbnailUrl)
            }
            startActivity(intent)
        }

        btnYtSubscribe.setOnClickListener {
            if (btnYtSubscribe.text == "Subscribe") {
                btnYtSubscribe.text = "Subscribed"
                btnYtSubscribe.setBackgroundColor(Color.parseColor("#272727"))
                btnYtSubscribe.setTextColor(Color.WHITE)
                Toast.makeText(this, "Subscribed to channel", Toast.LENGTH_SHORT).show()
            } else {
                btnYtSubscribe.text = "Subscribe"
                btnYtSubscribe.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
                btnYtSubscribe.setTextColor(Color.BLACK)
                Toast.makeText(this, "Unsubscribed", Toast.LENGTH_SHORT).show()
            }
        }

        layoutYtLikePill.setOnClickListener {
            Toast.makeText(this, "Added to Liked Videos", Toast.LENGTH_SHORT).show()
        }

        layoutYtSharePill.setOnClickListener {
            val v = currentPlayingYtVideo ?: return@setOnClickListener
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, v.title)
                putExtra(Intent.EXTRA_TEXT, "Watch '${v.title}' on YouTube: https://youtu.be/${v.id}")
            }
            startActivity(Intent.createChooser(intent, "Share Video"))
        }

        layoutYtDownloadPill.setOnClickListener {
            currentPlayingYtVideo?.let { v ->
                YouTubeDownloaderHelper.downloadVideo(this, v)
            }
        }

        layoutYtSavePill.setOnClickListener {
            currentPlayingYtVideo?.let { v ->
                val saved = YouTubeHistoryManager.toggleBookmark(this, v)
                Toast.makeText(this, if (saved) "Saved to Library" else "Removed from Library", Toast.LENGTH_SHORT).show()
            }
        }

        layoutYtCommentsCard.setOnClickListener {
            Toast.makeText(this, "Comments: 234 community replies", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupYouTubeMiniPlayer() {
        cardYtMiniPlayer.setOnClickListener {
            cardYtMiniPlayer.visibility = View.GONE
            layoutYtPlayerDetail.visibility = View.VISIBLE
            YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        }

        btnYtMiniClose.setOnClickListener {
            YouTubeExoPlayerManager.pause()
            cardYtMiniPlayer.visibility = View.GONE
            currentPlayingYtVideo = null
            isYtVideoPlaying = false
        }

        btnYtMiniPlayPause.setOnClickListener {
            YouTubeExoPlayerManager.togglePlayPause()
        }
    }

    private fun collapseYouTubePlayer() {
        if (layoutYtPlayerDetail.visibility == View.VISIBLE && currentPlayingYtVideo != null) {
            layoutYtPlayerDetail.visibility = View.GONE
            cardYtMiniPlayer.visibility = View.VISIBLE
            val video = currentPlayingYtVideo!!
            tvYtMiniTitle.text = video.title
            tvYtMiniChannel.text = video.channelTitle
            ImageLoaderHelper.loadImage(video.thumbnailUrl, ivYtMiniThumb, R.drawable.ic_video)
            btnYtMiniPlayPause.setImageResource(if (YouTubeExoPlayerManager.exoPlayer?.isPlaying == true) R.drawable.ic_pause_player else R.drawable.ic_play_player)
        }
    }

    private fun exitYouTubeToLocal() {
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            layoutYtPlayerDetail.visibility = View.GONE
        }
        if (cardYtMiniPlayer.visibility == View.VISIBLE) {
            cardYtMiniPlayer.visibility = View.GONE
        }
        YouTubeExoPlayerManager.pause()
        currentPlayingYtVideo = null
        isYtVideoPlaying = false
        showTab(video = true, audio = false, youtube = false, settings = false)
        bottomNav.selectedItemId = R.id.nav_video
    }

    private fun playYouTubeVideoInApp(video: YouTubeVideo) {
        currentPlayingYtVideo = video
        isYtVideoPlaying = true
        YouTubeHistoryManager.addWatchHistory(this, video)

        // Populate video details using verified declared properties
        tvYtDetailTitle.text = video.title
        tvYtDetailSubtitle.text = "${video.views} • ${video.uploadDate}"
        tvYtDetailChannel.text = video.channelTitle
        ImageLoaderHelper.loadImage(video.channelAvatarUrl, ivYtDetailAvatar, R.drawable.ic_account_circle)
        tvYtDetailLikes.text = video.likes
        tvYtDetailCommentsCount.text = video.commentsCount

        // Populate related recommendations in portrait feed below player
        val related = YouTubeFeedRepository.defaultFeed.filter { it.id != video.id }
        youTubeFeedSecondaryAdapter.updateItems(related)

        cardYtMiniPlayer.visibility = View.GONE
        layoutYtPlayerDetail.visibility = View.VISIBLE
        YouTubeExoPlayerManager.attachPlayerView(playerViewYt)

        // Resolve streams via Innertube with adaptive DASH & HLS for Media3 ExoPlayer
        YouTubeFeedRepository.resolveStreamFormats(video.id) { bestUrl, _, dashUrl, hlsUrl ->
            val targetStream = dashUrl ?: (hlsUrl ?: bestUrl)
            YouTubeExoPlayerManager.playVideo(
                context = this,
                video = video,
                streamUrl = targetStream,
                isDash = dashUrl != null,
                isHls = hlsUrl != null
            )
        }
    }

    private fun updateMicroGAccountState() {
        if (MicroGAuthManager.isLoggedIn(this)) {
            btnYtAccount.setColorFilter(Color.parseColor("#4CAF50"))
        } else {
            btnYtAccount.clearColorFilter()
        }
    }

    private fun loadYouTubeFeed(category: String) {
        pbYtFeedLoading.visibility = View.VISIBLE
        layoutYtEmpty.visibility = View.GONE
        YouTubeFeedRepository.getFeed(category) { videos ->
            pbYtFeedLoading.visibility = View.GONE
            srlYouTubeFeed.isRefreshing = false
            isYtFeedLoaded = true

            if (videos.isEmpty()) {
                layoutYtEmpty.visibility = View.VISIBLE
            } else {
                layoutYtEmpty.visibility = View.GONE
                val topFeed = if (videos.size > 2) videos.subList(0, 2) else videos
                val secondaryFeed = if (videos.size > 2) videos.subList(2, videos.size) else emptyList()
                youTubeFeedAdapter.updateItems(topFeed)
                youTubeFeedSecondaryAdapter.updateItems(secondaryFeed)
            }
        }
    }

    private fun performYouTubeSearch(query: String) {
        pbYtFeedLoading.visibility = View.VISIBLE
        layoutYtEmpty.visibility = View.GONE
        YouTubeFeedRepository.searchVideos(query) { videos ->
            pbYtFeedLoading.visibility = View.GONE
            if (videos.isEmpty()) {
                layoutYtEmpty.visibility = View.VISIBLE
            } else {
                layoutYtEmpty.visibility = View.GONE
                youTubeFeedAdapter.updateItems(videos)
                youTubeFeedSecondaryAdapter.updateItems(emptyList())
            }
        }
    }

    // --- 1. Video Settings Handlers ---
    private fun setupVideoSettings() {
        btnToggleHighRefreshRate.setOnClickListener {
            PlayerHolder.isHighRefreshRateEnabled = !PlayerHolder.isHighRefreshRateEnabled
            PlayerHolder.savePreferences(this)
            applyHighRefreshRate()
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHighRefreshRate).setOnClickListener {
            btnToggleHighRefreshRate.performClick()
        }

        val orientationOptions = arrayOf("Auto Sensor (Free Rotation)", "Direct Landscape (Recommended)", "Portrait (Vertical)")
        val openOrientationDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Default Video Orientation")
                .setSingleChoiceItems(orientationOptions, PlayerHolder.defaultOrientation) { dialog, which ->
                    PlayerHolder.defaultOrientation = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeOrientation.setOnClickListener { openOrientationDialog() }
        findViewById<View>(R.id.rowDefaultOrientation).setOnClickListener { openOrientationDialog() }
        val openVideoColorDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Picture Mode & Color Boost")
                .setSingleChoiceItems(PlayerHolder.videoProfileNames, PlayerHolder.videoColorProfile.coerceIn(0, 4)) { dialog, which ->
                    PlayerHolder.applyVideoColorProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeVideoColor.setOnClickListener { openVideoColorDialog() }
        findViewById<View>(R.id.rowVideoColor).setOnClickListener { openVideoColorDialog() }

        btnToggleWideColor.setOnClickListener {
            PlayerHolder.isWideColorGamutEnabled = !PlayerHolder.isWideColorGamutEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowWideColor).setOnClickListener {
            btnToggleWideColor.performClick()
        }

        btnToggleDeblocking.setOnClickListener {
            PlayerHolder.isDeblockingFilterEnabled = !PlayerHolder.isDeblockingFilterEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDeblocking).setOnClickListener {
            btnToggleDeblocking.performClick()
        }
        val hwOptions = arrayOf("Disabled (Software)", "Automatic (Recommended)", "Decoding Only", "Full Acceleration")
        val openHwDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_hw_decoding)
                .setSingleChoiceItems(hwOptions, PlayerHolder.hwAccelerationMode) { dialog, which ->
                    PlayerHolder.hwAccelerationMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeHw.setOnClickListener { openHwDialog() }
        findViewById<View>(R.id.rowHwDecode).setOnClickListener { openHwDialog() }

        val bgPipOptions = arrayOf("Stop Playback", "Play in Background", "Picture-in-Picture (PiP)")
        val openBgPipDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_bg_pip)
                .setSingleChoiceItems(bgPipOptions, PlayerHolder.backgroundPipMode) { dialog, which ->
                    PlayerHolder.backgroundPipMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeBgPip.setOnClickListener { openBgPipDialog() }
        findViewById<View>(R.id.rowBgPip).setOnClickListener { openBgPipDialog() }

        val resumeOptions = arrayOf("Never (Always start from beginning)", "Ask confirmation on open", "Always resume automatically")
        val openResumeDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_resume)
                .setSingleChoiceItems(resumeOptions, PlayerHolder.resumeMode) { dialog, which ->
                    PlayerHolder.resumeMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeResumeMode.setOnClickListener { openResumeDialog() }
        findViewById<View>(R.id.rowResumeMode).setOnClickListener { openResumeDialog() }

        val seekOptions = arrayOf("5 seconds", "10 seconds", "20 seconds", "30 seconds")
        val seekValues = arrayOf(5, 10, 20, 30)
        val openSeekDialog = {
            val currentIdx = seekValues.indexOf(PlayerHolder.doubleTapSeekSeconds).coerceAtLeast(1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_double_tap)
                .setSingleChoiceItems(seekOptions, currentIdx) { dialog, which ->
                    PlayerHolder.doubleTapSeekSeconds = seekValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDoubleTap.setOnClickListener { openSeekDialog() }
        findViewById<View>(R.id.rowDoubleTap).setOnClickListener { openSeekDialog() }

        val aspectOptions = arrayOf("Best Fit (Default)", "Fit Screen", "Fill Screen", "16:9 Aspect Ratio", "4:3 Aspect Ratio")
        val openAspectDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_aspect_ratio)
                .setSingleChoiceItems(aspectOptions, PlayerHolder.defaultAspectRatio) { dialog, which ->
                    PlayerHolder.defaultAspectRatio = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAspectRatio.setOnClickListener { openAspectDialog() }
        findViewById<View>(R.id.rowAspectRatio).setOnClickListener { openAspectDialog() }

        btnToggleAudioBoost.setOnClickListener {
            PlayerHolder.isAudioBoostEnabled = !PlayerHolder.isAudioBoostEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowAudioBoost).setOnClickListener {
            btnToggleAudioBoost.performClick()
        }
    }

    // --- 2. Integrated Dolby, Spatial & Equalizer Audio Suite Handlers ---
    private fun setupAudioSuiteSettings() {
        // Master Profile Dialog
        val openMasterProfileDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Select Audio Profile")
                .setSingleChoiceItems(PlayerHolder.masterProfileNames, PlayerHolder.masterAudioProfile) { dialog, which ->
                    PlayerHolder.applyMasterProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeMasterProfile.setOnClickListener { openMasterProfileDialog() }
        findViewById<View>(R.id.rowMasterProfile).setOnClickListener { openMasterProfileDialog() }

        // Dolby & Spatial Virtualizer Mode
        val modes = arrayOf("Standard Stereo (Downmix)", "Dolby 3D Headphone (Binaural HRTF)", "Dolby ProLogic Surround (Matrix)", "Cinema 3D Soundstage (Wide Room)")
        val openDolbyDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_dolby_surround)
                .setSingleChoiceItems(modes, PlayerHolder.dolbySpatialMode) { dialog, which ->
                    PlayerHolder.dolbySpatialMode = which
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDolbySurround.setOnClickListener { openDolbyDialog() }
        findViewById<View>(R.id.rowDolbySurround).setOnClickListener { openDolbyDialog() }

        // 10-Band Equalizer Presets
        val openEqDialog = {
            val presets = PlayerHolder.equalizerPresets
            val currentIdx = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_equalizer)
                .setSingleChoiceItems(presets, currentIdx) { dialog, which ->
                    PlayerHolder.currentEqualizerPreset = which - 1
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeEqualizer.setOnClickListener { openEqDialog() }
        findViewById<View>(R.id.rowEqualizer).setOnClickListener { openEqDialog() }

        // Dialogue Boost (Night Mode) Toggle
        btnToggleDialogueBoost.setOnClickListener {
            PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
            PlayerHolder.masterAudioProfile = 4 // Custom
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDialogueBoost).setOnClickListener {
            btnToggleDialogueBoost.performClick()
        }

        // Digital Passthrough Toggle
        btnTogglePassthrough.setOnClickListener {
            PlayerHolder.isDolbyPassthroughEnabled = !PlayerHolder.isDolbyPassthroughEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDigitalPassthrough).setOnClickListener {
            btnTogglePassthrough.performClick()
        }

        // Audio Output Engine Dialog
        val engines = arrayOf("AudioTrack (Standard)", "OpenSL ES (Low Latency)", "AAudio (Modern NDK)")
        val openEngineDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_audio_output)
                .setSingleChoiceItems(engines, PlayerHolder.audioOutputEngine) { dialog, which ->
                    PlayerHolder.audioOutputEngine = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAudioOutput.setOnClickListener { openEngineDialog() }
        findViewById<View>(R.id.rowAudioOutput).setOnClickListener { openEngineDialog() }

        btnToggleHeadsetPause.setOnClickListener {
            PlayerHolder.isHeadsetPauseEnabled = !PlayerHolder.isHeadsetPauseEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHeadsetPause).setOnClickListener {
            btnToggleHeadsetPause.performClick()
        }

        btnToggleTimeStretch.setOnClickListener {
            PlayerHolder.isTimeStretchingEnabled = !PlayerHolder.isTimeStretchingEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowTimeStretching).setOnClickListener {
            btnToggleTimeStretch.performClick()
        }
    }

    // --- 3. Subtitle Settings Handlers ---
    
    private fun showSubtitleSettings() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_subtitle_settings, null)
        dialog.setContentView(view)

        val isMono = PlayerHolder.isMonochrome()
        val accentColor = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        val accentTintList = ColorStateList.valueOf(accentColor)

        view.findViewById<TextView>(R.id.tvSubHeaderTitle)?.setTextColor(accentColor)
        view.findViewById<View>(R.id.btnSubBack).setOnClickListener { dialog.dismiss() }
        view.findViewById<View>(R.id.btnSubSearch)?.setOnClickListener { dialog.dismiss() }

        val subHeaders = listOf(
            R.id.tvHeaderFontStyle,
            R.id.tvHeaderBg,
            R.id.tvHeaderShadow,
            R.id.tvHeaderOutline,
            R.id.tvHeaderPos
        )
        for (hId in subHeaders) {
            view.findViewById<TextView>(hId)?.setTextColor(accentColor)
        }

        val checkBoxes = listOf(
            R.id.cbSubAutoLoad,
            R.id.cbSubBold,
            R.id.cbSubBgToggle,
            R.id.cbSubShadowToggle,
            R.id.cbSubOutlineToggle
        )
        for (cbId in checkBoxes) {
            view.findViewById<CheckBox>(cbId)?.buttonTintList = accentTintList
        }

        val seekBars = listOf(
            R.id.sbSubFontOpacity,
            R.id.sbSubBgOpacity,
            R.id.sbSubShadowOpacity,
            R.id.sbSubOutlineOpacity
        )
        for (sbId in seekBars) {
            view.findViewById<SeekBar>(sbId)?.apply {
                progressTintList = accentTintList
                thumbTintList = accentTintList
            }
        }

        // Presets
        view.findViewById<View>(R.id.rowSubPresets).setOnClickListener {
            val presets = arrayOf("Default (White + Shadow)", "Cinema (Yellow + Outline)", "High Contrast (Black Box)", "Clean Minimal")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles presets")
                .setItems(presets) { _, which ->
                    when (which) {
                        0 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBold = false
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = true
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        1 -> {
                            PlayerHolder.subFontColor = "16772155"
                            PlayerHolder.isSubBold = true
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        2 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = true
                            PlayerHolder.subBackgroundOpacity = 75
                        }
                        3 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = false
                            PlayerHolder.isSubOutlineEnabled = false
                        }
                    }
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                    showSubtitleSettings()
                }
                .show()
        }

        // Auto load subtitles
        val cbAutoLoad = view.findViewById<CheckBox>(R.id.cbSubAutoLoad)
        cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
        view.findViewById<View>(R.id.rowSubAutoLoad).setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }

        // Subtitle text encoding
        val tvEncoding = view.findViewById<TextView>(R.id.tvSubEncodingSub)
        tvEncoding.text = "Default (" + PlayerHolder.subEncoding + ")"
        view.findViewById<View>(R.id.rowSubEncoding).setOnClickListener {
            val encodings = arrayOf("UTF-8", "Windows-1252", "ISO-8859-1", "GBK", "Big5")
            val cur = encodings.indexOf(PlayerHolder.subEncoding).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitle text encoding")
                .setSingleChoiceItems(encodings, cur) { d, w ->
                    PlayerHolder.subEncoding = encodings[w]
                    tvEncoding.text = "Default (" + encodings[w] + ")"
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Preferred subtitle language
        val tvLang = view.findViewById<TextView>(R.id.tvSubLanguageSub)
        tvLang.text = PlayerHolder.subPreferredLanguage
        view.findViewById<View>(R.id.rowSubLanguage).setOnClickListener {
            val langs = arrayOf("No language preference", "English", "Hindi", "Spanish", "French", "German")
            val cur = langs.indexOf(PlayerHolder.subPreferredLanguage).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Preferred subtitle language")
                .setSingleChoiceItems(langs, cur) { d, w ->
                    PlayerHolder.subPreferredLanguage = langs[w]
                    tvLang.text = langs[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        // Subtitle Size
        val tvSize = view.findViewById<TextView>(R.id.tvSubSizeSub)
        val sizeLabel = when (PlayerHolder.subFontSize) {
            "14" -> "Small"
            "22" -> "Large"
            "26" -> "Extra large"
            else -> "Normal"
        }
        tvSize.text = sizeLabel
        view.findViewById<View>(R.id.rowSubSize).setOnClickListener {
            val sizes = arrayOf("Small", "Normal", "Large", "Extra large")
            val sizeVals = arrayOf("14", "18", "22", "26")
            val cur = sizeVals.indexOf(PlayerHolder.subFontSize).let { if (it < 0) 1 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles Size")
                .setSingleChoiceItems(sizes, cur) { d, w ->
                    PlayerHolder.subFontSize = sizeVals[w]
                    tvSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Bold subtitles
        val cbBold = view.findViewById<CheckBox>(R.id.cbSubBold)
        cbBold.isChecked = PlayerHolder.isSubBold
        view.findViewById<View>(R.id.rowSubBold).setOnClickListener {
            PlayerHolder.isSubBold = !PlayerHolder.isSubBold
            cbBold.isChecked = PlayerHolder.isSubBold
            PlayerHolder.savePreferences(this)
        }

        // Font Colour Badge
        val cardFontBadge = view.findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardSubFontColorBadge)
        val fontBadgeColor = try {
            val cL = PlayerHolder.subFontColor.toLongOrNull() ?: 16777215L
            if (cL <= 16777215L) (0xFF000000 or cL).toInt() else cL.toInt()
        } catch (e: Exception) { Color.WHITE }
        cardFontBadge.setCardBackgroundColor(fontBadgeColor)

        view.findViewById<View>(R.id.rowSubFontColor).setOnClickListener {
            val colors = arrayOf("White", "Yellow", "Cyan", "Green", "Amber")
            val colorVals = arrayOf("16777215", "16772155", "58879", "6942894", "16766720")
            val colorInts = arrayOf(Color.WHITE, Color.parseColor("#FFEB3B"), Color.parseColor("#00E5FF"), Color.parseColor("#69F0AE"), Color.parseColor("#FFD700"))
            val cur = colorVals.indexOf(PlayerHolder.subFontColor).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Colour")
                .setSingleChoiceItems(colors, cur) { d, w ->
                    PlayerHolder.subFontColor = colorVals[w]
                    cardFontBadge.setCardBackgroundColor(colorInts[w])
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Font Opacity
        val sbFontOpacity = view.findViewById<SeekBar>(R.id.sbSubFontOpacity)
        sbFontOpacity.progress = PlayerHolder.subFontOpacity
        sbFontOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subFontOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Background Checkbox & Slider
        val cbBg = view.findViewById<CheckBox>(R.id.cbSubBgToggle)
        cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
        view.findViewById<View>(R.id.rowSubBgToggle).setOnClickListener {
            PlayerHolder.isSubBackgroundEnabled = !PlayerHolder.isSubBackgroundEnabled
            cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
            PlayerHolder.savePreferences(this)
        }
        val sbBgOpacity = view.findViewById<SeekBar>(R.id.sbSubBgOpacity)
        sbBgOpacity.progress = PlayerHolder.subBackgroundOpacity
        sbBgOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subBackgroundOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Shadow Checkbox & Slider
        val cbShadow = view.findViewById<CheckBox>(R.id.cbSubShadowToggle)
        cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
        view.findViewById<View>(R.id.rowSubShadowToggle).setOnClickListener {
            PlayerHolder.isSubShadowEnabled = !PlayerHolder.isSubShadowEnabled
            cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
            PlayerHolder.savePreferences(this)
        }
        val sbShadowOpacity = view.findViewById<SeekBar>(R.id.sbSubShadowOpacity)
        sbShadowOpacity.progress = PlayerHolder.subShadowOpacity
        sbShadowOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subShadowOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Outline Checkbox & Slider
        val cbOutline = view.findViewById<CheckBox>(R.id.cbSubOutlineToggle)
        cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
        view.findViewById<View>(R.id.rowSubOutlineToggle).setOnClickListener {
            PlayerHolder.isSubOutlineEnabled = !PlayerHolder.isSubOutlineEnabled
            cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
            PlayerHolder.savePreferences(this)
        }
        val tvOutlineSize = view.findViewById<TextView>(R.id.tvSubOutlineSizeSub)
        tvOutlineSize.text = when (PlayerHolder.subOutlineSize) { 0 -> "Thin"; 2 -> "Thick"; else -> "Normal" }
        view.findViewById<View>(R.id.rowSubOutlineSize).setOnClickListener {
            val sizes = arrayOf("Thin", "Normal", "Thick")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Outline Size")
                .setSingleChoiceItems(sizes, PlayerHolder.subOutlineSize.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subOutlineSize = w
                    tvOutlineSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }
        val sbOutlineOpacity = view.findViewById<SeekBar>(R.id.sbSubOutlineOpacity)
        sbOutlineOpacity.progress = PlayerHolder.subOutlineOpacity
        sbOutlineOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subOutlineOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitle Screen Position & Elevation
        val tvPos = view.findViewById<TextView>(R.id.tvSubPositionSub)
        tvPos.text = when (PlayerHolder.subPosition) { 1 -> "Elevated (Above controls)"; 2 -> "Center Screen"; else -> "Standard Bottom (Default)" }
        view.findViewById<View>(R.id.rowSubPosition).setOnClickListener {
            val posNames = arrayOf("Standard Bottom (Default)", "Elevated (Above controls)", "Center Screen")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles position & elevation")
                .setSingleChoiceItems(posNames, PlayerHolder.subPosition.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subPosition = w
                    tvPos.text = posNames[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        dialog.show()
    }

    private fun setupSubtitleSettings() {
        findViewById<View>(R.id.rowSubtitles)?.setOnClickListener {
            showSubtitleSettings()
        }
        btnToggleSubAutoload.setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubAutoload).setOnClickListener {
            btnToggleSubAutoload.performClick()
        }

        val sizeLabels = arrayOf("Very Small (12sp)", "Small (14sp)", "Normal (18sp)", "Large (24sp)", "Huge (32sp)")
        val sizeValues = arrayOf("12", "14", "18", "24", "32")
        val openSizeDialog = {
            val currentIdx = sizeValues.indexOf(PlayerHolder.subFontSize).coerceAtLeast(2)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_size)
                .setSingleChoiceItems(sizeLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontSize = sizeValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubSize.setOnClickListener { openSizeDialog() }
        findViewById<View>(R.id.rowSubSize).setOnClickListener { openSizeDialog() }

        val colorLabels = arrayOf("White", "Yellow", "Cyan", "Green")
        val colorValues = arrayOf("16777215", "16776960", "65535", "65280")
        val openColorDialog = {
            val currentIdx = colorValues.indexOf(PlayerHolder.subFontColor).coerceAtLeast(0)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_color)
                .setSingleChoiceItems(colorLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontColor = colorValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubColor.setOnClickListener { openColorDialog() }
        findViewById<View>(R.id.rowSubColor).setOnClickListener { openColorDialog() }

        val bgLabels = arrayOf("Transparent / None", "Translucent Box", "Solid Black Box")
        val openBgDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_background)
                .setSingleChoiceItems(bgLabels, PlayerHolder.subBackgroundStyle) { dialog, which ->
                    PlayerHolder.subBackgroundStyle = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubBackground.setOnClickListener { openBgDialog() }
        findViewById<View>(R.id.rowSubBackground).setOnClickListener { openBgDialog() }

        btnToggleSubStyle.setOnClickListener {
            PlayerHolder.subFontStyle = if (PlayerHolder.subFontStyle == 1) 0 else 1
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubStyle).setOnClickListener {
            btnToggleSubStyle.performClick()
        }

        val encodings = arrayOf("UTF-8 (Default)", "Windows-1252 (Western)", "ISO-8859-1 (Latin)", "GBK (Chinese)", "Shift-JIS (Japanese)")
        val encValues = arrayOf("UTF-8", "WINDOWS-1252", "ISO-8859-1", "GBK", "SHIFT-JIS")
        val openEncDialog = {
            val currentIdx = encValues.indexOf(PlayerHolder.subEncoding).coerceAtLeast(0)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_encoding)
                .setSingleChoiceItems(encodings, currentIdx) { dialog, which ->
                    PlayerHolder.subEncoding = encValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubEncoding.setOnClickListener { openEncDialog() }
        findViewById<View>(R.id.rowSubEncoding).setOnClickListener { openEncDialog() }
    }

    // --- 4. Controls & Gestures Handlers ---
    private fun setupGestureSettings() {
        btnToggleGestureVolume.setOnClickListener {
            PlayerHolder.isVolumeGestureEnabled = !PlayerHolder.isVolumeGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureVolume).setOnClickListener { btnToggleGestureVolume.performClick() }

        btnToggleGestureBrightness.setOnClickListener {
            PlayerHolder.isBrightnessGestureEnabled = !PlayerHolder.isBrightnessGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureBrightness).setOnClickListener { btnToggleGestureBrightness.performClick() }

        btnToggleGestureSeek.setOnClickListener {
            PlayerHolder.isSeekGestureEnabled = !PlayerHolder.isSeekGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureSeek).setOnClickListener { btnToggleGestureSeek.performClick() }

        btnToggleFastSeek.setOnClickListener {
            PlayerHolder.isFastSeekEnabled = !PlayerHolder.isFastSeekEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowFastSeek).setOnClickListener { btnToggleFastSeek.performClick() }
    }

    // --- 5. Interface & Advanced Handlers ---
    private fun setupInterfaceAndAdvancedSettings() {
        val themes = arrayOf("Pure Black OLED (Default)", "Dark Charcoal", getString(R.string.theme_monochrome))
        val openThemeDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_app_theme)
                .setSingleChoiceItems(themes, PlayerHolder.appThemeMode) { dialog, which ->
                    if (PlayerHolder.appThemeMode != which) {
                        PlayerHolder.appThemeMode = which
                        PlayerHolder.savePreferences(this)
                        dialog.dismiss()
                        applyThemeUI()
                        recreate()
                    } else {
                        dialog.dismiss()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAppTheme.setOnClickListener { openThemeDialog() }
        findViewById<View>(R.id.rowAppTheme).setOnClickListener { openThemeDialog() }

        updateCacheSizeDisplay()
        btnClearCache.setOnClickListener {
            clearAppCache()
            updateCacheSizeDisplay()
            Toast.makeText(this, "Cache cleared successfully", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.rowClearCache).setOnClickListener { btnClearCache.performClick() }

        findViewById<View>(R.id.rowAppVersion)?.setOnClickListener {
            showAppVersionDialog()
        }

        btnClearResume.setOnClickListener {
            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            prefs.edit().clear().apply()
            Toast.makeText(this, "Playback history cleared", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.rowClearResume).setOnClickListener { btnClearResume.performClick() }

        btnResetSettings.setOnClickListener {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_reset_settings)
                .setMessage("Restore all player settings to default values?")
                .setPositiveButton("Reset") { _, _ ->
                    PlayerHolder.resetPreferences(this)
                    updateSettingsUI()
                    Toast.makeText(this, "Settings restored to defaults", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.rowResetSettings).setOnClickListener { btnResetSettings.performClick() }
    }

    private fun applyHighRefreshRate() {
        if (!PlayerHolder.isHighRefreshRateEnabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val modes = display?.supportedModes ?: emptyArray()
                val currentMode = display?.mode
                val targetMode = modes.filter {
                    currentMode == null || (it.physicalWidth == currentMode.physicalWidth && it.physicalHeight == currentMode.physicalHeight)
                }.maxByOrNull { it.refreshRate } ?: modes.maxByOrNull { it.refreshRate }

                targetMode?.let { mode ->
                    val params = window.attributes
                    params.preferredDisplayModeId = mode.modeId
                    window.attributes = params
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun updateToggleButton(btn: Button, isEnabled: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isEnabled) "ON" else "OFF"
        btn.setTextColor(if (isEnabled) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isEnabled) primaryColor else offStrokeColor)
    }

    private fun updateSubStyleButton(btn: Button, isBold: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isBold) "BOLD" else "REG"
        btn.setTextColor(if (isBold) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isBold) primaryColor else offStrokeColor)
    }

    private fun styleActionButton(btn: Button) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        btn.setTextColor(primaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(primaryColor)
    }

    private fun applyThemeUI() {
        val isMono = PlayerHolder.isMonochrome()
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()

        // 1. Bottom Navigation
        val navTint = if (isMono) {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint_mono)
        } else {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint)
        }
        bottomNav.itemIconTintList = navTint
        bottomNav.itemTextColor = navTint

        // 2. Floating Action Button (FAB)
        fabPlay.backgroundTintList = ColorStateList.valueOf(PlayerHolder.getFabBgColorInt())
        fabPlay.setColorFilter(PlayerHolder.getFabIconColorInt())

        // 3. Top Tabs (VIDEOS / FOLDERS)
        if (isFolderViewActive) {
            btnViewFolders.setTextColor(primaryColor)
            btnViewAllVideos.setTextColor(secondaryColor)
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)
        }

        // 4. Search Bar
        val layoutSearch = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.layoutSearch)
        layoutSearch?.boxStrokeColor = primaryColor
        layoutSearch?.hintTextColor = ColorStateList.valueOf(primaryColor)

        // 5. Notch Dynamic Island Player
        btnNotchPlayPause.setColorFilter(primaryColor)
        btnNotchOpen.setColorFilter(primaryColor)
        findViewById<ImageView>(R.id.ivNotchIcon)?.setColorFilter(primaryColor)
        sbNotch.progressTintList = ColorStateList.valueOf(primaryColor)
        sbNotch.thumbTintList = ColorStateList.valueOf(primaryColor)
        val notchStroke = if (isMono) Color.parseColor("#2E2E2E") else Color.parseColor("#2E3440")
        cardNotchPlayer.strokeColor = notchStroke

        // 6. Section Headers & App Name
        findViewById<TextView>(R.id.tvCatVideo)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatAudio)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatSubtitles)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatGestures)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatInterface)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvAppVersionTitle)?.setTextColor(primaryColor)
        val badgeAppVersion = findViewById<TextView>(R.id.badgeAppVersion)
        val cardAppVersion = findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardAppVersion)
        if (isMono) {
            badgeAppVersion?.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#333333"))
            badgeAppVersion?.setTextColor(Color.WHITE)
            cardAppVersion?.strokeColor = Color.parseColor("#2E2E2E")
        } else {
            badgeAppVersion?.backgroundTintList = ColorStateList.valueOf(primaryColor)
            badgeAppVersion?.setTextColor(Color.WHITE)
            cardAppVersion?.strokeColor = Color.parseColor("#2E3440")
        }
        findViewById<TextView>(R.id.tvMasterAudioTitle)?.setTextColor(primaryColor)
        tvVideoColorStatus.setTextColor(primaryColor)

        // 7. Browse Buttons
        btnBrowseVideo.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseVideo.setTextColor(if (isMono) Color.BLACK else Color.WHITE)
        btnBrowseAudio.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseAudio.setTextColor(if (isMono) Color.BLACK else Color.WHITE)

        // 8. Action Buttons ("Change", "Clear", "Reset")
        val actionButtons = listOf(
            btnChangeHw,
            btnChangeOrientation,
            btnChangeVideoColor,
            btnChangeMasterProfile,
            btnChangeDolbySurround,
            btnChangeEqualizer,
            btnChangeAudioOutput,
            btnChangeBgPip,
            btnChangeResumeMode,
            btnChangeDoubleTap,
            btnChangeAspectRatio,
            btnChangeSubSize,
            btnChangeSubColor,
            btnChangeSubBackground,
            btnChangeSubEncoding,
            btnChangeAppTheme,
            btnClearCache,
            btnClearResume,
            btnResetSettings
        )
        for (btn in actionButtons) {
            styleActionButton(btn)
        }

        // 9. Update Settings Toggle Buttons
        updateSettingsUI()

        // 10. Notify media adapters so list items update their colors
        videoAdapter?.notifyDataSetChanged()
        audioAdapter?.notifyDataSetChanged()
        folderVideoAdapter?.notifyDataSetChanged()
        folderAdapter?.notifyDataSetChanged()
    }

    private fun updateSettingsUI() {
        // Video UI
        updateToggleButton(btnToggleHighRefreshRate, PlayerHolder.isHighRefreshRateEnabled)
        tvHighRefreshRateStatus.text = if (PlayerHolder.isHighRefreshRateEnabled) "Enabled (Auto 120Hz / High Refresh Rate)" else "Disabled (Standard 60Hz)"

        tvDefaultOrientationStatus.text = when (PlayerHolder.defaultOrientation) {
            0 -> "Auto Sensor (Free Rotation)"
            2 -> "Portrait (Vertical)"
            else -> "Direct Landscape (Recommended)"
        }
        tvVideoColorStatus.text = when (PlayerHolder.videoColorProfile) {
            0 -> "Standard / Natural (Original)"
            1 -> "Vivid / AMOLED Boost (Recommended)"
            2 -> "Cinema / HDR Effect"
            3 -> "Sharp & Crisp Studio"
            else -> "Custom Color Tuning"
        }

        updateToggleButton(btnToggleWideColor, PlayerHolder.isWideColorGamutEnabled)
        tvWideColorStatus.text = if (PlayerHolder.isWideColorGamutEnabled) "Enabled (10-bit dynamic colors)" else "Disabled (Standard sRGB)"

        updateToggleButton(btnToggleDeblocking, PlayerHolder.isDeblockingFilterEnabled)
        tvDeblockingStatus.text = if (PlayerHolder.isDeblockingFilterEnabled) "Enabled (Crisp gradients & deblocking)" else "Disabled"

        tvHwDecodeStatus.text = when (PlayerHolder.hwAccelerationMode) {
            0 -> "Disabled (Software FFmpeg)"
            2 -> "Decoding Only"
            3 -> "Full Acceleration"
            else -> "Automatic (Recommended)"
        }
        tvBgPipStatus.text = when (PlayerHolder.backgroundPipMode) {
            0 -> "Stop Playback"
            2 -> "Picture-in-Picture (PiP)"
            else -> "Play in Background"
        }
        tvResumeModeStatus.text = when (PlayerHolder.resumeMode) {
            0 -> "Never (Always start over)"
            2 -> "Always resume automatically"
            else -> "Ask confirmation"
        }
        tvDoubleTapStatus.text = "${PlayerHolder.doubleTapSeekSeconds} seconds"
        tvAspectRatioStatus.text = when (PlayerHolder.defaultAspectRatio) {
            1 -> "Fit Screen"
            2 -> "Fill Screen"
            3 -> "16:9"
            4 -> "4:3"
            else -> "Best Fit"
        }

        updateToggleButton(btnToggleAudioBoost, PlayerHolder.isAudioBoostEnabled)
        tvAudioBoostStatus.text = if (PlayerHolder.isAudioBoostEnabled) "Enabled (Up to 200%)" else "Disabled (Standard 100%)"

        // Integrated Audio Suite UI
        tvMasterProfileStatus.text = PlayerHolder.masterProfileNames[PlayerHolder.masterAudioProfile.coerceIn(0, 4)]
        tvDolbySurroundStatus.text = when (PlayerHolder.dolbySpatialMode) {
            1 -> "Dolby 3D Headphone (Binaural HRTF)"
            2 -> "Dolby ProLogic Surround (Matrix)"
            3 -> "Cinema 3D Soundstage (Wide Room)"
            else -> "Standard Stereo (Downmix)"
        }
        val eqIdx = PlayerHolder.currentEqualizerPreset
        tvEqualizerStatus.text = if (eqIdx >= 0 && eqIdx < PlayerHolder.equalizerPresets.size - 1) {
            PlayerHolder.equalizerPresets[eqIdx + 1]
        } else {
            "Flat (Off)"
        }

        updateToggleButton(btnToggleDialogueBoost, PlayerHolder.isDialogueBoostEnabled)
        tvDialogueBoostStatus.text = if (PlayerHolder.isDialogueBoostEnabled) "Dynamic range compression: Clear speech (Enabled)" else "Disabled"

        updateToggleButton(btnTogglePassthrough, PlayerHolder.isDolbyPassthroughEnabled)
        tvDigitalPassthroughStatus.text = if (PlayerHolder.isDolbyPassthroughEnabled) "HDMI / S/PDIF Passthrough (Active)" else "Disabled"

        tvAudioOutputStatus.text = when (PlayerHolder.audioOutputEngine) {
            1 -> "OpenSL ES (Low Latency)"
            2 -> "AAudio (Modern NDK)"
            else -> "AudioTrack (Standard)"
        }

        updateToggleButton(btnToggleHeadsetPause, PlayerHolder.isHeadsetPauseEnabled)
        tvHeadsetPauseStatus.text = if (PlayerHolder.isHeadsetPauseEnabled) "Auto-pause when unplugged (Enabled)" else "Disabled"

        updateToggleButton(btnToggleTimeStretch, PlayerHolder.isTimeStretchingEnabled)
        tvTimeStretchStatus.text = if (PlayerHolder.isTimeStretchingEnabled) "Pitch lock active (Enabled)" else "Disabled"

        // Subtitle UI
        updateToggleButton(btnToggleSubAutoload, PlayerHolder.isSubAutoloadEnabled)

        tvSubSizeStatus.text = when (PlayerHolder.subFontSize) {
            "12" -> "Very Small (12sp)"
            "14" -> "Small (14sp)"
            "24" -> "Large (24sp)"
            "32" -> "Huge (32sp)"
            else -> "Normal (18sp)"
        }
        tvSubColorStatus.text = when (PlayerHolder.subFontColor) {
            "16776960" -> "Yellow"
            "65535" -> "Cyan"
            "65280" -> "Green"
            else -> "White"
        }
        tvSubBackgroundStatus.text = when (PlayerHolder.subBackgroundStyle) {
            1 -> "Translucent Box"
            2 -> "Solid Black Box"
            else -> "Transparent / None"
        }

        updateSubStyleButton(btnToggleSubStyle, PlayerHolder.subFontStyle == 1)
        tvSubStyleStatus.text = if (PlayerHolder.subFontStyle == 1) "Bold font weight" else "Normal font weight"

        tvSubEncodingStatus.text = PlayerHolder.subEncoding

        // Gestures UI
        updateToggleButton(btnToggleGestureVolume, PlayerHolder.isVolumeGestureEnabled)
        tvGestureVolumeStatus.text = if (PlayerHolder.isVolumeGestureEnabled) "Right side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureBrightness, PlayerHolder.isBrightnessGestureEnabled)
        tvGestureBrightnessStatus.text = if (PlayerHolder.isBrightnessGestureEnabled) "Left side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureSeek, PlayerHolder.isSeekGestureEnabled)
        tvGestureSeekStatus.text = if (PlayerHolder.isSeekGestureEnabled) "Horizontal drag (Enabled)" else "Disabled"

        updateToggleButton(btnToggleFastSeek, PlayerHolder.isFastSeekEnabled)
        tvFastSeekStatus.text = if (PlayerHolder.isFastSeekEnabled) "Seek to nearest keyframe (Enabled)" else "Exact frame seek (Disabled)"

        // Interface UI
        tvAppThemeStatus.text = when (PlayerHolder.appThemeMode) {
            PlayerHolder.THEME_MONOCHROME -> getString(R.string.theme_monochrome)
            PlayerHolder.THEME_CHARCOAL -> "Dark Charcoal"
            else -> "Pure Black OLED (Default)"
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            storagePermissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            loadMediaFiles()
        }
    }

    private fun switchVideoViewMode(folders: Boolean) {
        isFolderViewActive = folders
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        if (folders) {
            btnViewAllVideos.setTextColor(secondaryColor)
            btnViewFolders.setTextColor(primaryColor)

            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            updateFoldersData()
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)

            rvVideos.visibility = View.VISIBLE
            layoutFoldersContainer.visibility = View.GONE
            closeFolderDetail()
        }
    }

    private fun closeFolderDetail() {
        currentSelectedFolder = null
        layoutFolderDetailHeader.visibility = View.GONE
        rvFolderVideos.visibility = View.GONE
        rvFolders.visibility = View.VISIBLE
    }

    private fun updateFoldersData() {
        val folderMap = linkedMapOf<String, MediaFolder>()
        for (video in allVideos) {
            val key = if (video.folderPath.isNotEmpty()) video.folderPath else video.folderName
            val folder = folderMap.getOrPut(key) {
                MediaFolder(video.folderName, video.folderPath)
            }
            folder.videos.add(video)
        }
        allFolders = folderMap.values.toList()

        btnViewFolders.text = "FOLDERS"
        btnViewAllVideos.text = "VIDEOS"

        if (folderAdapter == null) {
            folderAdapter = FolderAdapter(allFolders) { folder ->
                openFolderDetail(folder)
            }
            rvFolders.adapter = folderAdapter
        } else {
            folderAdapter?.updateFolders(allFolders)
        }
    }

    private fun openFolderDetail(folder: MediaFolder) {
        currentSelectedFolder = folder
        rvFolders.visibility = View.GONE
        layoutFolderDetailHeader.visibility = View.VISIBLE
        rvFolderVideos.visibility = View.VISIBLE

        tvFolderHeaderTitle.text = folder.folderName
        tvFolderHeaderSubtitle.text = "${folder.count} videos • ${folder.getFormattedSize()}"

        folderVideoAdapter = MediaAdapter(folder.videos) { item, _ ->
            try {
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
        rvFolderVideos.adapter = folderVideoAdapter
    }

    private fun loadMediaFiles() {
        allVideos = MediaScanner.scanVideos(this)
        if (allVideos.isNotEmpty()) {
            layoutEmptyVideo.visibility = View.GONE
            if (videoAdapter == null) {
                videoAdapter = MediaAdapter(allVideos) { item, _ ->
                    try {
                        openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
                rvVideos.adapter = videoAdapter
            } else {
                videoAdapter?.updateList(allVideos)
            }
            updateFoldersData()
            if (isFolderViewActive) {
                rvVideos.visibility = View.GONE
                layoutFoldersContainer.visibility = View.VISIBLE
            } else {
                rvVideos.visibility = View.VISIBLE
                layoutFoldersContainer.visibility = View.GONE
            }
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = View.VISIBLE
        }

        allAudio = MediaScanner.scanAudio(this)
        if (allAudio.isNotEmpty()) {
            rvAudio.visibility = View.VISIBLE
            layoutEmptyAudio.visibility = View.GONE
            if (audioAdapter == null) {
                audioAdapter = MediaAdapter(allAudio) { item, pos ->
                    try {
                        PlayerHolder.setPlaylistAndPlay(this, allAudio, pos)
                        audioAdapter?.setPlayingUri(item.uri)
                        updateNotchPlayerUI()
                        openPlayer(item.uri, item.title, isVideo = false, path = item.filePath, artist = item.artist)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
                rvAudio.adapter = audioAdapter
            } else {
                audioAdapter?.updateList(allAudio)
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            }
        } else {
            rvAudio.visibility = View.GONE
            layoutEmptyAudio.visibility = View.VISIBLE
        }
    }

    private fun openPlayer(uri: Uri, title: String, isVideo: Boolean = true, path: String? = null, artist: String? = null) {
        PlayerHolder.isAudioOnly = !isVideo
        PlayerHolder.currentArtist = artist ?: "Unknown artist"
        val intent = Intent(this, PlayerActivity::class.java).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra("media_uri", uri.toString())
            putExtra("media_title", title)
            putExtra("media_artist", PlayerHolder.currentArtist)
            putExtra("is_video", isVideo)
            if (!path.isNullOrEmpty()) {
                putExtra("media_path", path)
            }
        }
        startActivity(intent)
    }

    private fun updateCacheSizeDisplay() {
        try {
            var size = getDirSize(cacheDir)
            size += getDirSize(codeCacheDir)
            externalCacheDir?.let { size += getDirSize(it) }
            val formatted = if (size <= 0) "0 B (Clean)" else android.text.format.Formatter.formatFileSize(this, size)
            tvCacheSizeStatus.text = "$formatted • Free up temporary cache & thumbnails"
        } catch (e: Exception) {
            tvCacheSizeStatus.text = "0 B (Clean) • Free up temporary cache"
        }
    }

    private fun getDirSize(dir: java.io.File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var bytes = 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            bytes += if (f.isDirectory) getDirSize(f) else f.length()
        }
        return bytes
    }

    private fun clearAppCache() {
        try {
            cacheDir.deleteRecursively()
            codeCacheDir.deleteRecursively()
            externalCacheDir?.deleteRecursively()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAppVersionDialog() {
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle(R.string.app_name)
            .setMessage("Version 3.0 (Master Edition)\nBuild: 300\n\nLead Developer: Rajesh Shah\nEngine: Universal Hardware Core with Dolby Surround\n\nStatus: Up to date")
            .setPositiveButton("OK", null)
            .show()
    }
}
