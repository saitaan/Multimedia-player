package com.cleanplayer.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView

/**
 * AndroidX Media3 (ExoPlayer) Dedicated Adaptive Engine for YouTube
 * Thread-safe, synchronized playback manager with null-safety and robust lifecycle controls.
 */
object YouTubeExoPlayerManager {

    var exoPlayer: ExoPlayer? = null
        private set

    var currentPlayingVideo: YouTubeVideo? = null
        private set

    var currentStreamUrl: String? = null
        private set

    var currentQualityLabel: String = "Auto"
        private set

    private var trackSelector: DefaultTrackSelector? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var sponsorCheckRunnable: Runnable? = null
    private val playerLock = Any()

    var onSponsorSkipped: ((category: String) -> Unit)? = null
    var onPlaybackStateChanged: ((isPlaying: Boolean) -> Unit)? = null

    @Synchronized
    fun getOrCreatePlayer(context: Context): ExoPlayer {
        val existing = exoPlayer
        if (existing != null) return existing

        val appContext = context.applicationContext
        val selector = DefaultTrackSelector(appContext).apply {
            setParameters(buildUponParameters().setPreferredVideoMimeType(MimeTypes.VIDEO_MP4))
        }
        trackSelector = selector

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                DefaultLoadControl.DEFAULT_MIN_BUFFER_MS,
                DefaultLoadControl.DEFAULT_MAX_BUFFER_MS,
                1500, // min buffer for playback
                2500  // min buffer for playback after rebuffer
            )
            .build()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val player = ExoPlayer.Builder(appContext)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                onPlaybackStateChanged?.invoke(isPlaying)
                if (isPlaying) {
                    startSponsorCheckLoop()
                } else {
                    stopSponsorCheckLoop()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    stopSponsorCheckLoop()
                }
            }
        })

        exoPlayer = player
        return player
    }

    @Synchronized
    fun playVideo(
        context: Context,
        video: YouTubeVideo,
        streamUrl: String,
        isDash: Boolean = false,
        isHls: Boolean = false,
        startPosMs: Long = 0L
    ) {
        val player = getOrCreatePlayer(context)

        // If same video and URL are already loaded, just seek if needed
        if (currentPlayingVideo?.id == video.id && currentStreamUrl == streamUrl) {
            try {
                if (startPosMs > 0L) player.seekTo(startPosMs)
                player.play()
            } catch (e: Exception) {}
            return
        }

        currentPlayingVideo = video
        currentStreamUrl = streamUrl

        val mimeType = when {
            isDash || streamUrl.contains(".mpd") -> MimeTypes.APPLICATION_MPD
            isHls || streamUrl.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
            else -> MimeTypes.VIDEO_MP4
        }

        val metadata = MediaMetadata.Builder()
            .setTitle(video.title)
            .setArtist(video.channelTitle)
            .setArtworkUri(Uri.parse(video.thumbnailUrl))
            .build()

        val mediaItem = MediaItem.Builder()
            .setUri(Uri.parse(streamUrl))
            .setMimeType(mimeType)
            .setMediaMetadata(metadata)
            .build()

        // Fetch SponsorBlock segments for this video
        SponsorBlockManager.fetchSegments(video.id)

        try {
            player.setMediaItem(mediaItem)
            player.prepare()
            if (startPosMs > 0L) {
                player.seekTo(startPosMs)
            }
            player.playWhenReady = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun attachPlayerView(playerView: PlayerView) {
        val player = getOrCreatePlayer(playerView.context)
        playerView.player = player
    }

    fun detachPlayerView(playerView: PlayerView) {
        if (playerView.player == exoPlayer) {
            playerView.player = null
        }
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        try {
            if (player.isPlaying) {
                player.pause()
            } else {
                player.play()
            }
        } catch (e: Exception) {}
    }

    fun pause() {
        try {
            exoPlayer?.pause()
        } catch (e: Exception) {}
    }

    fun play() {
        try {
            exoPlayer?.play()
        } catch (e: Exception) {}
    }

    fun seekTo(posMs: Long) {
        try {
            exoPlayer?.seekTo(posMs)
        } catch (e: Exception) {}
    }

    fun setPlaybackSpeed(speed: Float) {
        try {
            exoPlayer?.playbackParameters = PlaybackParameters(speed)
        } catch (e: Exception) {}
    }

    fun setVideoQuality(maxHeight: Int) {
        val selector = trackSelector ?: return
        try {
            if (maxHeight <= 0) {
                selector.parameters = selector.buildUponParameters()
                    .clearVideoSizeConstraints()
                    .build()
                currentQualityLabel = "Auto"
            } else {
                selector.parameters = selector.buildUponParameters()
                    .setMaxVideoSize(3840, maxHeight)
                    .build()
                currentQualityLabel = "${maxHeight}p"
            }
        } catch (e: Exception) {}
    }

    @Synchronized
    private fun startSponsorCheckLoop() {
        stopSponsorCheckLoop()
        val runnable = object : Runnable {
            override fun run() {
                synchronized(playerLock) {
                    val player = exoPlayer
                    if (player != null && player.playbackState != Player.STATE_IDLE && player.playbackState != Player.STATE_ENDED) {
                        try {
                            if (player.isPlaying) {
                                val currentPos = player.currentPosition
                                val skip = SponsorBlockManager.checkSkip(currentPos)
                                if (skip != null) {
                                    player.seekTo(skip.first)
                                    onSponsorSkipped?.invoke(skip.second)
                                }
                            }
                        } catch (e: Exception) {
                            // Suppress transient player position exceptions
                        }
                        mainHandler.postDelayed(this, 250)
                    }
                }
            }
        }
        sponsorCheckRunnable = runnable
        mainHandler.postDelayed(runnable, 250)
    }

    @Synchronized
    private fun stopSponsorCheckLoop() {
        sponsorCheckRunnable?.let {
            mainHandler.removeCallbacks(it)
            sponsorCheckRunnable = null
        }
    }

    @Synchronized
    fun release() {
        stopSponsorCheckLoop()
        synchronized(playerLock) {
            try {
                exoPlayer?.stop()
                exoPlayer?.release()
            } catch (e: Exception) {}
            exoPlayer = null
            trackSelector = null
            currentPlayingVideo = null
            currentStreamUrl = null
            onPlaybackStateChanged = null
            onSponsorSkipped = null
        }
    }
}
