package com.cleanplayer.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat

class MediaPlaybackService : Service() {

    companion object {
        const val CHANNEL_ID = "multimedia_playback_channel"
        const val NOTIFICATION_ID = 101
        const val ACTION_PLAY_PAUSE = "com.cleanplayer.app.ACTION_PLAY_PAUSE"
        const val ACTION_PREVIOUS = "com.cleanplayer.app.ACTION_PREVIOUS"
        const val ACTION_NEXT = "com.cleanplayer.app.ACTION_NEXT"
        const val ACTION_STOP = "com.cleanplayer.app.ACTION_STOP"
        const val ACTION_UPDATE = "com.cleanplayer.app.ACTION_UPDATE"

        var mediaSession: MediaSessionCompat? = null

        fun start(
            context: Context,
            title: String = "",
            artist: String = "Unknown artist",
            isPlaying: Boolean = true,
            isYouTube: Boolean = false,
            thumbUrl: String? = null
        ) {
            val intent = Intent(context, MediaPlaybackService::class.java).apply {
                action = ACTION_UPDATE
                putExtra("title", title)
                putExtra("artist", artist)
                putExtra("is_playing", isPlaying)
                putExtra("is_youtube", isYouTube)
                putExtra("thumb_url", thumbUrl)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun stop(context: Context) {
            try {
                val intent = Intent(context, MediaPlaybackService::class.java).apply {
                    action = ACTION_STOP
                }
                context.startService(intent)
            } catch (e: Exception) {}
        }
    }

    private var defaultAlbumArt: Bitmap? = null

    private fun isAnyPlaying(): Boolean {
        return if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
            YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
        } else if (PlayerHolder.audioExoPlayer != null) {
            PlayerHolder.audioExoPlayer?.isPlaying == true
        } else {
            PlayerHolder.mediaPlayer?.isPlaying == true
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        defaultAlbumArt = createDefaultAlbumArt()

        mediaSession = MediaSessionCompat(this, "MultimediaAudioSession").apply {
            isActive = true
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() {
                    if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                        YouTubeExoPlayerManager.play()
                    } else if (PlayerHolder.audioExoPlayer != null) {
                        PlayerHolder.audioExoPlayer?.play()
                    } else {
                        PlayerHolder.mediaPlayer?.play()
                    }
                    updatePlaybackState(true)
                    updateNotification()
                }

                override fun onPause() {
                    if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                        YouTubeExoPlayerManager.pause()
                    } else if (PlayerHolder.audioExoPlayer != null) {
                        PlayerHolder.audioExoPlayer?.pause()
                    } else {
                        PlayerHolder.mediaPlayer?.pause()
                    }
                    updatePlaybackState(false)
                    updateNotification()
                }

                override fun onSkipToPrevious() {
                    PlayerHolder.playPrevious(this@MediaPlaybackService)
                    updatePlaybackState(isAnyPlaying())
                    updateNotification()
                }

                override fun onSkipToNext() {
                    PlayerHolder.playNext(this@MediaPlaybackService)
                    updatePlaybackState(isAnyPlaying())
                    updateNotification()
                }

                override fun onSeekTo(pos: Long) {
                    if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                        YouTubeExoPlayerManager.seekTo(pos)
                    } else if (PlayerHolder.audioExoPlayer != null) {
                        PlayerHolder.audioExoPlayer?.seekTo(pos)
                    } else {
                        PlayerHolder.mediaPlayer?.time = pos
                    }
                    updatePlaybackState(true)
                    updateNotification()
                }

                override fun onStop() {
                    YouTubeExoPlayerManager.pause()
                    PlayerHolder.release()
                    stopServiceInternal()
                }
            })
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val isPlaying = intent?.getBooleanExtra("is_playing", true) ?: isAnyPlaying()
            updatePlaybackState(isPlaying)
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        when (intent?.action) {
            ACTION_PLAY_PAUSE -> {
                if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                    YouTubeExoPlayerManager.togglePlayPause()
                    val isPlaying = YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
                    updatePlaybackState(isPlaying)
                    updateNotification()
                } else if (PlayerHolder.audioExoPlayer != null) {
                    val p = PlayerHolder.audioExoPlayer!!
                    val willPlay = !p.isPlaying
                    if (willPlay) p.play() else p.pause()
                    updatePlaybackState(willPlay)
                    updateNotification()
                } else {
                    PlayerHolder.mediaPlayer?.let { player ->
                        if (player.isPlaying) {
                            player.pause()
                            updatePlaybackState(false)
                        } else {
                            player.play()
                            updatePlaybackState(true)
                        }
                        updateNotification()
                    }
                }
            }
            ACTION_PREVIOUS -> {
                PlayerHolder.playPrevious(this)
                updatePlaybackState(isAnyPlaying())
                updateNotification()
            }
            ACTION_NEXT -> {
                PlayerHolder.playNext(this)
                updatePlaybackState(isAnyPlaying())
                updateNotification()
            }
            ACTION_STOP -> {
                YouTubeExoPlayerManager.pause()
                PlayerHolder.release()
                stopServiceInternal()
                return START_NOT_STICKY
            }
            else -> {
                // Foreground service already started safely above
            }
        }
        return START_NOT_STICKY
    }

    private fun updatePlaybackState(isPlaying: Boolean) {
        val isYt = YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null
        val isAudioExo = PlayerHolder.audioExoPlayer != null

        val pos = when {
            isYt -> YouTubeExoPlayerManager.exoPlayer?.currentPosition ?: 0L
            isAudioExo -> PlayerHolder.audioExoPlayer?.currentPosition ?: 0L
            else -> PlayerHolder.mediaPlayer?.time ?: 0L
        }
        val duration = when {
            isYt -> YouTubeExoPlayerManager.exoPlayer?.duration ?: 0L
            isAudioExo -> PlayerHolder.audioExoPlayer?.duration ?: 0L
            else -> PlayerHolder.mediaPlayer?.length ?: 0L
        }.coerceAtLeast(0L)
        val actions = PlaybackStateCompat.ACTION_PLAY or
                PlaybackStateCompat.ACTION_PAUSE or
                PlaybackStateCompat.ACTION_PLAY_PAUSE or
                PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
                PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
                PlaybackStateCompat.ACTION_SEEK_TO or
                PlaybackStateCompat.ACTION_STOP

        val state = if (isPlaying) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED

        val stateBuilder = PlaybackStateCompat.Builder()
            .setActions(actions)
            .setState(state, pos, 1.0f, SystemClock.elapsedRealtime())

        mediaSession?.setPlaybackState(stateBuilder.build())

        val title = PlayerHolder.currentTitle
        val artist = PlayerHolder.currentArtist

        val metadataBuilder = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, "Multimedia Player")
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, duration)
            .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, defaultAlbumArt)

        mediaSession?.setMetadata(metadataBuilder.build())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Multimedia Playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background Audio Playback Service with Dynamic Island Notch Support"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val session = mediaSession
        val token = session?.sessionToken

        val openAppIntent = Intent(this, PlayerActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("is_video", !PlayerHolder.isAudioOnly)
            putExtra("media_title", PlayerHolder.currentTitle)
            putExtra("media_artist", PlayerHolder.currentArtist)
            putExtra("media_uri", PlayerHolder.currentUri?.toString())
            putExtra("media_path", PlayerHolder.currentPath)
        }
        val pendingOpenApp = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prevIntent = Intent(this, MediaPlaybackService::class.java).apply { action = ACTION_PREVIOUS }
        val pendingPrev = PendingIntent.getService(this, 1, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val playPauseIntent = Intent(this, MediaPlaybackService::class.java).apply { action = ACTION_PLAY_PAUSE }
        val pendingPlayPause = PendingIntent.getService(this, 2, playPauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val nextIntent = Intent(this, MediaPlaybackService::class.java).apply { action = ACTION_NEXT }
        val pendingNext = PendingIntent.getService(this, 3, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val stopIntent = Intent(this, MediaPlaybackService::class.java).apply { action = ACTION_STOP }
        val pendingStop = PendingIntent.getService(this, 4, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val isYt = YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null
        val isAudioExo = PlayerHolder.audioExoPlayer != null
        val isPlaying = when {
            isYt -> YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
            isAudioExo -> PlayerHolder.audioExoPlayer?.isPlaying == true
            else -> PlayerHolder.mediaPlayer?.isPlaying == true
        }
        val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseTitle = if (isPlaying) "Pause" else "Play"

        val style = androidx.media.app.NotificationCompat.MediaStyle()
        if (token != null) {
            style.setMediaSession(token)
        }
        style.setShowActionsInCompactView(0, 1, 2)

        val isOnlineYt = PlayerHolder.currentPath?.startsWith("http") == true || PlayerHolder.currentUri?.scheme == "http" || PlayerHolder.currentUri?.scheme == "https"
        val smallIconRes = if (isOnlineYt) R.drawable.ic_youtube else R.drawable.ic_audio
        val subLabel = if (isOnlineYt) "YouTube Premium Audio" else "Multimedia Music"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(smallIconRes)
            .setLargeIcon(defaultAlbumArt)
            .setContentTitle(PlayerHolder.currentTitle)
            .setContentText(PlayerHolder.currentArtist)
            .setSubText(subLabel)
            .setContentIntent(pendingOpenApp)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(isPlaying)
            .addAction(android.R.drawable.ic_media_previous, "Previous", pendingPrev)
            .addAction(playPauseIcon, playPauseTitle, pendingPlayPause)
            .addAction(android.R.drawable.ic_media_next, "Next", pendingNext)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", pendingStop)
            .setStyle(style)
            .build()
    }

    private fun updateNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun createDefaultAlbumArt(): Bitmap {
        val size = 256
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#1C1E24")
        }
        canvas.drawRoundRect(0f, 0f, size.toFloat(), size.toFloat(), 36f, 36f, paint)

        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2979FF")
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        canvas.drawRoundRect(6f, 6f, size - 6f, size - 6f, 32f, 32f, ringPaint)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#2979FF")
            textSize = 96f
            typeface = Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("♪", size / 2f, size / 2f + 32f, textPaint)
        return bitmap
    }

    private fun stopServiceInternal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaSession?.release()
        mediaSession = null
        defaultAlbumArt = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
