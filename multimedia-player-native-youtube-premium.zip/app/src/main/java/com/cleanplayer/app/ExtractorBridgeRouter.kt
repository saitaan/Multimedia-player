package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/**
 * Dynamic Extractor Engine Router
 * Dynamically resolves video streams based on user configuration and provides
 * zero-downtime automatic failover across InnerTube, Piped, and Invidious clusters.
 */
object ExtractorBridgeRouter {

    const val PREFS_KEY_ENGINE = "pref_yt_extractor_bridge"

    const val ENGINE_AUTO = "AUTO"
    const val ENGINE_INNERTUBE = "INNERTUBE"
    const val ENGINE_PIPED = "PIPED"
    const val ENGINE_INVIDIOUS = "INVIDIOUS"

    private val pipedBridge = PipedBridge()
    private val invidiousBridge = InvidiousBridge()

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun getActiveEngineId(context: Context): String {
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        return prefs.getString(PREFS_KEY_ENGINE, ENGINE_AUTO) ?: ENGINE_AUTO
    }

    fun getActiveEngineName(context: Context): String {
        return when (getActiveEngineId(context)) {
            ENGINE_INNERTUBE -> "Direct InnerTube (ReVanced Spoofing)"
            ENGINE_PIPED -> "Piped Privacy Cluster"
            ENGINE_INVIDIOUS -> "Invidious Dynamic Pool"
            else -> "Smart Auto Failover (Recommended)"
        }
    }

    fun setActiveEngine(context: Context, engineId: String) {
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString(PREFS_KEY_ENGINE, engineId).apply()
    }

    private fun hasValidStream(res: VideoExtractionResult?): Boolean {
        if (res == null) return false
        return res.formats.isNotEmpty() || res.bestStreamUrl.isNotBlank() || res.dashManifestUrl != null || res.hlsManifestUrl != null
    }

    fun resolveStream(
        context: Context,
        videoId: String,
        callback: (VideoExtractionResult?) -> Unit
    ) {
        val engine = getActiveEngineId(context)
        val authToken = if (MicroGAuthManager.isLoggedIn(context)) {
            MicroGAuthManager.getAuthToken(context)
        } else {
            null
        }

        // Pass application context so DefaultInnertubeBridge reads user client spoofing preferences without memory leaks
        val localizedInnertubeBridge = DefaultInnertubeBridge(context.applicationContext)

        executor.execute {
            var result: VideoExtractionResult? = null

            result = when (engine) {
                ENGINE_INNERTUBE -> localizedInnertubeBridge.extract(videoId, authToken)
                ENGINE_INVIDIOUS -> invidiousBridge.extract(videoId, authToken)
                ENGINE_PIPED -> pipedBridge.extract(videoId, authToken)
                else -> null
            }

            // Zero-Downtime Smart Failover: InnerTube -> Invidious -> Piped
            if (!hasValidStream(result)) {
                result = localizedInnertubeBridge.extract(videoId, authToken)
            }
            if (!hasValidStream(result)) {
                result = invidiousBridge.extract(videoId, authToken)
            }
            if (!hasValidStream(result)) {
                result = pipedBridge.extract(videoId, authToken)
            }

            mainHandler.post {
                callback(result)
            }
        }
    }
}
