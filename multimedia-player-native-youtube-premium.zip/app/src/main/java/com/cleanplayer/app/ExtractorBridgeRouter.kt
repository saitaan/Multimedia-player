package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors

/**
 * Dynamic Extractor Engine Router
 * Dynamically resolves video streams based on user configuration and provides
 * zero-downtime automatic failover across InnerTube, Piped, and Invidious clusters.
 */
object ExtractorBridgeRouter {

    const val PREFS_KEY_ENGINE = "pref_yt_extractor_bridge"

    const val ENGINE_AUTO = "AUTO"
    const val ENGINE_INNERTUBE = "INNERTUBE"
    const val ENGINE_PIPED = "PIPED"
    const val ENGINE_INVIDIOUS = "INVIDIOUS"

    private val innertubeBridge = DefaultInnertubeBridge()
    private val pipedBridge = PipedBridge()
    private val invidiousBridge = InvidiousBridge()

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun getActiveEngineId(context: Context): String {
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        return prefs.getString(PREFS_KEY_ENGINE, ENGINE_AUTO) ?: ENGINE_AUTO
    }

    fun getActiveEngineName(context: Context): String {
        return when (getActiveEngineId(context)) {
            ENGINE_INNERTUBE -> "Direct InnerTube (ReVanced Spoofing)"
            ENGINE_PIPED -> "Piped Privacy Cluster"
            ENGINE_INVIDIOUS -> "Invidious Dynamic Pool"
            else -> "Smart Auto Failover (Recommended)"
        }
    }

    fun setActiveEngine(context: Context, engineId: String) {
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString(PREFS_KEY_ENGINE, engineId).apply()
    }

    fun resolveStream(
        context: Context,
        videoId: String,
        callback: (VideoExtractionResult?) -> Unit
    ) {
        val engine = getActiveEngineId(context)
        val authToken = if (MicroGAuthManager.isLoggedIn(context)) {
            MicroGAuthManager.getAuthToken(context)
        } else {
            null
        }

        executor.execute {
            var result: VideoExtractionResult? = null

            when (engine) {
                ENGINE_INNERTUBE -> {
                    result = innertubeBridge.extract(videoId, authToken)
                }
                ENGINE_PIPED -> {
                    result = pipedBridge.extract(videoId, authToken)
                }
                ENGINE_INVIDIOUS -> {
                    result = invidiousBridge.extract(videoId, authToken)
                }
                else -> {
                    // Smart Auto Failover: InnerTube -> Piped -> Invidious
                    result = innertubeBridge.extract(videoId, authToken)
                    if (result == null || result.formats.isEmpty()) {
                        result = pipedBridge.extract(videoId, authToken)
                    }
                    if (result == null || result.formats.isEmpty()) {
                        result = invidiousBridge.extract(videoId, authToken)
                    }
                }
            }

            mainHandler.post {
                callback(result)
            }
        }
    }
}
