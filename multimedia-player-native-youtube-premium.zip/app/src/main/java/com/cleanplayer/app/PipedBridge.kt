package com.cleanplayer.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Piped Privacy Cluster Bridge
 * Dispatches requests across a live pool of decentralized Piped API instances.
 */
class PipedBridge : VideoExtractorBridge {

    override val engineId: String = "piped"
    override val displayName: String = "Piped Privacy Cluster"
    override val description: String = "Decentralized privacy proxy bypassing Google tracking"

    companion object {
        val PIPED_INSTANCES = listOf(
            "https://pipedapi.tokhmi.xyz",
            "https://api.piped.privacydev.net",
            "https://pipedapi.r4ce.nl",
            "https://api.piped.projectsegfau.lt",
            "https://piped-api.lunar.icu",
            "https://pipedapi.reallyawesomedomain.gov"
        )
    }

    override fun extract(videoId: String, authToken: String?): VideoExtractionResult? {
        for (instance in PIPED_INSTANCES) {
            try {
                val endpoint = "$instance/streams/$videoId"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6000
                    readTimeout = 6000
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) CleanPlayer")
                }
                if (conn.responseCode == 200) {
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(resp)

                    val formatList = mutableListOf<VideoStreamFormat>()
                    val videoStreams = json.optJSONArray("videoStreams")
                    if (videoStreams != null) {
                        for (i in 0 until videoStreams.length()) {
                            val stream = videoStreams.getJSONObject(i)
                            val url = stream.optString("url")
                            val quality = stream.optString("quality", "")
                            val height = quality.replace("p", "").toIntOrNull() ?: 0

                            if (url.isNotEmpty()) {
                                formatList.add(VideoStreamFormat(quality, height, url))
                            }
                        }
                    }

                    val hlsUrl = json.optString("hls").takeIf { it.isNotBlank() }
                    val dashUrl = json.optString("dash").takeIf { it.isNotBlank() }

                    if (formatList.isNotEmpty() || !dashUrl.isNullOrEmpty() || !hlsUrl.isNullOrEmpty()) {
                        formatList.sortByDescending { it.resolution }
                        val best = formatList.firstOrNull()?.url ?: (dashUrl ?: hlsUrl ?: "")
                        val host = try { URL(instance).host } catch (e: Exception) { "piped" }
                        return VideoExtractionResult(
                            bestStreamUrl = best,
                            formats = formatList,
                            dashManifestUrl = dashUrl,
                            hlsManifestUrl = hlsUrl,
                            engineName = "Piped [$host]",
                            isUnthrottled = true
                        )
                    }
                }
            } catch (e: Exception) {
                // Failover to next instance in rotation
            }
        }
        return null
    }
}
