package com.cleanplayer.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Invidious Dynamic Pool Bridge
 * Rotates across unthrottled Invidious instances worldwide.
 */
class InvidiousBridge : VideoExtractorBridge {

    override val engineId: String = "invidious"
    override val displayName: String = "Invidious Dynamic Pool"
    override val description: String = "Open-source federated proxy with multi-server failover"

    companion object {
        val INVIDIOUS_INSTANCES = listOf(
            "https://yewtu.be",
            "https://inv.nadeko.net",
            "https://invidious.nerdvpn.de",
            "https://invidious.jing.rocks",
            "https://invidious.projectsegfau.lt",
            "https://invidious.privacydev.net",
            "https://invidious.flokinet.to",
            "https://invidious.drgns.space"
        )
    }

    override fun extract(videoId: String, authToken: String?): VideoExtractionResult? {
        for (instance in INVIDIOUS_INSTANCES) {
            try {
                val endpoint = "$instance/api/v1/videos/$videoId"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6000
                    readTimeout = 6000
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) CleanPlayer")
                }
                if (conn.responseCode == 200) {
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(resp)

                    val formatList = mutableListOf<VideoStreamFormat>()
                    val formats = json.optJSONArray("formatStreams") ?: json.optJSONArray("adaptiveFormats")
                    if (formats != null) {
                        for (i in 0 until formats.length()) {
                            val fmt = formats.getJSONObject(i)
                            val rawUrl = fmt.optString("url")
                            val type = fmt.optString("type", "")
                            if (type.isNotEmpty() && !type.contains("video/mp4") && !type.contains("video/webm")) continue

                            val sizeStr = fmt.optString("size", "")
                            val labelStr = fmt.optString("qualityLabel", fmt.optString("quality", ""))
                            val height = when {
                                sizeStr.contains("x") -> sizeStr.substringAfter("x").toIntOrNull() ?: 0
                                labelStr.contains("p") -> labelStr.replace("p", "").toIntOrNull() ?: 0
                                else -> fmt.optInt("resolution", 0)
                            }
                            val label = if (labelStr.isNotBlank()) labelStr else (if (height > 0) "${height}p" else "360p")
                            val resolvedHeight = if (height > 0) height else 360

                            if (rawUrl.isNotEmpty()) {
                                val fullUrl = if (rawUrl.startsWith("http")) rawUrl else "$instance$rawUrl"
                                formatList.add(VideoStreamFormat(label, resolvedHeight, fullUrl))
                            }
                        }
                    }

                    val hlsUrl = json.optString("hlsUrl").takeIf { it.isNotBlank() }
                    val dashUrl = json.optString("dashUrl").takeIf { it.isNotBlank() }

                    if (formatList.isNotEmpty() || !hlsUrl.isNullOrEmpty() || !dashUrl.isNullOrEmpty()) {
                        formatList.sortByDescending { it.resolution }
                        val best = formatList.firstOrNull()?.url ?: (hlsUrl ?: dashUrl ?: "")
                        val host = try { URL(instance).host } catch (e: Exception) { "invidious" }
                        return VideoExtractionResult(
                            bestStreamUrl = best,
                            formats = formatList,
                            dashManifestUrl = dashUrl,
                            hlsManifestUrl = hlsUrl,
                            engineName = "Invidious [$host]",
                            isUnthrottled = true
                        )
                    }
                }
            } catch (e: Exception) {
                // Failover to next instance in rotation
            }
        }
        return null
    }
}
