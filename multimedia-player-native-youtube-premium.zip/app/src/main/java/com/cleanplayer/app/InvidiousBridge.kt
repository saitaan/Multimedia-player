package com.cleanplayer.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Invidious Dynamic Pool Bridge
 * Rotates across unthrottled Invidious instances worldwide.
 */
class InvidiousBridge : VideoExtractorBridge {

    override val engineId: String = "invidious"
    override val displayName: String = "Invidious Dynamic Pool"
    override val description: String = "Open-source federated proxy with multi-server failover"

    companion object {
        val INVIDIOUS_INSTANCES = listOf(
            "https://invidious.nerdvpn.de",
            "https://yt.artemislena.eu",
            "https://invidious.jing.rocks",
            "https://invidious.drgns.space",
            "https://inv.nadeko.net"
        )
    }

    override fun extract(videoId: String, authToken: String?): VideoExtractionResult? {
        for (instance in INVIDIOUS_INSTANCES) {
            try {
                val endpoint = "$instance/api/v1/videos/$videoId"
                val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6000
                    readTimeout = 6000
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) CleanPlayer")
                }
                if (conn.responseCode == 200) {
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(resp)

                    val formatList = mutableListOf<VideoStreamFormat>()
                    val formats = json.optJSONArray("formatStreams")
                    if (formats != null) {
                        for (i in 0 until formats.length()) {
                            val fmt = formats.getJSONObject(i)
                            val u = fmt.optString("url")
                            val height = fmt.optInt("size", 0)
                            val label = fmt.optString("qualityLabel", if (height > 0) "${height}p" else "Auto")
                            if (u.isNotEmpty() && height > 0) {
                                formatList.add(VideoStreamFormat(label, height, u))
                            }
                        }
                    }

                    val hlsUrl = json.optString("hlsUrl").takeIf { it.isNotBlank() }
                    val dashUrl = json.optString("dashUrl").takeIf { it.isNotBlank() }

                    if (formatList.isNotEmpty() || !hlsUrl.isNullOrEmpty() || !dashUrl.isNullOrEmpty()) {
                        formatList.sortByDescending { it.resolution }
                        val best = formatList.firstOrNull()?.url ?: (hlsUrl ?: dashUrl ?: "")
                        return VideoExtractionResult(
                            bestStreamUrl = best,
                            formats = formatList,
                            dashManifestUrl = dashUrl,
                            hlsManifestUrl = hlsUrl,
                            engineName = "Invidious [${URL(instance).host}]",
                            isUnthrottled = true
                        )
                    }
                }
            } catch (e: Exception) {
                // Failover to next instance in rotation
            }
        }
        return null
    }
}
