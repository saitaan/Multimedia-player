package com.cleanplayer.app

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu
import androidx.recyclerview.widget.RecyclerView

class YouTubeFeedAdapter(
    private val context: Context,
    private var items: List<YouTubeVideo>,
    private val onItemClick: (YouTubeVideo) -> Unit
) : RecyclerView.Adapter<YouTubeFeedAdapter.VideoViewHolder>() {

    var onChannelClick: ((channelTitle: String, avatarUrl: String?) -> Unit)? = null

    fun updateItems(newItems: List<YouTubeVideo>) {
        this.items = newItems
        notifyDataSetChanged()
    }

    fun updateData(newItems: List<YouTubeVideo>) {
        updateItems(newItems)
    }

    fun appendItems(newItems: List<YouTubeVideo>) {
        if (newItems.isEmpty()) return
        val currentIds = this.items.map { it.id }.toSet()
        val toAdd = newItems.filter { !currentIds.contains(it.id) }
        if (toAdd.isNotEmpty()) {
            val start = this.items.size
            this.items = this.items + toAdd
            notifyItemRangeInserted(start, toAdd.size)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_youtube_video, parent, false)
        return VideoViewHolder(view)
    }

    override fun onBindViewHolder(holder: VideoViewHolder, position: Int) {
        val item = items[position]

        holder.tvTitle.text = item.title
        holder.tvSubtitle.text = "${item.channelTitle} • ${item.views} • ${item.uploadDate}"
        holder.tvDuration.text = item.duration

        ImageLoaderHelper.loadImage(item.thumbnailUrl, holder.ivThumbnail, R.drawable.ic_video)
        val avatarToUse = if (!item.channelAvatarUrl.isNullOrBlank()) item.channelAvatarUrl else ChannelAvatarManager.getAvatar(item.channelTitle)
        ImageLoaderHelper.loadImage(avatarToUse, holder.ivChannelAvatar, R.drawable.ic_account_circle)

        holder.ivChannelAvatar.setOnClickListener {
            if (onChannelClick != null) {
                onChannelClick?.invoke(item.channelTitle, item.channelAvatarUrl)
            } else {
                onItemClick(item)
            }
        }

        holder.itemView.setOnClickListener {
            onItemClick(item)
        }

        holder.btnMore.setOnClickListener { v ->
            showOptionsPopup(v, item)
        }
    }

    private fun showOptionsPopup(anchor: View, item: YouTubeVideo) {
        val popup = PopupMenu(context, anchor)
        popup.menu.add(0, 1, 0, "Play in Background (Audio)")
        popup.menu.add(0, 2, 1, "Play with 3D Spatial Audio")
        popup.menu.add(0, 3, 2, "Download Video (Offline MP4)")
        popup.menu.add(0, 4, 3, "Share Video Link")

        popup.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                1 -> {
                    // Silent play
                    onItemClick(item)
                    true
                }
                2 -> {
                    // Silent play
                    onItemClick(item)
                    true
                }
                3 -> {
                    YouTubeDownloaderHelper.downloadVideo(context, item)
                    true
                }
                4 -> {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, item.title)
                        putExtra(Intent.EXTRA_TEXT, "Watch '${item.title}' on Multimedia Native YouTube: https://youtu.be/${item.id}")
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share Video"))
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    fun getItems(): List<YouTubeVideo> = items

    override fun getItemCount(): Int = items.size

    class VideoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivThumbnail: ImageView = itemView.findViewById(R.id.ivYtThumbnail)
        val tvDuration: TextView = itemView.findViewById(R.id.tvYtDuration)
        val ivChannelAvatar: ImageView = itemView.findViewById(R.id.ivYtChannelAvatar)
        val tvTitle: TextView = itemView.findViewById(R.id.tvYtTitle)
        val tvSubtitle: TextView = itemView.findViewById(R.id.tvYtSubtitle)
        val btnMore: ImageButton = itemView.findViewById(R.id.btnYtMore)
    }
}

typealias YouTubeAdapter = YouTubeFeedAdapter
