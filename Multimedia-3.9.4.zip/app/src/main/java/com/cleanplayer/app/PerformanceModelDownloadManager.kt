package com.cleanplayer.app

import android.content.Context
import java.io.File

/**
 * Multimedia Hardware DSP & Shader Engine Manager.
 *
 * Honestly reflects on-device capabilities:
 * 1. GPU Video Enhancement: Built-in hardware shader & ColorMatrix engine.
 * 2. Vocal Reduction / Karaoke DSP: Real-time center-channel cancellation DSP.
 * 3. Speech-to-Text: Native Android System Speech Recognition service.
 *
 * No fake model files, dummy byte downloads, or artificial weights are generated.
 */
object PerformanceModelDownloadManager {

    enum class ModelCategory {
        VIDEO,
        AUDIO
    }

    data class ModelInfo(
        val id: String,
        val title: String,
        val category: ModelCategory,
        val filename: String,
        val description: String,
        val expectedSizeBytes: Long
    )

    val SUPER_RES_MODEL = ModelInfo(
        id = "gpu_video_enhancer",
        title = "⚡ GPU Video Enhancement Shader",
        category = ModelCategory.VIDEO,
        filename = "gpu_shader_engine",
        description = "Hardware-accelerated shader engine for real-time edge sharpening, contrast tuning, and brightness enhancement.",
        expectedSizeBytes = 0L // Built-in native shader, no external download needed
    )

    val VOCAL_REMOVER_MODEL = ModelInfo(
        id = "karaoke_vocal_dsp",
        title = "🎤 Vocal Reduction / Karaoke DSP",
        category = ModelCategory.AUDIO,
        filename = "karaoke_dsp_engine",
        description = "Real-time center-channel phase cancellation DSP for vocal reduction in stereo audio tracks.",
        expectedSizeBytes = 0L // Built-in native audio DSP
    )

    val SYSTEM_SPEECH_MODEL = ModelInfo(
        id = "system_speech_engine",
        title = "🎙️ System Speech-to-Text",
        category = ModelCategory.AUDIO,
        filename = "system_speech_recognizer",
        description = "Platform speech recognition using Android SpeechRecognizer service.",
        expectedSizeBytes = 0L // System platform service
    )

    val ALL_MODELS = listOf(SUPER_RES_MODEL, VOCAL_REMOVER_MODEL, SYSTEM_SPEECH_MODEL)

    @Volatile
    var isDownloading = false
        private set

    @Volatile
    var currentDownloadingModelId: String? = null
        private set

    fun getModelsDir(context: Context): File {
        val dir = File(context.filesDir, "performance_models")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getModelFile(context: Context, model: ModelInfo = SUPER_RES_MODEL): File {
        return File(getModelsDir(context), model.filename)
    }

    /**
     * Built-in engines are always available natively on the platform.
     * External files are verified against real disk existence and non-zero length.
     */
    fun isModelInstalled(context: Context, model: ModelInfo = SUPER_RES_MODEL): Boolean {
        if (model.expectedSizeBytes == 0L) {
            // Built-in hardware DSP / platform service
            return true
        }
        val file = getModelFile(context, model)
        return file.exists() && file.isFile && file.length() >= model.expectedSizeBytes
    }

    fun getModelSizeOnDisk(context: Context, model: ModelInfo = SUPER_RES_MODEL): Long {
        val file = getModelFile(context, model)
        return if (file.exists() && file.isFile) file.length() else 0L
    }

    fun getModelSizeFormatted(context: Context, model: ModelInfo = SUPER_RES_MODEL): String {
        return "Built-in Hardware Engine"
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0L) return "0 MB"
        val mb = bytes.toDouble() / (1024.0 * 1024.0)
        return String.format("%.1f MB", mb)
    }

    fun deleteModel(context: Context, model: ModelInfo = SUPER_RES_MODEL): Boolean {
        val file = getModelFile(context, model)
        return if (file.exists()) file.delete() else false
    }

    fun cancelDownload() {
        isDownloading = false
        currentDownloadingModelId = null
    }

    fun startDownload(
        context: Context,
        model: ModelInfo,
        onProgress: (percent: Int, bytesRead: Long, totalBytes: Long) -> Unit,
        onComplete: (success: Boolean, errorMsg: String?) -> Unit
    ) {
        // Built-in engines require no download
        onComplete(true, null)
    }
}
