package com.cleanplayer.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Process
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.Executors

/**
 * Global Application Class for Multimedia.
 * Asynchronously initializes NewPipeExtractor engine with HTTP disk cache, ImageLoader 2-tier disk cache, and Crash Guard.
 */
class MultimediaApp : Application() {

    companion object {
        lateinit var instance: MultimediaApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Attach Resilient Exception Crash Guard with Crash-Loop Prevention
        setupCrashGuard()

        // High-Performance Asynchronous Engine & Cache Warmup:
        // Offloads heavy disk I/O, OkHttpClient construction, SSL context setup,
        // and NewPipe localization from the main thread.
        // This ensures the main UI thread never blocks during cold start.
        Executors.newSingleThreadExecutor().execute {
            try {
                ImageLoaderHelper.init(this)
                DownloaderImpl.init(cacheDir = cacheDir)
                YouTubeStreamResolver.initNewPipe(this)
                DynamicExtractorOtaEngine.initialize(this)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    private fun setupCrashGuard() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                val pw = PrintWriter(sw)
                throwable.printStackTrace(pw)
                val stackTraceStr = sw.toString()

                Log.e("MultimediaCrashGuard", "Intercepted uncaught exception: ${throwable.localizedMessage}\n$stackTraceStr")

                // Persist crash dump to disk for user/developer diagnostics without masking
                try {
                    val crashFile = File(filesDir, "last_crash_report.txt")
                    crashFile.writeText("Time: ${System.currentTimeMillis()}\nThread: ${thread.name}\nException: ${throwable.javaClass.name}\nMessage: ${throwable.message}\n\nStack:\n$stackTraceStr")
                } catch (e: Throwable) {}

                // Crash-Loop Protection:
                // If more than 1 crash happens within 15 seconds, avoid repeated restart loop!
                val prefs = getSharedPreferences("cleanplayer_crash_tracker", Context.MODE_PRIVATE)
                val lastCrashTime = prefs.getLong("last_crash_timestamp", 0L)
                val crashCount = prefs.getInt("crash_count", 0)
                val now = System.currentTimeMillis()

                val newCrashCount = if (now - lastCrashTime < 15_000L) crashCount + 1 else 1
                prefs.edit()
                    .putLong("last_crash_timestamp", now)
                    .putInt("crash_count", newCrashCount)
                    .commit()

                if (newCrashCount <= 1) {
                    // First crash: attempt clean safe restart
                    val restartIntent = Intent(applicationContext, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    }
                    startActivity(restartIntent)
                    Process.killProcess(Process.myPid())
                    System.exit(10)
                } else {
                    // Crash loop detected: do not restart blindly; let OS handle termination cleanly
                    defaultHandler?.uncaughtException(thread, throwable)
                }
            } catch (e: Throwable) {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }
}
