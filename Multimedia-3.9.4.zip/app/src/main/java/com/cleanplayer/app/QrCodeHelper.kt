package com.cleanplayer.app

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.util.EnumMap

object QrCodeHelper {

    /**
     * Generates a standard Wi-Fi QR Code Bitmap for WebShare (and standard Wi-Fi connection).
     * Strictly contains ONLY the standard Wi-Fi connection payload:
     * Specification: WIFI:T:WPA;S:<SSID>;P:<PASSWORD>;;
     * Or for open network: WIFI:T:nopass;S:<SSID>;;
     * NEVER includes HTTP host or port metadata.
     */
    fun generateWifiQrCode(
        ssid: String,
        password: String,
        width: Int = 512,
        height: Int = 512
    ): Bitmap? {
        if (ssid.isBlank()) return null
        val payload = if (password.isNotBlank()) {
            "WIFI:T:WPA;S:$ssid;P:$password;;"
        } else {
            "WIFI:T:nopass;S:$ssid;;"
        }
        return generateQrBitmap(payload, width, height)
    }

    /**
     * Generates a Wi-Fi QR Code Bitmap with Multimedia FastShare P2P Host IP/Port metadata.
     * Specification: WIFI:T:WPA;S:<SSID>;P:<PASSWORD>;H:<IP>;PORT:<PORT>;;
     * Used exclusively for Multimedia-to-Multimedia FastShare P2P high-speed transfer.
     */
    fun generateWifiQrCodeWithHost(
        ssid: String,
        password: String,
        hostIp: String? = null,
        port: Int = 8988,
        width: Int = 512,
        height: Int = 512
    ): Bitmap? {
        if (ssid.isBlank()) return null
        val authType = if (password.isNotBlank()) "WPA" else "nopass"
        val ipPart = if (!hostIp.isNullOrBlank()) "H:$hostIp;PORT:$port;" else ""
        val payload = if (password.isNotBlank()) {
            "WIFI:T:$authType;S:$ssid;P:$password;${ipPart};"
        } else {
            "WIFI:T:nopass;S:$ssid;${ipPart};"
        }
        return generateQrBitmap(payload, width, height)
    }

    /**
     * Generates a raw QR Code bitmap for arbitrary text/URLs (e.g. WebShare URL QR).
     */
    fun generateQrBitmap(content: String, width: Int = 512, height: Int = 512): Bitmap? {
        return try {
            val hints = EnumMap<EncodeHintType, Any>(EncodeHintType::class.java).apply {
                put(EncodeHintType.CHARACTER_SET, "UTF-8")
                put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M)
                put(EncodeHintType.MARGIN, 2)
            }

            val writer = QRCodeWriter()
            val bitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, width, height, hints)
            val matrixWidth = bitMatrix.width
            val matrixHeight = bitMatrix.height
            val pixels = IntArray(matrixWidth * matrixHeight)

            for (y in 0 until matrixHeight) {
                val offset = y * matrixWidth
                for (x in 0 until matrixWidth) {
                    pixels[offset + x] = if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE
                }
            }

            val bitmap = Bitmap.createBitmap(matrixWidth, matrixHeight, Bitmap.Config.ARGB_8888)
            bitmap.setPixels(pixels, 0, matrixWidth, 0, 0, matrixWidth, matrixHeight)
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
