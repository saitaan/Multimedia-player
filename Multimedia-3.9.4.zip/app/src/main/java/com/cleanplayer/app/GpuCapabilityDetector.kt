package com.cleanplayer.app

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ConfigurationInfo
import android.os.Build

/**
 * Hardware GPU capability detector for OpenGL ES and hardware video acceleration.
 */
object GpuCapabilityDetector {

    data class GpuProfile(
        val gpuRenderer: String = "Adreno / Mali GPU",
        val recommendedProfile: String = "High Performance"
    )

    fun isGpuEnhancementSupported(context: Context): Boolean {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val configInfo: ConfigurationInfo? = am?.deviceConfigurationInfo
            val glVersion = configInfo?.reqGlEsVersion ?: 0
            glVersion >= 0x00020000 // OpenGL ES 2.0+
        } catch (_: Throwable) {
            true
        }
    }

    fun getProfile(context: Context): GpuProfile {
        val renderer = Build.HARDWARE.ifBlank { "Standard GPU" }
        return GpuProfile(
            gpuRenderer = renderer,
            recommendedProfile = "60 FPS Boost"
        )
    }
}
