package com.cleanplayer.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView

/**
 * Interactive Dialog for Tuning Real GPU Video & HDR Boost Parameters:
 * - Scale Profile (2x Balanced Profile, 3x Enhanced Profile, 4x Ultra Cinema Profile)
 * - Spatial Edge-Adaptive Sharpening (0% to 100%)
 * - Localized Micro-Contrast Boost (0% to 100%)
 * - Edge-Preserving Bilateral Denoise (0% to 100%)
 *
 * Runs live on the OpenGL ES fragment shader pipeline.
 */
object SuperResTuneDialog {

    fun show(context: Context, onUpdated: (() -> Unit)? = null) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_super_res_tuning, null)
        val dialog = AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val btnClose = view.findViewById<ImageButton>(R.id.btnSuperResTuneClose)
        val tvHwProfile = view.findViewById<TextView>(R.id.tvSuperResHardwareProfile)

        val prof = GpuCapabilityDetector.getProfile(context)
        val shortRenderer = if (prof.gpuRenderer.length > 20) prof.gpuRenderer.take(20) + "…" else prof.gpuRenderer
        tvHwProfile?.text = "$shortRenderer • OpenGL ES • ${prof.recommendedProfile}"

        val btnScale2x = view.findViewById<TextView>(R.id.btnScale2x)
        val btnScale3x = view.findViewById<TextView>(R.id.btnScale3x)
        val btnScale4x = view.findViewById<TextView>(R.id.btnScale4x)

        val tvValSharpness = view.findViewById<TextView>(R.id.tvValSharpness)
        val sbSharpness = view.findViewById<SeekBar>(R.id.sbSharpness)

        val tvValContrast = view.findViewById<TextView>(R.id.tvValContrast)
        val sbContrast = view.findViewById<SeekBar>(R.id.sbContrast)

        val tvValDeNoise = view.findViewById<TextView>(R.id.tvValDeNoise)
        val sbDeNoise = view.findViewById<SeekBar>(R.id.sbDeNoise)

        val btnReset = view.findViewById<Button>(R.id.btnResetSuperResDefaults)
        val btnApply = view.findViewById<Button>(R.id.btnApplySuperResTuning)

        fun updateScaleButtons() {
            val scale = PlayerHolder.superResScaleFactor
            btnScale2x?.setBackgroundResource(if (scale == 2) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            btnScale2x?.setTextColor(if (scale == 2) Color.BLACK else Color.WHITE)

            btnScale3x?.setBackgroundResource(if (scale == 3) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            btnScale3x?.setTextColor(if (scale == 3) Color.BLACK else Color.WHITE)

            btnScale4x?.setBackgroundResource(if (scale == 4) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            btnScale4x?.setTextColor(if (scale == 4) Color.BLACK else Color.WHITE)
        }

        fun updateUiFromState() {
            updateScaleButtons()
            sbSharpness?.progress = PlayerHolder.superResSharpness
            tvValSharpness?.text = "${PlayerHolder.superResSharpness}%"

            sbContrast?.progress = PlayerHolder.superResMicroContrast
            tvValContrast?.text = "${PlayerHolder.superResMicroContrast}%"

            sbDeNoise?.progress = PlayerHolder.superResDeNoise
            tvValDeNoise?.text = "${PlayerHolder.superResDeNoise}%"
        }

        updateUiFromState()

        btnScale2x?.setOnClickListener {
            PlayerHolder.superResScaleFactor = 2
            updateScaleButtons()
            SuperResolutionEngine.applyHardwareEnhancement(context, true)
            onUpdated?.invoke()
        }

        btnScale3x?.setOnClickListener {
            PlayerHolder.superResScaleFactor = 3
            updateScaleButtons()
            SuperResolutionEngine.applyHardwareEnhancement(context, true)
            onUpdated?.invoke()
        }

        btnScale4x?.setOnClickListener {
            PlayerHolder.superResScaleFactor = 4
            updateScaleButtons()
            SuperResolutionEngine.applyHardwareEnhancement(context, true)
            onUpdated?.invoke()
        }

        sbSharpness?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val p = progress.coerceIn(0, 100)
                    PlayerHolder.superResSharpness = p
                    tvValSharpness?.text = "$p%"
                    SuperResolutionEngine.applyHardwareEnhancement(context, true)
                    onUpdated?.invoke()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        sbContrast?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val p = progress.coerceIn(0, 100)
                    PlayerHolder.superResMicroContrast = p
                    tvValContrast?.text = "$p%"
                    SuperResolutionEngine.applyHardwareEnhancement(context, true)
                    onUpdated?.invoke()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        sbDeNoise?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val p = progress.coerceIn(0, 100)
                    PlayerHolder.superResDeNoise = p
                    tvValDeNoise?.text = "$p%"
                    SuperResolutionEngine.applyHardwareEnhancement(context, true)
                    onUpdated?.invoke()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnReset?.setOnClickListener {
            PlayerHolder.superResScaleFactor = 4
            PlayerHolder.superResSharpness = 80
            PlayerHolder.superResMicroContrast = 75
            PlayerHolder.superResDeNoise = 70
            PlayerHolder.savePreferences(context)
            updateUiFromState()
            SuperResolutionEngine.applyHardwareEnhancement(context, true)
            CleanToast.show(context, "Defaults Restored: Ultra Profile • 80% Sharpness • 75% Contrast")
            onUpdated?.invoke()
        }

        btnApply?.setOnClickListener {
            PlayerHolder.savePreferences(context)
            SuperResolutionEngine.applyHardwareEnhancement(context, true)
            CleanToast.show(context, "🎬 GPU Video & HDR Boost applied: ${if (PlayerHolder.superResScaleFactor == 4) "Ultra" else if (PlayerHolder.superResScaleFactor == 3) "Enhanced" else "Balanced"} • ${PlayerHolder.superResSharpness}% Sharpness")
            dialog.dismiss()
        }

        btnClose?.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }
}
