package com.cleanplayer.app

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp

/**
 * Real-time stereo vocal-reduction processor for Media3 PCM output.
 *
 * The previous implementation used a broad EQ cut over the vocal frequency
 * range. That also removed centered drums, bass, guitars and other music.
 * This processor instead attenuates the common (center) component only in the
 * vocal-focused mid band, while retaining the stereo side component and the
 * low/high center content.
 *
 * This is still source-separation by phase/center cancellation, not an ML stem
 * separator. It is intentionally conservative so the backing track remains
 * musical instead of sounding hollow.
 */
@androidx.media3.common.util.UnstableApi
class KaraokeAudioProcessor : BaseAudioProcessor() {

    private var sampleRate = 44100
    private var channelCount = 2
    private var lowState = 0f
    private var highState = 0f
    private var lowAlpha = 0f
    private var highAlpha = 0f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.channelCount != 2) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT &&
            inputAudioFormat.encoding != C.ENCODING_PCM_FLOAT) {
            return AudioProcessor.AudioFormat.NOT_SET
        }

        sampleRate = inputAudioFormat.sampleRate
        channelCount = inputAudioFormat.channelCount
        lowAlpha = onePoleAlpha(180f, sampleRate)
        highAlpha = onePoleAlpha(7000f.coerceAtMost(sampleRate * 0.45f), sampleRate)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val bytes = inputBuffer.remaining()
        if (bytes <= 0 || channelCount != 2) return

        val output = replaceOutputBuffer(bytes).order(ByteOrder.nativeOrder())
        val input = inputBuffer.duplicate().order(ByteOrder.nativeOrder())
        val enabled = PlayerHolder.isKaraokeEnabled

        if (!enabled) {
            output.put(input)
            inputBuffer.position(inputBuffer.limit())
            output.flip()
            return
        }

        if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT) {
            while (input.remaining() >= 4) {
                val left = input.short.toFloat() / 32768f
                val right = input.short.toFloat() / 32768f
                val (outLeft, outRight) = processFrame(left, right)
                output.putShort((outLeft * 32767f).coerceIn(-32768f, 32767f).toInt().toShort())
                output.putShort((outRight * 32767f).coerceIn(-32768f, 32767f).toInt().toShort())
            }
        } else {
            while (input.remaining() >= 8) {
                val left = input.float
                val right = input.float
                val (outLeft, outRight) = processFrame(left, right)
                output.putFloat(outLeft.coerceIn(-1f, 1f))
                output.putFloat(outRight.coerceIn(-1f, 1f))
            }
        }

        inputBuffer.position(inputBuffer.limit())
        output.flip()
    }

    override fun onFlush(streamMetadata: AudioProcessor.StreamMetadata) {
        lowState = 0f
        highState = 0f
    }

    override fun onReset() {
        lowState = 0f
        highState = 0f
    }

    private fun processFrame(left: Float, right: Float): Pair<Float, Float> {
        val center = (left + right) * 0.5f
        val side = (left - right) * 0.5f

        // Band-pass approximation of the vocal-heavy center content:
        // LP(7kHz) - LP(180Hz). Bass and very-high-frequency center content stay.
        lowState += lowAlpha * (center - lowState)
        highState += highAlpha * (center - highState)
        val vocalBand = highState - lowState

        // Conservative reduction. Strong enough to reduce a centered vocal,
        // but avoids the destructive full-band EQ used previously.
        val reducedCenter = center - vocalBand * 0.82f

        return Pair(side + reducedCenter, -side + reducedCenter)
    }

    private fun onePoleAlpha(cutoffHz: Float, rate: Int): Float {
        if (rate <= 0) return 1f
        return (1f - exp((-2.0 * PI * cutoffHz / rate).toFloat())).coerceIn(0.001f, 1f)
    }
}
