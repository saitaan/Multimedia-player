package com.cleanplayer.app

import android.content.Context
import android.util.Log
import androidx.media3.common.Effect
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.exoplayer.ExoPlayer

/**
 * Real Media3 GPU video-effect controller.
 *
 * Media3's setVideoEffects() runs effects through the video-frame OpenGL pipeline.
 * This controller deliberately uses documented effects instead of claiming ML or
 * neural super-resolution that is not actually present in the app.
 */
@OptIn(androidx.media3.common.util.UnstableApi::class)
object GpuEffectController {
    private const val TAG = "GpuEffectController"

    fun attachToExoPlayer(player: ExoPlayer, context: Context) {
        apply(player, context)
    }

    fun updateLiveSettings(context: Context) {
        PlayerHolder.videoExoPlayer?.let { apply(it, context) }
        YouTubeExoPlayerManager.exoPlayer?.let { apply(it, context) }
    }

    private fun apply(player: ExoPlayer, context: Context) {
        try {
            val effects = buildEffects()
            player.setVideoEffects(effects)
        } catch (t: Throwable) {
            Log.e(TAG, "Unable to apply Media3 GPU effects", t)
        }
    }

    private fun buildEffects(): List<Effect> {
        val enabled = PlayerHolder.isVideoSharpnessEnabled || PlayerHolder.isSuperResEnabled
        if (!enabled && !PlayerHolder.isNightVisionEnabled) return emptyList()

        val effects = mutableListOf<Effect>()

        if (PlayerHolder.isVideoSharpnessEnabled || PlayerHolder.isSuperResEnabled) {
            // Media3 Contrast is a real per-frame OpenGL effect. Keep the value
            // conservative so HDR content is enhanced without crushing highlights.
            // Conservative contrast enhancement that preserves natural black levels and avoids shadow tinting
            val contrast = (((PlayerHolder.superResMicroContrast - 50) / 100f) * 0.20f)
                .coerceIn(-0.12f, 0.15f)
            if (kotlin.math.abs(contrast) > 0.005f) {
                effects += Contrast(contrast)
            }

            // Subtle saturation adjustment to prevent posterization and skin-tone oversaturation
            val saturation = ((PlayerHolder.superResSharpness - 50) * 0.25f)
                .coerceIn(-10f, 12f)
            if (kotlin.math.abs(saturation) > 0.05f) {
                effects += HslAdjustment.Builder()
                    .adjustSaturation(saturation)
                    .build()
            }
        }

        if (PlayerHolder.isNightVisionEnabled) {
            effects += HslAdjustment.Builder()
                .adjustLightness(12f)
                .build()
        }

        return effects
    }
}
