package com.cleanplayer.app

import android.content.Context
import android.util.Log
import androidx.media3.common.Effect
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.exoplayer.ExoPlayer

/**
 * Real Media3 GPU video-effect controller.
 *
 * Media3's setVideoEffects() runs effects through the video-frame OpenGL pipeline.
 * This controller deliberately uses documented effects instead of claiming ML or
 * neural super-resolution that is not actually present in the app.
 */
@OptIn(androidx.media3.common.util.UnstableApi::class)
object GpuEffectController {
    private const val TAG = "GpuEffectController"

    fun attachToExoPlayer(player: ExoPlayer, context: Context) {
        apply(player, context)
    }

    fun updateLiveSettings(context: Context) {
        PlayerHolder.videoExoPlayer?.let { apply(it, context) }
        YouTubeExoPlayerManager.exoPlayer?.let { apply(it, context) }
    }

    private fun apply(player: ExoPlayer, context: Context) {
        try {
            val effects = buildEffects()
            player.setVideoEffects(effects)
        } catch (t: Throwable) {
            Log.e(TAG, "Unable to apply Media3 GPU effects", t)
        }
    }

    private fun buildEffects(): List<Effect> {
        val enabled = PlayerHolder.isVideoSharpnessEnabled || PlayerHolder.isSuperResEnabled
        if (!enabled && !PlayerHolder.isNightVisionEnabled) return emptyList()

        val effects = mutableListOf<Effect>()

        if (PlayerHolder.isVideoSharpnessEnabled || PlayerHolder.isSuperResEnabled) {
            // Media3 Contrast is a real per-frame OpenGL effect. Keep the value
            // conservative so HDR content is enhanced without crushing highlights.
            val contrast = (((PlayerHolder.superResMicroContrast - 50) / 100f) * 0.65f)
                .coerceIn(-0.35f, 0.35f)
            if (kotlin.math.abs(contrast) > 0.001f) {
                effects += Contrast(contrast)
            }

            // HSL saturation is another real GPU frame effect. The slider maps
            // 0..100 to a restrained -20..+30 range around neutral.
            val saturation = ((PlayerHolder.superResSharpness - 50) * 0.6f)
                .coerceIn(-20f, 30f)
            if (kotlin.math.abs(saturation) > 0.01f) {
                effects += HslAdjustment.Builder()
                    .adjustSaturation(saturation)
                    .build()
            }
        }

        if (PlayerHolder.isNightVisionEnabled) {
            effects += HslAdjustment.Builder()
                .adjustLightness(12f)
                .build()
        }

        return effects
    }
}
