package com.cleanplayer.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Dynamic Cipher Self-Healing Mechanism
 * Maintains offline-first decipher regex patterns, n-sig transforms, and client spoofing configurations,
 * with background over-the-air (OTA) sync capability to heal YouTube backend signature changes
 * without requiring an APK update.
 */
object CipherSelfHealingResolver {

    private val executor = Executors.newSingleThreadExecutor()

    private const val DEFAULT_DECIPHER_REGEX = "([a-zA-Z0-9$]+)&&\\s*\\1\\.set\\([^,]+\\s*,\\s*encodeURIComponent\\s*\\(\\s*([a-zA-Z0-9$]+)"
    private const val DEFAULT_N_SIG_REGEX = "\\.get\\(\"n\"\\)\\)&&\\(b=([a-zA-Z0-9$]+)(?:\\[(\\d+)\\])?\\([a-zA-Z0-9$]+\\)"

    @Volatile
    var activeDecipherRegex: String = DEFAULT_DECIPHER_REGEX
        private set

    @Volatile
    var activeNSigRegex: String = DEFAULT_N_SIG_REGEX
        private set

    @Volatile
    var lastSyncTimestamp: Long = 0L
        private set

    fun getDecipherPattern(): Regex {
        return try {
            Regex(activeDecipherRegex)
        } catch (e: Exception) {
            Regex(DEFAULT_DECIPHER_REGEX)
        }
    }

    fun getNSigPattern(): Regex {
        return try {
            Regex(activeNSigRegex)
        } catch (e: Exception) {
            Regex(DEFAULT_N_SIG_REGEX)
        }
    }

    fun syncRulesIfStale() {
        val now = System.currentTimeMillis()
        if (now - lastSyncTimestamp < 6 * 60 * 60 * 1000L) {
            return
        }

        executor.execute {
            try {
                val mirrorUrls = listOf(
                    "https://raw.githubusercontent.com/TeamNewPipe/NewPipeExtractor/dev/extractor/src/main/resources/youtube/decipher.json",
                    "https://cdn.jsdelivr.net/gh/TeamNewPipe/NewPipeExtractor@dev/extractor/src/main/resources/youtube/decipher.json"
                )

                for (url in mirrorUrls) {
                    try {
                        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 3000
                            readTimeout = 3000
                            setRequestProperty("User-Agent", "Mozilla/5.0 CleanPlayer-CipherHealer/1.0")
                        }
                        if (conn.responseCode == 200) {
                            val body = conn.inputStream.bufferedReader().use { it.readText() }
                            val json = JSONObject(body)
                            val decipher = json.optString("decipher_regex", "")
                            val nSig = json.optString("n_sig_regex", "")

                            if (decipher.isNotBlank()) activeDecipherRegex = decipher
                            if (nSig.isNotBlank()) activeNSigRegex = nSig
                            lastSyncTimestamp = System.currentTimeMillis()
                            break
                        }
                    } catch (e: Exception) {}
                }
            } catch (e: Exception) {}
        }
    }
}
