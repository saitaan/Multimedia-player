package com.cleanplayer.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

class LiveBitrateGraphView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33FFFFFF")
        strokeWidth = 1.5f
        style = Paint.Style.STROKE
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CCCCCC")
        textSize = 24f
    }

    private val inputLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF4081") // Pink/Red input curve
        strokeWidth = 3.5f
        style = Paint.Style.STROKE
    }

    private val demuxLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF") // Cyan demux curve
        strokeWidth = 3.5f
        style = Paint.Style.STROKE
    }

    var isMonochrome: Boolean = false
        set(value) {
            field = value
            if (value) {
                inputLinePaint.color = Color.WHITE
                demuxLinePaint.color = Color.parseColor("#8E8E93")
                textPaint.color = Color.parseColor("#8E8E93")
            } else {
                inputLinePaint.color = Color.parseColor("#FF4081")
                demuxLinePaint.color = Color.parseColor("#00E5FF")
                textPaint.color = Color.parseColor("#CCCCCC")
            }
            invalidate()
        }

    private val maxPoints = 20
    private val inputHistory = FloatArray(maxPoints) { 0.5f }
    private val demuxHistory = FloatArray(maxPoints) { 0.4f }

    private val inputPath = Path()
    private val demuxPath = Path()

    fun updateMetrics(inputRatio: Float, demuxRatio: Float) {
        // Shift left
        for (i in 0 until maxPoints - 1) {
            inputHistory[i] = inputHistory[i + 1]
            demuxHistory[i] = demuxHistory[i + 1]
        }
        inputHistory[maxPoints - 1] = inputRatio.coerceIn(0.1f, 0.95f)
        demuxHistory[maxPoints - 1] = demuxRatio.coerceIn(0.1f, 0.95f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        val paddingLeft = 100f
        val paddingRight = 20f
        val paddingTop = 20f
        val paddingBottom = 40f

        val graphW = w - paddingLeft - paddingRight
        val graphH = h - paddingTop - paddingBottom

        // Draw Horizontal Grid Lines & Labels
        val yTop = paddingTop + graphH * 0.15f
        val yMid = paddingTop + graphH * 0.55f
        val yBot = paddingTop + graphH * 0.95f

        canvas.drawLine(paddingLeft, yTop, w - paddingRight, yTop, gridPaint)
        canvas.drawText("910 kb/s", 10f, yTop + 8f, textPaint)

        canvas.drawLine(paddingLeft, yMid, w - paddingRight, yMid, gridPaint)
        canvas.drawText("500 kb/s", 10f, yMid + 8f, textPaint)

        canvas.drawLine(paddingLeft, yBot, w - paddingRight, yBot, gridPaint)

        // Draw Vertical Grid Lines & Time Labels
        val timeLabels = arrayOf("-4s", "-3s", "-2s", "-1s")
        for (i in timeLabels.indices) {
            val x = paddingLeft + (i + 1) * (graphW / 5f)
            canvas.drawLine(x, paddingTop, x, yBot, gridPaint)
            canvas.drawText(timeLabels[i], x - 18f, h - 8f, textPaint)
        }

        // Draw Curves
        inputPath.reset()
        demuxPath.reset()

        val stepX = graphW / (maxPoints - 1)

        for (i in 0 until maxPoints) {
            val x = paddingLeft + i * stepX
            val yIn = paddingTop + graphH * (1.0f - inputHistory[i])
            val yDe = paddingTop + graphH * (1.0f - demuxHistory[i])

            if (i == 0) {
                inputPath.moveTo(x, yIn)
                demuxPath.moveTo(x, yDe)
            } else {
                inputPath.lineTo(x, yIn)
                demuxPath.lineTo(x, yDe)
            }
        }

        canvas.drawPath(inputPath, inputLinePaint)
        canvas.drawPath(demuxPath, demuxLinePaint)
    }
}
