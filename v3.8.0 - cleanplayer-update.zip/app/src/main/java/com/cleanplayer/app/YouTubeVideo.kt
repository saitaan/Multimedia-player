package com.cleanplayer.app

import java.io.Serializable

data class YouTubeVideo(
    val id: String,
    val title: String,
    val channelTitle: String,
    val channelAvatarUrl: String? = null,
    val thumbnailUrl: String,
    val duration: String = "00:00",
    val views: String = "0 views",
    val uploadDate: String = "Recently",
    val streamUrl: String? = null,
    val description: String? = null,
    val category: String = "All",
    val likes: String = "15K",
    val commentsCount: String = "234",
    val isShort: Boolean = false
) : Serializable

typealias YouTubeItem = YouTubeVideo
