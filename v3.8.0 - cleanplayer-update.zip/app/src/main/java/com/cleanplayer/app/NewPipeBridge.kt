package com.cleanplayer.app

import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.services.youtube.extractors.YoutubeStreamExtractor
import org.schabi.newpipe.extractor.stream.StreamInfoItem

/**
 * TeamNewPipe Extractor Native Bridge
 */
class NewPipeBridge : VideoExtractorBridge {

    override val engineId: String = "newpipe"
    override val displayName: String = "NewPipe Extractor"
    override val description: String = "Direct scraping engine via TeamNewPipe Extractor"

    override fun extract(videoId: String, authToken: String?): VideoExtractionResult? {
        return try {
            DownloaderImpl.getInstance()
            val service = ServiceList.YouTube
            val extractor = service.getStreamExtractor("https://www.youtube.com/watch?v=$videoId") as? YoutubeStreamExtractor
                ?: return null

            extractor.fetchPage()

            val formatList = mutableListOf<VideoStreamFormat>()
            val videoStreams = extractor.videoStreams
            if (videoStreams != null) {
                for (s in videoStreams) {
                    val url = s.content ?: continue
                    val res = s.resolution ?: "360p"
                    val height = res.replace("p", "").toIntOrNull() ?: 360
                    formatList.add(VideoStreamFormat(res, height, url))
                }
            }

            val audioStreams = extractor.audioStreams
            val bestAudioUrl = audioStreams?.firstOrNull()?.content

            if (formatList.isEmpty()) return null

            formatList.sortByDescending { it.resolution }
            val bestUrl = formatList.first().url

            VideoExtractionResult(
                bestStreamUrl = bestUrl,
                formats = formatList,
                dashManifestUrl = extractor.dashMpdUrl,
                hlsManifestUrl = extractor.hlsUrl,
                engineName = "NewPipe Extractor",
                isUnthrottled = true,
                audioStreamUrl = bestAudioUrl
            )
        } catch (e: Exception) {
            null
        }
    }
}
