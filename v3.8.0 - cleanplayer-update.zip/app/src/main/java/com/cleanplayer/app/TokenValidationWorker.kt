package com.cleanplayer.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/**
 * Proactive WorkManager Background Worker
 * Preemptively validates and refreshes MicroG OAuth tokens before user opens the app or initiates streaming,
 * eliminating runtime token mismatch and expiration errors.
 */
class TokenValidationWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            if (MicroGAuthManager.isLoggedIn(context)) {
                val token = MicroGAuthManager.getOAuthToken(context)
                if (token.isNullOrBlank()) {
                    MicroGAuthManager.invalidateAndRefreshToken(context)
                } else {
                    MicroGAuthManager.syncAccountsFromSystem(context)
                }
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val UNIQUE_WORK_NAME = "CleanPlayerTokenValidationWork"

        fun schedule(context: Context) {
            try {
                val constraints = Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()

                val workRequest = PeriodicWorkRequestBuilder<TokenValidationWorker>(
                    6, TimeUnit.HOURS,
                    30, TimeUnit.MINUTES
                )
                    .setConstraints(constraints)
                    .build()

                WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                    UNIQUE_WORK_NAME,
                    ExistingPeriodicWorkPolicy.KEEP,
                    workRequest
                )
            } catch (e: Exception) {}
        }
    }
}
