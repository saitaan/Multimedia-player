package com.cleanplayer.app

import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.downloader.Downloader
import org.schabi.newpipe.extractor.downloader.Request
import org.schabi.newpipe.extractor.downloader.Response
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * High-Performance OkHttp3 Downloader for NewPipeExtractor.
 * Implements connection pooling, redirect handling, and browser user-agent spoofing.
 */
class DownloaderImpl private constructor(private val client: OkHttpClient) : Downloader() {

    companion object {
        const val USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"

        @Volatile
        private var instance: DownloaderImpl? = null

        fun init(customClient: OkHttpClient? = null): DownloaderImpl {
            return instance ?: synchronized(this) {
                instance ?: DownloaderImpl(
                    customClient ?: OkHttpClient.Builder()
                        .connectTimeout(15, TimeUnit.SECONDS)
                        .readTimeout(20, TimeUnit.SECONDS)
                        .followRedirects(true)
                        .followSslRedirects(true)
                        .build()
                ).also { instance = it }
            }
        }

        fun getInstance(): DownloaderImpl {
            return instance ?: init()
        }
    }

    @Throws(IOException::class)
    override fun execute(request: Request): Response {
        val httpMethod = request.httpMethod()
        val url = request.url()
        val headers = request.headers()
        val dataToSend = request.dataToSend()

        val okHttpRequestBuilder = okhttp3.Request.Builder()
            .url(url)

        headers.forEach { (name, values) ->
            values.forEach { value ->
                okHttpRequestBuilder.addHeader(name, value)
            }
        }

        if (headers["User-Agent"].isNullOrEmpty()) {
            okHttpRequestBuilder.header("User-Agent", USER_AGENT)
        }

        val requestBody = dataToSend?.toRequestBody()
        okHttpRequestBuilder.method(httpMethod, requestBody)

        val okHttpResponse = client.newCall(okHttpRequestBuilder.build()).execute()
        val responseBody = okHttpResponse.body?.string() ?: ""
        val responseHeaders = mutableMapOf<String, List<String>>()
        okHttpResponse.headers.names().forEach { name ->
            responseHeaders[name] = okHttpResponse.headers(name)
        }

        return Response(
            okHttpResponse.code,
            okHttpResponse.message,
            responseHeaders,
            responseBody,
            okHttpResponse.request.url.toString()
        )
    }
}
