package com.cleanplayer.app

import android.net.Uri
import java.util.Locale

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val isVideo: Boolean,
    val artist: String? = null,
    val filePath: String? = null,
    val folderName: String = "Videos",
    val folderPath: String = ""
) {
    fun getFormattedDuration(): String {
        val totalSecs = durationMs / 1000
        val hours = totalSecs / 3600
        val mins = (totalSecs % 3600) / 60
        val secs = totalSecs % 60
        return if (hours > 0) {
            String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, mins, secs)
        } else {
            String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
        }
    }

    fun getFormattedSize(): String {
        val mb = sizeBytes.toDouble() / (1024 * 1024)
        return if (mb >= 1024) {
            String.format(Locale.getDefault(), "%.1f GB", mb / 1024.0)
        } else {
            String.format(Locale.getDefault(), "%.1f MB", mb)
        }
    }
}

data class MediaFolder(
    val folderName: String,
    val folderPath: String,
    val videos: MutableList<MediaItem> = mutableListOf()
) {
    val count: Int get() = videos.size
    val totalSizeBytes: Long get() = videos.sumOf { it.sizeBytes }

    fun getFormattedSize(): String {
        val mb = totalSizeBytes.toDouble() / (1024 * 1024)
        return if (mb >= 1024) {
            String.format(Locale.US, "%.1f GB", mb / 1024.0)
        } else {
            String.format(Locale.US, "%.1f MB", mb)
        }
    }
}
