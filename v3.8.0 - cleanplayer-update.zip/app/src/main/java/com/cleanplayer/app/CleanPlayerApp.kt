package com.cleanplayer.app

import android.app.Application
import android.content.Intent
import android.os.Process
import android.util.Log

/**
 * Global Application Class for CleanPlayer.
 * Initializes NewPipeExtractor engine with DownloaderImpl and attaches Crash Guard.
 */
class CleanPlayerApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // Initialize Official NewPipe Extractor
        try {
            DownloaderImpl.init()
            YouTubeStreamResolver.initNewPipe(this)
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        // Attach Global Exception Crash Guard
        setupCrashGuard()
    }

    private fun setupCrashGuard() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                Log.e("CleanPlayerCrashGuard", "Intercepted uncaught exception: " + throwable.localizedMessage, throwable)

                val restartIntent = Intent(applicationContext, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                startActivity(restartIntent)

                Process.killProcess(Process.myPid())
                System.exit(10)
            } catch (e: Throwable) {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }
}
