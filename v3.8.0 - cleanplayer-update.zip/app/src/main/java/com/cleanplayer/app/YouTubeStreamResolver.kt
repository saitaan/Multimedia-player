package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.util.concurrent.Executors

data class StreamQualityOption(
    val qualityLabel: String,
    val resolution: Int,
    val videoUrl: String,
    val audioUrl: String?
)

data class ResolvedYouTubeStream(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val videoUrl: String,
    val audioUrl: String?,
    val isMerged: Boolean,
    val qualityLabel: String,
    val resolution: Int,
    val availableQualities: List<StreamQualityOption>
)

/**
 * Native Ad-Free Stream Resolver using official TeamNewPipe NewPipeExtractor.
 * Extracts pure, untracked .mp4 (video) and .m4a (audio) stream URLs that contain zero ads.
 */
object YouTubeStreamResolver {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isInitialized = false

    fun initNewPipe(context: Context? = null) {
        if (!isInitialized) {
            synchronized(this) {
                if (!isInitialized) {
                    try {
                        NewPipe.init(DownloaderImpl.getInstance())
                        isInitialized = true
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    fun resolveStreams(
        videoId: String,
        preferredResolution: Int = 1080,
        callback: (ResolvedYouTubeStream?) -> Unit
    ) {
        initNewPipe()
        executor.execute {
            try {
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)
                val watchUrl = "https://www.youtube.com/watch?v=$videoId"
                val streamInfo = StreamInfo.getInfo(service, watchUrl)

                // 1. Extract best Audio stream (.m4a / audio/mp4 prioritized for ExoPlayer Media3)
                val audioStreams = streamInfo.audioStreams
                val bestAudioStream = audioStreams.maxByOrNull { it.averageBitrate }
                val bestAudioUrl = bestAudioStream?.content

                // 2. Extract Video streams (Both videoOnly 1080p/720p and muxed 720p/360p)
                val qualityOptions = mutableListOf<StreamQualityOption>()

                // Video-only high-res streams (1080p, 1440p, 2160p, 720p)
                for (vStream in streamInfo.videoOnlyStreams) {
                    val res = vStream.resolution?.replace("p", "")?.toIntOrNull() ?: 720
                    val label = vStream.resolution ?: "${res}p"
                    qualityOptions.add(
                        StreamQualityOption(
                            qualityLabel = label,
                            resolution = res,
                            videoUrl = vStream.content,
                            audioUrl = bestAudioUrl
                        )
                    )
                }

                // Fallback to muxed streams if videoOnly is empty
                if (qualityOptions.isEmpty()) {
                    for (vStream in streamInfo.videoStreams) {
                        val res = vStream.resolution?.replace("p", "")?.toIntOrNull() ?: 360
                        val label = vStream.resolution ?: "${res}p"
                        qualityOptions.add(
                            StreamQualityOption(
                                qualityLabel = label,
                                resolution = res,
                                videoUrl = vStream.content,
                                audioUrl = null
                            )
                        )
                    }
                }

                val distinctOptions = qualityOptions
                    .filter { it.videoUrl.isNotBlank() }
                    .distinctBy { it.qualityLabel }
                    .sortedByDescending { it.resolution }

                // Pick preferred or best available resolution
                val selectedOption = distinctOptions.firstOrNull { it.resolution <= preferredResolution } ?: distinctOptions.firstOrNull()

                if (selectedOption != null) {
                    val resolvedStream = ResolvedYouTubeStream(
                        videoId = videoId,
                        title = streamInfo.name ?: "YouTube Video",
                        channelTitle = streamInfo.uploaderName ?: "Creator",
                        videoUrl = selectedOption.videoUrl,
                        audioUrl = selectedOption.audioUrl,
                        isMerged = !selectedOption.audioUrl.isNullOrBlank(),
                        qualityLabel = selectedOption.qualityLabel,
                        resolution = selectedOption.resolution,
                        availableQualities = distinctOptions
                    )
                    mainHandler.post { callback(resolvedStream) }
                } else {
                    mainHandler.post { callback(null) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                mainHandler.post { callback(null) }
            }
        }
    }
}
