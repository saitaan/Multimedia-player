package com.cleanplayer.app

import android.content.Context
import java.util.concurrent.ConcurrentHashMap

/**
 * High-speed in-memory & persistent cache for YouTube Channel Logos/Avatars.
 */
object ChannelAvatarManager {

    private val memoryMap = ConcurrentHashMap<String, String>()
    private const val PREFS_NAME = "cleanplayer_channel_avatars_prefs"
    private var isInitialized = false

    fun init(context: Context) {
        if (isInitialized) return
        isInitialized = true
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            for ((k, v) in prefs.all) {
                if (v is String && v.isNotBlank()) {
                    memoryMap[k] = v
                }
            }
        } catch (e: Throwable) {}
    }

    fun getAvatar(channelName: String?): String? {
        if (channelName.isNullOrBlank()) return null
        val clean = channelName.trim().lowercase()
        return memoryMap[clean]
    }

    fun saveAvatar(context: Context, channelName: String?, avatarUrl: String?) {
        if (channelName.isNullOrBlank() || avatarUrl.isNullOrBlank()) return
        val clean = channelName.trim().lowercase()
        memoryMap[clean] = avatarUrl
        try {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(clean, avatarUrl)
                .apply()
        } catch (e: Throwable) {}
    }
}
