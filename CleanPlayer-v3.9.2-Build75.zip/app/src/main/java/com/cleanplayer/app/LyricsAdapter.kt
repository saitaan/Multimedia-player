package com.cleanplayer.app

import android.graphics.Color
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class LyricsAdapter(
    private var items: List<LyricsLine> = emptyList(),
    private val onLineClick: (Long) -> Unit
) : RecyclerView.Adapter<LyricsAdapter.ViewHolder>() {

    var activeIndex: Int = -1
    var activeColor: Int = Color.parseColor("#FF9800")

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvLyricLine: TextView = view.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_1, parent, false)
        val tv = view.findViewById<TextView>(android.R.id.text1).apply {
            setPadding(8, 12, 8, 12)
            gravity = android.view.Gravity.CENTER_HORIZONTAL
        }
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvLyricLine.text = item.text
        val isActive = (position == activeIndex)

        if (isActive) {
            holder.tvLyricLine.setTextColor(activeColor)
            holder.tvLyricLine.textSize = 17f
            holder.tvLyricLine.setTypeface(null, Typeface.BOLD)
            holder.itemView.alpha = 1.0f
        } else {
            holder.tvLyricLine.setTextColor(Color.parseColor("#888888"))
            holder.tvLyricLine.textSize = 14f
            holder.tvLyricLine.setTypeface(null, Typeface.NORMAL)
            holder.itemView.alpha = 0.65f
        }

        holder.itemView.setOnClickListener {
            onLineClick(item.timestampMs)
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateLyrics(newItems: List<LyricsLine>) {
        items = newItems
        activeIndex = -1
        notifyDataSetChanged()
    }

    fun updatePlaybackPosition(posMs: Long): Int {
        if (items.isEmpty()) return -1
        var newIdx = -1
        for (i in items.indices) {
            if (posMs >= items[i].timestampMs) {
                newIdx = i
            } else {
                break
            }
        }
        if (newIdx != activeIndex && newIdx in items.indices) {
            val oldIdx = activeIndex
            activeIndex = newIdx
            if (oldIdx in items.indices) notifyItemChanged(oldIdx)
            notifyItemChanged(newIdx)
            return newIdx
        }
        return -1
    }
}
