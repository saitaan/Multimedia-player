# Multimedia (VLC-Style Clean Media Player for Android)

High-performance, Lightweight, Zero-Ads, Zero-Tracking Android Media Player with VLC-Style Homescreen, Categorized Settings Menu, and LibVLC Core Engine.

## Features
- **VLC-Style Homescreen:**
  - Bottom Navigation with **Video**, **Audio**, and **Settings** tabs.
  - Automatic local media discovery (scans storage for video and audio tracks).
  - Open File button for direct file manager browsing.
- **VLC-Style Settings Menu:**
  - **Video & Playback:** Hardware Acceleration toggle (MediaCodec HW vs. CPU Software SW), Background Playback toggle.
  - **Audio & Sound:** Spatial Audio Virtualizer modes (Off, 3D Headphone, Cinema 3D, Wide Soundstage), OpenSL ES low-latency engine.
  - **Touch Gestures Guide:** VLC-style swipe brightness (left), volume (right), and time seeking (horizontal).
  - **About Multimedia:** App version 1.2, Lead Developer: **Rajesh Shah**, powered by official LibVLC Android SDK.
- **Crash Fix:**
  - Complete safeguard against LibVLC `AWindow` / `IllegalStateException` view attachment errors on MIUI / HyperOS and modern Android.
- **Zero Ads & Zero Bloatware:**
  - 100% clean local playback.

## How to Build on GitHub Actions
1. Push these files to your GitHub repository (or upload `multimedia-vlc-style.zip`).
2. Go to the **Actions** tab in GitHub.
3. The `Build Multimedia Android APK` workflow will run automatically.
4. Download the compiled `Multimedia-debug.apk` from the **Artifacts** section.
