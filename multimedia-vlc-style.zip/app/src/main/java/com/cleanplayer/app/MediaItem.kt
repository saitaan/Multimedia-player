package com.cleanplayer.app

import android.net.Uri
import java.util.Locale

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val isVideo: Boolean,
    val artist: String? = null
) {
    fun getFormattedDuration(): String {
        val totalSecs = durationMs / 1000
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
    }

    fun getFormattedSize(): String {
        val mb = sizeBytes.toDouble() / (1024 * 1024)
        return String.format(Locale.getDefault(), "%.1f MB", mb)
    }
}
