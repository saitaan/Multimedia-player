package com.cleanplayer.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnToolbarOpen: Button
    private lateinit var tabVideo: LinearLayout
    private lateinit var tabAudio: LinearLayout
    private lateinit var tabSettings: ScrollView
    private lateinit var bottomNav: BottomNavigationView

    private lateinit var rvVideos: RecyclerView
    private lateinit var layoutEmptyVideo: LinearLayout
    private lateinit var btnBrowseVideo: Button

    private lateinit var rvAudio: RecyclerView
    private lateinit var layoutEmptyAudio: LinearLayout
    private lateinit var btnBrowseAudio: Button

    // Settings UI elements
    private lateinit var tvHwDecodeStatus: TextView
    private lateinit var btnToggleHW: Button
    private lateinit var tvBgPlayStatus: TextView
    private lateinit var btnToggleBG: Button
    private lateinit var tvSpatialModeStatus: TextView
    private lateinit var btnChangeSpatial: Button

    private var videoAdapter: MediaAdapter? = null
    private var audioAdapter: MediaAdapter? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val title = it.lastPathSegment?.substringAfterLast('/') ?: "Media File"
            openPlayer(it, title)
        }
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        loadMediaFiles()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initViews()
        setupBottomNav()
        setupSettingsControls()
        checkAndRequestPermissions()

        // If app opened via VIEW intent (e.g. user clicked a video in file manager)
        intent?.data?.let { uri ->
            val title = uri.lastPathSegment?.substringAfterLast('/') ?: "Media File"
            openPlayer(uri, title)
        }
    }

    override fun onResume() {
        super.onResume()
        updateSettingsUI()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        btnToolbarOpen = findViewById(R.id.btnToolbarOpen)
        tabVideo = findViewById(R.id.tabVideo)
        tabAudio = findViewById(R.id.tabAudio)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)

        rvVideos = findViewById(R.id.rvVideos)
        layoutEmptyVideo = findViewById(R.id.layoutEmptyVideo)
        btnBrowseVideo = findViewById(R.id.btnBrowseVideo)

        rvAudio = findViewById(R.id.rvAudio)
        layoutEmptyAudio = findViewById(R.id.layoutEmptyAudio)
        btnBrowseAudio = findViewById(R.id.btnBrowseAudio)

        tvHwDecodeStatus = findViewById(R.id.tvHwDecodeStatus)
        btnToggleHW = findViewById(R.id.btnToggleHW)
        tvBgPlayStatus = findViewById(R.id.tvBgPlayStatus)
        btnToggleBG = findViewById(R.id.btnToggleBG)
        tvSpatialModeStatus = findViewById(R.id.tvSpatialModeStatus)
        btnChangeSpatial = findViewById(R.id.btnChangeSpatial)

        rvVideos.layoutManager = LinearLayoutManager(this)
        rvAudio.layoutManager = LinearLayoutManager(this)

        val openFileAction = {
            filePickerLauncher.launch(arrayOf("video/*", "audio/*"))
        }

        btnToolbarOpen.setOnClickListener { openFileAction() }
        btnBrowseVideo.setOnClickListener { openFileAction() }
        btnBrowseAudio.setOnClickListener { openFileAction() }
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_video -> {
                    showTab(video = true, audio = false, settings = false)
                    toolbar.title = getString(R.string.app_name)
                    toolbar.subtitle = getString(R.string.nav_video)
                    true
                }
                R.id.nav_audio -> {
                    showTab(video = false, audio = true, settings = false)
                    toolbar.title = getString(R.string.app_name)
                    toolbar.subtitle = getString(R.string.nav_audio)
                    true
                }
                R.id.nav_settings -> {
                    showTab(video = false, audio = false, settings = true)
                    toolbar.title = getString(R.string.app_name)
                    toolbar.subtitle = getString(R.string.nav_settings)
                    true
                }
                else -> false
            }
        }
    }

    private fun showTab(video: Boolean, audio: Boolean, settings: Boolean) {
        tabVideo.visibility = if (video) View.VISIBLE else View.GONE
        tabAudio.visibility = if (audio) View.VISIBLE else View.GONE
        tabSettings.visibility = if (settings) View.VISIBLE else View.GONE
    }

    private fun setupSettingsControls() {
        btnToggleHW.setOnClickListener {
            PlayerHolder.isHardwareDecoding = !PlayerHolder.isHardwareDecoding
            updateSettingsUI()
        }

        findViewById<View>(R.id.rowHwDecode).setOnClickListener {
            btnToggleHW.performClick()
        }

        btnToggleBG.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            updateSettingsUI()
        }

        findViewById<View>(R.id.rowBgPlay).setOnClickListener {
            btnToggleBG.performClick()
        }

        val openSpatialDialog = {
            val modes = SpatialAudioMode.values()
            val names = modes.map { it.displayName }.toTypedArray()
            val currentIdx = modes.indexOf(PlayerHolder.spatialAudioMode)

            AlertDialog.Builder(this)
                .setTitle(R.string.spatial_audio)
                .setSingleChoiceItems(names, currentIdx) { dialog, which ->
                    PlayerHolder.spatialAudioMode = modes[which]
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        btnChangeSpatial.setOnClickListener { openSpatialDialog() }
        findViewById<View>(R.id.rowSpatialAudio).setOnClickListener { openSpatialDialog() }

        updateSettingsUI()
    }

    private fun updateSettingsUI() {
        if (PlayerHolder.isHardwareDecoding) {
            tvHwDecodeStatus.text = "MediaCodec Hardware Acceleration (Enabled)"
            tvHwDecodeStatus.setTextColor(ContextCompat.getColor(this, R.color.vlc_orange_light))
            btnToggleHW.text = "ON"
            btnToggleHW.setTextColor(ContextCompat.getColor(this, R.color.vlc_orange))
        } else {
            tvHwDecodeStatus.text = "CPU FFmpeg Software Decoder (Active)"
            tvHwDecodeStatus.setTextColor(ContextCompat.getColor(this, R.color.vlc_text_secondary))
            btnToggleHW.text = "SW"
            btnToggleHW.setTextColor(ContextCompat.getColor(this, R.color.vlc_text_secondary))
        }

        if (PlayerHolder.isBackgroundPlayEnabled) {
            tvBgPlayStatus.text = "Audio continues playing in background (Enabled)"
            btnToggleBG.text = "ON"
            btnToggleBG.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
        } else {
            tvBgPlayStatus.text = "Audio stops when app is closed (Off)"
            btnToggleBG.text = "OFF"
            btnToggleBG.setTextColor(ContextCompat.getColor(this, R.color.vlc_text_secondary))
        }

        tvSpatialModeStatus.text = PlayerHolder.spatialAudioMode.displayName
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            storagePermissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            loadMediaFiles()
        }
    }

    private fun loadMediaFiles() {
        // Load videos
        val videos = MediaScanner.scanVideos(this)
        if (videos.isNotEmpty()) {
            rvVideos.visibility = View.VISIBLE
            layoutEmptyVideo.visibility = View.GONE
            if (videoAdapter == null) {
                videoAdapter = MediaAdapter(videos) { item ->
                    openPlayer(item.uri, item.title)
                }
                rvVideos.adapter = videoAdapter
            } else {
                videoAdapter?.updateList(videos)
            }
        } else {
            rvVideos.visibility = View.GONE
            layoutEmptyVideo.visibility = View.VISIBLE
        }

        // Load audio
        val audioList = MediaScanner.scanAudio(this)
        if (audioList.isNotEmpty()) {
            rvAudio.visibility = View.VISIBLE
            layoutEmptyAudio.visibility = View.GONE
            if (audioAdapter == null) {
                audioAdapter = MediaAdapter(audioList) { item ->
                    openPlayer(item.uri, item.title)
                }
                rvAudio.adapter = audioAdapter
            } else {
                audioAdapter?.updateList(audioList)
            }
        } else {
            rvAudio.visibility = View.GONE
            layoutEmptyAudio.visibility = View.VISIBLE
        }
    }

    private fun openPlayer(uri: Uri, title: String) {
        val intent = Intent(this, PlayerActivity::class.java).apply {
            data = uri
            putExtra("media_uri", uri.toString())
            putExtra("media_title", title)
        }
        startActivity(intent)
    }
}
