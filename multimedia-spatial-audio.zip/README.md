# Multimedia (Clean Media Player for Android / POCO C85x)

Lightweight, Zero-Ads, Zero-Background-Bloat VLC-style Multimedia Player with Hardware & Software Decoding, Touch Gestures, Background Audio Playback, and Spatial Audio.

## Key Features
- **Spatial Audio Settings:**
  - `Spatial: Off` (Pure direct stereo output)
  - `Spatial: 3D Headphone` (Binaural 3D headphone virtualization)
  - `Spatial: Cinema 3D` (Combined binaural surround + immersive acoustics)
  - `Spatial: Wide` (Expanded soundstage room acoustics)
  - Tap button to cycle modes or long-press for settings dialog.
- **Hardware & Software Decoders:** Instant on-screen toggle between MediaCodec (HW) and CPU FFmpeg (SW).
- **VLC-Style Gestures:**
  - Left swipe: Brightness adjustment with percentage overlay.
  - Right swipe: Volume adjustment with level overlay.
  - Horizontal swipe: Time seeking with ±seconds overlay.
  - Single tap: Toggle playback control bars.
- **Background Audio Playback:** Optional toggle for background audio playback with notification controls.
- **Zero Ads & Zero Telemetry:** Pure local media player with zero bloat.

## How to Build on GitHub
1. Push all files in this repository to GitHub.
2. Go to the **Actions** tab in your repository.
3. The `Build Multimedia Android APK` workflow will run automatically.
4. Download the compiled `Multimedia-debug.apk` from the **Artifacts** section.
