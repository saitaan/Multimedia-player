package com.cleanplayer.app

import android.content.Context
import android.net.Uri
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

enum class SpatialAudioMode(val displayName: String, val shortName: String, val filterArg: String?) {
    OFF("Spatial Audio: Off", "Spatial: Off", null),
    HEADPHONE_3D("3D Headphone (Binaural)", "Spatial: 3D", "headphone"),
    CINEMA_3D("Cinema 3D Immersive", "Spatial: Cinema", "headphone,spatializer"),
    WIDE_SOUNDSTAGE("Wide Soundstage (Room)", "Spatial: Wide", "spatializer");

    fun next(): SpatialAudioMode {
        val values = values()
        return values[(ordinal + 1) % values.size]
    }
}

object PlayerHolder {
    var libVLC: LibVLC? = null
    var mediaPlayer: MediaPlayer? = null
    var currentUri: Uri? = null
    var currentTitle: String = "Media Track"
    var isHardwareDecoding: Boolean = true
    var isBackgroundPlayEnabled: Boolean = false
    var isAudioOnly: Boolean = false
    var spatialAudioMode: SpatialAudioMode = SpatialAudioMode.OFF

    fun initPlayer(context: Context, uri: Uri, hwDecode: Boolean): MediaPlayer {
        release()
        currentUri = uri
        isHardwareDecoding = hwDecode
        currentTitle = uri.lastPathSegment?.substringAfterLast('/') ?: "Media Track"

        val options = ArrayList<String>().apply {
            if (hwDecode) {
                add("--avcodec-hw=any")
                add("--codec=mediacodec_ndk,mediacodec_jni,all")
            } else {
                add("--avcodec-hw=none")
                add("--codec=all")
            }

            // Audio output engine
            add("--aout=opensles")
            add("--audio-time-stretch")

            // Spatial Audio Filter Configuration
            spatialAudioMode.filterArg?.let { filter ->
                add("--audio-filter=$filter")
                if (filter.contains("spatializer")) {
                    add("--spatializer-roomsize=1.05")
                    add("--spatializer-width=10.0")
                    add("--spatializer-wet=3.0")
                    add("--spatializer-dry=2.0")
                    add("--spatializer-damp=0.2")
                }
            }
        }

        libVLC = LibVLC(context.applicationContext, options)
        val player = MediaPlayer(libVLC)
        mediaPlayer = player

        val media = Media(libVLC, uri).apply {
            setHWDecoderEnabled(hwDecode, false)
        }
        player.media = media
        media.release()

        return player
    }

    fun release() {
        mediaPlayer?.let {
            it.stop()
            it.detachViews()
            it.release()
        }
        mediaPlayer = null
        libVLC?.release()
        libVLC = null
    }
}
