package com.cleanplayer.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var layoutAudioPlaceholder: LinearLayout
    private lateinit var layoutGestureOverlay: LinearLayout
    private lateinit var ivGestureIcon: ImageView
    private lateinit var tvGestureValue: TextView
    private lateinit var tvMediaTitle: TextView
    private lateinit var tvAudioSpatialBadge: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnDecoderToggle: Button
    private lateinit var btnBgPlayToggle: Button
    private lateinit var btnSpatialAudio: Button
    private lateinit var btnOpenFile: Button
    private lateinit var seekBar: SeekBar
    private lateinit var tvTime: TextView
    private lateinit var topBar: HorizontalScrollView
    private lateinit var bottomBar: LinearLayout

    private lateinit var audioManager: AudioManager
    private var maxVolume: Int = 15

    // Gesture tracking
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var isGestureActive = false
    private var activeGestureType: GestureType = GestureType.NONE
    private var initialVolume = 0
    private var initialBrightness = 0.5f

    enum class GestureType {
        NONE, BRIGHTNESS, VOLUME, SEEK
    }

    private val handler = Handler(Looper.getMainLooper())
    private val hideControlsRunnable = Runnable {
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
    }
    private val hideGestureOverlayRunnable = Runnable {
        layoutGestureOverlay.visibility = View.GONE
    }

    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            PlayerHolder.mediaPlayer?.let { player ->
                if (player.isPlaying) {
                    val time = player.time
                    val length = player.length
                    if (length > 0) {
                        val progress = ((time.toFloat() / length) * 1000).toInt()
                        seekBar.progress = progress
                        tvTime.text = "${formatTime(time)} / ${formatTime(length)}"
                    }

                    val trackCount = player.videoTracksCount
                    if (trackCount > 0) {
                        PlayerHolder.isAudioOnly = false
                        layoutAudioPlaceholder.visibility = View.GONE
                        videoLayout.visibility = View.VISIBLE
                    } else {
                        PlayerHolder.isAudioOnly = true
                        layoutAudioPlaceholder.visibility = View.VISIBLE
                        videoLayout.visibility = View.GONE
                    }
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                playMedia(uri, 0L)
            }
        }
    }

    private val requestNotificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_main)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

        videoLayout = findViewById(R.id.videoLayout)
        layoutAudioPlaceholder = findViewById(R.id.layoutAudioPlaceholder)
        layoutGestureOverlay = findViewById(R.id.layoutGestureOverlay)
        ivGestureIcon = findViewById(R.id.ivGestureIcon)
        tvGestureValue = findViewById(R.id.tvGestureValue)
        tvMediaTitle = findViewById(R.id.tvMediaTitle)
        tvAudioSpatialBadge = findViewById(R.id.tvAudioSpatialBadge)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnDecoderToggle = findViewById(R.id.btnDecoderToggle)
        btnBgPlayToggle = findViewById(R.id.btnBgPlayToggle)
        btnSpatialAudio = findViewById(R.id.btnSpatialAudio)
        btnOpenFile = findViewById(R.id.btnOpenFile)
        seekBar = findViewById(R.id.seekBar)
        tvTime = findViewById(R.id.tvTime)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)

        checkNotificationPermission()
        setupListeners()
        updateBgPlayButtonState()
        updateSpatialAudioButton()

        intent?.data?.let { uri ->
            playMedia(uri, 0L)
        }
    }

    override fun onResume() {
        super.onResume()
        MediaPlaybackService.stop(this)
        PlayerHolder.mediaPlayer?.let { player ->
            player.attachViews(videoLayout, null, false, false)
            if (player.isPlaying) {
                btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
            }
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
                requestNotificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun setupListeners() {
        btnOpenFile.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "audio/*"))
            }
            filePickerLauncher.launch(intent)
        }

        btnPlayPause.setOnClickListener {
            PlayerHolder.mediaPlayer?.let { player ->
                if (player.isPlaying) {
                    player.pause()
                    btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
                } else {
                    player.play()
                    btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
                }
            }
            resetControlsTimer()
        }

        btnDecoderToggle.setOnClickListener {
            PlayerHolder.isHardwareDecoding = !PlayerHolder.isHardwareDecoding
            updateDecoderButtonLabel()
            PlayerHolder.currentUri?.let { uri ->
                val lastPos = PlayerHolder.mediaPlayer?.time ?: 0L
                playMedia(uri, lastPos)
            }
            resetControlsTimer()
        }

        btnBgPlayToggle.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            updateBgPlayButtonState()
            resetControlsTimer()
        }

        // Tap cycles spatial mode, Long-press opens detailed settings dialog
        btnSpatialAudio.setOnClickListener {
            val nextMode = PlayerHolder.spatialAudioMode.next()
            applySpatialAudioMode(nextMode)
            resetControlsTimer()
        }

        btnSpatialAudio.setOnLongClickListener {
            showSpatialAudioDialog()
            true
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    PlayerHolder.mediaPlayer?.let { player ->
                        val newTime = (player.length * progress) / 1000
                        player.time = newTime
                    }
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                handler.removeCallbacks(hideControlsRunnable)
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                resetControlsTimer()
            }
        })
    }

    private fun showSpatialAudioDialog() {
        val modes = SpatialAudioMode.values()
        val names = modes.map { it.displayName }.toTypedArray()
        val currentIdx = modes.indexOf(PlayerHolder.spatialAudioMode)

        AlertDialog.Builder(this)
            .setTitle(R.string.spatial_audio)
            .setSingleChoiceItems(names, currentIdx) { dialog, which ->
                applySpatialAudioMode(modes[which])
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun applySpatialAudioMode(mode: SpatialAudioMode) {
        PlayerHolder.spatialAudioMode = mode
        updateSpatialAudioButton()
        showGestureOverlay(android.R.drawable.ic_btn_speak_now, mode.displayName)

        // Hot re-apply audio filter by restarting LibVLC at current timestamp
        PlayerHolder.currentUri?.let { uri ->
            val lastPos = PlayerHolder.mediaPlayer?.time ?: 0L
            playMedia(uri, lastPos)
        }
    }

    private fun updateSpatialAudioButton() {
        btnSpatialAudio.text = PlayerHolder.spatialAudioMode.shortName
        tvAudioSpatialBadge.text = PlayerHolder.spatialAudioMode.displayName

        if (PlayerHolder.spatialAudioMode != SpatialAudioMode.OFF) {
            btnSpatialAudio.backgroundTintList = ContextCompat.getColorStateList(this, android.R.color.holo_blue_dark)
        } else {
            btnSpatialAudio.backgroundTintList = ContextCompat.getColorStateList(this, android.R.color.darker_gray)
        }
    }

    private fun updateDecoderButtonLabel() {
        if (PlayerHolder.isHardwareDecoding) {
            btnDecoderToggle.text = getString(R.string.decoder_hw)
        } else {
            btnDecoderToggle.text = getString(R.string.decoder_sw)
        }
    }

    private fun updateBgPlayButtonState() {
        if (PlayerHolder.isBackgroundPlayEnabled) {
            btnBgPlayToggle.text = "BG Play: ON"
            btnBgPlayToggle.backgroundTintList = ContextCompat.getColorStateList(this, android.R.color.holo_green_dark)
        } else {
            btnBgPlayToggle.text = "BG Play: OFF"
            btnBgPlayToggle.backgroundTintList = ContextCompat.getColorStateList(this, android.R.color.darker_gray)
        }
    }

    private fun playMedia(uri: Uri, resumeTimeMs: Long) {
        val player = PlayerHolder.initPlayer(this, uri, PlayerHolder.isHardwareDecoding)
        player.attachViews(videoLayout, null, false, false)
        tvMediaTitle.text = PlayerHolder.currentTitle

        player.play()
        btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)

        if (resumeTimeMs > 0) {
            player.time = resumeTimeMs
        }

        handler.post(updateProgressRunnable)
        resetControlsTimer()
    }

    private fun resetControlsTimer() {
        handler.removeCallbacks(hideControlsRunnable)
        handler.postDelayed(hideControlsRunnable, 4000)
    }

    // VLC Style Gestures: Left=Brightness, Right=Volume, Horizontal=Seek, Tap=Toggle Controls
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                downTime = System.currentTimeMillis()
                isGestureActive = false
                activeGestureType = GestureType.NONE
                initialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                initialBrightness = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                handler.removeCallbacks(hideControlsRunnable)
            }
            MotionEvent.ACTION_MOVE -> {
                val deltaX = event.x - downX
                val deltaY = downY - event.y // Upward swipe is positive

                if (!isGestureActive && (abs(deltaX) > 40 || abs(deltaY) > 40)) {
                    isGestureActive = true
                    activeGestureType = if (abs(deltaX) > abs(deltaY)) {
                        GestureType.SEEK
                    } else if (downX < screenWidth * 0.45f) {
                        GestureType.BRIGHTNESS
                    } else {
                        GestureType.VOLUME
                    }
                }

                if (isGestureActive) {
                    when (activeGestureType) {
                        GestureType.BRIGHTNESS -> {
                            val brightnessChange = deltaY / (screenHeight * 0.7f)
                            val newBrightness = (initialBrightness + brightnessChange).coerceIn(0.01f, 1.0f)
                            val lp = window.attributes
                            lp.screenBrightness = newBrightness
                            window.attributes = lp
                            showGestureOverlay(
                                android.R.drawable.ic_menu_view,
                                "Brightness: ${(newBrightness * 100).toInt()}%"
                            )
                        }
                        GestureType.VOLUME -> {
                            val volumeChange = (deltaY / (screenHeight * 0.7f)) * maxVolume
                            val newVolume = (initialVolume + volumeChange.toInt()).coerceIn(0, maxVolume)
                            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)
                            showGestureOverlay(
                                android.R.drawable.ic_lock_silent_mode_off,
                                "Volume: ${(newVolume * 100) / maxVolume}%"
                            )
                        }
                        GestureType.SEEK -> {
                            PlayerHolder.mediaPlayer?.let { player ->
                                val duration = player.length
                                if (duration > 0) {
                                    val seekOffset = ((deltaX / screenWidth) * 60_000).toLong()
                                    val targetTime = (player.time + seekOffset).coerceIn(0, duration)
                                    val sign = if (seekOffset >= 0) "+" else ""
                                    showGestureOverlay(
                                        android.R.drawable.ic_media_ff,
                                        "Seek: $sign${seekOffset / 1000}s (${formatTime(targetTime)})"
                                    )
                                }
                            }
                        }
                        else -> {}
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                val upTime = System.currentTimeMillis()
                val moveDistX = abs(event.x - downX)
                val moveDistY = abs(event.y - downY)

                if (!isGestureActive && (upTime - downTime < 300) && moveDistX < 30 && moveDistY < 30) {
                    if (topBar.visibility == View.VISIBLE) {
                        topBar.visibility = View.GONE
                        bottomBar.visibility = View.GONE
                    } else {
                        topBar.visibility = View.VISIBLE
                        bottomBar.visibility = View.VISIBLE
                        resetControlsTimer()
                    }
                } else if (activeGestureType == GestureType.SEEK) {
                    PlayerHolder.mediaPlayer?.let { player ->
                        val deltaX = event.x - downX
                        val seekOffset = ((deltaX / screenWidth) * 60_000).toLong()
                        val targetTime = (player.time + seekOffset).coerceIn(0, player.length)
                        player.time = targetTime
                    }
                }

                handler.removeCallbacks(hideGestureOverlayRunnable)
                handler.postDelayed(hideGestureOverlayRunnable, 800)
                resetControlsTimer()
            }
        }
        return true
    }

    private fun showGestureOverlay(iconResId: Int, text: String) {
        ivGestureIcon.setImageResource(iconResId)
        tvGestureValue.text = text
        layoutGestureOverlay.visibility = View.VISIBLE
        handler.removeCallbacks(hideGestureOverlayRunnable)
    }

    private fun formatTime(millis: Long): String {
        val totalSeconds = millis / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
    }

    override fun onStop() {
        super.onStop()
        val isAudioPlaying = PlayerHolder.mediaPlayer?.isPlaying == true
        if (PlayerHolder.isBackgroundPlayEnabled && isAudioPlaying) {
            PlayerHolder.mediaPlayer?.detachViews()
            MediaPlaybackService.start(this)
        } else {
            PlayerHolder.release()
            MediaPlaybackService.stop(this)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (!PlayerHolder.isBackgroundPlayEnabled || PlayerHolder.mediaPlayer?.isPlaying != true) {
            PlayerHolder.release()
            MediaPlaybackService.stop(this)
        }
    }
}
