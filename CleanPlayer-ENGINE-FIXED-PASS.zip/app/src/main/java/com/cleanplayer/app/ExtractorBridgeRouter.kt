package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors



class CircuitBreaker(
    val name: String,
    private val failureThreshold: Int = 3,
    private val cooldownDurationMs: Long = 180_000L
) {
    private val failureCount = java.util.concurrent.atomic.AtomicInteger(0)
    private val lastFailureTimeMs = java.util.concurrent.atomic.AtomicLong(0L)

    fun allowExecution(): Boolean {
        val count = failureCount.get()
        if (count < failureThreshold) return true
        val elapsed = System.currentTimeMillis() - lastFailureTimeMs.get()
        if (elapsed > cooldownDurationMs) {
            failureCount.set(0)
            return true
        }
        return false
    }

    fun recordSuccess() {
        failureCount.set(0)
    }

    fun recordFailure() {
        failureCount.incrementAndGet()
        lastFailureTimeMs.set(System.currentTimeMillis())
    }
}


/**
 * Dynamic Extractor Engine Router
 * Dynamically resolves video streams based on user configuration and provides
 * zero-downtime automatic failover with Circuit Breakers across InnerTube, Invidious, and Piped.
 */
object ExtractorBridgeRouter {

    const val PREFS_KEY_ENGINE = "pref_yt_extractor_bridge"

    const val ENGINE_AUTO = "AUTO"
    const val ENGINE_INNERTUBE = "INNERTUBE"
    const val ENGINE_PIPED = "PIPED"
    const val ENGINE_INVIDIOUS = "INVIDIOUS"

    private val pipedBridge = PipedBridge()
    private val invidiousBridge = InvidiousBridge()

    // Circuit Breakers for each bridge to prevent UI hangs on dead engines
    val innertubeBreaker = CircuitBreaker("InnerTube", failureThreshold = 3, cooldownDurationMs = 180_000L)
    val invidiousBreaker = CircuitBreaker("Invidious", failureThreshold = 3, cooldownDurationMs = 180_000L)
    val pipedBreaker = CircuitBreaker("Piped", failureThreshold = 3, cooldownDurationMs = 180_000L)

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun getActiveEngineId(context: Context): String {
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        return prefs.getString(PREFS_KEY_ENGINE, ENGINE_AUTO) ?: ENGINE_AUTO
    }

    fun getActiveEngineName(context: Context): String {
        return when (getActiveEngineId(context)) {
            ENGINE_INNERTUBE -> "Direct InnerTube (Client Spoofing)"
            ENGINE_NEWPIPE -> "NewPipe Extractor (Legacy Fallback)"
            ENGINE_PIPED -> "Piped Privacy Cluster"
            ENGINE_INVIDIOUS -> "Invidious Dynamic Pool"
            else -> "Smart Auto Failover (Recommended)"
        }
    }

    fun setActiveEngine(context: Context, engineId: String) {
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString(PREFS_KEY_ENGINE, engineId).apply()
    }

    private fun hasValidStream(res: VideoExtractionResult?): Boolean {
        if (res == null) return false
        return res.formats.isNotEmpty() || res.bestStreamUrl.isNotBlank() || res.dashManifestUrl != null || res.hlsManifestUrl != null
    }

    fun resolveStream(
        context: Context,
        videoId: String,
        callback: (VideoExtractionResult?) -> Unit
    ) {
        val engine = getActiveEngineId(context)
        val authToken = if (MicroGAuthManager.isLoggedIn(context)) {
            MicroGAuthManager.getAuthToken(context)
        } else {
            null
        }

        val localizedInnertubeBridge = DefaultInnertubeBridge(context.applicationContext)

        executor.execute {
            val effectiveAuthToken = authToken ?: if (MicroGAuthManager.isLoggedIn(context)) MicroGAuthManager.getAuthToken(context) else null
            var result: VideoExtractionResult? = null

            // 1. Primary engine attempt (respecting user preference)
            when (engine) {
                ENGINE_INNERTUBE -> {
                    if (innertubeBreaker.allowExecution()) {
                        result = localizedInnertubeBridge.extract(videoId, effectiveAuthToken)
                        if (hasValidStream(result)) innertubeBreaker.recordSuccess() else innertubeBreaker.recordFailure()
                    }
                }
                ENGINE_INVIDIOUS -> {
                    if (invidiousBreaker.allowExecution()) {
                        result = invidiousBridge.extract(videoId, effectiveAuthToken)
                        if (hasValidStream(result)) invidiousBreaker.recordSuccess() else invidiousBreaker.recordFailure()
                    }
                }
                ENGINE_PIPED -> {
                    if (pipedBreaker.allowExecution()) {
                        result = pipedBridge.extract(videoId, effectiveAuthToken)
                        if (hasValidStream(result)) pipedBreaker.recordSuccess() else pipedBreaker.recordFailure()
                    }
                }
                else -> null
            }

            // 2. Cascading Circuit-Breaker Failover: InnerTube -> Invidious -> Piped
            if (!hasValidStream(result) && innertubeBreaker.allowExecution()) {
                result = localizedInnertubeBridge.extract(videoId, effectiveAuthToken)
                if (hasValidStream(result)) innertubeBreaker.recordSuccess() else innertubeBreaker.recordFailure()
            }

            // Auto-Refresh Token Retry on Auth Failures
            if (!hasValidStream(result) && !effectiveAuthToken.isNullOrBlank()) {
                val refreshedToken = MicroGAuthManager.invalidateAndRefreshToken(context)
                if (!refreshedToken.isNullOrBlank() && refreshedToken != effectiveAuthToken) {
                    result = localizedInnertubeBridge.extract(videoId, refreshedToken)
                    if (hasValidStream(result)) innertubeBreaker.recordSuccess()
                }
            }

            if (!hasValidStream(result) && invidiousBreaker.allowExecution()) {
                result = invidiousBridge.extract(videoId, effectiveAuthToken)
                if (hasValidStream(result)) invidiousBreaker.recordSuccess() else invidiousBreaker.recordFailure()
            }

            if (!hasValidStream(result) && pipedBreaker.allowExecution()) {
                result = pipedBridge.extract(videoId, effectiveAuthToken)
                if (hasValidStream(result)) pipedBreaker.recordSuccess() else pipedBreaker.recordFailure()
            }

            mainHandler.post {
                callback(result)
            }
        }
    }
}
