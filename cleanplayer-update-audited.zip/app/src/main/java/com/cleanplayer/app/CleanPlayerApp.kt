package com.cleanplayer.app

import android.app.Application
import android.util.Log
import java.util.concurrent.Executors

/**
 * Global Application Class for CleanPlayer.
 * Initializes the NewPipeExtractor engine deterministically and warms the image cache in the background.
 */
class CleanPlayerApp : Application() {

    companion object {
        lateinit var instance: CleanPlayerApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // NewPipe/Downloader setup is deliberately deterministic. The resolver can be called
        // immediately from an Activity, so it must never race application initialization.
        try {
            DownloaderImpl.init(cacheDir = cacheDir)
            YouTubeStreamResolver.initNewPipe(this)
        } catch (e: Exception) {
            Log.e("CleanPlayerApp", "Failed to initialize YouTube extractor", e)
        }

        // Image cache warming is independent of the extractor and can safely run in the background.
        Executors.newSingleThreadExecutor().execute {
            try {
                ImageLoaderHelper.init(this)
            } catch (e: Exception) {
                Log.e("CleanPlayerApp", "Image cache initialization failed", e)
            }
        }
    }
}
