# CleanPlayer Update — Line-by-Line Audit Report

Audit date: 2026-09-26

## Scope
- 43 Kotlin source files
- 126 Android XML resource files
- Gradle/Kotlin/KSP configuration
- AndroidManifest.xml
- GitHub Actions workflow
- NewPipe downloader/resolver and Media3 playback paths
- Share/hotspot services and Activity lifecycle paths

## Verified
- All 126 XML files parse successfully.
- No Kotlin `!!` force-unwrapping was found in the application source.
- Edited Kotlin files have balanced delimiters.
- Internal resource references were reviewed.
- NewPipe Downloader `Response` construction matches the extractor API shape used by the project.

## Fixes applied
### 1. Hotspot permission safety
`FastShareService` and `WebShareManager` now check the appropriate runtime permission before invoking `WifiManager.startLocalOnlyHotspot()`.

- Android 13+: `NEARBY_WIFI_DEVICES`
- Older Android versions using LocalOnlyHotspot: `ACCESS_FINE_LOCATION`
- Missing permission now falls back to the current Wi-Fi/local IP instead of risking a `SecurityException`.

### 2. FastShare hotspot watchdog
Added a single-shot 2.5 second watchdog and guarded callback notification with `AtomicBoolean`. This prevents duplicate startup callbacks and handles devices where LocalOnlyHotspot does not call back promptly.

### 3. NewPipe startup race
Downloader + NewPipe initialization is now deterministic during `Application.onCreate()`. Image cache warming remains asynchronous because it is independent of stream extraction.

### 4. Crash-loop removal
The previous global uncaught-exception handler automatically relaunched `MainActivity` and killed the process. That could turn one crash into an infinite restart loop and obscure the original stack trace. It has been removed so Android's normal crash handling remains intact.

### 5. YouTube stream selection
Stream selection now considers:
1. requested resolution,
2. FPS,
3. bitrate.

For the requested resolution, separate video-only + audio is preferred over a lower-capability muxed/progressive alternative. Lower resolutions remain available as fallback.

### 6. GitHub Actions
The workflow now uses `gradle/actions/setup-gradle@v4`, validates the Android project structure, and builds with Gradle 8.4 directly. The previous `|| true` wrapper-download logic that could hide setup failures was removed.

## Remaining limitation
The supplied ZIP does not contain `gradle/wrapper/gradle-wrapper.jar`. The execution environment also does not have Gradle installed and cannot resolve external Gradle distribution hosts, so a full Android dependency build could not be executed here.

The GitHub workflow no longer depends on the missing wrapper JAR because it provisions Gradle 8.4 through the official setup action.

## Important pre-release checks
A real device/emulator CI build should still verify:
- Android 13/14/15 hotspot permission denial and grant flows.
- Xiaomi/MediaTek LocalOnlyHotspot timeout/fallback behavior.
- YouTube extraction against current live YouTube responses.
- 1080p/1440p/2160p video-only + audio synchronization.
- Background playback, PiP, Activity recreation, and service lifecycle.
- Foreground-service restrictions on Android 14+.
