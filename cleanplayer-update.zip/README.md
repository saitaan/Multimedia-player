# CleanPlayer (v3.9.2 Master Edition)

High-performance, Lightweight, Zero-Ads, Zero-Tracking Universal Android Multimedia & Streaming Application.

## Key Features & Architecture

### 1. High-Performance Local Media Engine (LibVLC Core & Media3)
- **HW / SW Decoder Toggle Button:** Instant on-screen hardware acceleration toggle (MediaCodec HW vs. CPU FFmpeg SW) with position preservation.
- **Production Battery & Screen-Awake Safety:** Screen remains awake exclusively while media is actively playing. Upon natural playback completion (`STATE_ENDED` / `EndReached`), screen-awake flags (`FLAG_KEEP_SCREEN_ON`, `keepScreenOn`) and WakeLocks are immediately released, allowing normal Android system display timeout without battery drain.
- **Repeat / Loop Intelligence:** Repeat OFF stops playback and cleans wake state; Repeat ON seamlessly loops without dropping screen state.
- **Dolby Surround & 3D Spatial Audio:** Virtualizer supporting 3D Headphone, Cinema 3D, and Wide Soundstage with 10-band customizable graphic equalizer presets.
- **Audio Time-Stretching & Pitch Lock:** Seamless vocal pitch preservation across 0.25x to 4.0x playback speeds.
- **Storage Write Safety:** Debounced playback progress resume tracking (saving at 5-second intervals rather than high-frequency ticks), eliminating unnecessary flash storage wear.

### 2. Native Ad-Free YouTube Client (TeamNewPipe Extractor v0.26.5)
- **Untracked Native YouTube Streaming:** Background audio, video detail view, channel profiles, comments, and related videos with zero Google Play Services tracking.
- **Cipher Self-Healing & Dynamic OTA Engine:** Automated runtime updates for YouTube signature decipher rules and n-sig transforms with schema validation and last-known-good rollback protection.
- **MicroG / GmsCore Auth:** Optional Google Account login via GmsCore.

### 3. 5GHz Turbo FastShare & Universal WebShare
- **Universal WebShare (Any Browser / Any Device):** Single authoritative session state hosting direct P2P streaming and downloads over local Wi-Fi / Hotspot.
- **Strict QR Separation:** Dedicated standard Wi-Fi QR (`WIFI:T:WPA;S:...;P:...;;`) for connecting to hotspot, and separate WebShare URL QR (`http://<actual-ip>:<actual-port>`) with dynamic port resolution (no hard-coded ports).
- **Direct Browser Action:** One-tap "Open in Browser" button and Copy URL action.
- **WebShare Security:** Hardened path-traversal protection blocking `../`, `%2e%2e`, backslashes, and unauthorized filesystem escape. RFC 5987 / RFC 6266 Unicode filename support.

### 4. On-Demand Performance Models Manager
- **Zero-Bloat Architecture:** Keeps the core APK at ~15MB.
- **Real Model Lifecycle:** True on-disk model existence verification, storage threshold validation, cancelable background downloads, real disk size accounting, and clean model uninstallation for 4K Super-Resolution, Demucs Vocal Remover, and Whisper Speech-to-Text.

### 5. Resilient Crash Guard
- **Crash-Loop Prevention:** 15-second multi-crash frequency tracking preventing recursive restart loops, with unmasked diagnostics written to disk.

---

## Technical Specifications
- **Application ID:** `com.cleanplayer.app`
- **Version Name:** `3.9.2`
- **Version Code:** `37`
- **Compile SDK:** `34` (Android 14)
- **Target SDK:** `34`
- **Min SDK:** `21` (Android 5.0 Lollipop)
- **Java / JDK:** Java 17 (Temurin)
- **Gradle Version:** Gradle 8.4
- **Lead Developer:** Rajesh Shah

---

## How to Build on GitHub Actions & Locally

### GitHub Actions CI/CD
1. Push code to `main` or `master` branch (or trigger manually via `workflow_dispatch`).
2. The workflow in `.github/workflows/build-apk.yml` runs automated unit tests (`testDebugUnitTest`) and builds the debug APK (`assembleDebug`).
3. Download the signed debug APK from GitHub Actions **Artifacts**.

### Local Build
```bash
# Ensure execution permissions on gradlew
chmod +x gradlew

# Run unit tests
./gradlew testDebugUnitTest

# Build debug APK
./gradlew assembleDebug
```
Output APK location: `app/build/outputs/apk/debug/CleanPlayer-v3.9.2-debug.apk`
