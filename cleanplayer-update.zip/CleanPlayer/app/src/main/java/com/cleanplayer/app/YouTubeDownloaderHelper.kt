package com.cleanplayer.app

import android.app.Activity
import androidx.appcompat.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

data class DownloadQualityOption(
    val label: String,
    val resolutionOrBitrate: String,
    val url: String,
    val isAudio: Boolean,
    val estimatedSizeMb: String
)

data class ActiveDownloadInfo(
    val downloadId: Long,
    val title: String,
    val fileName: String,
    val isAudio: Boolean,
    val video: YouTubeVideo? = null,
    val option: DownloadQualityOption? = null,
    var hasRetried: Boolean = false,
    var percent: Int = 0,
    var downloadedBytes: Long = 0L,
    var totalBytes: Long = 0L,
    var status: Int = DownloadManager.STATUS_PENDING
)

object YouTubeDownloaderHelper {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val activeDownloads = mutableMapOf<Long, ActiveDownloadInfo>()
    private var progressTrackingRunnable: Runnable? = null

    var onDownloadProgressChanged: ((downloadId: Long, percent: Int, downloadedStr: String, totalStr: String, status: Int) -> Unit)? = null
    var onDownloadFinished: ((downloadId: Long, fileName: String, success: Boolean) -> Unit)? = null

    fun downloadVideo(context: Context, video: YouTubeVideo) {
        var current: Context? = context
        while (current != null) {
            if (current is Activity) {
                showDownloadDialog(current, video)
                return
            }
            if (current is android.content.ContextWrapper) {
                current = current.baseContext
            } else {
                break
            }
        }
        CleanToast.show(context, "Please open video to download")
    }

    fun showDownloadDialog(activity: Activity, video: YouTubeVideo) {
        YouTubeStreamResolver.resolveStreams(video.id) { resolvedStream ->
            if (resolvedStream == null) {
                CleanToast.show(activity, "Download failed: unable to extract stream links.")
                return@resolveStreams
            }

            // Parse Duration in seconds for size estimation
            val durationParts = video.duration.split(":")
            val durationSec = try {
                if (durationParts.size == 2) {
                    durationParts[0].toInt() * 60 + durationParts[1].toInt()
                } else if (durationParts.size == 3) {
                    durationParts[0].toInt() * 3600 + durationParts[1].toInt() * 60 + durationParts[2].toInt()
                } else 210
            } catch (e: Exception) {
                210
            }

            // Build Quality Options
            val videoOptions = mutableListOf<DownloadQualityOption>()
            val audioOptions = mutableListOf<DownloadQualityOption>()

            // 1. Video Options: Exclusively use genuine progressive muxed streams (Audio + Video combined in 1 file).
            // A downloaded MP4 must NEVER silently lack audio!
            for (qual in resolvedStream.availableQualities) {
                // If qual.audioUrl != null, this is an adaptive video-only stream without sound.
                // We skip video-only streams to ensure downloaded MP4 files always contain audio.
                if (qual.audioUrl != null) continue

                val approxMb = when (qual.resolution) {
                    1080 -> (durationSec * 2.5 / 8).coerceAtLeast(15.0)
                    720 -> (durationSec * 1.5 / 8).coerceAtLeast(8.0)
                    480 -> (durationSec * 0.8 / 8).coerceAtLeast(4.0)
                    360 -> (durationSec * 0.4 / 8).coerceAtLeast(2.0)
                    else -> (durationSec * 0.3 / 8).coerceAtLeast(1.5)
                }
                val sizeStr = String.format("~%.1f MB", approxMb)
                videoOptions.add(
                    DownloadQualityOption(
                        label = "${qual.qualityLabel.replace(" (Fast)", "")} (Video + Audio)",
                        resolutionOrBitrate = "${qual.resolution}p",
                        url = qual.videoUrl,
                        isAudio = false,
                        estimatedSizeMb = sizeStr
                    )
                )
            }

            // 2. Audio Options (Pure Audio Streams - Ultra Low Data)
            val audioUrls = resolvedStream.allAudioUrls
            val bestAudio = resolvedStream.pureAudioUrl ?: resolvedStream.audioUrl
            if (!bestAudio.isNullOrBlank()) {
                val highMb = String.format("~%.1f MB", (durationSec * 0.16 / 8).coerceAtLeast(1.0))
                audioOptions.add(
                    DownloadQualityOption(
                        label = "High Audio (160 kbps HQ)",
                        resolutionOrBitrate = "160 kbps",
                        url = bestAudio,
                        isAudio = true,
                        estimatedSizeMb = highMb
                    )
                )
                val medMb = String.format("~%.1f MB", (durationSec * 0.128 / 8).coerceAtLeast(0.8))
                audioOptions.add(
                    DownloadQualityOption(
                        label = "Standard Audio (128 kbps)",
                        resolutionOrBitrate = "128 kbps",
                        url = if (audioUrls.size > 1) audioUrls[1] else bestAudio,
                        isAudio = true,
                        estimatedSizeMb = medMb
                    )
                )
                val lowMb = String.format("~%.1f MB", (durationSec * 0.064 / 8).coerceAtLeast(0.5))
                audioOptions.add(
                    DownloadQualityOption(
                        label = "Data Saver Audio (64 kbps)",
                        resolutionOrBitrate = "64 kbps",
                        url = if (audioUrls.isNotEmpty()) audioUrls.last() else bestAudio,
                        isAudio = true,
                        estimatedSizeMb = lowMb
                    )
                )
            }

            displayOptionsDialog(activity, video, videoOptions, audioOptions)
        }
    }

    private fun displayOptionsDialog(
        activity: Activity,
        video: YouTubeVideo,
        videoOptions: List<DownloadQualityOption>,
        audioOptions: List<DownloadQualityOption>
    ) {
        val context = activity
        val builder = AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)

        val mainLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 36, 48, 24)
            setBackgroundColor(Color.parseColor("#181818"))
        }

        // Title & Channel
        val tvTitle = TextView(context).apply {
            text = "Download Options"
            textSize = 18f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 8)
        }
        mainLayout.addView(tvTitle)

        val tvSub = TextView(context).apply {
            text = "${video.title}\n${video.channelTitle}"
            textSize = 12f
            setTextColor(Color.parseColor("#AAAAAA"))
            maxLines = 2
            setPadding(0, 0, 0, 16)
        }
        mainLayout.addView(tvSub)

        // Type Tabs: Video vs Audio
        val typeRadioGroup = RadioGroup(context).apply {
            orientation = RadioGroup.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 8, 0, 16)
        }

        val hasVideo = videoOptions.isNotEmpty()
        val rbVideo = RadioButton(context).apply {
            id = View.generateViewId()
            text = "🎬 Video (MP4 + Audio)"
            setTextColor(Color.WHITE)
            isChecked = hasVideo
            setPadding(8, 0, 24, 0)
        }

        val rbAudio = RadioButton(context).apply {
            id = View.generateViewId()
            text = "🎧 Audio Only (M4A)"
            setTextColor(Color.WHITE)
            isChecked = !hasVideo
            setPadding(8, 0, 8, 0)
        }

        typeRadioGroup.addView(rbVideo)
        typeRadioGroup.addView(rbAudio)
        mainLayout.addView(typeRadioGroup)

        // Quality Options Container
        val scrollView = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                weight = 1f
            }
        }

        val qualityRadioGroup = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
        }

        var currentSelectedOption: DownloadQualityOption? = if (hasVideo) videoOptions.firstOrNull() else audioOptions.firstOrNull()

        fun populateQualityOptions(isAudio: Boolean) {
            qualityRadioGroup.removeAllViews()
            val list = if (isAudio) audioOptions else videoOptions
            currentSelectedOption = list.firstOrNull()

            if (list.isEmpty()) {
                val tvEmpty = TextView(context).apply {
                    text = "No progressive muxed video stream available. Please select Audio (M4A)."
                    setTextColor(Color.parseColor("#CCCCCC"))
                    textSize = 13sp
                    setPadding(12, 16, 12, 16)
                }
                qualityRadioGroup.addView(tvEmpty)
                return
            }

            list.forEachIndexed { index, option ->
                val rb = RadioButton(context).apply {
                    text = "${option.label}  (${option.estimatedSizeMb})"
                    textSize = 14f
                    setTextColor(Color.parseColor("#E0E0E0"))
                    isChecked = (index == 0)
                    setPadding(12, 16, 12, 16)
                    setOnClickListener {
                        currentSelectedOption = option
                    }
                }
                qualityRadioGroup.addView(rb)
            }
        }

        typeRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == rbVideo.id) {
                populateQualityOptions(false)
            } else if (checkedId == rbAudio.id) {
                populateQualityOptions(true)
            }
        }

        populateQualityOptions(!hasVideo)
        scrollView.addView(qualityRadioGroup)
        mainLayout.addView(scrollView)

        builder.setView(mainLayout)
        builder.setPositiveButton("Download") { dialog, _ ->
            currentSelectedOption?.let { opt ->
                startDownload(context, video, opt)
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancel", null)

        val dialog = builder.create()
        dialog.show()
    }

    fun startDownload(context: Context, video: YouTubeVideo, option: DownloadQualityOption, isRetry: Boolean = false) {
        // Pre-flight expiration check: refresh stream if URL expired before download starts
        if (YouTubeStreamResolver.isStreamUrlExpired(option.url, 0L) && !isRetry) {
            YouTubeStreamResolver.resolveStreams(video.id, forceFresh = true) { freshStream ->
                if (freshStream != null) {
                    val freshUrl = if (option.isAudio) {
                        freshStream.pureAudioUrl ?: freshStream.audioUrl ?: freshStream.videoUrl
                    } else {
                        freshStream.availableQualities.firstOrNull { it.audioUrl == null && it.resolution == option.resolutionOrBitrate.replace("p", "").toIntOrNull() }?.videoUrl
                            ?: freshStream.availableQualities.firstOrNull { it.audioUrl == null }?.videoUrl
                            ?: freshStream.videoUrl
                    }
                    startDownload(context, video, option.copy(url = freshUrl), isRetry = true)
                } else {
                    CleanToast.show(context, "Download failed: unable to refresh stream link.")
                }
            }
            return
        }

        val ext = if (option.isAudio) "m4a" else "mp4"
        var cleanName = sanitizeFileName("${video.title} [${option.resolutionOrBitrate}].$ext")

        // Duplicate name collision prevention: make unique file name
        try {
            val downloadDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CleanPlayer")
            if (!downloadDir.exists()) downloadDir.mkdirs()

            var candidate = File(downloadDir, cleanName)
            if (candidate.exists()) {
                val base = candidate.nameWithoutExtension
                var counter = 1
                while (candidate.exists()) {
                    cleanName = "$base ($counter).$ext"
                    candidate = File(downloadDir, cleanName)
                    counter++
                }
            }

            // Storage space safety check
            val freeBytes = downloadDir.usableSpace
            if (freeBytes < 10L * 1024L * 1024L) {
                CleanToast.show(context, "Insufficient storage space for download.")
                return
            }

            val request = DownloadManager.Request(Uri.parse(option.url)).apply {
                setTitle(video.title)
                setDescription("${option.label} • CleanPlayer")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "CleanPlayer/$cleanName")
                setAllowedOverMetered(true)
                setAllowedOverRoaming(true)
            }

            val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val downloadId = downloadManager.enqueue(request)

            val info = ActiveDownloadInfo(
                downloadId = downloadId,
                title = video.title,
                fileName = cleanName,
                isAudio = option.isAudio,
                video = video,
                option = option,
                hasRetried = isRetry
            )
            synchronized(activeDownloads) {
                activeDownloads[downloadId] = info
            }

            CleanToast.show(context, "⬇️ Download started: ${video.title} (${option.label})")

            startProgressMonitoring(context)
        } catch (e: Exception) {
            e.printStackTrace()
            CleanToast.show(context, "Download failed: ${e.localizedMessage}")
        }
    }

    private fun startProgressMonitoring(context: Context) {
        if (progressTrackingRunnable != null) return

        val appContext = context.applicationContext
        val downloadManager = appContext.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

        val runnable = object : Runnable {
            override fun run() {
                val toRemove = mutableListOf<Long>()
                val activeList: List<ActiveDownloadInfo>

                synchronized(activeDownloads) {
                    activeList = activeDownloads.values.toList()
                }

                if (activeList.isEmpty()) {
                    progressTrackingRunnable = null
                    return
                }

                for (info in activeList) {
                    try {
                        val query = DownloadManager.Query().setFilterById(info.downloadId)
                        val cursor = downloadManager.query(query)
                        if (cursor != null && cursor.moveToFirst()) {
                            val bytesCol = cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                            val totalCol = cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                            val statusCol = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)

                            val downloaded = if (bytesCol >= 0) cursor.getLong(bytesCol) else 0L
                            val total = if (totalCol >= 0) cursor.getLong(totalCol) else 0L
                            val status = if (statusCol >= 0) cursor.getInt(statusCol) else DownloadManager.STATUS_RUNNING

                            info.downloadedBytes = downloaded
                            info.totalBytes = total
                            info.status = status

                            val percent = if (total > 0) ((downloaded * 100) / total).toInt() else 0
                            info.percent = percent

                            val downStr = formatSize(downloaded)
                            val totalStr = formatSize(total)

                            mainHandler.post {
                                onDownloadProgressChanged?.invoke(info.downloadId, percent, downStr, totalStr, status)
                            }

                            if (status == DownloadManager.STATUS_SUCCESSFUL) {
                                toRemove.add(info.downloadId)
                                mainHandler.post {
                                    CleanToast.show(appContext, "✅ Download Complete!\n${info.title}")
                                    onDownloadFinished?.invoke(info.downloadId, info.fileName, true)
                                }
                            } else if (status == DownloadManager.STATUS_FAILED) {
                                val reasonCol = cursor.getColumnIndex(DownloadManager.COLUMN_REASON)
                                val reason = if (reasonCol >= 0) cursor.getInt(reasonCol) else -1
                                if ((reason == 403 || reason == 410) && info.video != null && info.option != null && !info.hasRetried) {
                                    info.hasRetried = true
                                    toRemove.add(info.downloadId)
                                    YouTubeStreamResolver.invalidateStreamCache(info.video.id)
                                    YouTubeStreamResolver.resolveStreams(info.video.id, forceFresh = true) { freshStream ->
                                        if (freshStream != null) {
                                            val freshUrl = if (info.option.isAudio) {
                                                freshStream.pureAudioUrl ?: freshStream.audioUrl ?: freshStream.videoUrl
                                            } else {
                                                freshStream.availableQualities.firstOrNull { it.audioUrl == null && it.resolution == info.option.resolutionOrBitrate.replace("p", "").toIntOrNull() }?.videoUrl
                                                    ?: freshStream.availableQualities.firstOrNull { it.audioUrl == null }?.videoUrl
                                                    ?: freshStream.videoUrl
                                            }
                                            startDownload(appContext, info.video, info.option.copy(url = freshUrl), isRetry = true)
                                        } else {
                                            mainHandler.post {
                                                CleanToast.show(appContext, "❌ Download failed: ${info.title}")
                                                onDownloadFinished?.invoke(info.downloadId, info.fileName, false)
                                            }
                                        }
                                    }
                                } else {
                                    toRemove.add(info.downloadId)
                                    mainHandler.post {
                                        CleanToast.show(appContext, "❌ Download failed: ${info.title}")
                                        onDownloadFinished?.invoke(info.downloadId, info.fileName, false)
                                    }
                                }
                            }
                            cursor.close()
                        } else {
                            cursor?.close()
                            toRemove.add(info.downloadId)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                synchronized(activeDownloads) {
                    toRemove.forEach { activeDownloads.remove(it) }
                }

                if (activeDownloads.isNotEmpty()) {
                    mainHandler.postDelayed(this, 750)
                } else {
                    progressTrackingRunnable = null
                }
            }
        }

        progressTrackingRunnable = runnable
        mainHandler.post(runnable)
    }

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 MB"
        val mb = bytes.toDouble() / (1024 * 1024)
        return String.format("%.1f MB", mb)
    }

    fun sanitizeFileName(name: String): String {
        var clean = name.replace("\u0000", "")
            .replace("../", "")
            .replace("..\\", "")
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .trim()
        while (clean.startsWith(".")) {
            clean = clean.drop(1)
        }
        if (clean.isBlank()) {
            clean = "download_${System.currentTimeMillis()}"
        }
        return if (clean.length > 150) clean.take(150) else clean
    }

    fun getDownloadedVideos(context: Context): List<YouTubeVideo> {
        val list = mutableListOf<YouTubeVideo>()
        try {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CleanPlayer")
            if (dir.exists() && dir.isDirectory) {
                dir.listFiles()?.filter { it.extension.lowercase() in listOf("mp4", "m4a", "webm", "mkv", "mp3") }?.forEach { f ->
                    val rawTitle = f.nameWithoutExtension.substringBeforeLast(" [")
                    val isAudio = f.extension.lowercase() in listOf("m4a", "mp3")
                    list.add(
                        YouTubeVideo(
                            id = f.absolutePath,
                            title = if (rawTitle.isNotBlank()) rawTitle else f.nameWithoutExtension,
                            channelTitle = if (isAudio) "Downloaded Audio" else "Downloaded Video",
                            thumbnailUrl = "",
                            duration = "Offline",
                            views = String.format("%.1f MB", f.length() / (1024.0 * 1024.0)),
                            uploadDate = "Saved on Device",
                            category = "Downloads"
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun findDownloadedFile(title: String, videoId: String): File? {
        try {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CleanPlayer")
            if (dir.exists() && dir.isDirectory) {
                val clean = sanitizeFileName(title).take(20).lowercase()
                val files = dir.listFiles() ?: return null
                return files.firstOrNull { f ->
                    val fn = f.name.lowercase()
                    (clean.isNotBlank() && fn.contains(clean)) || (videoId.isNotBlank() && fn.contains(videoId.lowercase()))
                }
            }
        } catch (e: Exception) {}
        return null
    }

    fun deleteDownloadedVideo(context: Context, video: YouTubeVideo): Boolean {
        try {
            val directFile = File(video.id)
            if (directFile.exists() && directFile.isFile) {
                return directFile.delete()
            }
            val found = findDownloadedFile(video.title, video.id)
            if (found != null && found.exists()) {
                return found.delete()
            }
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "CleanPlayer")
            if (dir.exists() && dir.isDirectory) {
                val clean = sanitizeFileName(video.title).take(15).lowercase()
                dir.listFiles()?.forEach { f ->
                    val fn = f.name.lowercase()
                    if ((clean.isNotBlank() && fn.contains(clean)) || (video.id.isNotBlank() && fn.contains(video.id.lowercase()))) {
                        return f.delete()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }
}
