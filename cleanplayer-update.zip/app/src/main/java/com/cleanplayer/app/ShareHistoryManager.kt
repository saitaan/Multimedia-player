package com.cleanplayer.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ShareHistoryManager {

    private const val PREFS_NAME = "cleanplayer_share_history_prefs"
    private const val KEY_RECORDS = "key_transfer_records"
    private val recordsList = mutableListOf<TransferRecord>()
    private var isLoaded = false

    @Synchronized
    fun getRecords(context: Context): List<TransferRecord> {
        if (!isLoaded) {
            loadRecords(context)
        }
        return recordsList.toList()
    }

    @Synchronized
    fun addOrUpdateRecord(context: Context, record: TransferRecord) {
        if (!isLoaded) loadRecords(context)
        val idx = recordsList.indexOfFirst { it.id == record.id }
        if (idx >= 0) {
            recordsList[idx] = record
        } else {
            recordsList.add(0, record)
        }
        saveRecords(context)
    }

    @Synchronized
    fun clearHistory(context: Context) {
        recordsList.clear()
        saveRecords(context)
    }

    private fun loadRecords(context: Context) {
        recordsList.clear()
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_RECORDS, null)
        if (!jsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    recordsList.add(
                        TransferRecord(
                            id = obj.getString("id"),
                            fileName = obj.getString("fileName"),
                            filePath = obj.getString("filePath"),
                            totalSize = obj.getLong("totalSize"),
                            transferredBytes = obj.getLong("transferredBytes"),
                            isOutgoing = obj.getBoolean("isOutgoing"),
                            isCompleted = obj.getBoolean("isCompleted"),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                            speedMbPerSec = obj.optDouble("speedMbPerSec", 0.0).toFloat(),
                            type = try {
                                ShareItemType.valueOf(obj.optString("type", "FILE"))
                            } catch (e: Exception) {
                                ShareItemType.FILE
                            }
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        isLoaded = true
    }

    private fun saveRecords(context: Context) {
        try {
            val array = JSONArray()
            for (rec in recordsList.take(200)) {
                val obj = JSONObject().apply {
                    put("id", rec.id)
                    put("fileName", rec.fileName)
                    put("filePath", rec.filePath)
                    put("totalSize", rec.totalSize)
                    put("transferredBytes", rec.transferredBytes)
                    put("isOutgoing", rec.isOutgoing)
                    put("isCompleted", rec.isCompleted)
                    put("timestamp", rec.timestamp)
                    put("speedMbPerSec", rec.speedMbPerSec.toDouble())
                    put("type", rec.type.name)
                }
                array.put(obj)
            }
            context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_RECORDS, array.toString())
                .apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun formatDateGroup(timestamp: Long): String {
        val now = System.currentTimeMillis()
        val diffDays = (now - timestamp) / (24 * 60 * 60 * 1000L)
        return when {
            diffDays == 0L -> "Today"
            diffDays == 1L -> "Yesterday"
            else -> SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(timestamp))
        }
    }
}
