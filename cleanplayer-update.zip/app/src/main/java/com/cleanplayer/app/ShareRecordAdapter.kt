package com.cleanplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class ShareRecordAdapter(
    private var records: List<TransferRecord> = emptyList(),
    private val onActionClick: (TransferRecord) -> Unit
) : RecyclerView.Adapter<ShareRecordAdapter.RecordViewHolder>() {

    fun updateRecords(newRecords: List<TransferRecord>) {
        records = newRecords
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecordViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_share_record, parent, false)
        return RecordViewHolder(view)
    }

    override fun onBindViewHolder(holder: RecordViewHolder, position: Int) {
        val item = records[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int = records.size

    inner class RecordViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivIcon: ImageView = itemView.findViewById(R.id.ivRecordIcon)
        private val ivDirection: ImageView = itemView.findViewById(R.id.ivRecordDirection)
        private val tvFileName: TextView = itemView.findViewById(R.id.tvRecordFileName)
        private val tvSubtitle: TextView = itemView.findViewById(R.id.tvRecordSubtitle)
        private val btnAction: Button = itemView.findViewById(R.id.btnRecordAction)

        fun bind(record: TransferRecord) {
            tvFileName.text = record.fileName
            val sizeMb = String.format("%.1f MB", record.totalSize / (1024f * 1024f))
            val status = if (record.isCompleted) "Completed" else "Incomplete (${(record.transferredBytes * 100 / record.totalSize.coerceAtLeast(1L)).toInt()}%)"
            val direction = if (record.isOutgoing) "Sent" else "Received"
            tvSubtitle.text = "$sizeMb • $direction • $status"

            if (record.isOutgoing) {
                ivDirection.setImageResource(R.drawable.ic_send_arrow)
                ivDirection.setColorFilter(android.graphics.Color.parseColor("#00E5FF"))
            } else {
                ivDirection.setImageResource(R.drawable.ic_receive_arrow)
                ivDirection.setColorFilter(android.graphics.Color.parseColor("#00F5A0"))
            }

            when (record.type) {
                ShareItemType.VIDEO -> ivIcon.setImageResource(R.drawable.ic_video)
                ShareItemType.AUDIO -> ivIcon.setImageResource(R.drawable.ic_audio)
                ShareItemType.IMAGE -> ivIcon.setImageResource(android.R.drawable.ic_menu_gallery)
                ShareItemType.APP -> ivIcon.setImageResource(android.R.drawable.sym_def_app_icon)
                ShareItemType.FILE -> ivIcon.setImageResource(R.drawable.ic_folder)
            }

            if (record.isCompleted) {
                btnAction.text = if (record.fileName.endsWith(".apk", true)) "Install" else "Open"
            } else {
                btnAction.text = "Resume"
            }

            btnAction.setOnClickListener {
                onActionClick(record)
            }
        }
    }
}
