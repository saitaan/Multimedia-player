package com.cleanplayer.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView

/**
 * Interactive Dialog for Manual Tuning of Neural Super-Resolution Parameters:
 * - Scale Factor (2x 1080p, 3x 2K QHD, 4x 4K Ultra)
 * - Sub-Pixel Edge Sharpness (10% to 150%)
 * - Dynamic Micro-Contrast Boost (10% to 150%)
 * - Sub-Pixel Clarity & Texture Smoothing (0% to 100%)
 *
 * Fully tuned and optimized for POCO C85x, Xiaomi HyperOS 3, and Android 16 (Baklava).
 */
object NeuralSuperResTuneDialog {

    fun show(context: Context, onUpdated: (() -> Unit)? = null) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_super_res_tuning, null)
        val dialog = AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val btnClose = view.findViewById<ImageButton>(R.id.btnSuperResTuneClose)
        val tvHwProfile = view.findViewById<TextView>(R.id.tvSuperResHardwareProfile)

        val prof = HardwareProfilerEngine.getProfile(context)
        tvHwProfile?.text = "${prof.brand} ${prof.model} • ${prof.recommendedShader}"

        val btnScale2x = view.findViewById<TextView>(R.id.btnScale2x)
        val btnScale3x = view.findViewById<TextView>(R.id.btnScale3x)
        val btnScale4x = view.findViewById<TextView>(R.id.btnScale4x)

        val tvValSharpness = view.findViewById<TextView>(R.id.tvValSharpness)
        val sbSharpness = view.findViewById<SeekBar>(R.id.sbSharpness)

        val tvValContrast = view.findViewById<TextView>(R.id.tvValContrast)
        val sbContrast = view.findViewById<SeekBar>(R.id.sbContrast)

        val tvValDeNoise = view.findViewById<TextView>(R.id.tvValDeNoise)
        val sbDeNoise = view.findViewById<SeekBar>(R.id.sbDeNoise)

        val btnReset = view.findViewById<Button>(R.id.btnResetSuperResDefaults)
        val btnApply = view.findViewById<Button>(R.id.btnApplySuperResTuning)

        fun updateScaleButtons() {
            val scale = PlayerHolder.aiSuperResScaleFactor
            btnScale2x?.setBackgroundResource(if (scale == 2) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            btnScale2x?.setTextColor(if (scale == 2) Color.BLACK else Color.WHITE)

            btnScale3x?.setBackgroundResource(if (scale == 3) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            btnScale3x?.setTextColor(if (scale == 3) Color.BLACK else Color.WHITE)

            btnScale4x?.setBackgroundResource(if (scale == 4) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            btnScale4x?.setTextColor(if (scale == 4) Color.BLACK else Color.WHITE)
        }

        fun updateUiFromState() {
            updateScaleButtons()
            sbSharpness?.progress = PlayerHolder.aiSuperResSharpness
            tvValSharpness?.text = "${PlayerHolder.aiSuperResSharpness}%"

            sbContrast?.progress = PlayerHolder.aiSuperResMicroContrast
            tvValContrast?.text = "${PlayerHolder.aiSuperResMicroContrast}%"

            sbDeNoise?.progress = PlayerHolder.aiSuperResDeNoise
            tvValDeNoise?.text = "${PlayerHolder.aiSuperResDeNoise}%"
        }

        updateUiFromState()

        btnScale2x?.setOnClickListener {
            PlayerHolder.aiSuperResScaleFactor = 2
            updateScaleButtons()
            AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
            onUpdated?.invoke()
        }

        btnScale3x?.setOnClickListener {
            PlayerHolder.aiSuperResScaleFactor = 3
            updateScaleButtons()
            AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
            onUpdated?.invoke()
        }

        btnScale4x?.setOnClickListener {
            PlayerHolder.aiSuperResScaleFactor = 4
            updateScaleButtons()
            AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
            onUpdated?.invoke()
        }

        sbSharpness?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val p = progress.coerceIn(10, 100)
                    PlayerHolder.aiSuperResSharpness = p
                    tvValSharpness?.text = "$p%"
                    AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
                    onUpdated?.invoke()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        sbContrast?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val p = progress.coerceIn(10, 100)
                    PlayerHolder.aiSuperResMicroContrast = p
                    tvValContrast?.text = "$p%"
                    AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
                    onUpdated?.invoke()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        sbDeNoise?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val p = progress.coerceIn(0, 100)
                    PlayerHolder.aiSuperResDeNoise = p
                    tvValDeNoise?.text = "$p%"
                    AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
                    onUpdated?.invoke()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnReset?.setOnClickListener {
            PlayerHolder.aiSuperResScaleFactor = 4
            PlayerHolder.aiSuperResSharpness = 80
            PlayerHolder.aiSuperResMicroContrast = 75
            PlayerHolder.aiSuperResDeNoise = 70
            PlayerHolder.savePreferences(context)
            updateUiFromState()
            AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
            CleanToast.show(context, "Defaults Restored: 4K • 80% Sharpness • 75% Contrast")
            onUpdated?.invoke()
        }

        btnApply?.setOnClickListener {
            PlayerHolder.savePreferences(context)
            CleanToast.show(context, "⚡ Neural Super-Res parameters applied: ${PlayerHolder.aiSuperResScaleFactor}x • ${PlayerHolder.aiSuperResSharpness}% Sharpness")
            dialog.dismiss()
        }

        btnClose?.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }
}
