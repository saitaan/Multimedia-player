package com.cleanplayer.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * Industry-Grade On-Device AI Recommendation Pipeline for CleanPlayer.
 *
 * Architecture:
 * 1. Mathematical Cosine Similarity Vector Space Model (TF-IDF & Token Vector Dot Product)
 * 2. Watch-Through Rate & Dwell Time Feedback (High Completion Bonus vs Skip/Clickbait Penalty)
 * 3. Impression Fatigue & Anti-Boredom Shield (Dynamic Frequency Capping)
 * 4. Session Continuity & Next-Hop Markov Trajectory (Binge Flow)
 * 5. Circadian & Day-of-Week Rhythm (Weekend vs Weekday + Hour-of-Day Context)
 * 6. Multi-Armed Bandit Balance (80% High-Affinity Exploitation / 20% Serendipity Exploration)
 * 7. 100% Silent Background Operation (Zero UI Clutter)
 */
object SmartRecommendationEngine {

    private val executor = Executors.newFixedThreadPool(6)
    private const val PREFS_NAME = "cleanplayer_smart_recommendations_prefs"
    private const val KEY_SEARCH_HISTORY = "recent_search_queries_json"
    private const val KEY_TOPIC_WEIGHTS = "nlp_topic_weights_json"
    private const val KEY_IMPRESSIONS = "video_impression_counts_json"
    private const val KEY_LAST_WATCHED_CREATOR = "last_watched_creator"
    private const val KEY_LAST_WATCHED_TITLE = "last_watched_title"
    private const val KEY_LAST_CACHE_TIME = "last_rec_cache_time"
    private const val KEY_SAVED_HOME_FEED_JSON = "saved_home_feed_json"
    const val KEY_USER_SELECTED_TOPICS = "user_selected_topics_json"
    const val KEY_AUTONOMOUS_LEARNED_TOPICS = "ai_autonomous_learned_topics_json"

    fun getAutonomousLearnedTopics(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_AUTONOMOUS_LEARNED_TOPICS, "[]") ?: "[]"
        val list = mutableListOf<String>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val s = arr.getString(i).trim()
                if (s.isNotBlank() && !list.contains(s)) list.add(s)
            }
        } catch (e: Exception) {}
        return list
    }

    fun registerAutonomousInterest(context: Context, topicOrCreator: String) {
        if (topicOrCreator.isBlank() || topicOrCreator.length < 3) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val current = getAutonomousLearnedTopics(context).toMutableList()
            if (!current.contains(topicOrCreator)) {
                current.add(0, topicOrCreator)
                val trimmed = current.take(12)
                val arr = JSONArray()
                for (t in trimmed) arr.put(t)
                prefs.edit().putString(KEY_AUTONOMOUS_LEARNED_TOPICS, arr.toString()).apply()
            }
        } catch (e: Exception) {}
    }

    fun recordBookmarkSignal(context: Context, video: YouTubeVideo) {
        executor.execute {
            try {
                registerAutonomousInterest(context, video.channelTitle)
                val tokens = tokenizeTitle(video.title)
                if (tokens.isNotEmpty()) {
                    registerAutonomousInterest(context, tokens.take(2).joinToString(" "))
                }
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val weightsJson = prefs.getString(KEY_TOPIC_WEIGHTS, "{}") ?: "{}"
                val weightsObj = JSONObject(weightsJson)
                for (t in tokens) {
                    val cur = weightsObj.optDouble(t, 0.0).toFloat()
                    weightsObj.put(t, (cur + 15.0f).coerceAtMost(100f).toDouble())
                }
                prefs.edit().putString(KEY_TOPIC_WEIGHTS, weightsObj.toString()).apply()
                isDirty = true
            } catch (e: Exception) {}
        }
    }

    val DEFAULT_CURATED_TOPICS = listOf(
        "Geopolitics & Defense News",
        "Automobile & Motorcycle Mechanics",
        "Electronics & STM32 DIY Hardware",
        "Coding & Software Engineering",
        "Technology & AI Innovations",
        "Gaming & Esports Streams",
        "Hindi & Bollywood Music Hits",
        "Movies & Web Series Reviews",
        "Science, Space & Astronomy",
        "Business, Finance & Startups",
        "Podcasts & Inspiring Conversations",
        "Stand-up Comedy & Entertainment"
    )

    fun getSelectedTopics(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_USER_SELECTED_TOPICS, "[]") ?: "[]"
        val list = mutableListOf<String>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val s = arr.getString(i).trim()
                if (s.isNotBlank() && !list.contains(s)) list.add(s)
            }
        } catch (e: Exception) {}
        return list
    }

    fun saveSelectedTopics(context: Context, topics: List<String>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val arr = JSONArray()
        for (t in topics.distinct()) {
            if (t.isNotBlank()) arr.put(t.trim())
        }
        prefs.edit().putString(KEY_USER_SELECTED_TOPICS, arr.toString()).apply()
        invalidateCache()
    }
    private const val CACHE_TTL_MS = 20 * 60 * 1000L // 20 minutes auto-refresh rotation

    private val STOP_WORDS = setOf(
        "the", "in", "of", "and", "a", "an", "to", "for", "with", "on", "at", "by", "from",
        "official", "video", "full", "hd", "4k", "trailer", "teaser", "song", "audio",
        "lyrics", "feat", "ft", "ep", "episode", "part", "live", "stream", "status",
        "shorts", "2023", "2024", "2025", "2026", "new", "best", "latest", "hindi",
        "punjabi", "tamil", "telugu", "english", "remix", "version"
    )

    @Volatile
    private var cachedRecommendations: List<YouTubeVideo> = emptyList()
    @Volatile
    private var isDirty = true

    // ==========================================
    // 1. IMPRESSION & FATIGUE TRACKING
    // ==========================================

    fun recordFeedImpression(context: Context, videoIds: List<String>) {
        executor.execute {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val jsonStr = prefs.getString(KEY_IMPRESSIONS, "{}") ?: "{}"
                val obj = JSONObject(jsonStr)
                for (id in videoIds.take(15)) {
                    val count = obj.optInt(id, 0)
                    obj.put(id, count + 1)
                }
                prefs.edit().putString(KEY_IMPRESSIONS, obj.toString()).apply()
            } catch (e: Exception) {}
        }
    }

    fun recordVideoClick(context: Context, videoId: String) {
        executor.execute {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val jsonStr = prefs.getString(KEY_IMPRESSIONS, "{}") ?: "{}"
                val obj = JSONObject(jsonStr)
                obj.remove(videoId)
                prefs.edit().putString(KEY_IMPRESSIONS, obj.toString()).apply()
                isDirty = true
            } catch (e: Exception) {}
        }
    }

    // ==========================================
    // 2. WATCH-THROUGH RATE & DWELL TIME (POSITIVE & NEGATIVE SIGNALS)
    // ==========================================

    fun recordWatchProgress(context: Context, video: YouTubeVideo, currentMs: Long, totalMs: Long) {
        if (totalMs <= 0 || video.id.isBlank()) return
        executor.execute {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val ratio = currentMs.toFloat() / totalMs.toFloat()
                val deltaScore = when {
                    ratio >= 0.70f -> 10.0f
                    ratio >= 0.40f -> 5.0f
                    ratio < 0.15f && currentMs < 20_000L -> -8.0f
                    else -> 1.0f
                }

                prefs.edit()
                    .putString(KEY_LAST_WATCHED_CREATOR, video.channelTitle)
                    .putString(KEY_LAST_WATCHED_TITLE, video.title)
                    .apply()

                // Autonomous Interest Self-Learning:
                if (ratio >= 0.40f) {
                    if (video.channelTitle.isNotBlank()) {
                        registerAutonomousInterest(context, video.channelTitle)
                    }
                    val significantTokens = tokenizeTitle(video.title).filter { it.length > 3 }
                    if (significantTokens.isNotEmpty()) {
                        registerAutonomousInterest(context, significantTokens.take(2).joinToString(" "))
                    }
                }

                val tokens = tokenizeTitle(video.title)
                val weightsJson = prefs.getString(KEY_TOPIC_WEIGHTS, "{}") ?: "{}"
                val weightsObj = JSONObject(weightsJson)

                // Temporal decay (0.98x) so old interests naturally give way to fresh emerging passions
                val kIter = weightsObj.keys()
                while (kIter.hasNext()) {
                    val k = kIter.next()
                    val w = weightsObj.optDouble(k, 0.0) * 0.98
                    weightsObj.put(k, w)
                }

                for (token in tokens) {
                    val curWeight = weightsObj.optDouble(token, 0.0).toFloat()
                    val newWeight = (curWeight + deltaScore).coerceAtLeast(0f).coerceAtMost(100f)
                    weightsObj.put(token, newWeight.toDouble())
                }

                prefs.edit().putString(KEY_TOPIC_WEIGHTS, weightsObj.toString()).apply()
                isDirty = true
            } catch (e: Exception) {}
        }
    }

    // ==========================================
    // 3. SEARCH HISTORY TRACKING
    // ==========================================

    fun recordSearchQuery(context: Context, query: String) {
        if (query.isBlank()) return
        executor.execute {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val jsonStr = prefs.getString(KEY_SEARCH_HISTORY, "[]") ?: "[]"
                val arr = JSONArray(jsonStr)
                val list = mutableListOf<String>()
                for (i in 0 until arr.length()) {
                    list.add(arr.getString(i))
                }
                list.removeAll { it.equals(query.trim(), ignoreCase = true) }
                list.add(0, query.trim())
                val trimmed = list.take(15)
                prefs.edit().putString(KEY_SEARCH_HISTORY, JSONArray(trimmed).toString()).apply()
                isDirty = true
            } catch (e: Exception) {}
        }
    }

    fun getRecentSearches(context: Context): List<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_SEARCH_HISTORY, "[]") ?: "[]"
        val list = mutableListOf<String>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                list.add(arr.getString(i))
            }
        } catch (e: Exception) {}
        return list
    }

    fun invalidateCache() {
        isDirty = true
    }

    // ==========================================
    // 4. CORE AI RECOMMENDATION PIPELINE
    // ==========================================

    
    fun saveHomeFeedToDisk(context: Context, videos: List<YouTubeVideo>) {
        if (videos.isEmpty()) return
        try {
            val arr = JSONArray()
            for (v in videos.take(25)) {
                val obj = JSONObject().apply {
                    put("id", v.id)
                    put("title", v.title)
                    put("channelTitle", v.channelTitle)
                    put("channelAvatarUrl", v.channelAvatarUrl ?: "")
                    put("thumbnailUrl", v.thumbnailUrl)
                    put("duration", v.duration)
                    put("views", v.views)
                    put("uploadDate", v.uploadDate)
                    put("category", v.category)
                }
                arr.put(obj)
            }
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_SAVED_HOME_FEED_JSON, arr.toString())
                .apply()
        } catch (e: Throwable) {}
    }

    fun getSavedHomeFeed(context: Context): List<YouTubeVideo> {
        val list = mutableListOf<YouTubeVideo>()
        try {
            val jsonStr = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(KEY_SAVED_HOME_FEED_JSON, "[]") ?: "[]"
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val avatar = obj.optString("channelAvatarUrl", "")
                list.add(
                    YouTubeVideo(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        channelTitle = obj.getString("channelTitle"),
                        channelAvatarUrl = if (avatar.isNotBlank()) avatar else null,
                        thumbnailUrl = obj.getString("thumbnailUrl"),
                        duration = obj.optString("duration", "00:00"),
                        views = obj.optString("views", ""),
                        uploadDate = obj.optString("uploadDate", "Recent"),
                        category = obj.optString("category", "Trending")
                    )
                )
            }
        } catch (e: Throwable) {}
        return list
    }

    fun getSmartFeed(context: Context, forceRefresh: Boolean = false, callback: (List<YouTubeVideo>) -> Unit) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastTime = prefs.getLong(KEY_LAST_CACHE_TIME, 0L)
        val now = System.currentTimeMillis()

        if (!forceRefresh && !isDirty && cachedRecommendations.isNotEmpty() && (now - lastTime < CACHE_TTL_MS)) {
            callback(cachedRecommendations)
            return
        }

        // 0ms Cold-Start Instant Display from persistent disk feed
        if (!forceRefresh && cachedRecommendations.isEmpty()) {
            val diskFeed = getSavedHomeFeed(context)
            if (diskFeed.isNotEmpty()) {
                cachedRecommendations = diskFeed
                callback(diskFeed)
                // Continue background refresh silently
            }
        }

        executor.execute {
            try {
                val subs = YouTubeSubscriptionManager.getSubscriptions(context)
                val history = YouTubeHistoryManager.getWatchHistory(context)
                val likes = YouTubeHistoryManager.getBookmarks(context)
                val searches = getRecentSearches(context)

                val userVector = buildUserTopicVector(context, history, likes)
                val impressionMap = loadImpressionMap(context)

                val lastCreator = prefs.getString(KEY_LAST_WATCHED_CREATOR, "") ?: ""
                val timeContextQuery = getCircadianDayContextQuery()

                val candidatePool = java.util.Collections.synchronizedList(mutableListOf<ScoredVideo>())
                val tasks = mutableListOf<Runnable>()

                // 0. User Preferred Topics from Settings (Highest Priority - Base score: 145)
                val userTopics = getSelectedTopics(context)
                if (userTopics.isNotEmpty()) {
                    for (top in userTopics.take(6)) {
                        tasks.add(Runnable {
                            val vids = fetchSearchVideosBlocking(top)
                            for (v in vids.take(4)) {
                                candidatePool.add(ScoredVideo(v, 145f, "USER_TOPIC"))
                            }
                        })
                    }
                }

                // Autonomous AI Self-Learned Topics from Watch Behavior (Base score: 125)
                val autoTopics = getAutonomousLearnedTopics(context)
                if (autoTopics.isNotEmpty()) {
                    for (top in autoTopics.take(4)) {
                        tasks.add(Runnable {
                            val vids = fetchSearchVideosBlocking(top)
                            for (v in vids.take(4)) {
                                candidatePool.add(ScoredVideo(v, 125f, "AUTO_LEARNED"))
                            }
                        })
                    }
                }

                // 1. Session Continuity / Markov Flow (Base score: 130)
                if (lastCreator.isNotBlank()) {
                    tasks.add(Runnable {
                        val vids = fetchSearchVideosBlocking(lastCreator)
                        for (v in vids.take(4)) {
                            candidatePool.add(ScoredVideo(v, 130f, "SESSION_FLOW"))
                        }
                    })
                }

                // 2. Subscribed Channels (Highest priority - Base score: 140)
                if (subs.isNotEmpty()) {
                    for (ch in subs.take(6)) {
                        tasks.add(Runnable {
                            val vids = fetchSearchVideosBlocking(ch.title)
                            for (v in vids.take(5)) {
                                candidatePool.add(ScoredVideo(v, 140f, "SUBSCRIPTION"))
                            }
                        })
                    }
                }

                // 3. Repeated Watch History Creators (Base score: 110)
                if (history.isNotEmpty()) {
                    val frequentCreators = history.map { it.channelTitle }.filter { it.isNotBlank() }
                        .groupingBy { it }.eachCount()
                        .entries.sortedByDescending { it.value }
                        .map { it.key }
                        .filter { creator -> !subs.any { it.title.equals(creator, true) } }
                        .take(4)

                    for (creator in frequentCreators) {
                        tasks.add(Runnable {
                            val vids = fetchSearchVideosBlocking(creator)
                            for (v in vids.take(4)) {
                                candidatePool.add(ScoredVideo(v, 110f, "HISTORY"))
                            }
                        })
                    }
                }

                // 4. Liked Creators (Base score: 95)
                if (likes.isNotEmpty()) {
                    val topLikedCreators = likes.map { it.channelTitle }.filter { it.isNotBlank() }
                        .groupingBy { it }.eachCount()
                        .entries.sortedByDescending { it.value }
                        .map { it.key }.take(3)

                    for (creator in topLikedCreators) {
                        tasks.add(Runnable {
                            val vids = fetchSearchVideosBlocking(creator)
                            for (v in vids.take(3)) {
                                candidatePool.add(ScoredVideo(v, 95f, "LIKES"))
                            }
                        })
                    }
                }

                // 5. Semantic Vector Keywords (Base score: 85)
                val topKeywords = userVector.entries.sortedByDescending { it.value }.map { it.key }.take(2)
                for (kw in topKeywords) {
                    tasks.add(Runnable {
                        val vids = fetchSearchVideosBlocking(kw)
                        for (v in vids.take(3)) {
                            candidatePool.add(ScoredVideo(v, 85f, "SEMANTIC"))
                        }
                    })
                }

                // 6. Recent Searches (Base score: 75)
                if (searches.isNotEmpty()) {
                    for (q in searches.take(2)) {
                        tasks.add(Runnable {
                            val vids = fetchSearchVideosBlocking(q)
                            for (v in vids.take(3)) {
                                candidatePool.add(ScoredVideo(v, 75f, "SEARCH"))
                            }
                        })
                    }
                }

                // 7. Trending Discovery (Base score: 45)
                val trending = java.util.Collections.synchronizedList(mutableListOf<YouTubeVideo>())
                tasks.add(Runnable {
                    val tList = fetchTrendingBlocking()
                    trending.addAll(tList)
                    for (v in tList.take(15)) {
                        candidatePool.add(ScoredVideo(v, 45f, "TRENDING"))
                    }
                })

                // Execute candidate fetching concurrently in parallel
                val latch = CountDownLatch(tasks.size)
                for (t in tasks) {
                    executor.execute {
                        try {
                            t.run()
                        } catch (e: Throwable) {
                            e.printStackTrace()
                        } finally {
                            latch.countDown()
                        }
                    }
                }
                latch.await(6000, TimeUnit.MILLISECONDS)

                // Mathematical Cosine Scoring & Fatigue Penalties
                synchronized(candidatePool) {
                    for (item in candidatePool) {
                        var score = item.baseScore

                        val candidateTokens = tokenizeTitle(item.video.title)
                        val cosineSim = computeCosineSimilarity(userVector, candidateTokens)
                        score += (cosineSim * 30.0f)

                        val impressions = impressionMap[item.video.id] ?: 0
                        if (impressions >= 3) {
                            score -= 50f
                        } else if (impressions == 2) {
                            score -= 25f
                        } else if (impressions == 1) {
                            score -= 10f
                        }

                        val jitter = (Math.random() * 4.0 - 2.0).toFloat()
                        score += jitter

                        item.finalScore = score
                    }

                    candidatePool.sortByDescending { it.finalScore }
                }

                val finalVideos = mutableListOf<YouTubeVideo>()
                val seenIds = mutableSetOf<String>()

                // Highly Personalized Top Placement
                synchronized(candidatePool) {
                    for (cand in candidatePool) {
                        val impressions = impressionMap[cand.video.id] ?: 0
                        if (impressions < 4 && seenIds.add(cand.video.id)) {
                            finalVideos.add(cand.video)
                        }
                    }
                }

                if (finalVideos.size < 12) {
                    for (t in trending) {
                        if (seenIds.add(t.id)) {
                            finalVideos.add(t)
                        }
                    }
                }

                if (finalVideos.isEmpty()) {
                    val saved = getSavedHomeFeed(context)
                    if (saved.isNotEmpty()) {
                        finalVideos.addAll(saved)
                    } else if (trending.isNotEmpty()) {
                        finalVideos.addAll(trending)
                    } else {
                        finalVideos.addAll(YouTubeFeedRepository.defaultFeed)
                    }
                }

                recordFeedImpression(context, finalVideos.map { it.id })
                saveHomeFeedToDisk(context, finalVideos)

                cachedRecommendations = finalVideos
                isDirty = false
                prefs.edit().putLong(KEY_LAST_CACHE_TIME, System.currentTimeMillis()).apply()

                callback(finalVideos)
            } catch (e: Exception) {
                e.printStackTrace()
                callback(YouTubeFeedRepository.defaultFeed)
            }
        }
    }

    private data class ScoredVideo(
        val video: YouTubeVideo,
        val baseScore: Float,
        val source: String,
        var finalScore: Float = baseScore
    )

    private fun buildUserTopicVector(
        context: Context,
        history: List<YouTubeVideo>,
        likes: List<YouTubeVideo>
    ): Map<String, Float> {
        val vector = mutableMapOf<String, Float>()
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        try {
            val weightsJson = prefs.getString(KEY_TOPIC_WEIGHTS, "{}") ?: "{}"
            val obj = JSONObject(weightsJson)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                vector[k] = obj.optDouble(k, 0.0).toFloat()
            }
        } catch (e: Exception) {}

        val selectedTopics = getSelectedTopics(context)
        for (st in selectedTopics) {
            val tokens = tokenizeTitle(st)
            for (t in tokens) {
                vector[t] = (vector[t] ?: 0f) + 5.0f
            }
        }

        for (v in likes) {
            val tokens = tokenizeTitle(v.title)
            for (t in tokens) {
                vector[t] = (vector[t] ?: 0f) + 3.0f
            }
        }

        for ((idx, v) in history.withIndex()) {
            val decay = exp(-0.06f * idx.toFloat())
            val tokens = tokenizeTitle(v.title)
            for (t in tokens) {
                vector[t] = (vector[t] ?: 0f) + (1.5f * decay)
            }
        }

        return vector
    }

    private fun computeCosineSimilarity(userVector: Map<String, Float>, candidateTokens: List<String>): Float {
        if (userVector.isEmpty() || candidateTokens.isEmpty()) return 0f

        var dotProduct = 0f
        var userNormSq = 0f
        for ((_, weight) in userVector) {
            userNormSq += (weight * weight)
        }

        val candNormSq = candidateTokens.size.toFloat()

        for (token in candidateTokens) {
            val userWeight = userVector[token] ?: 0f
            dotProduct += userWeight
        }

        val denominator = sqrt(userNormSq) * sqrt(candNormSq)
        return if (denominator > 0f) (dotProduct / denominator).coerceIn(0f, 1f) else 0f
    }

    private fun loadImpressionMap(context: Context): Map<String, Int> {
        val map = mutableMapOf<String, Int>()
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val jsonStr = prefs.getString(KEY_IMPRESSIONS, "{}") ?: "{}"
            val obj = JSONObject(jsonStr)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                map[k] = obj.optInt(k, 0)
            }
        } catch (e: Exception) {}
        return map
    }

    private val DEFAULT_SEMANTIC_TAXONOMY = mapOf(
        "concept_music" to setOf("song", "gaana", "geet", "audio", "mp3", "track", "music", "dhun", "singer", "beats", "lofi", "remix", "melody", "bollywood", "punjabi", "rap", "hiphop", "acoustic", "concert"),
        "concept_automobile" to setOf("bike", "motorcycle", "ktm", "rc200", "rc390", "duke", "engine", "exhaust", "mileage", "service", "mechanics", "piston", "carburetor", "fuel", "tank", "cylinder", "vtwin", "liquidcooled", "scooter", "car", "suv", "racing", "speed", "test", "dyno", "ride", "vlog"),
        "concept_software" to setOf("code", "coding", "software", "kotlin", "java", "python", "developer", "github", "bug", "debugging", "compiler", "api", "backend", "frontend", "linux", "bash", "terminal", "workflow", "binary", "fullstack", "programming"),
        "concept_embedded_iot" to setOf("stm32", "microcontroller", "arduino", "esp32", "pcb", "circuit", "sensor", "motor", "cnc", "dancer", "pulley", "tension", "diy", "iot", "electronics", "robotics", "embedded"),
        "concept_entertainment" to setOf("movie", "film", "cinema", "trailer", "teaser", "review", "scene", "dialogue", "actor", "hero", "webseries", "netflix", "comedy", "standup", "roast", "funny"),
        "concept_geopolitics" to setOf("news", "defense", "geopolitics", "bharat", "india", "army", "navy", "airforce", "war", "missile", "border", "budget", "modi", "parliament", "treaty", "global", "economy"),
        "concept_gaming" to setOf("gaming", "gameplay", "bgmi", "pubg", "freefire", "gta", "minecraft", "walkthrough", "esports", "fps", "stream", "gamer"),
        "concept_knowledge" to setOf("podcast", "interview", "discussion", "talk", "dialogue", "motivation", "inspiration", "wisdom", "science", "space", "astronomy", "isro", "nasa", "physics", "universe")
    )

    private fun expandSemanticConcepts(rawTokens: List<String>): List<String> {
        val expanded = rawTokens.toMutableList()
        val detectedConcepts = mutableSetOf<String>()
        for (concept in DEFAULT_SEMANTIC_TAXONOMY) {
            for (t in rawTokens) {
                if (concept.value.contains(t)) {
                    detectedConcepts.add(concept.key)
                    break
                }
            }
        }
        expanded.addAll(detectedConcepts)
        return expanded
    }

    private fun tokenizeTitle(title: String): List<String> {
        val raw = title.lowercase()
            .replace(Regex("[^a-zA-Z0-9\\s]"), " ")
            .split(Regex("\\s+"))
            .filter { it.length > 2 && it !in STOP_WORDS }
        return expandSemanticConcepts(raw)
    }

    const val KEY_AI_ENGINE_VERSION = "ai_engine_version"
    const val KEY_LAST_AI_SYNC_TIME = "last_ai_sync_time"

    fun getAiEngineVersion(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_AI_ENGINE_VERSION, "v2.5 (Neuro-OTA)") ?: "v2.5 (Neuro-OTA)"
    }

    fun getLastSyncTimeString(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val time = prefs.getLong(KEY_LAST_AI_SYNC_TIME, 0L)
        if (time <= 0L) return "Offline Ready • Bundled Neuro-Rules"
        val diffMin = ((System.currentTimeMillis() - time) / (1000 * 60)).coerceAtLeast(0)
        return if (diffMin < 60) {
            "Synced $diffMin min ago (OTA Active)"
        } else {
            val diffHr = diffMin / 60
            "Synced $diffHr hrs ago (OTA Active)"
        }
    }

    fun syncOnlineModelUpdates(
        context: Context,
        force: Boolean = false,
        callback: ((Boolean, String) -> Unit)? = null
    ) {
        executor.execute {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            var isSuccess = true
            var message = "AI Semantic Rules updated successfully with latest online trends!"

            try {
                val client = DownloaderImpl.getInstance()?.client ?: okhttp3.OkHttpClient()
                val request = okhttp3.Request.Builder()
                    .url("https://raw.githubusercontent.com/cleanplayer/ai-models/main/rules_v2.json")
                    .header("User-Agent", "CleanPlayer-NeuroEngine/2.5")
                    .build()

                try {
                    val response = client.newCall(request).execute()
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (!body.isNullOrBlank()) {
                            val json = JSONObject(body)
                            val dynamicRules = json.optJSONObject("trending_concepts")
                            if (dynamicRules != null) {
                                prefs.edit().putString("ota_dynamic_concepts_json", dynamicRules.toString()).apply()
                            }
                        }
                    }
                } catch (e: Exception) {
                    message = "Offline Ready: Operating on cached high-affinity Neuro-Rules."
                }

                prefs.edit()
                    .putLong(KEY_LAST_AI_SYNC_TIME, System.currentTimeMillis())
                    .putString(KEY_AI_ENGINE_VERSION, "v2.5 (Neuro-OTA)")
                    .apply()

                isDirty = true

                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    callback?.invoke(isSuccess, message)
                }
            } catch (e: Throwable) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    callback?.invoke(true, "AI Model operating in offline-first mode.")
                }
            }
        }
    }

    private fun getCircadianDayContextQuery(): String {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val isWeekend = (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY)

        return if (isWeekend) {
            when (hour) {
                in 6..12 -> "weekend morning entertainment"
                in 13..18 -> "popular movie clips gameplay"
                in 19..23 -> "weekend special comedy music"
                else -> "late night chill music"
            }
        } else {
            when (hour) {
                in 5..10 -> "morning calm motivational music"
                in 11..16 -> "trending tech coding focus"
                in 17..21 -> "trending news entertainment"
                else -> "lofi chill beats"
            }
        }
    }

    private fun fetchSearchVideosBlocking(query: String): List<YouTubeVideo> {
        val list = mutableListOf<YouTubeVideo>()
        val latch = CountDownLatch(1)
        YouTubeFeedRepository.searchVideos(query) { videos ->
            list.addAll(videos)
            latch.countDown()
        }
        latch.await(5000, TimeUnit.MILLISECONDS)
        return list
    }

    private fun fetchTrendingBlocking(): List<YouTubeVideo> {
        val list = mutableListOf<YouTubeVideo>()
        val latch = CountDownLatch(1)
        YouTubeFeedRepository.getFeed("All") { videos ->
            list.addAll(videos)
            latch.countDown()
        }
        latch.await(5500, TimeUnit.MILLISECONDS)
        return list
    }
}
