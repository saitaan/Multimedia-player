package com.cleanplayer.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.audiofx.Visualizer
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.sin

class AudioVisualizerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        const val MODEL_STUDIO_BARS = 0      // Symmetrical rounded pillars
        const val MODEL_RETRO_LED_MATRIX = 1 // Stacked square LED blocks
        const val MODEL_CYBERPUNK_LASER = 2  // Fine needle spikes with golden glow
    }

    var currentModel = MODEL_STUDIO_BARS
    var onModelChangedListener: ((model: Int, name: String) -> Unit)? = null

    // Audio FFT & Processing
    private var visualizer: Visualizer? = null
    private val barCount = 32
    private val currentHeights = FloatArray(barCount) { 0.15f }
    private val targetHeights = FloatArray(barCount) { 0.15f }
    private val peakHeights = FloatArray(barCount) { 0.15f }
    private val peakHoldFrames = IntArray(barCount) { 0 }

    // Laser spikes high-density data (Model 2)
    private val spikeCount = 80
    private val currentSpikes = FloatArray(spikeCount) { 0.10f }
    private val targetSpikes = FloatArray(spikeCount) { 0.10f }

    private val barRect = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }

    private var isPlaying = false
    private var isMonochrome = false
    private var accentColor = Color.parseColor("#FF9800")
    private var phase = 0.0
    private var hasRealFftData = false
    private var lastFftTime = 0L

    private val animRunnable = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow || !isPlaying || visibility != View.VISIBLE) {
                isRunning = false
                return
            }
            updateData()
            invalidate()
            postDelayed(this, 25) // ~40fps, highly responsive yet power efficient
        }
    }

    private var isRunning = false

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (e1 == null) return false
            val dx = e2.x - e1.x
            val dy = e2.y - e1.y
            if (abs(dx.toDouble()) > abs(dy.toDouble()) && abs(dx.toDouble()) > 50) {
                if (dx < 0) {
                    val name = nextModel()
                    onModelChangedListener?.invoke(currentModel, name)
                } else {
                    val name = prevModel()
                    onModelChangedListener?.invoke(currentModel, name)
                }
                return true
            }
            return false
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            val name = nextModel()
            onModelChangedListener?.invoke(currentModel, name)
            return true
        }
    })

    fun nextModel(): String {
        currentModel = (currentModel + 1) % 3
        invalidate()
        return getModelName()
    }

    fun prevModel(): String {
        currentModel = (currentModel + 2) % 3
        invalidate()
        return getModelName()
    }

    fun setModel(model: Int) {
        currentModel = model.coerceIn(0, 2)
        invalidate()
    }

    fun getModelName(): String {
        return when (currentModel) {
            MODEL_STUDIO_BARS -> "Visualizer: Studio Soundwave"
            MODEL_RETRO_LED_MATRIX -> "Visualizer: Retro LED Matrix"
            MODEL_CYBERPUNK_LASER -> "Visualizer: Cyberpunk Laser"
            else -> "Visualizer"
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val handled = gestureDetector.onTouchEvent(event)
        return handled || super.onTouchEvent(event)
    }

    fun linkToAudio(audioSessionId: Int = 0) {
        val targetSessionId = if (audioSessionId > 0) {
            audioSessionId
        } else {
            PlayerHolder.audioExoPlayer?.audioSessionId?.takeIf { it > 0 }
                ?: YouTubeExoPlayerManager.exoPlayer?.audioSessionId?.takeIf { it > 0 }
                ?: 0
        }
        if (targetSessionId <= 0) return

        try {
            releaseVisualizer()
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                val captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(512)
                val v = Visualizer(targetSessionId).apply {
                    setCaptureSize(captureSize)
                    setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                            if (waveform != null && isPlaying && !hasRealFftData) {
                                processWaveform(waveform)
                            }
                        }

                        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                            if (fft != null && isPlaying) {
                                processFft(fft)
                            }
                        }
                    }, Visualizer.getMaxCaptureRate(), true, true)
                    enabled = true
                }
                visualizer = v
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun processWaveform(waveform: ByteArray) {
        hasRealFftData = true
        lastFftTime = System.currentTimeMillis()
        if (waveform.isEmpty()) return

        val step = (waveform.size / barCount).coerceAtLeast(1)
        for (i in 0 until barCount) {
            var sum = 0.0
            val start = (i * step).coerceAtMost(waveform.size - 1)
            val end = ((i + 1) * step).coerceAtMost(waveform.size)
            var count = 0
            for (k in start until end) {
                val sample = abs(waveform[k].toInt() - 128)
                sum += sample
                count++
            }
            val avg = if (count > 0) sum / count else 0.0
            val normalized = (avg / 35.0).toFloat().coerceIn(0.12f, 0.98f)
            targetHeights[i] = (targetHeights[i] * 0.3f) + (normalized * 0.7f)
        }

        val spikeStep = (waveform.size / spikeCount).coerceAtLeast(1)
        for (i in 0 until spikeCount) {
            val k = (i * spikeStep).coerceAtMost(waveform.size - 1)
            val sample = abs(waveform[k].toInt() - 128)
            val normalized = (sample / 35.0).toFloat().coerceIn(0.10f, 0.98f)
            targetSpikes[i] = (targetSpikes[i] * 0.3f) + (normalized * 0.7f)
        }
    }

    fun releaseVisualizer() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        visualizer = null
    }

    private fun processFft(fft: ByteArray) {
        hasRealFftData = true
        lastFftTime = System.currentTimeMillis()
        val n = (fft.size / 2).coerceAtMost(256)
        if (n <= 1) return

        // Logarithmic Frequency Binning for 32 Spectrum Bars
        for (i in 0 until barCount) {
            val minFreqIndex = 1.0
            val maxFreqIndex = (n - 1).toDouble()
            val startRatio = Math.pow(i.toDouble() / barCount, 2.2)
            val endRatio = Math.pow((i + 1).toDouble() / barCount, 2.2)

            val startBin = (minFreqIndex + startRatio * (maxFreqIndex - minFreqIndex)).toInt().coerceIn(1, n - 1)
            val endBin = (minFreqIndex + endRatio * (maxFreqIndex - minFreqIndex)).toInt().coerceIn(startBin + 1, n)

            var maxMag = 0.0
            for (k in startBin until endBin) {
                val r = fft[2 * k].toDouble()
                val im = fft[2 * k + 1].toDouble()
                val mag = hypot(r, im)
                if (mag > maxMag) maxMag = mag
            }

            val gain = 1.0 + (i.toDouble() / barCount) * 1.8
            val normalized = ((maxMag / 58.0) * gain).toFloat().coerceIn(0.12f, 0.98f)

            if (normalized > targetHeights[i]) {
                targetHeights[i] = (targetHeights[i] * 0.2f) + (normalized * 0.8f)
            } else {
                targetHeights[i] = (targetHeights[i] * 0.65f) + (normalized * 0.35f)
            }
        }

        for (i in 0 until spikeCount) {
            val minFreqIndex = 1.0
            val maxFreqIndex = (n - 1).toDouble()
            val ratio = Math.pow(i.toDouble() / spikeCount, 2.2)
            val k = (minFreqIndex + ratio * (maxFreqIndex - minFreqIndex)).toInt().coerceIn(1, n - 1)
            val r = fft[2 * k].toDouble()
            val im = fft[2 * k + 1].toDouble()
            val mag = hypot(r, im)
            val gain = 1.0 + (i.toDouble() / spikeCount) * 1.5
            val normalized = ((mag / 58.0) * gain).toFloat().coerceIn(0.10f, 0.98f)

            if (normalized > targetSpikes[i]) {
                targetSpikes[i] = (targetSpikes[i] * 0.2f) + (normalized * 0.8f)
            } else {
                targetSpikes[i] = (targetSpikes[i] * 0.65f) + (normalized * 0.35f)
            }
        }
    }

    fun setMonochrome(mono: Boolean) {
        isMonochrome = mono
        invalidate()
    }

    fun setColor(color: Int) {
        accentColor = color
        invalidate()
    }

    fun setPlaying(playing: Boolean) {
        isPlaying = playing
        if (playing) {
            postInvalidateOnAnimation()
            start()
        } else {
            stop()
        }
    }

    fun start() {
        isPlaying = true
        if (!isRunning) {
            isRunning = true
            removeCallbacks(animRunnable)
            post(animRunnable)
        }
    }

    fun stop() {
        isPlaying = false
        isRunning = false
        removeCallbacks(animRunnable)
        for (i in 0 until barCount) {
            targetHeights[i] = 0.02f
            currentHeights[i] = 0.02f
            peakHeights[i] = 0.02f
            peakHoldFrames[i] = 0
        }
        for (i in 0 until spikeCount) {
            targetSpikes[i] = 0.02f
            currentSpikes[i] = 0.02f
        }
        invalidate()
    }

    fun onPlaybackProgress(posMs: Long, durationMs: Long) {
        if (posMs > 0L) {
            isPlaying = true
            if (!hasRealFftData || (System.currentTimeMillis() - lastFftTime > 800)) {
                if (visualizer == null) {
                    val sId = PlayerHolder.audioExoPlayer?.audioSessionId?.takeIf { it > 0 }
                        ?: YouTubeExoPlayerManager.exoPlayer?.audioSessionId?.takeIf { it > 0 }
                    if (sId != null && sId > 0) {
                        linkToAudio(sId)
                    }
                }
                updateRhythmFromPosition(posMs)
            }
            postInvalidateOnAnimation()
        }
    }

    fun feedPcmData(pcmData: ByteArray) {
        hasRealFftData = true
        lastFftTime = System.currentTimeMillis()
        if (pcmData.isEmpty()) return

        val samples = pcmData.size / 2
        val step = (samples / barCount).coerceAtLeast(1)
        for (i in 0 until barCount) {
            var sum = 0.0
            val startSample = i * step
            val endSample = ((i + 1) * step).coerceAtMost(samples)
            var count = 0
            for (s in startSample until endSample) {
                val idx = s * 2
                if (idx + 1 < pcmData.size) {
                    val sampleVal = (pcmData[idx].toInt() and 0xFF) or (pcmData[idx + 1].toInt() shl 8)
                    val sampleShort = sampleVal.toShort()
                    sum += abs(sampleShort.toDouble())
                    count++
                }
            }
            val avg = if (count > 0) sum / count else 0.0
            val normalized = (avg / 12000.0).toFloat().coerceIn(0.12f, 0.98f)
            targetHeights[i] = (targetHeights[i] * 0.35f) + (normalized * 0.65f)
        }
        postInvalidateOnAnimation()
    }

    private fun updateRhythmFromPosition(posMs: Long) {
        if (!isPlaying || posMs <= 0L) return
        val beatSec = posMs / 1000.0
        val tempoBps = 125.0 / 60.0
        val beatPhase = (beatSec * tempoBps) % 1.0
        val bassEnergy = ((1.0 - beatPhase) * (1.0 - beatPhase) * (1.0 - beatPhase)).toFloat().coerceIn(0f, 1f)
        val snarePhase = ((beatSec * tempoBps) + 0.5) % 1.0
        val snareEnergy = ((1.0 - snarePhase) * (1.0 - snarePhase)).toFloat().coerceIn(0f, 1f)
        val trebleEnergy = (0.5 + 0.5 * sin(beatSec * 14.0)).toFloat()

        for (i in 0 until barCount) {
            val freqRatio = i.toFloat() / barCount
            val bassInfluence = exp(-((freqRatio * 3.6f) * (freqRatio * 3.6f)).toDouble()).toFloat() * bassEnergy
            val midInfluence = exp(-(((freqRatio - 0.45f) * 4.2f) * ((freqRatio - 0.45f) * 4.2f)).toDouble()).toFloat() * snareEnergy
            val trebleInfluence = exp(-(((freqRatio - 0.85f) * 3.2f) * ((freqRatio - 0.85f) * 3.2f)).toDouble()).toFloat() * trebleEnergy
            val waveRipple = (0.07f * sin(i * 0.82 + beatSec * 4.5)).toFloat()

            val h = 0.12f + (bassInfluence * 0.82f) + (midInfluence * 0.62f) + (trebleInfluence * 0.42f) + waveRipple
            targetHeights[i] = h.coerceIn(0.10f, 0.98f)
        }

        for (i in 0 until spikeCount) {
            val ratio = i.toFloat() / spikeCount
            val bassInf = exp(-((ratio * 3.6f) * (ratio * 3.6f)).toDouble()).toFloat() * bassEnergy
            val midInf = exp(-(((ratio - 0.5f) * 4.2f) * ((ratio - 0.5f) * 4.2f)).toDouble()).toFloat() * snareEnergy
            val ripple = (0.05f * sin(i * 0.55 + beatSec * 6.0)).toFloat()
            targetSpikes[i] = (0.10f + bassInf * 0.80f + midInf * 0.55f + ripple).coerceIn(0.08f, 0.98f)
        }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility != View.VISIBLE) {
            stop()
        } else if (isPlaying) {
            postInvalidateOnAnimation()
            start()
        }
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility != View.VISIBLE) {
            stop()
        } else if (isPlaying) {
            postInvalidateOnAnimation()
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isPlaying && visibility == View.VISIBLE) start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
        releaseVisualizer()
    }

    private fun updateData() {
        if (!isPlaying) {
            for (i in 0 until barCount) {
                targetHeights[i] = 0.02f
                currentHeights[i] = 0.02f
                peakHeights[i] = 0.02f
            }
            for (i in 0 until spikeCount) {
                targetSpikes[i] = 0.02f
                currentSpikes[i] = 0.02f
            }
            return
        }

        val now = System.currentTimeMillis()
        val useSimulation = !hasRealFftData || (now - lastFftTime > 800)

        if (useSimulation) {
            // Continuous dynamic audio synthesis: simulates real musical beats and lively dancing waveforms
            phase += 0.09
            val t = phase
            for (i in 0 until barCount) {
                val ratio = i.toFloat() / barCount
                val bassPulse = ((0.5 + 0.5 * sin(t * 3.6)).toFloat() * exp(-ratio * 3.2f)).toFloat()
                val midPulse = ((0.5 + 0.5 * sin(t * 7.2 + i * 0.42)).toFloat() * (0.55f + 0.45f * sin(t * 1.8).toFloat()))
                val treblePulse = ((0.5 + 0.5 * sin(t * 12.0 + i * 0.85)).toFloat() * (0.3f + ratio * 0.7f))
                val waveRipple = (0.08f * sin(i * 0.65 + t * 4.2)).toFloat()
                val target = (0.15f + (bassPulse * 0.72f) + (midPulse * 0.42f) + (treblePulse * 0.32f) + waveRipple).coerceIn(0.12f, 0.96f)
                targetHeights[i] = target
            }
            for (i in 0 until spikeCount) {
                val ratio = i.toFloat() / spikeCount
                val sWave = (0.14f + (0.5f + 0.5f * sin(t * 4.5 + i * 0.28).toFloat()) * 0.76f).coerceIn(0.10f, 0.96f)
                targetSpikes[i] = sWave
            }
        }

        // Smooth interpolation
        for (i in 0 until barCount) {
            val diff = targetHeights[i] - currentHeights[i]
            currentHeights[i] += diff * 0.35f

            // Peak drop calculation (for LED matrix)
            if (currentHeights[i] > peakHeights[i]) {
                peakHeights[i] = currentHeights[i]
                peakHoldFrames[i] = 8 // hold for 8 frames
            } else {
                if (peakHoldFrames[i] > 0) {
                    peakHoldFrames[i]--
                } else {
                    peakHeights[i] = (peakHeights[i] - 0.025f).coerceAtLeast(currentHeights[i])
                }
            }
        }

        for (i in 0 until spikeCount) {
            val diff = targetSpikes[i] - currentSpikes[i]
            currentSpikes[i] += diff * 0.40f
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        when (currentModel) {
            MODEL_STUDIO_BARS -> drawStudioBars(canvas, w, h)
            MODEL_RETRO_LED_MATRIX -> drawRetroLedMatrix(canvas, w, h)
            MODEL_CYBERPUNK_LASER -> drawCyberpunkLaser(canvas, w, h)
        }

        if (isPlaying && isShown) {
            updateData()
            postInvalidateOnAnimation()
        }
    }

    // --- Model 0: Studio Symmetrical Bars ---
    private fun drawStudioBars(canvas: Canvas, w: Float, h: Float) {
        val paddingHorizontal = w * 0.05f
        val usableWidth = w - (paddingHorizontal * 2)
        val barSpacing = usableWidth * 0.015f
        val barWidth = (usableWidth - (barSpacing * (barCount - 1))) / barCount
        val cornerRadius = barWidth / 2f
        val centerY = h / 2f

        for (i in 0 until barCount) {
            val left = paddingHorizontal + i * (barWidth + barSpacing)
            val right = left + barWidth
            val barH = (h * 0.85f) * currentHeights[i].coerceIn(0.10f, 0.98f)
            val top = centerY - (barH / 2f)
            val bottom = centerY + (barH / 2f)

            barRect.set(left, top, right, bottom)

            if (isMonochrome) {
                paint.shader = LinearGradient(
                    left, top, left, bottom,
                    Color.WHITE,
                    Color.parseColor("#707070"),
                    Shader.TileMode.CLAMP
                )
            } else {
                paint.shader = LinearGradient(
                    left, top, left, bottom,
                    Color.WHITE,
                    Color.parseColor("#44000000") or (accentColor and 0x00FFFFFF),
                    Shader.TileMode.CLAMP
                )
            }

            canvas.drawRoundRect(barRect, cornerRadius, cornerRadius, paint)
        }
    }

    // --- Model 1: Retro Digital LED Matrix ---
    private fun drawRetroLedMatrix(canvas: Canvas, w: Float, h: Float) {
        val paddingHorizontal = w * 0.05f
        val usableWidth = w - (paddingHorizontal * 2)
        val barSpacing = usableWidth * 0.018f
        val barWidth = (usableWidth - (barSpacing * (barCount - 1))) / barCount
        val totalBlocks = 18
        val paddingBottom = h * 0.10f
        val usableHeight = h * 0.80f
        val blockGap = 2.5f
        val blockHeight = (usableHeight - (blockGap * (totalBlocks - 1))) / totalBlocks
        val blockCorner = 2.0f

        for (i in 0 until barCount) {
            val left = paddingHorizontal + i * (barWidth + barSpacing)
            val right = left + barWidth

            val litBlocks = (currentHeights[i] * totalBlocks).toInt().coerceIn(1, totalBlocks)
            val peakBlock = (peakHeights[i] * totalBlocks).toInt().coerceIn(1, totalBlocks)

            for (b in 0 until totalBlocks) {
                val blockBottom = h - paddingBottom - b * (blockHeight + blockGap)
                val blockTop = blockBottom - blockHeight

                barRect.set(left, blockTop, right, blockBottom)

                if (b < litBlocks) {
                    val blockRatio = b.toFloat() / totalBlocks
                    val blockColor = if (isMonochrome) {
                        if (blockRatio > 0.75f) Color.WHITE else Color.parseColor("#B0B0B0")
                    } else {
                        when {
                            blockRatio > 0.82f -> Color.parseColor("#FF5252")
                            blockRatio > 0.60f -> Color.parseColor("#FFD740")
                            else -> Color.parseColor("#7C4DFF")
                        }
                    }
                    paint.shader = null
                    paint.color = blockColor
                    canvas.drawRoundRect(barRect, blockCorner, blockCorner, paint)
                } else if (b == peakBlock && peakBlock >= litBlocks) {
                    paint.shader = null
                    paint.color = if (isMonochrome) Color.WHITE else Color.parseColor("#FF5252")
                    canvas.drawRoundRect(barRect, blockCorner, blockCorner, paint)
                } else {
                    paint.shader = null
                    paint.color = Color.parseColor("#14FFFFFF")
                    canvas.drawRoundRect(barRect, blockCorner, blockCorner, paint)
                }
            }
        }
    }

    // --- Model 2: Cyberpunk Golden Laser Needles ---
    private fun drawCyberpunkLaser(canvas: Canvas, w: Float, h: Float) {
        val paddingHorizontal = w * 0.04f
        val usableWidth = w - (paddingHorizontal * 2)
        val spikeSpacing = usableWidth / spikeCount
        val centerY = h / 2f
        val maxAmplitude = h * 0.44f

        linePaint.strokeWidth = 2.5f
        linePaint.shader = LinearGradient(
            0f, centerY, w, centerY,
            Color.parseColor("#44FFE082"),
            Color.parseColor("#FFFFFFFF"),
            Shader.TileMode.MIRROR
        )
        canvas.drawLine(0f, centerY, w, centerY, linePaint)

        linePaint.strokeWidth = 2.0f
        for (i in 0 until spikeCount) {
            val x = paddingHorizontal + i * spikeSpacing
            val spikeH = maxAmplitude * currentSpikes[i].coerceIn(0.08f, 0.98f)
            val top = centerY - spikeH
            val bottom = centerY + spikeH

            if (isMonochrome) {
                linePaint.shader = LinearGradient(
                    x, top, x, bottom,
                    Color.parseColor("#33FFFFFF"),
                    Color.WHITE,
                    Shader.TileMode.MIRROR
                )
            } else {
                linePaint.shader = LinearGradient(
                    x, centerY, x, top,
                    Color.parseColor("#FFFFFF"),
                    Color.parseColor("#FFD54F"),
                    Shader.TileMode.CLAMP
                )
            }

            canvas.drawLine(x, centerY, x, top, linePaint)

            if (!isMonochrome) {
                linePaint.shader = LinearGradient(
                    x, centerY, x, bottom,
                    Color.parseColor("#FFFFFF"),
                    Color.parseColor("#FFB300"),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawLine(x, centerY, x, bottom, linePaint)
        }
    }
}
