package com.cleanplayer.app

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class YouTubeHistoryAdapter(
    private val context: Context,
    private var items: List<YouTubeVideo>,
    private val onItemClick: (YouTubeVideo) -> Unit
) : RecyclerView.Adapter<YouTubeHistoryAdapter.HistoryViewHolder>() {

    fun updateItems(newItems: List<YouTubeVideo>) {
        this.items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_youtube_history, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val item = items[position]
        holder.tvTitle.text = item.title
        holder.tvChannel.text = item.channelTitle
        holder.tvDuration.text = item.duration.ifBlank { "Video" }
        ImageLoaderHelper.loadImage(item.thumbnailUrl, holder.ivThumb, R.drawable.ic_video)

        holder.itemView.setOnClickListener {
            onItemClick(item)
        }
    }

    override fun getItemCount(): Int = items.size

    class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivThumb: ImageView = itemView.findViewById(R.id.ivHistoryThumb)
        val tvDuration: TextView = itemView.findViewById(R.id.tvHistoryDuration)
        val tvTitle: TextView = itemView.findViewById(R.id.tvHistoryTitle)
        val tvChannel: TextView = itemView.findViewById(R.id.tvHistoryChannel)
        val btnMore: ImageButton = itemView.findViewById(R.id.btnHistoryMore)
    }
}
