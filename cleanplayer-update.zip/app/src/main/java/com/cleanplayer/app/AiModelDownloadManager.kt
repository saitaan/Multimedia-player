package com.cleanplayer.app

import android.content.Context
import java.io.File

/**
 * 🛡️ CleanPlayer 100% Genuine & Transparent Architecture.
 * All fake external neural downloads have been completely decommissioned.
 * All video enhancement, speech recognition, and audio stem splitting
 * run 100% locally via hardware-accelerated GPU & Android native APIs (0 MB download).
 */
object AiModelDownloadManager {

    enum class ModelCategory {
        VIDEO,
        AUDIO
    }

    data class AiModelInfo(
        val id: String,
        val title: String,
        val category: ModelCategory,
        val filename: String,
        val description: String,
        val expectedSizeBytes: Long
    )

    val SUPER_RES_MODEL = AiModelInfo(
        id = "gpu_hardware_boost",
        title = "Hardware Video & HDR Boost (GPU Engine)",
        category = ModelCategory.VIDEO,
        filename = "",
        description = "Built-in GPU compute engine for real-time edge sharpening, contrast boost, and HDR shadow lift. 0 MB download required.",
        expectedSizeBytes = 0L
    )

    val WHISPER_SPEECH_MODEL = AiModelInfo(
        id = "native_android_speech",
        title = "Native Android Speech-to-Text Engine",
        category = ModelCategory.AUDIO,
        filename = "",
        description = "Built-in Android system speech recognizer. 0 MB download required.",
        expectedSizeBytes = 0L
    )

    val ALL_MODELS = listOf(SUPER_RES_MODEL, WHISPER_SPEECH_MODEL)

    var isDownloading = false
    var currentDownloadingModelId: String? = null

    fun isModelInstalled(context: Context, model: AiModelInfo = SUPER_RES_MODEL): Boolean = true
    fun getModelFile(context: Context, model: AiModelInfo = SUPER_RES_MODEL): File = File(context.filesDir, "built_in")
    fun getModelSizeOnDisk(context: Context, model: AiModelInfo = SUPER_RES_MODEL): Long = 0L
    fun getModelSizeFormatted(context: Context, model: AiModelInfo = SUPER_RES_MODEL): String = "Built-in (0 MB)"
    fun deleteModel(context: Context, model: AiModelInfo = SUPER_RES_MODEL): Boolean = false
    fun cancelDownload() {}
    fun startDownload(
        context: Context,
        model: AiModelInfo,
        onProgress: (percent: Int, bytesRead: Long, totalBytes: Long) -> Unit,
        onComplete: (success: Boolean, errorMsg: String?) -> Unit
    ) {
        onComplete(true, "Engine is built-in. No download needed.")
    }
}
