package com.cleanplayer.app

import android.content.Context
import org.json.JSONObject

data class LocalTrackStats(
    val path: String,
    var playCount: Int = 0,
    var completeCount: Int = 0,
    var skipCount: Int = 0,
    var lastPlayedTimestamp: Long = 0L
)

/**
 * 100% Offline, Purely Behavioral Local Player AI Engine.
 *
 * Architecture:
 * 1. Strictly isolated from YouTube (zero pollution from corrupted/unknown local ID3 tags).
 * 2. Implicit Feedback Learning: Tracks play count, dwell time, and quick skips (< 15s).
 * 3. Weighted Smart Shuffle: Dynamically promotes favorites and suppresses frequently skipped tracks.
 * 4. Zero network calls, 100% persistent on-device storage.
 */
object LocalSmartPlaybackEngine {

    private const val PREFS_NAME = "cleanplayer_local_ai_engine_prefs"
    private const val KEY_TRACK_STATS = "local_track_stats_json"
    var isSmartShuffleEnabled: Boolean = true

    private val inMemoryStats = mutableMapOf<String, LocalTrackStats>()
    private var isLoaded = false

    fun recordTrackStarted(context: Context, path: String) {
        if (path.isBlank()) return
        updateStats(context, path) { stats ->
            stats.playCount++
            stats.lastPlayedTimestamp = System.currentTimeMillis()
        }
    }

    fun recordTrackProgress(context: Context, path: String, currentMs: Long, totalMs: Long) {
        if (totalMs <= 0 || path.isBlank()) return
        val ratio = currentMs.toFloat() / totalMs.toFloat()
        updateStats(context, path) { stats ->
            if (ratio >= 0.60f) {
                stats.completeCount++
            } else if (ratio < 0.15f && currentMs < 15_000L) {
                stats.skipCount++
            }
        }
    }

    fun getNextSmartTrackIndex(playlist: List<MediaItem>, currentIndex: Int): Int {
        if (playlist.isEmpty()) return -1
        if (playlist.size == 1) return 0

        val candidates = playlist.indices.filter { it != currentIndex }
        if (candidates.isEmpty()) return currentIndex

        if (!isSmartShuffleEnabled) {
            return candidates.random()
        }

        // Weighted Behavioral Selection (Offline AI):
        // Higher probability for tracks with high completion rate, lower for quick skips
        val scores = candidates.map { idx ->
            val item = playlist[idx]
            val path = item.path ?: ""
            val stats = inMemoryStats[path]
            val weight = if (stats != null) {
                val base = (stats.completeCount * 3.0) + (stats.playCount * 1.5) - (stats.skipCount * 2.5)
                base.coerceAtLeast(1.0)
            } else {
                3.0 // Fair exploration weight for unplayed tracks
            }
            idx to weight
        }

        val totalWeight = scores.sumOf { it.second }
        var randomValue = Math.random() * totalWeight
        for ((idx, weight) in scores) {
            randomValue -= weight
            if (randomValue <= 0.0) {
                return idx
            }
        }
        return candidates.random()
    }

    fun loadStats(context: Context) {
        if (isLoaded) return
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val jsonStr = prefs.getString(KEY_TRACK_STATS, "{}") ?: "{}"
            val obj = JSONObject(jsonStr)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val path = keys.next()
                val itemObj = obj.getJSONObject(path)
                inMemoryStats[path] = LocalTrackStats(
                    path = path,
                    playCount = itemObj.optInt("playCount", 0),
                    completeCount = itemObj.optInt("completeCount", 0),
                    skipCount = itemObj.optInt("skipCount", 0),
                    lastPlayedTimestamp = itemObj.optLong("lastPlayedTimestamp", 0L)
                )
            }
            isLoaded = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateStats(context: Context, path: String, action: (LocalTrackStats) -> Unit) {
        loadStats(context)
        val stats = inMemoryStats.getOrPut(path) { LocalTrackStats(path) }
        action(stats)
        saveStats(context)
    }

    private fun saveStats(context: Context) {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val obj = JSONObject()
            for ((path, stats) in inMemoryStats) {
                val itemObj = JSONObject().apply {
                    put("playCount", stats.playCount)
                    put("completeCount", stats.completeCount)
                    put("skipCount", stats.skipCount)
                    put("lastPlayedTimestamp", stats.lastPlayedTimestamp)
                }
                obj.put(path, itemObj)
            }
            prefs.edit().putString(KEY_TRACK_STATS, obj.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
