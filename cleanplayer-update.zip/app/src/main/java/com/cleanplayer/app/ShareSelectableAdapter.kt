package com.cleanplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ShareSelectableAdapter(
    private var items: List<ShareItem> = emptyList(),
    private val onSelectionChanged: (selectedItems: List<ShareItem>) -> Unit
) : RecyclerView.Adapter<ShareSelectableAdapter.SelectableViewHolder>() {

    fun updateItems(newItems: List<ShareItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun getItems(): List<ShareItem> = items

    fun getSelectedItems(): List<ShareItem> = items.filter { it.isSelected }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SelectableViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_share_selectable, parent, false)
        return SelectableViewHolder(view)
    }

    override fun onBindViewHolder(holder: SelectableViewHolder, position: Int) {
        val item = items[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int = items.size

    inner class SelectableViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivIcon: ImageView = itemView.findViewById(R.id.ivSelectableIcon)
        private val tvTitle: TextView = itemView.findViewById(R.id.tvSelectableTitle)
        private val tvSubtitle: TextView = itemView.findViewById(R.id.tvSelectableSubtitle)
        private val cbSelect: CheckBox = itemView.findViewById(R.id.cbSelectable)

        fun bind(item: ShareItem) {
            tvTitle.text = item.name
            val sizeMb = String.format("%.1f MB", item.size / (1024f * 1024f))
            val extra = item.durationStr ?: item.packageName ?: ""
            tvSubtitle.text = if (extra.isNotBlank()) "$sizeMb • $extra" else sizeMb
            cbSelect.isChecked = item.isSelected

            when (item.type) {
                ShareItemType.VIDEO -> ivIcon.setImageResource(R.drawable.ic_video)
                ShareItemType.AUDIO -> ivIcon.setImageResource(R.drawable.ic_audio)
                ShareItemType.IMAGE -> ivIcon.setImageResource(android.R.drawable.ic_menu_gallery)
                ShareItemType.APP -> ivIcon.setImageResource(android.R.drawable.sym_def_app_icon)
                ShareItemType.FILE -> ivIcon.setImageResource(R.drawable.ic_folder)
            }

            itemView.setOnClickListener {
                item.isSelected = !item.isSelected
                cbSelect.isChecked = item.isSelected
                onSelectionChanged(getSelectedItems())
            }
        }
    }
}
