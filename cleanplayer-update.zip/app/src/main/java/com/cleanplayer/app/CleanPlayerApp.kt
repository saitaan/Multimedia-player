package com.cleanplayer.app

import android.app.Application
import android.content.Intent
import android.os.Process
import android.util.Log
import java.util.concurrent.Executors

/**
 * Global Application Class for CleanPlayer.
 * Asynchronously initializes NewPipeExtractor engine with HTTP disk cache, ImageLoader 2-tier disk cache, and Crash Guard.
 */
class CleanPlayerApp : Application() {

    companion object {
        lateinit var instance: CleanPlayerApp
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Attach Global Exception Crash Guard immediately
        setupCrashGuard()

        // High-Performance Asynchronous Engine & Cache Warmup:
        // Offloads heavy disk I/O, OkHttpClient construction, SSL context setup,
        // and NewPipe localization from the main thread.
        // This ensures the main UI thread never blocks during cold start.
        Executors.newSingleThreadExecutor().execute {
            try {
                ImageLoaderHelper.init(this)
                DownloaderImpl.init(cacheDir = cacheDir)
                YouTubeStreamResolver.initNewPipe(this)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    private fun setupCrashGuard() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                Log.e("CleanPlayerCrashGuard", "Intercepted uncaught exception: " + throwable.localizedMessage, throwable)

                val restartIntent = Intent(applicationContext, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                startActivity(restartIntent)

                Process.killProcess(Process.myPid())
                System.exit(10)
            } catch (e: Throwable) {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }
}
