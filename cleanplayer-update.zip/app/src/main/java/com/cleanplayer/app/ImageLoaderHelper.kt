package com.cleanplayer.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors

object ImageLoaderHelper {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var diskCacheDir: File? = null

    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = maxMemory / 8

    private val memoryCache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
    }

    fun init(context: Context) {
        if (diskCacheDir == null) {
            diskCacheDir = File(context.cacheDir, "yt_thumbs").apply { mkdirs() }
        }
    }

    fun load(context: Any?, url: String?, imageView: ImageView, placeholderRes: Int = R.drawable.ic_video) {
        if (context is Context) init(context)
        loadImage(url, imageView, placeholderRes)
    }

    fun load(url: String?, imageView: ImageView, placeholderRes: Int = R.drawable.ic_video) {
        init(imageView.context)
        loadImage(url, imageView, placeholderRes)
    }

    fun loadImage(url: String?, imageView: ImageView, placeholderRes: Int = R.drawable.ic_video) {
        if (url.isNullOrEmpty()) {
            imageView.setImageResource(placeholderRes)
            return
        }

        init(imageView.context)

        // Tier 1: Check In-Memory LruCache (0ms, 0 data)
        val cached = memoryCache.get(url)
        if (cached != null) {
            imageView.setImageBitmap(cached)
            return
        }

        imageView.setImageResource(placeholderRes)
        imageView.tag = url

        executor.execute {
            val hashKey = hashUrl(url)
            val diskFile = diskCacheDir?.let { File(it, hashKey) }

            // Tier 2: Check Persistent Disk Cache (5ms, 0 data)
            if (diskFile != null && diskFile.exists() && diskFile.length() > 0) {
                try {
                    val bitmap = BitmapFactory.decodeFile(diskFile.absolutePath)
                    if (bitmap != null) {
                        memoryCache.put(url, bitmap)
                        mainHandler.post {
                            if (imageView.tag == url) {
                                imageView.setImageBitmap(bitmap)
                            }
                        }
                        return@execute
                    }
                } catch (e: Exception) {}
            }

            // Tier 3: Fetch from Network ONCE and save to disk
            try {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3000
                    readTimeout = 3000
                    doInput = true
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Android; CleanPlayer)")
                }
                conn.connect()
                val bytes = conn.inputStream.use { it.readBytes() }

                if (bytes.isNotEmpty()) {
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bitmap != null) {
                        memoryCache.put(url, bitmap)

                        // Save to disk cache for future launches
                        diskFile?.let { f ->
                            try {
                                FileOutputStream(f).use { out -> out.write(bytes) }
                            } catch (e: Exception) {}
                        }

                        mainHandler.post {
                            if (imageView.tag == url) {
                                imageView.setImageBitmap(bitmap)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // Keep placeholder on error
            }
        }
    }

    private fun hashUrl(url: String): String {
        return try {
            val md = MessageDigest.getInstance("MD5")
            val digest = md.digest(url.toByteArray())
            digest.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            url.hashCode().toString()
        }
    }
}
