package com.cleanplayer.app

import android.net.Uri

enum class ShareItemType {
    RECENT,
    VIDEO,
    AUDIO,
    APP,
    IMAGE,
    FILE
}

data class ShareItem(
    val id: String,
    val name: String,
    val path: String,
    val size: Long,
    val mimeType: String,
    val type: ShareItemType,
    val dateModified: Long = System.currentTimeMillis(),
    val durationStr: String? = null,
    val packageName: String? = null,
    var isSelected: Boolean = false
)

data class TransferRecord(
    val id: String,
    val fileName: String,
    val filePath: String,
    val totalSize: Long,
    var transferredBytes: Long,
    val isOutgoing: Boolean,
    var isCompleted: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    var speedMbPerSec: Float = 0f,
    val type: ShareItemType = ShareItemType.FILE
)
