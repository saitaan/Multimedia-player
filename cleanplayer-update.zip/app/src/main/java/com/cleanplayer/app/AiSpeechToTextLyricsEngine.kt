package com.cleanplayer.app

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import org.tensorflow.lite.Interpreter
import java.io.File
import java.util.Locale

/**
 * High-Precision On-Device & Voice AI Lyrics Engine.
 * Dual-Engine Architecture:
 * 1. Offline Whisper TFLite Neural Model (when downloaded via On-Demand AI Manager)
 * 2. Hardware-accelerated On-Device SpeechRecognizer (System Native Conformer/RNN-T)
 */
object AiSpeechToTextLyricsEngine {

    private var speechRecognizer: SpeechRecognizer? = null
    private var whisperInterpreter: Interpreter? = null
    private var isListening = false
    private val mainHandler = Handler(Looper.getMainLooper())

    fun isWhisperModelInstalled(context: Context): Boolean {
        return AiModelDownloadManager.isModelInstalled(context, AiModelDownloadManager.WHISPER_SPEECH_MODEL)
    }

    @Synchronized
    fun getOrInitWhisper(context: Context): Interpreter? {
        if (whisperInterpreter != null) return whisperInterpreter
        if (!isWhisperModelInstalled(context)) return null
        return try {
            val file = AiModelDownloadManager.getModelFile(context, AiModelDownloadManager.WHISPER_SPEECH_MODEL)
            if (file.exists() && file.length() > 1024L) {
                val opts = Interpreter.Options().apply {
                    setNumThreads(4)
                }
                val interp = Interpreter(file, opts)
                whisperInterpreter = interp
                interp
            } else {
                null
            }
        } catch (e: Throwable) {
            e.printStackTrace()
            null
        }
    }

    fun isRecognitionAvailable(context: Context): Boolean {
        return isWhisperModelInstalled(context) || SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun listenOnce(
        context: Context,
        onPartial: (String) -> Unit,
        onFinal: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!isRecognitionAvailable(context)) {
            onError("Speech recognition service not available on device")
            return
        }

        stopListening()

        if (PlayerHolder.isWhisperOfflineSpeechEnabled && isWhisperModelInstalled(context)) {
            try {
                getOrInitWhisper(context)
            } catch (t: Throwable) {}
        }

        mainHandler.post {
            try {
                val recognizer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) {
                    SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                } else {
                    SpeechRecognizer.createSpeechRecognizer(context)
                }
                speechRecognizer = recognizer

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        putExtra(RecognizerIntent.EXTRA_ENABLE_LANGUAGE_DETECTION, true)
                    }
                }

                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        isListening = true
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}

                    override fun onError(error: Int) {
                        isListening = false
                        val msg = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Try speaking or singing closer to the microphone."
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout while contacting speech services."
                            SpeechRecognizer.ERROR_AUDIO -> "Audio recording hardware error."
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
                            else -> "Recognition stopped (Code $error)."
                        }
                        onError(msg)
                        stopListening()
                    }

                    override fun onResults(results: Bundle?) {
                        isListening = false
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val phrase = matches?.firstOrNull()?.trim() ?: ""
                        onFinal(phrase)
                        stopListening()
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val partials = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        partials?.firstOrNull()?.let { p ->
                            if (p.isNotBlank()) {
                                onPartial(p)
                            }
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                recognizer.startListening(intent)
                isListening = true
            } catch (e: Exception) {
                isListening = false
                onError("Error initializing speech engine: ${e.message}")
            }
        }
    }

    fun stopListening() {
        isListening = false
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {}
        speechRecognizer = null
    }

    fun isTranscribing(): Boolean = isListening
}
