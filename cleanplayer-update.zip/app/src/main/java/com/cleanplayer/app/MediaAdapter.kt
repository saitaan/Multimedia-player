package com.cleanplayer.app

import android.content.Context
import android.graphics.Color
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class MediaAdapter(
    private var items: List<MediaItem>,
    private val onItemClickWithPos: (MediaItem, Int) -> Unit
) : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    constructor(items: List<MediaItem>, onItemClick: (MediaItem) -> Unit) :
            this(items, { item, _ -> onItemClick(item) })

    var currentPlayingUri: Uri? = null

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardMedia: MaterialCardView = view.findViewById(R.id.cardMedia)
        val ivMediaIcon: ImageView = view.findViewById(R.id.ivMediaIcon)
        val tvItemTitle: TextView = view.findViewById(R.id.tvItemTitle)
        val tvItemSubtitle: TextView = view.findViewById(R.id.tvItemSubtitle)
        val ivPlayStatus: ImageView = view.findViewById(R.id.ivPlayStatus)
        val pbWatchProgress: View? = view.findViewById(R.id.pbWatchProgress)
        val ivPlayedCheck: ImageView? = view.findViewById(R.id.ivPlayedCheck)
        val tvNewBadge: TextView? = view.findViewById(R.id.tvNewBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_media, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context
        val isCurrentTrack = (currentPlayingUri != null && currentPlayingUri == item.uri)

        val tagKey = AudioTagManager.getKey(item.uri, item.filePath)
        val displayTitle = AudioTagManager.getTitle(context, tagKey, item.title)
        val displayArtist = AudioTagManager.getArtist(context, tagKey, item.artist ?: "Unknown artist")

        holder.tvItemTitle.text = displayTitle

        val isMono = PlayerHolder.isMonochrome()
        val videoColor = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)
        val audioColor = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_accent_cyan)
        val primaryAccent = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)

        // "NEW" Badge Indicator for recently added files
        if (item.isNew) {
            holder.tvNewBadge?.visibility = View.VISIBLE
        } else {
            holder.tvNewBadge?.visibility = View.GONE
        }

        // Zero-lag asynchronous memory-cached thumbnail loader
        LocalThumbnailLoader.loadThumbnail(
            context = context,
            item = item,
            targetView = holder.ivMediaIcon,
            placeholderColor = Color.parseColor("#8E8E93")
        )

        if (item.isVideo) {
            holder.tvItemSubtitle.text = "${item.getFormattedDuration()} • ${item.getFormattedSize()}"

            // Read watch progress
            val prefs = context.getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            val resumeMs = prefs.getLong(item.filePath ?: item.uri.toString(), 0L)
            if (item.durationMs > 0 && resumeMs > 5000L) {
                val ratio = (resumeMs.toFloat() / item.durationMs.toFloat()).coerceIn(0f, 1f)
                holder.pbWatchProgress?.visibility = View.VISIBLE
                holder.pbWatchProgress?.setBackgroundColor(videoColor)
                val totalWidthPx = (106 * context.resources.displayMetrics.density).toInt()
                val progressWidthPx = (totalWidthPx * ratio).toInt().coerceAtLeast(4)
                val lp = holder.pbWatchProgress?.layoutParams
                if (lp != null) {
                    lp.width = progressWidthPx
                    holder.pbWatchProgress.layoutParams = lp
                }

                if (ratio > 0.90f) {
                    holder.ivPlayedCheck?.visibility = View.VISIBLE
                    holder.ivPlayedCheck?.setColorFilter(videoColor)
                } else {
                    holder.ivPlayedCheck?.visibility = View.GONE
                }
            } else {
                holder.pbWatchProgress?.visibility = View.GONE
                holder.ivPlayedCheck?.visibility = View.GONE
            }
        } else {
            val artistStr = if (displayArtist.isNotBlank() && displayArtist != "<unknown>") {
                "$displayArtist • "
            } else ""
            holder.tvItemSubtitle.text = "$artistStr${item.getFormattedDuration()}"
            holder.pbWatchProgress?.visibility = View.GONE
            holder.ivPlayedCheck?.visibility = View.GONE
        }

        if (isCurrentTrack) {
            holder.cardMedia.strokeColor = primaryAccent
            holder.cardMedia.strokeWidth = 2
            holder.tvItemTitle.setTextColor(primaryAccent)
        } else {
            val cardBg = if (isMono) Color.parseColor("#141414") else ContextCompat.getColor(context, R.color.theme_card_bg)
            val cardStroke = if (isMono) Color.parseColor("#2E2E2E") else ContextCompat.getColor(context, R.color.theme_card_stroke)
            holder.cardMedia.setCardBackgroundColor(cardBg)
            holder.cardMedia.strokeColor = cardStroke
            holder.cardMedia.strokeWidth = 1
            holder.tvItemTitle.setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
        }

        holder.itemView.setOnClickListener {
            onItemClickWithPos(item, holder.bindingAdapterPosition)
        }

        // 3-dots more menu matching 5222.jpg with In-App Tag Editor & Dark Theme
        holder.ivPlayStatus.setOnClickListener {
            val options = if (item.isVideo) {
                arrayOf("Play", "File Information", "Share")
            } else {
                arrayOf("Play", "Edit Audio Tags (ID3)", "File Information", "Share")
            }
            AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                .setTitle(displayTitle)
                .setItems(options) { _, which ->
                    if (item.isVideo) {
                        when (which) {
                            0 -> onItemClickWithPos(item, holder.bindingAdapterPosition)
                            1 -> {
                                val info = "Name: " + item.title + "\n\nPath: " + (item.filePath ?: item.uri.toString()) + "\n\nDuration: " + item.getFormattedDuration() + "\n\nSize: " + item.getFormattedSize()
                                AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                    .setTitle("File Information")
                                    .setMessage(info)
                                    .setPositiveButton("OK", null)
                                    .show()
                            }
                            2 -> {
                                try {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "video/*"
                                        putExtra(Intent.EXTRA_STREAM, item.uri)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Media"))
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    } else {
                        when (which) {
                            0 -> onItemClickWithPos(item, holder.bindingAdapterPosition)
                            1 -> {
                                // Open In-App Audio Tag Editor BottomSheet
                                val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(context, R.style.TransparentBottomSheetDialog)
                                val view = LayoutInflater.from(context).inflate(R.layout.dialog_audio_tag_editor, null)
                                dialog.setContentView(view)

                                val etTitle = view.findViewById<android.widget.EditText>(R.id.etTagTitle)
                                val etArtist = view.findViewById<android.widget.EditText>(R.id.etTagArtist)
                                val etAlbum = view.findViewById<android.widget.EditText>(R.id.etTagAlbum)
                                val btnSave = view.findViewById<android.widget.Button>(R.id.btnSaveTagEdit)
                                val btnCancel = view.findViewById<android.widget.Button>(R.id.btnCancelTagEdit)

                                val currentAlbum = AudioTagManager.getAlbum(context, tagKey, "") ?: ""
                                etTitle.setText(displayTitle)
                                etArtist.setText(displayArtist)
                                etAlbum.setText(currentAlbum)

                                btnCancel.setOnClickListener { dialog.dismiss() }
                                btnSave.setOnClickListener {
                                    val newTitle = etTitle.text.toString().trim()
                                    val newArtist = etArtist.text.toString().trim()
                                    val newAlbum = etAlbum.text.toString().trim()

                                    if (newTitle.isNotBlank()) {
                                        AudioTagManager.saveTags(context, tagKey, newTitle, newArtist, newAlbum)
                                        notifyItemChanged(holder.bindingAdapterPosition)
                                        CleanToast.show(context, "Tags saved: $newTitle")
                                        dialog.dismiss()
                                    }
                                }
                                dialog.show()
                            }
                            2 -> {
                                val info = "Title: " + displayTitle + "\nArtist: " + displayArtist + "\n\nPath: " + (item.filePath ?: item.uri.toString()) + "\n\nDuration: " + item.getFormattedDuration() + "\n\nSize: " + item.getFormattedSize()
                                AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                    .setTitle("File Information")
                                    .setMessage(info)
                                    .setPositiveButton("OK", null)
                                    .show()
                            }
                            3 -> {
                                try {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "audio/*"
                                        putExtra(Intent.EXTRA_STREAM, item.uri)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Media"))
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun getItemCount(): Int = items.size

    fun getItems(): List<MediaItem> = items

    fun updateList(newItems: List<MediaItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun setPlayingUri(uri: Uri?) {
        currentPlayingUri = uri
        notifyDataSetChanged()
    }
}

class FolderAdapter(
    private var folders: List<MediaFolder>,
    private val onFolderClick: (MediaFolder) -> Unit
) : RecyclerView.Adapter<FolderAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvFolderName: TextView = view.findViewById(R.id.tvFolderName)
        val tvFolderDetails: TextView = view.findViewById(R.id.tvFolderDetails)
        val tvFolderPath: TextView = view.findViewById(R.id.tvFolderPath)
        val ivFolderIcon: ImageView? = view.findViewById(R.id.ivFolderIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val folder = folders[position]
        holder.tvFolderName.text = folder.folderName
        val isMono = PlayerHolder.isMonochrome()
        val folderColor = if (isMono) Color.WHITE else ContextCompat.getColor(holder.itemView.context, R.color.theme_primary)
        val detailsColor = if (isMono) Color.parseColor("#8E8E93") else ContextCompat.getColor(holder.itemView.context, R.color.theme_accent_cyan)
        holder.ivFolderIcon?.setColorFilter(folderColor)
        holder.tvFolderDetails.setTextColor(detailsColor)
        holder.tvFolderDetails.text = "${folder.count} videos • ${folder.getFormattedSize()}"
        holder.tvFolderPath.text = if (folder.folderPath.isNotEmpty()) folder.folderPath else "/storage/emulated/0/..."

        holder.itemView.setOnClickListener {
            onFolderClick(folder)
        }
    }

    override fun getItemCount(): Int = folders.size

    fun updateFolders(newFolders: List<MediaFolder>) {
        folders = newFolders
        notifyDataSetChanged()
    }
}
