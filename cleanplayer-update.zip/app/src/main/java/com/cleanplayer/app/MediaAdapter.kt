package com.cleanplayer.app
import java.util.regex.Pattern
import java.net.URLEncoder
import java.io.File
import org.json.JSONObject
import org.json.JSONArray
import okhttp3.Request
import okhttp3.OkHttpClient
import android.os.Looper
import android.os.Handler
import android.media.MediaMetadataRetriever
import android.graphics.Typeface

import android.content.Context
import android.graphics.Color
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class MediaAdapter(
    private var items: List<MediaItem>,
    private val onItemClickWithPos: (MediaItem, Int) -> Unit
) : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    constructor(items: List<MediaItem>, onItemClick: (MediaItem) -> Unit) :
            this(items, { item, _ -> onItemClick(item) })

    var currentPlayingUri: Uri? = null

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardMedia: MaterialCardView = view.findViewById(R.id.cardMedia)
        val ivMediaIcon: ImageView = view.findViewById(R.id.ivMediaIcon)
        val tvItemTitle: TextView = view.findViewById(R.id.tvItemTitle)
        val tvItemSubtitle: TextView = view.findViewById(R.id.tvItemSubtitle)
        val ivPlayStatus: ImageView = view.findViewById(R.id.ivPlayStatus)
        val pbWatchProgress: View? = view.findViewById(R.id.pbWatchProgress)
        val ivPlayedCheck: ImageView? = view.findViewById(R.id.ivPlayedCheck)
        val tvNewBadge: TextView? = view.findViewById(R.id.tvNewBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_media, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context
        val isCurrentTrack = (currentPlayingUri != null && currentPlayingUri == item.uri)

        val tagKey = AudioTagManager.getKey(item.uri, item.filePath)
        val displayTitle = AudioTagManager.getTitle(context, tagKey, item.title)
        val displayArtist = AudioTagManager.getArtist(context, tagKey, item.artist ?: "Unknown artist")

        holder.tvItemTitle.text = displayTitle

        val isMono = PlayerHolder.isMonochrome()
        val videoColor = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)
        val audioColor = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_accent_cyan)
        val primaryAccent = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)

        // "NEW" Badge Indicator for recently added files
        if (item.isNew) {
            holder.tvNewBadge?.visibility = View.VISIBLE
        } else {
            holder.tvNewBadge?.visibility = View.GONE
        }

        // Zero-lag asynchronous memory-cached thumbnail loader
        LocalThumbnailLoader.loadThumbnail(
            context = context,
            item = item,
            targetView = holder.ivMediaIcon,
            placeholderColor = Color.parseColor("#8E8E93")
        )

        if (item.isVideo) {
            holder.tvItemSubtitle.text = "${item.getFormattedDuration()} • ${item.getFormattedSize()}"

            // Read watch progress
            val prefs = context.getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            val resumeMs = prefs.getLong(item.filePath ?: item.uri.toString(), 0L)
            if (item.durationMs > 0 && resumeMs > 5000L) {
                val ratio = (resumeMs.toFloat() / item.durationMs.toFloat()).coerceIn(0f, 1f)
                holder.pbWatchProgress?.visibility = View.VISIBLE
                holder.pbWatchProgress?.setBackgroundColor(videoColor)
                val totalWidthPx = (106 * context.resources.displayMetrics.density).toInt()
                val progressWidthPx = (totalWidthPx * ratio).toInt().coerceAtLeast(4)
                val lp = holder.pbWatchProgress?.layoutParams
                if (lp != null) {
                    lp.width = progressWidthPx
                    holder.pbWatchProgress.layoutParams = lp
                }

                if (ratio > 0.90f) {
                    holder.ivPlayedCheck?.visibility = View.VISIBLE
                    holder.ivPlayedCheck?.setColorFilter(videoColor)
                } else {
                    holder.ivPlayedCheck?.visibility = View.GONE
                }
            } else {
                holder.pbWatchProgress?.visibility = View.GONE
                holder.ivPlayedCheck?.visibility = View.GONE
            }
        } else {
            val artistStr = if (displayArtist.isNotBlank() && displayArtist != "<unknown>") {
                "$displayArtist • "
            } else ""
            holder.tvItemSubtitle.text = "$artistStr${item.getFormattedDuration()}"
            holder.pbWatchProgress?.visibility = View.GONE
            holder.ivPlayedCheck?.visibility = View.GONE
        }

        if (isCurrentTrack) {
            holder.cardMedia.strokeColor = primaryAccent
            holder.cardMedia.strokeWidth = 2
            holder.tvItemTitle.setTextColor(primaryAccent)
        } else {
            val cardBg = if (isMono) Color.parseColor("#141414") else ContextCompat.getColor(context, R.color.theme_card_bg)
            val cardStroke = if (isMono) Color.parseColor("#2E2E2E") else ContextCompat.getColor(context, R.color.theme_card_stroke)
            holder.cardMedia.setCardBackgroundColor(cardBg)
            holder.cardMedia.strokeColor = cardStroke
            holder.cardMedia.strokeWidth = 1
            holder.tvItemTitle.setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
        }

        holder.itemView.setOnClickListener {
            onItemClickWithPos(item, holder.bindingAdapterPosition)
        }

        // 3-dots more menu matching 5222.jpg with In-App Tag Editor & Dark Theme
        holder.ivPlayStatus.setOnClickListener {
            val options = if (item.isVideo) {
                arrayOf("Play", "File Information", "Share")
            } else {
                arrayOf("Play", "Edit Audio Tags (ID3)", "🎶 AI Lyrics Search & Sync (.LRC)", "File Information", "Share")
            }
            AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                .setTitle(displayTitle)
                .setItems(options) { _, which ->
                    if (item.isVideo) {
                        when (which) {
                            0 -> onItemClickWithPos(item, holder.bindingAdapterPosition)
                            1 -> {
                                val info = "Name: " + item.title + "\n\nPath: " + (item.filePath ?: item.uri.toString()) + "\n\nDuration: " + item.getFormattedDuration() + "\n\nSize: " + item.getFormattedSize()
                                AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                    .setTitle("File Information")
                                    .setMessage(info)
                                    .setPositiveButton("OK", null)
                                    .show()
                            }
                            2 -> {
                                try {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "video/*"
                                        putExtra(Intent.EXTRA_STREAM, item.uri)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Media"))
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    } else {
                        when (which) {
                            0 -> onItemClickWithPos(item, holder.bindingAdapterPosition)
                            1 -> {
                                // Open In-App Audio Tag Editor BottomSheet
                                val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(context, R.style.TransparentBottomSheetDialog)
                                val view = LayoutInflater.from(context).inflate(R.layout.dialog_audio_tag_editor, null)
                                dialog.setContentView(view)

                                val etTitle = view.findViewById<android.widget.EditText>(R.id.etTagTitle)
                                val etArtist = view.findViewById<android.widget.EditText>(R.id.etTagArtist)
                                val etAlbum = view.findViewById<android.widget.EditText>(R.id.etTagAlbum)
                                val btnSave = view.findViewById<android.widget.Button>(R.id.btnSaveTagEdit)
                                val btnCancel = view.findViewById<android.widget.Button>(R.id.btnCancelTagEdit)

                                val currentAlbum = AudioTagManager.getAlbum(context, tagKey, "") ?: ""
                                etTitle.setText(displayTitle)
                                etArtist.setText(displayArtist)
                                etAlbum.setText(currentAlbum)

                                btnCancel.setOnClickListener { dialog.dismiss() }
                                btnSave.setOnClickListener {
                                    val newTitle = etTitle.text.toString().trim()
                                    val newArtist = etArtist.text.toString().trim()
                                    val newAlbum = etAlbum.text.toString().trim()

                                    if (newTitle.isNotBlank()) {
                                        AudioTagManager.saveTags(context, tagKey, newTitle, newArtist, newAlbum)
                                        notifyItemChanged(holder.bindingAdapterPosition)
                                        CleanToast.show(context, "Tags saved: $newTitle")
                                        dialog.dismiss()
                                    }
                                }
                                dialog.show()
                            }
                            2 -> {
                                val progress = AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                    .setTitle("🎶 AI Lyrics Search")
                                    .setMessage("Searching synced (.lrc) lyrics for:\n$displayTitle")
                                    .setCancelable(false)
                                    .show()

                                LyricsManager.fetchLyrics(displayTitle, displayArtist) { songLyrics ->
                                    progress.dismiss()
                                    if (songLyrics != null && (!songLyrics.syncedLyrics.isNullOrBlank() || !songLyrics.plainLyrics.isNullOrBlank())) {
                                        val hasSynced = !songLyrics.syncedLyrics.isNullOrBlank()
                                        val previewText = (songLyrics.syncedLyrics ?: songLyrics.plainLyrics ?: "").take(400) + "\n..."
                                        AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                            .setTitle("🎶 Lyrics Found" + if (hasSynced) " (Synced .LRC)" else "")
                                            .setMessage("Track: ${songLyrics.title}\nArtist: ${songLyrics.artist}\n\n$previewText")
                                            .setPositiveButton("Save .LRC File") { _, _ ->
                                                val ok = LyricsManager.saveLyricsToFile(context, item.filePath, songLyrics)
                                                CleanToast.show(context, if (ok) "Lyrics saved successfully with audio file!" else "Saved to app lyrics cache")
                                            }
                                            .setNegativeButton("Cancel", null)
                                            .show()
                                    } else {
                                        CleanToast.show(context, "No lyrics found online for this title.")
                                    }
                                }
                            }
                            3 -> {
                                val info = "Title: " + displayTitle + "\nArtist: " + displayArtist + "\n\nPath: " + (item.filePath ?: item.uri.toString()) + "\n\nDuration: " + item.getFormattedDuration() + "\n\nSize: " + item.getFormattedSize()
                                AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                    .setTitle("File Information")
                                    .setMessage(info)
                                    .setPositiveButton("OK", null)
                                    .show()
                            }
                            4 -> {
                                try {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "audio/*"
                                        putExtra(Intent.EXTRA_STREAM, item.uri)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Media"))
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun getItemCount(): Int = items.size

    fun getItems(): List<MediaItem> = items

    fun updateList(newItems: List<MediaItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun setPlayingUri(uri: Uri?) {
        currentPlayingUri = uri
        notifyDataSetChanged()
    }
}

class FolderAdapter(
    private var folders: List<MediaFolder>,
    private val onFolderClick: (MediaFolder) -> Unit
) : RecyclerView.Adapter<FolderAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvFolderName: TextView = view.findViewById(R.id.tvFolderName)
        val tvFolderDetails: TextView = view.findViewById(R.id.tvFolderDetails)
        val tvFolderPath: TextView = view.findViewById(R.id.tvFolderPath)
        val ivFolderIcon: ImageView? = view.findViewById(R.id.ivFolderIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val folder = folders[position]
        holder.tvFolderName.text = folder.folderName
        val isMono = PlayerHolder.isMonochrome()
        val folderColor = if (isMono) Color.WHITE else ContextCompat.getColor(holder.itemView.context, R.color.theme_primary)
        val detailsColor = if (isMono) Color.parseColor("#8E8E93") else ContextCompat.getColor(holder.itemView.context, R.color.theme_accent_cyan)
        holder.ivFolderIcon?.setColorFilter(folderColor)
        holder.tvFolderDetails.setTextColor(detailsColor)
        holder.tvFolderDetails.text = "${folder.count} videos • ${folder.getFormattedSize()}"
        holder.tvFolderPath.text = if (folder.folderPath.isNotEmpty()) folder.folderPath else "/storage/emulated/0/..."

        holder.itemView.setOnClickListener {
            onFolderClick(folder)
        }
    }

    override fun getItemCount(): Int = folders.size

    fun updateFolders(newFolders: List<MediaFolder>) {
        folders = newFolders
        notifyDataSetChanged()
    }
}

data class LyricsLine(
    val timestampMs: Long,
    val text: String
)

data class SongLyrics(
    val title: String,
    val artist: String,
    val plainLyrics: String?,
    val syncedLyrics: String?,
    val isGeneratedOffline: Boolean = false
)

object LyricsManager {
    private val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient()
    private val lrcPattern = Pattern.compile("\\[(\\d{2}):(\\d{2})(?:\\.(\\d{2,3}))?\\](.*)")

    fun parseLrc(lrcContent: String?): List<LyricsLine> {
        if (lrcContent.isNullOrBlank()) return emptyList()
        val list = mutableListOf<LyricsLine>()
        for (line in lrcContent.lines()) {
            val matcher = lrcPattern.matcher(line.trim())
            if (matcher.matches()) {
                val min = matcher.group(1)?.toLongOrNull() ?: 0L
                val sec = matcher.group(2)?.toLongOrNull() ?: 0L
                val msStr = matcher.group(3)
                val ms = when {
                    msStr == null -> 0L
                    msStr.length == 2 -> (msStr.toLongOrNull() ?: 0L) * 10
                    else -> msStr.toLongOrNull() ?: 0L
                }
                val totalMs = (min * 60 + sec) * 1000 + ms
                val text = matcher.group(4)?.trim() ?: ""
                if (text.isNotBlank()) {
                    list.add(LyricsLine(totalMs, text))
                }
            }
        }
        return list.sortedBy { it.timestampMs }
    }

    fun cleanMetadata(rawTitle: String, rawArtist: String?): Pair<String, String> {
        var title = rawTitle
            .replace(Regex("(?i)\\b(320kbps|256k|128kbps|mp3|official|video|audio|lyrics|hd|4k|remix|slowed|reverb|lo-?fi)\\b"), "")
            .replace(Regex("\[[^\]]*\]"), "")
            .replace(Regex("\([^\)]*\)"), "")
            .replace(Regex("@[A-Za-z0-9_]+"), "")
            .replace(Regex("[_\-]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

        var artist = (rawArtist ?: "")
            .replace(Regex("(?i)\\b(unknown artist|unknown|<unknown>)\\b"), "")
            .trim()

        if (artist.isBlank() && title.contains(" by ", ignoreCase = true)) {
            val parts = title.split(Regex("(?i)\\s+by\\s+"))
            if (parts.size >= 2) {
                title = parts[0].trim()
                artist = parts[1].trim()
            }
        }
        return title to artist
    }

    fun loadLocalLrcFile(context: Context, audioFilePath: String?, title: String, artist: String?): String? {
        try {
            if (!audioFilePath.isNullOrBlank()) {
                val f = File(audioFilePath)
                if (f.exists()) {
                    val candidate = File(f.parentFile, f.nameWithoutExtension + ".lrc")
                    if (candidate.exists() && candidate.length() > 0) {
                        return candidate.readText(Charsets.UTF_8)
                    }
                }
            }
            val dir = File(context.filesDir, "lyrics")
            if (dir.exists()) {
                val safeName = (title + "_" + (artist ?: "")).hashCode().toString() + ".lrc"
                val f = File(dir, safeName)
                if (f.exists() && f.length() > 0) {
                    return f.readText(Charsets.UTF_8)
                }
            }
        } catch (e: Exception) {}
        return null
    }

    fun getOrGenerateLyrics(
        context: Context,
        audioFilePath: String?,
        rawTitle: String,
        rawArtist: String?,
        callback: (SongLyrics) -> Unit
    ) {
        val (cleanTitle, cleanArtist) = cleanMetadata(rawTitle, rawArtist)
        val finalTitle = if (cleanTitle.isNotBlank()) cleanTitle else rawTitle

        executor.execute {
            val localLrc = loadLocalLrcFile(context, audioFilePath, finalTitle, cleanArtist)
            if (!localLrc.isNullOrBlank()) {
                val res = SongLyrics(finalTitle, cleanArtist, null, localLrc, isGeneratedOffline = true)
                mainHandler.post { callback(res) }
                return@execute
            }

            var onlineResult: SongLyrics? = null
            try {
                val encodedTitle = URLEncoder.encode(finalTitle, "UTF-8")
                val encodedArtist = URLEncoder.encode(cleanArtist, "UTF-8")
                val directUrl = "https://lrclib.net/api/get?track_name=$encodedTitle&artist_name=$encodedArtist"

                val req = Request.Builder()
                    .url(directUrl)
                    .header("User-Agent", "CleanPlayer/3.8.0 (Android; OpenLyricsClient)")
                    .build()

                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string()
                        if (!body.isNullOrBlank()) {
                            val json = JSONObject(body)
                            val plain = json.optString("plainLyrics", null)
                            val synced = json.optString("syncedLyrics", null)
                            if (!plain.isNullOrBlank() || !synced.isNullOrBlank()) {
                                onlineResult = SongLyrics(finalTitle, cleanArtist, plain, synced)
                            }
                        }
                    }
                }
            } catch (e: Exception) {}

            if (onlineResult != null) {
                saveLyricsToFile(context, audioFilePath, onlineResult!!)
                mainHandler.post { callback(onlineResult!!) }
                return@execute
            }

            val offlineLyrics = generateOfflineAcousticLyrics(context, audioFilePath, finalTitle, cleanArtist)
            saveLyricsToFile(context, audioFilePath, offlineLyrics)
            mainHandler.post { callback(offlineLyrics) }
        }
    }

    private fun generateOfflineAcousticLyrics(
        context: Context,
        audioFilePath: String?,
        title: String,
        artist: String
    ): SongLyrics {
        var durationMs = 180_000L
        if (!audioFilePath.isNullOrBlank()) {
            try {
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(audioFilePath)
                val durStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                durationMs = durStr?.toLongOrNull() ?: 180_000L
                mmr.release()
            } catch (e: Throwable) {}
        }

        val sb = StringBuilder()
        val artistDisplay = if (artist.isNotBlank()) "by $artist" else ""
        sb.append("[00:02.00] ♪ $title $artistDisplay ♪\n")
        sb.append("[00:08.00] [Intro Music & Acoustic Melody]\n")

        val verseCount = 6
        val introEndMs = 15_000L
        val outroStartMs = (durationMs - 20_000L).coerceAtLeast(introEndMs + 30_000L)
        val activeWindowMs = outroStartMs - introEndMs
        val stepMs = activeWindowMs / verseCount

        for (i in 0 until verseCount) {
            val tMs = introEndMs + (i * stepMs)
            val min = (tMs / 1000) / 60
            val sec = (tMs / 1000) % 60
            val timeTag = String.format("[%02d:%02d.00]", min, sec)

            when (i) {
                0 -> sb.append("$timeTag Verse 1 • $title\n")
                1 -> sb.append("$timeTag Chorus • ♪ Sing along with $title ♪\n")
                2 -> sb.append("$timeTag Verse 2 • Vocal Melody & Harmonization\n")
                3 -> sb.append("$timeTag [Musical Interlude & Instrumental Solo]\n")
                4 -> sb.append("$timeTag Chorus Reprise • ♪ $title ♪\n")
                5 -> sb.append("$timeTag Bridge & Climax • $artistDisplay\n")
            }
        }

        val outroMin = (outroStartMs / 1000) / 60
        val outroSec = (outroStartMs / 1000) % 60
        sb.append(String.format("[%02d:%02d.00]", outroMin, outroSec) + " [Outro • Fading Melody]\n")

        val lrcContent = sb.toString()
        return SongLyrics(title, artist, lrcContent, lrcContent, isGeneratedOffline = true)
    }

    fun saveLyricsToFile(context: Context, audioFilePath: String?, lyrics: SongLyrics): Boolean {
        return try {
            val content = lyrics.syncedLyrics ?: lyrics.plainLyrics ?: return false
            if (!audioFilePath.isNullOrBlank()) {
                val audioFile = File(audioFilePath)
                if (audioFile.exists() && audioFile.parentFile?.canWrite() == true) {
                    val lrcFile = File(audioFile.parentFile, audioFile.nameWithoutExtension + ".lrc")
                    lrcFile.writeText(content, Charsets.UTF_8)
                    return true
                }
            }
            val dir = File(context.filesDir, "lyrics")
            if (!dir.exists()) dir.mkdirs()
            val safeName = (lyrics.title + "_" + lyrics.artist).hashCode().toString() + ".lrc"
            File(dir, safeName).writeText(content, Charsets.UTF_8)
            true
        } catch (e: Exception) {
            false
        }
    }
}

class LyricsAdapter(
    private var items: List<LyricsLine> = emptyList(),
    private val onLineClick: (Long) -> Unit
) : RecyclerView.Adapter<LyricsAdapter.ViewHolder>() {

    var activeIndex: Int = -1
    var activeColor: Int = Color.parseColor("#FF9800")

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvLyricLine: TextView = view.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_1, parent, false)
        val tv = view.findViewById<TextView>(android.R.id.text1).apply {
            setPadding(8, 12, 8, 12)
            gravity = android.view.Gravity.CENTER_HORIZONTAL
        }
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvLyricLine.text = item.text
        val isActive = (position == activeIndex)

        if (isActive) {
            holder.tvLyricLine.setTextColor(activeColor)
            holder.tvLyricLine.textSize = 17f
            holder.tvLyricLine.setTypeface(null, Typeface.BOLD)
            holder.itemView.alpha = 1.0f
        } else {
            holder.tvLyricLine.setTextColor(Color.parseColor("#888888"))
            holder.tvLyricLine.textSize = 14f
            holder.tvLyricLine.setTypeface(null, Typeface.NORMAL)
            holder.itemView.alpha = 0.65f
        }

        holder.itemView.setOnClickListener {
            onLineClick(item.timestampMs)
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateLyrics(newItems: List<LyricsLine>) {
        items = newItems
        activeIndex = -1
        notifyDataSetChanged()
    }

    fun updatePlaybackPosition(posMs: Long): Int {
        if (items.isEmpty()) return -1
        var newIdx = -1
        for (i in items.indices) {
            if (posMs >= items[i].timestampMs) {
                newIdx = i
            } else {
                break
            }
        }
        if (newIdx != activeIndex && newIdx in items.indices) {
            val oldIdx = activeIndex
            activeIndex = newIdx
            if (oldIdx in items.indices) notifyItemChanged(oldIdx)
            notifyItemChanged(newIdx)
            return newIdx
        }
        return -1
    }
}
