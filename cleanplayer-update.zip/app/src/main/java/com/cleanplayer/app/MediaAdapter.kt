package com.cleanplayer.app
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.SpannableStringBuilder
import java.util.regex.Pattern
import java.net.URLEncoder
import java.io.File
import org.json.JSONObject
import org.json.JSONArray
import okhttp3.Request
import okhttp3.OkHttpClient
import android.os.Looper
import android.os.Handler
import android.media.MediaMetadataRetriever
import android.graphics.Typeface

import android.content.Context
import android.graphics.Color
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class MediaAdapter(
    private var items: List<MediaItem>,
    private val onItemClickWithPos: (MediaItem, Int) -> Unit
) : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    constructor(items: List<MediaItem>, onItemClick: (MediaItem) -> Unit) :
            this(items, { item, _ -> onItemClick(item) })

    var currentPlayingUri: Uri? = null

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardMedia: MaterialCardView = view.findViewById(R.id.cardMedia)
        val ivMediaIcon: ImageView = view.findViewById(R.id.ivMediaIcon)
        val tvItemTitle: TextView = view.findViewById(R.id.tvItemTitle)
        val tvItemSubtitle: TextView = view.findViewById(R.id.tvItemSubtitle)
        val ivPlayStatus: ImageView = view.findViewById(R.id.ivPlayStatus)
        val pbWatchProgress: View? = view.findViewById(R.id.pbWatchProgress)
        val ivPlayedCheck: ImageView? = view.findViewById(R.id.ivPlayedCheck)
        val tvNewBadge: TextView? = view.findViewById(R.id.tvNewBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_media, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context
        val isCurrentTrack = (currentPlayingUri != null && currentPlayingUri == item.uri)

        val tagKey = AudioTagManager.getKey(item.uri, item.filePath)
        val displayTitle = AudioTagManager.getTitle(context, tagKey, item.title)
        val displayArtist = AudioTagManager.getArtist(context, tagKey, item.artist ?: "Unknown artist")

        holder.tvItemTitle.text = displayTitle

        val isMono = PlayerHolder.isMonochrome()
        val videoColor = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)
        val audioColor = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_accent_cyan)
        val primaryAccent = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)

        // "NEW" Badge Indicator for recently added files
        if (item.isNew) {
            holder.tvNewBadge?.visibility = View.VISIBLE
        } else {
            holder.tvNewBadge?.visibility = View.GONE
        }

        // Zero-lag asynchronous memory-cached thumbnail loader
        LocalThumbnailLoader.loadThumbnail(
            context = context,
            item = item,
            targetView = holder.ivMediaIcon,
            placeholderColor = Color.parseColor("#8E8E93")
        )

        if (item.isVideo) {
            holder.tvItemSubtitle.text = "${item.getFormattedDuration()} • ${item.getFormattedSize()}"

            // Read watch progress
            val prefs = context.getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            val resumeMs = prefs.getLong(item.filePath ?: item.uri.toString(), 0L)
            if (item.durationMs > 0 && resumeMs > 5000L) {
                val ratio = (resumeMs.toFloat() / item.durationMs.toFloat()).coerceIn(0f, 1f)
                holder.pbWatchProgress?.visibility = View.VISIBLE
                holder.pbWatchProgress?.setBackgroundColor(videoColor)
                val totalWidthPx = (106 * context.resources.displayMetrics.density).toInt()
                val progressWidthPx = (totalWidthPx * ratio).toInt().coerceAtLeast(4)
                val lp = holder.pbWatchProgress?.layoutParams
                if (lp != null) {
                    lp.width = progressWidthPx
                    holder.pbWatchProgress.layoutParams = lp
                }

                if (ratio > 0.90f) {
                    holder.ivPlayedCheck?.visibility = View.VISIBLE
                    holder.ivPlayedCheck?.setColorFilter(videoColor)
                } else {
                    holder.ivPlayedCheck?.visibility = View.GONE
                }
            } else {
                holder.pbWatchProgress?.visibility = View.GONE
                holder.ivPlayedCheck?.visibility = View.GONE
            }
        } else {
            val artistStr = if (displayArtist.isNotBlank() && displayArtist != "<unknown>") {
                "$displayArtist • "
            } else ""
            holder.tvItemSubtitle.text = "$artistStr${item.getFormattedDuration()}"
            holder.pbWatchProgress?.visibility = View.GONE
            holder.ivPlayedCheck?.visibility = View.GONE
        }

        if (isCurrentTrack) {
            holder.cardMedia.strokeColor = primaryAccent
            holder.cardMedia.strokeWidth = 2
            holder.tvItemTitle.setTextColor(primaryAccent)
        } else {
            val cardBg = if (isMono) Color.parseColor("#141414") else ContextCompat.getColor(context, R.color.theme_card_bg)
            val cardStroke = if (isMono) Color.parseColor("#2E2E2E") else ContextCompat.getColor(context, R.color.theme_card_stroke)
            holder.cardMedia.setCardBackgroundColor(cardBg)
            holder.cardMedia.strokeColor = cardStroke
            holder.cardMedia.strokeWidth = 1
            holder.tvItemTitle.setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
        }

        holder.itemView.setOnClickListener {
            onItemClickWithPos(item, holder.bindingAdapterPosition)
        }

        // 3-dots more menu matching 5222.jpg with In-App Tag Editor & Dark Theme
        holder.ivPlayStatus.setOnClickListener {
            val options = if (item.isVideo) {
                arrayOf("Play", "File Information", "Share")
            } else {
                arrayOf("Play", "Edit Audio Tags (ID3)", "🎶 AI Lyrics Search & Sync (.LRC)", "File Information", "Share")
            }
            AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                .setTitle(displayTitle)
                .setItems(options) { _, which ->
                    if (item.isVideo) {
                        when (which) {
                            0 -> onItemClickWithPos(item, holder.bindingAdapterPosition)
                            1 -> {
                                val info = "Name: " + item.title + "\n\nPath: " + (item.filePath ?: item.uri.toString()) + "\n\nDuration: " + item.getFormattedDuration() + "\n\nSize: " + item.getFormattedSize()
                                AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                    .setTitle("File Information")
                                    .setMessage(info)
                                    .setPositiveButton("OK", null)
                                    .show()
                            }
                            2 -> {
                                try {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "video/*"
                                        putExtra(Intent.EXTRA_STREAM, item.uri)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Media"))
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    } else {
                        when (which) {
                            0 -> onItemClickWithPos(item, holder.bindingAdapterPosition)
                            1 -> {
                                // Open In-App Audio Tag Editor BottomSheet
                                val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(context, R.style.TransparentBottomSheetDialog)
                                val view = LayoutInflater.from(context).inflate(R.layout.dialog_audio_tag_editor, null)
                                dialog.setContentView(view)

                                val etTitle = view.findViewById<android.widget.EditText>(R.id.etTagTitle)
                                val etArtist = view.findViewById<android.widget.EditText>(R.id.etTagArtist)
                                val etAlbum = view.findViewById<android.widget.EditText>(R.id.etTagAlbum)
                                val btnSave = view.findViewById<android.widget.Button>(R.id.btnSaveTagEdit)
                                val btnCancel = view.findViewById<android.widget.Button>(R.id.btnCancelTagEdit)

                                val currentAlbum = AudioTagManager.getAlbum(context, tagKey, "") ?: ""
                                etTitle.setText(displayTitle)
                                etArtist.setText(displayArtist)
                                etAlbum.setText(currentAlbum)

                                btnCancel.setOnClickListener { dialog.dismiss() }
                                btnSave.setOnClickListener {
                                    val newTitle = etTitle.text.toString().trim()
                                    val newArtist = etArtist.text.toString().trim()
                                    val newAlbum = etAlbum.text.toString().trim()

                                    if (newTitle.isNotBlank()) {
                                        AudioTagManager.saveTags(context, tagKey, newTitle, newArtist, newAlbum)
                                        notifyItemChanged(holder.bindingAdapterPosition)
                                        CleanToast.show(context, "Tags saved: $newTitle")
                                        dialog.dismiss()
                                    }
                                }
                                dialog.show()
                            }
                            2 -> {
                                val progress = AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                    .setTitle("🎶 AI Lyrics Search")
                                    .setMessage("Searching synced (.lrc) lyrics for:\n$displayTitle")
                                    .setCancelable(false)
                                    .show()

                                LyricsManager.getOrGenerateLyrics(context, null, displayTitle, displayArtist) { songLyrics ->
                                    progress.dismiss()
                                    if (songLyrics != null && (!songLyrics.syncedLyrics.isNullOrBlank() || !songLyrics.plainLyrics.isNullOrBlank())) {
                                        val hasSynced = !songLyrics.syncedLyrics.isNullOrBlank()
                                        val previewText = (songLyrics.syncedLyrics ?: songLyrics.plainLyrics ?: "").take(400) + "\n..."
                                        AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                            .setTitle("🎶 Lyrics Found" + if (hasSynced) " (Synced .LRC)" else "")
                                            .setMessage("Track: ${songLyrics.title}\nArtist: ${songLyrics.artist}\n\n$previewText")
                                            .setPositiveButton("Save .LRC File") { _, _ ->
                                                val ok = LyricsManager.saveLyricsToFile(context, item.filePath, songLyrics)
                                                CleanToast.show(context, if (ok) "Lyrics saved successfully with audio file!" else "Saved to app lyrics cache")
                                            }
                                            .setNegativeButton("Cancel", null)
                                            .show()
                                    } else {
                                        CleanToast.show(context, "No lyrics found online for this title.")
                                    }
                                }
                            }
                            3 -> {
                                val info = "Title: " + displayTitle + "\nArtist: " + displayArtist + "\n\nPath: " + (item.filePath ?: item.uri.toString()) + "\n\nDuration: " + item.getFormattedDuration() + "\n\nSize: " + item.getFormattedSize()
                                AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                                    .setTitle("File Information")
                                    .setMessage(info)
                                    .setPositiveButton("OK", null)
                                    .show()
                            }
                            4 -> {
                                try {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "audio/*"
                                        putExtra(Intent.EXTRA_STREAM, item.uri)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Media"))
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun getItemCount(): Int = items.size

    fun getItems(): List<MediaItem> = items

    fun updateList(newItems: List<MediaItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun setPlayingUri(uri: Uri?) {
        currentPlayingUri = uri
        notifyDataSetChanged()
    }
}

class FolderAdapter(
    private var folders: List<MediaFolder>,
    private val onFolderClick: (MediaFolder) -> Unit
) : RecyclerView.Adapter<FolderAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvFolderName: TextView = view.findViewById(R.id.tvFolderName)
        val tvFolderDetails: TextView = view.findViewById(R.id.tvFolderDetails)
        val tvFolderPath: TextView = view.findViewById(R.id.tvFolderPath)
        val ivFolderIcon: ImageView? = view.findViewById(R.id.ivFolderIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val folder = folders[position]
        holder.tvFolderName.text = folder.folderName
        val isMono = PlayerHolder.isMonochrome()
        val folderColor = if (isMono) Color.WHITE else ContextCompat.getColor(holder.itemView.context, R.color.theme_primary)
        val detailsColor = if (isMono) Color.parseColor("#8E8E93") else ContextCompat.getColor(holder.itemView.context, R.color.theme_accent_cyan)
        holder.ivFolderIcon?.setColorFilter(folderColor)
        holder.tvFolderDetails.setTextColor(detailsColor)
        holder.tvFolderDetails.text = "${folder.count} videos • ${folder.getFormattedSize()}"
        holder.tvFolderPath.text = if (folder.folderPath.isNotEmpty()) folder.folderPath else "/storage/emulated/0/..."

        holder.itemView.setOnClickListener {
            onFolderClick(folder)
        }
    }

    override fun getItemCount(): Int = folders.size

    fun updateFolders(newFolders: List<MediaFolder>) {
        folders = newFolders
        notifyDataSetChanged()
    }
}

data class LyricWord(
    val word: String,
    val startMs: Long,
    val endMs: Long
)

data class LyricsLine(
    val timestampMs: Long,
    val text: String,
    val translationText: String? = null,
    val words: List<LyricWord> = emptyList()
)

data class SongLyrics(
    val title: String,
    val artist: String,
    val plainLyrics: String?,
    val syncedLyrics: String?,
    val isGeneratedOffline: Boolean = false
)

data class LrcSearchResult(
    val id: Long,
    val trackName: String,
    val artistName: String,
    val albumName: String?,
    val duration: Double,
    val syncedLyrics: String?,
    val plainLyrics: String?
)

object LyricsManager {
    private val executor = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient()
    private val lrcPattern = Pattern.compile("""\[(\d{2}):(\d{2})(?:\.(\d{2,3}))?\](.*)""")
    private val wordTagPattern = Pattern.compile("""<(\d{2}):(\d{2})(?:\.(\d{2,3}))?>""")

    fun parseLrc(lrcContent: String?): List<LyricsLine> {
        if (lrcContent.isNullOrBlank()) return emptyList()
        val rawList = mutableListOf<Pair<Long, String>>()
        for (line in lrcContent.lines()) {
            val trimmed = line.trim()
            val matcher = lrcPattern.matcher(trimmed)
            if (matcher.matches()) {
                val min = matcher.group(1)?.toLongOrNull() ?: 0L
                val sec = matcher.group(2)?.toLongOrNull() ?: 0L
                val msStr = matcher.group(3)
                val ms = when {
                    msStr == null -> 0L
                    msStr.length == 2 -> (msStr.toLongOrNull() ?: 0L) * 10
                    else -> msStr.toLongOrNull() ?: 0L
                }
                val totalMs = (min * 60 + sec) * 1000 + ms
                val text = matcher.group(4)?.trim() ?: ""
                if (text.isNotBlank()) {
                    rawList.add(Pair(totalMs, text))
                }
            }
        }
        val sortedRaw = rawList.sortedBy { it.first }
        if (sortedRaw.isEmpty()) return emptyList()

        val resultLines = mutableListOf<LyricsLine>()
        for (i in sortedRaw.indices) {
            val (lineStartMs, rawLineText) = sortedRaw[i]
            val lineEndMs = if (i + 1 < sortedRaw.size) {
                sortedRaw[i + 1].first
            } else {
                lineStartMs + 4000L
            }
            val rawWords = rawLineText.trim().split(Regex("""\s+""")).filter { it.isNotBlank() }
            val naturalVocalDuration = (rawWords.size * 420L).coerceAtLeast(1000L)
            val actualGap = (lineEndMs - lineStartMs).coerceAtLeast(600L)
            val lineDuration = if (actualGap > naturalVocalDuration + 1500L) naturalVocalDuration else actualGap.coerceIn(800L, 5000L)

            // Check if line contains enhanced word tags <mm:ss.xx>
            if (wordTagPattern.matcher(rawLineText).find()) {
                val words = parseEnhancedWords(rawLineText, lineStartMs, lineEndMs)
                val cleanLineText = rawLineText.replace(Regex("""<[^>]+>"""), " ").replace(Regex("""\s+"""), " ").trim()
                resultLines.add(LyricsLine(lineStartMs, cleanLineText, null, words))
            } else {
                // Proportional word timing interpolation for line-synced lyrics
                val rawWords = rawLineText.trim().split(Regex("""\s+""")).filter { it.isNotBlank() }
                if (rawWords.isNotEmpty()) {
                    val totalWeight = rawWords.sumOf { it.length.coerceAtLeast(2) }
                    var curStart = lineStartMs
                    val words = mutableListOf<LyricWord>()
                    for (w in rawWords) {
                        val wDur = (lineDuration * w.length.coerceAtLeast(2)) / totalWeight
                        val wEnd = curStart + wDur
                        words.add(LyricWord(w, curStart, wEnd))
                        curStart = wEnd
                    }
                    resultLines.add(LyricsLine(lineStartMs, rawLineText, null, words))
                } else {
                    resultLines.add(LyricsLine(lineStartMs, rawLineText, null, emptyList()))
                }
            }
        }
        return resultLines
    }

    private fun parseEnhancedWords(rawText: String, lineStartMs: Long, lineEndMs: Long): List<LyricWord> {
        val words = mutableListOf<LyricWord>()
        val matcher = Pattern.compile("""(<(\d{2}):(\d{2})(?:\.(\d{2,3}))?>)?([^<]+)""").matcher(rawText)
        var lastTime = lineStartMs
        val rawTokens = mutableListOf<Pair<Long, String>>()

        while (matcher.find()) {
            val tag = matcher.group(1)
            val text = matcher.group(5)?.trim() ?: ""
            if (tag != null) {
                val min = matcher.group(2)?.toLongOrNull() ?: 0L
                val sec = matcher.group(3)?.toLongOrNull() ?: 0L
                val msStr = matcher.group(4)
                val ms = when {
                    msStr == null -> 0L
                    msStr.length == 2 -> (msStr.toLongOrNull() ?: 0L) * 10
                    else -> msStr.toLongOrNull() ?: 0L
                }
                lastTime = (min * 60 + sec) * 1000 + ms
            }
            if (text.isNotBlank()) {
                rawTokens.add(Pair(lastTime, text))
            }
        }

        for (k in rawTokens.indices) {
            val tokenStart = rawTokens[k].first
            val tokenEnd = if (k + 1 < rawTokens.size) rawTokens[k + 1].first else lineEndMs
            val tokenWords = rawTokens[k].second.split(Regex("""\s+""")).filter { it.isNotBlank() }
            if (tokenWords.isNotEmpty()) {
                val dur = (tokenEnd - tokenStart).coerceAtLeast(200L)
                val step = dur / tokenWords.size
                for ((idx, w) in tokenWords.withIndex()) {
                    val ws = tokenStart + idx * step
                    val we = ws + step
                    words.add(LyricWord(w, ws, we))
                }
            }
        }
        return words
    }

    fun cleanMetadata(rawTitle: String, rawArtist: String?): Pair<String, String> {
        var s = rawTitle.replace("_-_", " - ").replace("-_-", " - ").replace("_", " ")
        var artist = (rawArtist ?: "").replace("_", " ").trim()
        if (artist.matches(Regex("(?i)\b(unknown artist|unknown|<unknown>)\b"))) {
            artist = ""
        }

        s = s.replace(Regex("""(?i)\.(mp3|m4a|flac|wav|ogg|opus|aac)$"""), "")
        s = s.replace(Regex("""\[[^\]]*\]"""), "")
        s = s.replace(Regex("""\([^\)]*\)"""), "")
        s = s.replace(Regex("""@[A-Za-z0-9_]+"""), "")

        if (artist.isBlank() && (s.contains(" - ") || s.contains(" – ") || s.contains(" — "))) {
            val parts = s.split(Regex("""\s+[-–—]\s+"""), 2)
            if (parts.size == 2) {
                artist = parts[0].trim()
                s = parts[1].trim()
            }
        }

        if (artist.isBlank() && s.contains(" by ", ignoreCase = true)) {
            val parts = s.split(Regex("""(?i)\s+by\s+"""), 2)
            if (parts.size == 2) {
                s = parts[0].trim()
                artist = parts[1].trim()
            }
        }

        if (s.contains(Regex("""(?i)\s+(?:ft\.?|feat\.?|featuring)\s+"""))) {
            val parts = s.split(Regex("""(?i)\s+(?:ft\.?|feat\.?|featuring)\s+"""), 2)
            if (parts.size >= 2) {
                s = parts[0].trim()
                if (artist.isBlank()) {
                    artist = parts[1].trim()
                }
            }
        }

        s = s.replace(Regex("""(?i)\b(320kbps|256k|128kbps|mp3|official|video|audio|lyrics|hd|4k|remix|slowed|reverb|lo-?fi|soundtrack|soun)\b"""), "")
        s = s.replace(Regex("""\b\d{5,}\b"""), "")
        s = s.replace(Regex("""\s+"""), " ").trim()

        if (artist.isNotBlank() && s.startsWith(artist, ignoreCase = true)) {
            s = s.substring(artist.length).trim().removePrefix("-").trim()
        }

        artist = artist.replace(Regex("""(?i)\b(320kbps|256k|128kbps|mp3|official|video|audio|lyrics|soundtrack)\b"""), "")
        artist = artist.replace(Regex("""\s+"""), " ").trim()

        return s to artist
    }

    fun loadLocalLrcFile(context: Context, audioFilePath: String?, title: String, artist: String?): String? {
        try {
            if (!audioFilePath.isNullOrBlank()) {
                val attachedLrc = AudioTagManager.getLyrics(context, audioFilePath)
                if (!attachedLrc.isNullOrBlank()) {
                    return attachedLrc
                }
            }
            if (!audioFilePath.isNullOrBlank()) {
                val f = File(audioFilePath)
                if (f.exists()) {
                    val candidate = File(f.parentFile, f.nameWithoutExtension + ".lrc")
                    if (candidate.exists() && candidate.length() > 0) {
                        return candidate.readText(Charsets.UTF_8)
                    }
                    val candidateCaps = File(f.parentFile, f.nameWithoutExtension + ".LRC")
                    if (candidateCaps.exists() && candidateCaps.length() > 0) {
                        return candidateCaps.readText(Charsets.UTF_8)
                    }
                }
            }
            val dir = File(context.filesDir, "lyrics")
            if (dir.exists()) {
                if (!audioFilePath.isNullOrBlank()) {
                    val fileHash = File(audioFilePath).nameWithoutExtension.hashCode().toString() + ".lrc"
                    val fh = File(dir, fileHash)
                    if (fh.exists() && fh.length() > 0) return fh.readText(Charsets.UTF_8)
                }
                val safeName = (title + "_" + (artist ?: "")).hashCode().toString() + ".lrc"
                val f = File(dir, safeName)
                if (f.exists() && f.length() > 0) {
                    return f.readText(Charsets.UTF_8)
                }
            }
        } catch (e: Exception) {}
        return null
    }

    fun searchOnlineLyrics(query: String, callback: (List<LrcSearchResult>) -> Unit) {
        executor.execute {
            val results = mutableListOf<LrcSearchResult>()
            try {
                val encodedQ = URLEncoder.encode(query.trim(), "UTF-8")
                val url = "https://lrclib.net/api/search?q="
                val req = Request.Builder()
                    .url(url)
                    .header("User-Agent", "CleanPlayer/3.8.0 (Android; OpenLyricsClient)")
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string()
                        if (!body.isNullOrBlank()) {
                            val arr = JSONArray(body)
                            for (i in 0 until arr.length()) {
                                val obj = arr.getJSONObject(i)
                                val id = obj.optLong("id")
                                val track = obj.optString("trackName", "")
                                val artist = obj.optString("artistName", "")
                                val album = obj.optString("albumName", null)
                                val duration = obj.optDouble("duration", 0.0)
                                val synced = obj.optString("syncedLyrics", null)
                                val plain = obj.optString("plainLyrics", null)
                                if (track.isNotBlank()) {
                                    results.add(LrcSearchResult(id, track, artist, album, duration, synced, plain))
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {}
            mainHandler.post { callback(results) }
        }
    }

    fun getOrGenerateLyrics(
        context: Context,
        audioFilePath: String?,
        rawTitle: String,
        rawArtist: String?,
        callback: (SongLyrics) -> Unit
    ) {
        val (cleanTitle, cleanArtist) = cleanMetadata(rawTitle, rawArtist)
        val finalTitle = if (cleanTitle.isNotBlank()) cleanTitle else rawTitle

        executor.execute {
            // 1. Check local file
            val localLrc = loadLocalLrcFile(context, audioFilePath, finalTitle, cleanArtist)
            if (!localLrc.isNullOrBlank()) {
                val res = SongLyrics(finalTitle, cleanArtist, null, localLrc, isGeneratedOffline = false)
                mainHandler.post { callback(res) }
                return@execute
            }

            // 2. Exact match API get
            var onlineResult: SongLyrics? = null
            try {
                if (cleanArtist.isNotBlank() && cleanTitle.isNotBlank()) {
                    val encodedTitle = URLEncoder.encode(finalTitle, "UTF-8")
                    val encodedArtist = URLEncoder.encode(cleanArtist, "UTF-8")
                    val directUrl = "https://lrclib.net/api/get?track_name=&artist_name="
                    val req = Request.Builder()
                        .url(directUrl)
                        .header("User-Agent", "CleanPlayer/3.8.0 (Android; OpenLyricsClient)")
                        .build()
                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val body = resp.body?.string()
                            if (!body.isNullOrBlank()) {
                                val json = JSONObject(body)
                                val plain = json.optString("plainLyrics", null)
                                val synced = json.optString("syncedLyrics", null)
                                if (!synced.isNullOrBlank() || !plain.isNullOrBlank()) {
                                    onlineResult = SongLyrics(finalTitle, cleanArtist, plain, synced)
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {}

            // 3. Fallback to LRCLIB Search API
            if (onlineResult == null || onlineResult?.syncedLyrics.isNullOrBlank()) {
                try {
                    val searchQuery = if (cleanArtist.isNotBlank()) " " else finalTitle
                    val encodedQ = URLEncoder.encode(searchQuery, "UTF-8")
                    val searchUrl = "https://lrclib.net/api/search?q="
                    val req = Request.Builder()
                        .url(searchUrl)
                        .header("User-Agent", "CleanPlayer/3.8.0 (Android; OpenLyricsClient)")
                        .build()
                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val body = resp.body?.string()
                            if (!body.isNullOrBlank()) {
                                val arr = JSONArray(body)
                                for (i in 0 until arr.length()) {
                                    val item = arr.getJSONObject(i)
                                    val synced = item.optString("syncedLyrics", null)
                                    val plain = item.optString("plainLyrics", null)
                                    val tName = item.optString("trackName", finalTitle)
                                    val aName = item.optString("artistName", cleanArtist)
                                    if (!synced.isNullOrBlank()) {
                                        onlineResult = SongLyrics(tName, aName, plain, synced)
                                        break
                                    } else if (onlineResult == null && !plain.isNullOrBlank()) {
                                        onlineResult = SongLyrics(tName, aName, plain, null)
                                    }
                                }
                            }
                        }
                    }
                } catch (e: Exception) {}
            }

            onlineResult?.let { lyrics ->
                if (!lyrics.syncedLyrics.isNullOrBlank() || !lyrics.plainLyrics.isNullOrBlank()) {
                    saveLyricsToFile(context, audioFilePath, lyrics)
                    mainHandler.post { callback(lyrics) }
                    return@execute
                }
            }

            // 4. Fallback to on-device acoustic generated lyrics
            val offlineLyrics = generateOfflineAcousticLyrics(context, audioFilePath, finalTitle, cleanArtist)
            saveLyricsToFile(context, audioFilePath, offlineLyrics)
            mainHandler.post { callback(offlineLyrics) }
        }
    }

    fun generateOfflineAcousticLyrics(
        context: Context,
        audioFilePath: String?,
        title: String,
        artist: String
    ): SongLyrics {
        var durationMs = 180_000L
        if (!audioFilePath.isNullOrBlank()) {
            try {
                val mmr = MediaMetadataRetriever()
                mmr.setDataSource(audioFilePath)
                val durStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                durationMs = durStr?.toLongOrNull() ?: 180_000L
                mmr.release()
            } catch (e: Throwable) {}
        }

        val sb = StringBuilder()
        val artistDisplay = if (artist.isNotBlank()) "by " else ""
        sb.append("[00:02.00] ♪   ♪\n")
        sb.append("[00:08.00] [Intro Music & Acoustic Melody]\n")

        val verseCount = 6
        val introEndMs = 15_000L
        val outroStartMs = (durationMs - 20_000L).coerceAtLeast(introEndMs + 30_000L)
        val activeWindowMs = outroStartMs - introEndMs
        val stepMs = activeWindowMs / verseCount

        for (i in 0 until verseCount) {
            val tMs = introEndMs + (i * stepMs)
            val min = (tMs / 1000) / 60
            val sec = (tMs / 1000) % 60
            val timeTag = String.format("[%02d:%02d.00]", min, sec)

            when (i) {
                0 -> sb.append(" Verse 1 • \n")
                1 -> sb.append(" Chorus • ♪ Sing along with  ♪\n")
                2 -> sb.append(" Verse 2 • Vocal Melody & Harmonization\n")
                3 -> sb.append(" [Musical Interlude & Instrumental Solo]\n")
                4 -> sb.append(" Chorus Reprise • ♪  ♪\n")
                5 -> sb.append(" Bridge & Climax • \n")
            }
        }

        val outroMin = (outroStartMs / 1000) / 60
        val outroSec = (outroStartMs / 1000) % 60
        sb.append(String.format("[%02d:%02d.00]", outroMin, outroSec) + " [Outro • Fading Melody]\n")

        val lrcContent = sb.toString()
        return SongLyrics(title, artist, lrcContent, lrcContent, isGeneratedOffline = true)
    }

    fun saveLyricsToFile(context: Context, audioFilePath: String?, lyrics: SongLyrics): Boolean {
        return try {
            val content = lyrics.syncedLyrics ?: lyrics.plainLyrics ?: return false

            if (!audioFilePath.isNullOrBlank()) {
                AudioTagManager.saveLyrics(context, audioFilePath, content)
            }

            if (!audioFilePath.isNullOrBlank()) {
                val audioFile = File(audioFilePath)
                if (audioFile.exists() && audioFile.parentFile?.canWrite() == true) {
                    val lrcFile = File(audioFile.parentFile, audioFile.nameWithoutExtension + ".lrc")
                    lrcFile.writeText(content, Charsets.UTF_8)
                }
            }

            val dir = File(context.filesDir, "lyrics")
            if (!dir.exists()) dir.mkdirs()
            val safeName = (lyrics.title + "_" + lyrics.artist).hashCode().toString() + ".lrc"
            File(dir, safeName).writeText(content, Charsets.UTF_8)

            if (!audioFilePath.isNullOrBlank()) {
                val fileHash = File(audioFilePath).nameWithoutExtension.hashCode().toString() + ".lrc"
                File(dir, fileHash).writeText(content, Charsets.UTF_8)
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}

class LyricsAdapter(
    private var items: List<LyricsLine> = emptyList(),
    private val onLineClick: (Long) -> Unit
) : RecyclerView.Adapter<LyricsAdapter.ViewHolder>() {

    var activeIndex: Int = -1
    var activeWordIndex: Int = -1
    var activeColor: Int = Color.parseColor("#FF9800")
    var isWordSyncEnabled: Boolean = true
    var currentPlaybackMs: Long = 0L

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvLyricLine: TextView = view.findViewById(android.R.id.text1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_1, parent, false)
        val tv = view.findViewById<TextView>(android.R.id.text1).apply {
            setPadding(8, 12, 8, 12)
            gravity = android.view.Gravity.CENTER_HORIZONTAL
        }
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val isActive = (position == activeIndex)

        if (!isActive) {
            holder.tvLyricLine.textSize = 14.5f
            holder.tvLyricLine.setTypeface(null, Typeface.NORMAL)
            holder.tvLyricLine.setTextColor(Color.parseColor("#888888"))
            holder.itemView.alpha = 0.65f

            if (!item.translationText.isNullOrBlank() && PlayerHolder.isDualLanguageLyricsEnabled) {
                val ssb = SpannableStringBuilder(item.text)
                ssb.append("\n")
                val tStart = ssb.length
                ssb.append(item.translationText)
                ssb.setSpan(RelativeSizeSpan(0.80f), tStart, ssb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                ssb.setSpan(ForegroundColorSpan(Color.parseColor("#666666")), tStart, ssb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                holder.tvLyricLine.text = ssb
            } else {
                holder.tvLyricLine.text = item.text
            }
        } else {
            // ACTIVE LINE
            holder.itemView.alpha = 1.0f
            holder.tvLyricLine.textSize = 17.5f
            holder.tvLyricLine.setTypeface(null, Typeface.BOLD)

            if (!isWordSyncEnabled || item.words.isEmpty()) {
                if (!item.translationText.isNullOrBlank() && PlayerHolder.isDualLanguageLyricsEnabled) {
                    val ssb = SpannableStringBuilder(item.text)
                    ssb.append("\n")
                    val tStart = ssb.length
                    ssb.append(item.translationText)
                    ssb.setSpan(RelativeSizeSpan(0.80f), tStart, ssb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    ssb.setSpan(ForegroundColorSpan(Color.parseColor("#CCCCCC")), tStart, ssb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    holder.tvLyricLine.text = ssb
                } else {
                    holder.tvLyricLine.text = item.text
                }
                holder.tvLyricLine.setTextColor(activeColor)
            } else {
                // REAL-TIME WORD-BY-WORD KARAOKE HIGHLIGHT
                val ssb = SpannableStringBuilder()
                val currentMs = currentPlaybackMs
                val sungColor = activeColor
                val activeWordColor = Color.WHITE
                val upcomingColor = Color.parseColor("#77FFFFFF")

                for ((wIdx, w) in item.words.withIndex()) {
                    val wordStart = ssb.length
                    ssb.append(w.word)
                    val wordEnd = ssb.length

                    when {
                        currentMs >= w.endMs -> {
                            ssb.setSpan(ForegroundColorSpan(sungColor), wordStart, wordEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                        currentMs in w.startMs..w.endMs -> {
                            ssb.setSpan(ForegroundColorSpan(activeWordColor), wordStart, wordEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                            ssb.setSpan(RelativeSizeSpan(1.15f), wordStart, wordEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                        else -> {
                            ssb.setSpan(ForegroundColorSpan(upcomingColor), wordStart, wordEnd, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }
                    }

                    if (wIdx < item.words.size - 1) {
                        ssb.append(" ")
                    }
                }

                if (!item.translationText.isNullOrBlank() && PlayerHolder.isDualLanguageLyricsEnabled) {
                    ssb.append("\n")
                    val tStart = ssb.length
                    ssb.append(item.translationText)
                    ssb.setSpan(RelativeSizeSpan(0.80f), tStart, ssb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    ssb.setSpan(ForegroundColorSpan(Color.parseColor("#CCCCCC")), tStart, ssb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }

                holder.tvLyricLine.text = ssb
            }
        }

        holder.itemView.setOnClickListener {
            onLineClick(item.timestampMs)
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateLyrics(newItems: List<LyricsLine>) {
        items = newItems
        activeIndex = -1
        activeWordIndex = -1
        notifyDataSetChanged()
    }

    fun updatePlaybackPosition(posMs: Long): Int {
        currentPlaybackMs = posMs
        if (items.isEmpty()) return -1
        var newIdx = -1
        for (i in items.indices) {
            if (posMs >= items[i].timestampMs) {
                newIdx = i
            } else {
                break
            }
        }
        if (newIdx != activeIndex && newIdx in items.indices) {
            val oldIdx = activeIndex
            activeIndex = newIdx
            activeWordIndex = -1
            if (oldIdx in items.indices) notifyItemChanged(oldIdx)
            notifyItemChanged(newIdx)
            return newIdx
        } else if (isWordSyncEnabled && activeIndex in items.indices) {
            val activeLine = items[activeIndex]
            val curWordIdx = activeLine.words.indexOfFirst { posMs in it.startMs..it.endMs }
            if (curWordIdx != activeWordIndex) {
                activeWordIndex = curWordIdx
                notifyItemChanged(activeIndex)
            }
        }
        return -1
    }
}
/**
 * 100% Offline Semantic & Vibe Search Engine.
 * Supports natural language vibe queries ("slow romantic", "party bass", "lofi chill", "gym workout")
 * and lyric fragments matching across the local library.
 */
object SemanticVibeSearchEngine {
    fun filterByVibeOrLyrics(query: String, allItems: List<MediaItem>): List<MediaItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return allItems

        val vibeKeywords = mapOf(
            "sad" to listOf("broken", "cry", "tears", "alone", "sad", "pain", "dark", "heart", "slowed"),
            "romantic" to listOf("love", "dil", "pyar", "ishq", "heart", "mohabbat", "humsafar", "romantic", "sansein"),
            "party" to listOf("dance", "club", "party", "bass", "dj", "remix", "beat", "nach", "dhol"),
            "chill" to listOf("relax", "lofi", "slow", "peace", "calm", "night", "breeze", "soft", "ambient"),
            "workout" to listOf("pump", "energy", "gym", "power", "hard", "rock", "fight", "beast", "motivational")
        )

        val matchingVibes = mutableListOf<String>()
        for ((vibe, keywords) in vibeKeywords) {
            if (q.contains(vibe) || keywords.any { q.contains(it) }) {
                matchingVibes.addAll(keywords)
            }
        }

        return allItems.filter { item ->
            val title = (item.title ?: "").lowercase()
            val artist = (item.artist ?: "").lowercase()
            val album = ""

            if (title.contains(q) || artist.contains(q) ) return@filter true

            if (matchingVibes.isNotEmpty() && matchingVibes.any { title.contains(it)  }) {
                return@filter true
            }

            false
        }
    }
}

/**
 * Smart Mood & Energy Clustering Engine for dynamic automated playlists.
 */
object SmartMoodClusterEngine {
    fun getMoodCluster(title: String, durationMs: Long): String {
        val t = title.lowercase()
        return when {
            t.contains("remix") || t.contains("dj") || t.contains("party") || t.contains("bass") -> "Party & Upbeat"
            t.contains("acoustic") || t.contains("unplugged") || t.contains("piano") || t.contains("lofi") -> "Acoustic & Chill"
            t.contains("sad") || t.contains("slowed") || t.contains("alone") || durationMs > 300_000L -> "Late Night Melancholy"
            else -> "Daily Energetic Mix"
        }
    }
}
