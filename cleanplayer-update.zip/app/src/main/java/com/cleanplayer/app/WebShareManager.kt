package com.cleanplayer.app

import androidx.core.app.NotificationCompat
import android.os.PowerManager
import android.os.IBinder
import android.content.pm.ServiceInfo
import android.app.Service
import android.app.PendingIntent
import android.app.NotificationManager
import android.app.NotificationChannel

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.File
import java.io.RandomAccessFile
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Production-Ready High-Speed Universal WebShare Engine for CleanPlayer.
 *
 * Implements:
 * 1. Strict State Machine (IDLE -> STARTING_HOTSPOT -> HOTSPOT_READY -> STARTING_SERVER -> SERVER_READY -> RUNNING -> STOPPING).
 * 2. Zero-Race Hotspot Startup: Waits for genuine Android LocalOnlyHotspot callback without short-timeout fallback.
 * 3. Session Identification Guard: In-flight or delayed callbacks from prior sessions are dropped.
 * 4. Deterministic Hotspot IPv4 Gateway Resolution (rejecting cellular, VPN, loopback, link-local, IPv6).
 * 5. Server Socket Readiness Verification before publishing WebShare URL or QR code.
 * 6. WebShare URL QR Payload Protection: Strictly preserves "http://<ip>:<port>" architecture.
 * 7. Path Traversal & Unicode Download Hardening (RFC 5987 / RFC 6266).
 */
object WebShareManager {

    enum class WebShareState {
        IDLE,
        STARTING_HOTSPOT,
        HOTSPOT_READY,
        STARTING_SERVER,
        SERVER_READY,
        RUNNING,
        STOPPING,
        ERROR
    }

    /**
     * Authoritative Single Source of Truth for WebShare session state.
     * Synchronizes UI, QR generator, Copy URL, Browser Launch, and HTTP Server.
     */
    data class WebShareSession(
        val sessionId: Long = 0L,
        val ssid: String = "",
        val password: String = "",
        val hotspotIp: String = "",
        val serverHost: String = "",
        val serverPort: Int = 0,
        val serverUrl: String = "",
        val isRunning: Boolean = false,
        val isReady: Boolean = false
    )

    @Volatile
    var currentSession: WebShareSession = WebShareSession()
        private set

    @Volatile
    var currentState: WebShareState = WebShareState.IDLE
        private set

    private val sessionCounter = AtomicLong(0L)
    @Volatile
    var activeSessionId: Long = 0L
        private set

    var onStateChanged: ((state: WebShareState, errorMsg: String?) -> Unit)? = null

    private var serverSocket: ServerSocket? = null
    private val executor = Executors.newFixedThreadPool(6)
    val isRunning = AtomicBoolean(false)
    var sharedFiles: List<File> = emptyList()

    // Backward-compatible accessors bound to currentSession
    val currentPort: Int get() = currentSession.serverPort
    val currentServerUrl: String get() = currentSession.serverUrl
    val currentHotspotSsid: String get() = currentSession.ssid
    val currentHotspotPassword: String get() = currentSession.password

    private var localHotspotReservation: WifiManager.LocalOnlyHotspotReservation? = null

    // Callback with (fileName, percent, speedMb, transferredBytes, totalBytes)
    var onFileDownloadProgress: ((fileName: String, progressPercent: Int, speedMb: Float, transferredBytes: Long, totalBytes: Long) -> Unit)? = null
    var onFileDownloadCompleted: ((fileName: String) -> Unit)? = null

    fun startWebShare(
        context: Context,
        filePaths: List<String>,
        onStarted: (url: String, ssid: String, password: String) -> Unit,
        onError: ((errorMsg: String) -> Unit)? = null
    ) {
        val validFiles = filePaths.map { File(it) }.filter { it.exists() && it.isFile }
        if (validFiles.isEmpty()) {
            onError?.invoke("No valid files selected for WebShare")
            return
        }

        // Duplicate start protection: if already running with same files, notify immediately
        if (currentState == WebShareState.RUNNING && currentSession.isReady &&
            sharedFiles.map { it.absolutePath } == validFiles.map { it.absolutePath }) {
            onStarted(currentSession.serverUrl, currentSession.ssid, currentSession.password)
            return
        }

        // Clean shutdown of any previous session
        stopWebShare(context)

        sharedFiles = validFiles

        val currentSessionId = sessionCounter.incrementAndGet()
        activeSessionId = currentSessionId
        currentState = WebShareState.STARTING_HOTSPOT
        notifyState(WebShareState.STARTING_HOTSPOT, null)

        // 1. Start WebShareService for background wake-lock and Wi-Fi protection
        try {
            val serviceIntent = Intent(context, WebShareService::class.java).apply {
                action = WebShareService.ACTION_START_WEBSHARE
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

        val startHttpServerAndNotify = { ip: String, ssid: String, pwd: String, sessId: Long ->
            if (activeSessionId == sessId) {
                executor.execute {
                    try {
                        val candidatePorts = listOf(8080, 8081, 8888, 8990, 9090)
                        var ss: ServerSocket? = null
                        for (p in candidatePorts) {
                            try {
                                ss = ServerSocket(p).apply {
                                    reuseAddress = true
                                    receiveBufferSize = 2 * 1024 * 1024
                                }
                                break
                            } catch (e: Exception) {}
                        }
                        if (ss == null) {
                            // Dynamically bind to any free ephemeral port
                            ss = ServerSocket(0).apply {
                                reuseAddress = true
                                receiveBufferSize = 2 * 1024 * 1024
                            }
                        }

                        val actualBoundPort = ss.localPort
                        serverSocket = ss
                        isRunning.set(true)

                        // 2. Perform Server Readiness Verification before publishing URL/QR
                        var serverReady = false
                        try {
                            if (ss.isBound && !ss.isClosed) {
                                val testSocket = Socket()
                                testSocket.connect(InetSocketAddress("127.0.0.1", actualBoundPort), 500)
                                testSocket.close()
                                serverReady = true
                            }
                        } catch (e: Exception) {
                            serverReady = (ss.isBound && !ss.isClosed)
                        }

                        if (!serverReady) {
                            throw IllegalStateException("Server socket failed to verify readiness on port $actualBoundPort")
                        }

                        // Stale callback protection
                        if (activeSessionId != sessId) {
                            try { ss.close() } catch (e: Exception) {}
                            return@execute
                        }

                        val finalUrl = "http://$ip:$actualBoundPort"

                        // Single Source of Truth update
                        currentSession = WebShareSession(
                            sessionId = sessId,
                            ssid = ssid,
                            password = pwd,
                            hotspotIp = ip,
                            serverHost = ip,
                            serverPort = actualBoundPort,
                            serverUrl = finalUrl,
                            isRunning = true,
                            isReady = true
                        )

                        currentState = WebShareState.RUNNING
                        Handler(Looper.getMainLooper()).post {
                            notifyState(WebShareState.RUNNING, null)
                            onStarted(finalUrl, ssid, pwd)
                        }

                        // HTTP Request Processing Loop
                        while (isRunning.get() && !ss.isClosed && activeSessionId == sessId) {
                            try {
                                val client = ss.accept().apply {
                                    tcpNoDelay = true
                                    sendBufferSize = 4 * 1024 * 1024
                                    receiveBufferSize = 4 * 1024 * 1024
                                }
                                executor.execute {
                                    handleHttpClient(context, client)
                                }
                            } catch (e: Exception) {
                                break
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        if (activeSessionId == sessId) {
                            isRunning.set(false)
                            currentState = WebShareState.ERROR
                            currentSession = currentSession.copy(isRunning = false, isReady = false)
                            val errMsg = e.message ?: "Server bind failure"
                            Handler(Looper.getMainLooper()).post {
                                notifyState(WebShareState.ERROR, errMsg)
                                onError?.invoke(errMsg)
                            }
                        }
                    }
                }
            }
        }

        // Check if device is connected to an actual external Wi-Fi router (LAN)
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNet = cm?.activeNetwork
        val caps = cm?.getNetworkCapabilities(activeNet)
        val isConnectedToRealWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

        if (isConnectedToRealWifi) {
            val currentIp = getHotspotOrWifiIpAddress(context)
            if (currentIp != "127.0.0.1" && !currentIp.startsWith("192.168.49.") && !currentIp.startsWith("10.") && !currentIp.startsWith("100.")) {
                currentState = WebShareState.HOTSPOT_READY
                notifyState(WebShareState.HOTSPOT_READY, null)
                currentState = WebShareState.STARTING_SERVER
                notifyState(WebShareState.STARTING_SERVER, null)
                startHttpServerAndNotify(currentIp, "", "", currentSessionId)
                return
            }
        }

        // Start LocalOnlyHotspot on Android 8.0+
        // Zero-Race: No short watchdog timeout fallback. We wait for genuine Android callback.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && wifiManager != null) {
            try {
                wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                    override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                        super.onStarted(reservation)
                        // Stale callback guard: Drop if session was cancelled or restarted
                        if (activeSessionId != currentSessionId) {
                            try { reservation?.close() } catch (e: Exception) {}
                            return
                        }

                        localHotspotReservation = reservation
                        currentState = WebShareState.HOTSPOT_READY
                        notifyState(WebShareState.HOTSPOT_READY, null)

                        var ssid = "CleanPlayer_WebShare_5GHz"
                        var pwd = ""

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            try {
                                val softApConfig = reservation?.softApConfiguration
                                if (softApConfig != null) {
                                    ssid = softApConfig.ssid ?: ssid
                                    pwd = softApConfig.passphrase ?: pwd
                                }
                            } catch (e: Throwable) {}
                        } else {
                            try {
                                @Suppress("DEPRECATION")
                                val config = reservation?.wifiConfiguration
                                @Suppress("DEPRECATION")
                                ssid = config?.SSID ?: ssid
                                @Suppress("DEPRECATION")
                                pwd = config?.preSharedKey ?: pwd
                            } catch (e: Throwable) {}
                        }

                        // Poll newly created hotspot AP interface for its IPv4 address (up to 5s, 200ms intervals)
                        executor.execute {
                            var hotspotIp: String? = null
                            val maxAttempts = 25
                            for (attempt in 0 until maxAttempts) {
                                if (activeSessionId != currentSessionId) return@execute
                                val ip = getHotspotInterfaceIpAddress(context)
                                if (!ip.isNullOrBlank() && ip != "127.0.0.1") {
                                    hotspotIp = ip
                                    break
                                }
                                try { Thread.sleep(200) } catch (e: InterruptedException) { return@execute }
                            }

                            val finalIp = hotspotIp ?: getHotspotOrWifiIpAddress(context)
                            if (activeSessionId != currentSessionId) return@execute

                            currentState = WebShareState.STARTING_SERVER
                            Handler(Looper.getMainLooper()).post {
                                notifyState(WebShareState.STARTING_SERVER, null)
                            }
                            startHttpServerAndNotify(finalIp, ssid, pwd, currentSessionId)
                        }
                    }

                    override fun onFailed(reason: Int) {
                        super.onFailed(reason)
                        if (activeSessionId != currentSessionId) return
                        currentState = WebShareState.ERROR
                        val errorText = when (reason) {
                            1 -> "Hotspot failed: No channel available (ERROR_NO_CHANNEL)"
                            2 -> "Hotspot failed: System error (ERROR_GENERIC)"
                            3 -> "Hotspot failed: Incompatible mode (ERROR_INCOMPATIBLE_MODE)"
                            4 -> "Hotspot failed: Tethering disallowed (ERROR_TETHERING_DISALLOWED)"
                            else -> "Hotspot failed (code $reason)"
                        }
                        Handler(Looper.getMainLooper()).post {
                            notifyState(WebShareState.ERROR, errorText)
                            onError?.invoke(errorText)
                        }
                    }
                }, Handler(Looper.getMainLooper()))
            } catch (e: Throwable) {
                if (activeSessionId == currentSessionId) {
                    currentState = WebShareState.ERROR
                    val errorText = e.localizedMessage ?: "Failed to start hotspot"
                    Handler(Looper.getMainLooper()).post {
                        notifyState(WebShareState.ERROR, errorText)
                        onError?.invoke(errorText)
                    }
                }
            }
        } else {
            // Older Android (pre-Oreo): Start HTTP server on local network IP
            val fallbackIp = getHotspotOrWifiIpAddress(context)
            currentState = WebShareState.HOTSPOT_READY
            currentState = WebShareState.STARTING_SERVER
            startHttpServerAndNotify(fallbackIp, "", "", currentSessionId)
        }
    }

    private fun notifyState(state: WebShareState, errorMsg: String?) {
        currentState = state
        onStateChanged?.invoke(state, errorMsg)
    }

    fun stopWebShare(context: Context? = null) {
        currentState = WebShareState.STOPPING
        activeSessionId = 0L // Immediately invalidates any in-flight or delayed callbacks!
        isRunning.set(false)

        try {
            serverSocket?.close()
        } catch (e: Exception) {}
        serverSocket = null

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                localHotspotReservation?.close()
            }
        } catch (e: Exception) {}
        localHotspotReservation = null

        currentSession = WebShareSession()
        sharedFiles = emptyList()

        if (context != null) {
            try {
                val serviceIntent = Intent(context, WebShareService::class.java).apply {
                    action = WebShareService.ACTION_STOP_WEBSHARE
                }
                context.startService(serviceIntent)
            } catch (e: Exception) {}
        }

        currentState = WebShareState.IDLE
        notifyState(WebShareState.IDLE, null)
    }

    private fun handleHttpClient(context: Context, socket: Socket) {
        try {
            val input = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val output = BufferedOutputStream(socket.getOutputStream(), 256 * 1024)

            val requestLine = input.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) {
                serveBadRequest(output)
                return
            }

            val rawPath = parts[1]

            // Strict Security Guard: Block path traversal attacks (../, %2e%2e, backslash, null bytes)
            if (rawPath.contains("..") || rawPath.contains("%2e%2e", ignoreCase = true) ||
                rawPath.contains("\\") || rawPath.contains("\u0000")) {
                serveBadRequest(output)
                return
            }

            val path = URLDecoder.decode(rawPath, "UTF-8")

            var rangeHeader: String? = null
            while (true) {
                val headerLine = input.readLine() ?: break
                if (headerLine.isBlank()) break
                if (headerLine.startsWith("Range:", ignoreCase = true)) {
                    rangeHeader = headerLine.substringAfter("Range:").trim()
                }
            }

            if (path == "/" || path == "/index.html") {
                serveIndexPage(output)
            } else if (path.startsWith("/download/")) {
                val indexStr = path.substringAfter("/download/").substringBefore("?").substringBefore("/")
                val index = indexStr.toIntOrNull()
                if (index != null && index in sharedFiles.indices) {
                    val file = sharedFiles[index]
                    if (file.exists() && file.isFile) {
                        serveFileDownload(context, file, output, rangeHeader, isAttachment = true)
                    } else {
                        serveNotFound(output)
                    }
                } else {
                    serveNotFound(output)
                }
            } else if (path.startsWith("/stream/")) {
                val indexStr = path.substringAfter("/stream/").substringBefore("?").substringBefore("/")
                val index = indexStr.toIntOrNull()
                if (index != null && index in sharedFiles.indices) {
                    val file = sharedFiles[index]
                    if (file.exists() && file.isFile) {
                        serveFileDownload(context, file, output, rangeHeader, isAttachment = false)
                    } else {
                        serveNotFound(output)
                    }
                } else {
                    serveNotFound(output)
                }
            } else {
                serveNotFound(output)
            }
        } catch (e: Exception) {
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {}
        }
    }

    private fun escapeHtml(text: String): String {
        return text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;")
    }

    private fun serveIndexPage(out: OutputStream) {
        val sb = StringBuilder(8192)
        sb.append("<!DOCTYPE html><html><head><meta charset='UTF-8'>")
        sb.append("<meta name='viewport' content='width=device-width, initial-scale=1.0'>")
        sb.append("<title>CleanPlayer 5GHz Turbo WebShare</title>")
        sb.append("<style>")
        sb.append("body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background: #0E0F12; color: #FFFFFF; margin: 0; padding: 20px; }")
        sb.append(".header { text-align: center; margin-bottom: 24px; padding-top: 10px; }")
        sb.append(".logo { font-size: 26px; font-weight: 800; color: #00E5FF; letter-spacing: -0.5px; }")
        sb.append(".subtitle { color: #888899; font-size: 14px; margin-top: 6px; }")
        sb.append(".card-list { max-width: 600px; margin: 0 auto; display: flex; flex-direction: column; gap: 12px; }")
        sb.append(".card { background: #1A1B22; border: 1px solid #282936; border-radius: 14px; padding: 16px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 4px 16px rgba(0,0,0,0.4); }")
        sb.append(".info { flex: 1; min-width: 0; margin-right: 12px; }")
        sb.append(".name { font-size: 15px; font-weight: 600; color: #FFFFFF; word-break: break-all; margin-bottom: 4px; }")
        sb.append(".meta { font-size: 12px; color: #00E5FF; font-weight: 500; }")
        sb.append(".btn { display: inline-block; background: #00E5FF; color: #000000; padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 700; text-decoration: none; transition: transform 0.1s; }")
        sb.append(".btn:active { transform: scale(0.96); }")
        sb.append(".btn-play { background: #2A2B38; color: #FFFFFF; margin-right: 8px; }")
        sb.append(".footer { text-align: center; margin-top: 36px; font-size: 12px; color: #555566; }")
        sb.append("</style></head><body>")

        sb.append("<div class='header'>")
        sb.append("<div class='logo'>⚡ CleanPlayer 5GHz WebShare</div>")
        sb.append("<div class='subtitle'>High-Speed Direct P2P Browser Download</div>")
        sb.append("</div>")

        sb.append("<div class='card-list'>")
        for ((idx, f) in sharedFiles.withIndex()) {
            val fSize = formatFileSize(f.length())
            val name = f.name
            val escapedName = escapeHtml(name)
            val isMedia = name.endsWith(".mp4", true) || name.endsWith(".mkv", true) || name.endsWith(".mp3", true) || name.endsWith(".m4a", true) || name.endsWith(".wav", true)
            val icon = when {
                name.endsWith(".mp4", true) || name.endsWith(".mkv", true) -> "🎬"
                name.endsWith(".mp3", true) || name.endsWith(".m4a", true) || name.endsWith(".wav", true) -> "🎵"
                name.endsWith(".apk", true) -> "📦"
                name.endsWith(".jpg", true) || name.endsWith(".png", true) || name.endsWith(".webp", true) -> "🖼️"
                else -> "📁"
            }

            sb.append("<div class='card'>")
            sb.append("<div class='info'>")
            sb.append("<div class='name'>").append(icon).append(" ").append(escapedName).append("</div>")
            sb.append("<div class='meta'>").append(fSize).append("</div>")
            sb.append("</div>")
            sb.append("<div>")
            if (isMedia) {
                sb.append("<a href='/stream/").append(idx).append("' class='btn btn-play' target='_blank'>Play</a>")
            }
            sb.append("<a href='/download/").append(idx).append("' class='btn' download='").append(escapedName).append("'>Download</a>")
            sb.append("</div>")
            sb.append("</div>")
        }
        sb.append("</div>")

        sb.append("<div class='footer'>Sent from CleanPlayer High-Speed 5GHz P2P Engine</div>")
        sb.append("</body></html>")

        val bytes = sb.toString().toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n"
        out.write(header.toByteArray(Charsets.US_ASCII))
        out.write(bytes)
        out.flush()
    }

    private fun serveRangeNotSatisfiable(out: OutputStream, fileLength: Long) {
        val resp = "HTTP/1.1 416 Range Not Satisfiable\r\n" +
                "Content-Range: bytes */$fileLength\r\n" +
                "Content-Length: 0\r\n" +
                "Connection: close\r\n\r\n"
        out.write(resp.toByteArray(Charsets.US_ASCII))
        out.flush()
    }

    private fun serveFileDownload(context: Context, file: File, out: OutputStream, rangeHeader: String?, isAttachment: Boolean = true) {
        val fileLength = file.length()
        var start: Long = 0
        var end: Long = maxOf(0L, fileLength - 1)
        var isPartial = false

        if (!rangeHeader.isNullOrBlank() && rangeHeader.startsWith("bytes=")) {
            val range = rangeHeader.substringAfter("bytes=").trim()
            val dashIdx = range.indexOf('-')
            if (dashIdx != -1) {
                val sStr = range.substring(0, dashIdx).trim()
                val eStr = range.substring(dashIdx + 1).trim()
                if (sStr.isEmpty() && eStr.isNotEmpty()) {
                    // Suffix range: bytes=-N (last N bytes of file)
                    val suffixLen = eStr.toLongOrNull()
                    if (suffixLen != null && suffixLen > 0L) {
                        start = maxOf(0L, fileLength - suffixLen)
                        end = maxOf(0L, fileLength - 1)
                        isPartial = true
                    } else {
                        serveRangeNotSatisfiable(out, fileLength)
                        return
                    }
                } else if (sStr.isNotEmpty() && eStr.isEmpty()) {
                    // Open range: bytes=N-
                    val sVal = sStr.toLongOrNull()
                    if (sVal != null && sVal in 0 until fileLength) {
                        start = sVal
                        end = maxOf(0L, fileLength - 1)
                        isPartial = true
                    } else {
                        serveRangeNotSatisfiable(out, fileLength)
                        return
                    }
                } else if (sStr.isNotEmpty() && eStr.isNotEmpty()) {
                    // Closed range: bytes=N-M
                    val sVal = sStr.toLongOrNull()
                    val eVal = eStr.toLongOrNull()
                    if (sVal != null && eVal != null && sVal in 0 until fileLength && sVal <= eVal) {
                        start = sVal
                        end = minOf(eVal, fileLength - 1)
                        isPartial = true
                    } else {
                        serveRangeNotSatisfiable(out, fileLength)
                        return
                    }
                }
            }
        }

        val contentLength = if (fileLength == 0L) 0L else (end - start + 1)

        // RFC 5987 / RFC 6266 compliant Content-Disposition for Unicode, spaces, and quotes
        val safeAsciiName = file.name.replace("\"", "\\\"").replace("\r", "").replace("\n", "")
        val utf8EncodedName = URLEncoder.encode(file.name, "UTF-8").replace("+", "%20")
        val disposition = if (isAttachment) {
            "attachment; filename=\"$safeAsciiName\"; filename*=UTF-8''$utf8EncodedName"
        } else {
            "inline; filename=\"$safeAsciiName\"; filename*=UTF-8''$utf8EncodedName"
        }

        val statusLine = if (isPartial) "HTTP/1.1 206 Partial Content\r\n" else "HTTP/1.1 200 OK\r\n"

        val headers = statusLine +
                "Content-Type: ${getMimeType(file.name)}\r\n" +
                "Content-Length: $contentLength\r\n" +
                "Content-Disposition: $disposition\r\n" +
                "Accept-Ranges: bytes\r\n" +
                (if (isPartial) "Content-Range: bytes $start-$end/$fileLength\r\n" else "") +
                "Connection: close\r\n\r\n"

        out.write(headers.toByteArray(Charsets.US_ASCII))
        out.flush()

        val raf = RandomAccessFile(file, "r")
        val channel = raf.channel
        if (start > 0) {
            channel.position(start)
        }

        // 1024 KB Direct Turbo Buffer for 40-80+ MB/s Maximum Throughput
        val buffer = ByteArray(1024 * 1024)
        var remaining = contentLength
        var totalSent = 0L
        var lastTime = System.currentTimeMillis()
        var bytesSinceLast = 0L

        try {
            while (remaining > 0 && isRunning.get()) {
                val toRead = minOf(buffer.size.toLong(), remaining).toInt()
                val read = raf.read(buffer, 0, toRead)
                if (read == -1) break
                out.write(buffer, 0, read)
                remaining -= read
                totalSent += read
                bytesSinceLast += read

                val now = System.currentTimeMillis()
                val delta = now - lastTime

                // Smooth 350ms UI Throttling: prevents UI thread freezing on multi-gigabyte transfers
                if (delta >= 350 || remaining <= 0L) {
                    out.flush()
                    val speedMb = (bytesSinceLast.toFloat() / (1024f * 1024f)) / (delta.toFloat() / 1000f)
                    val percent = if (fileLength > 0) (((start + totalSent).toFloat() / fileLength.toFloat()) * 100).toInt() else 0

                    onFileDownloadProgress?.invoke(file.name, percent, speedMb, start + totalSent, fileLength)
                    WebShareService.updateProgressNotification(file.name, percent, speedMb)

                    lastTime = now
                    bytesSinceLast = 0L
                }
            }
            out.flush()
        } finally {
            try { channel.close() } catch (e: Exception) {}
            try { raf.close() } catch (e: Exception) {}
        }

        if (start + totalSent >= fileLength) {
            onFileDownloadCompleted?.invoke(file.name)
        }
    }

    private fun serveNotFound(out: OutputStream) {
        val resp = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: 9\r\nConnection: close\r\n\r\nNot Found"
        out.write(resp.toByteArray(Charsets.US_ASCII))
        out.flush()
    }

    private fun serveBadRequest(out: OutputStream) {
        val resp = "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain\r\nContent-Length: 11\r\nConnection: close\r\n\r\nBad Request"
        out.write(resp.toByteArray(Charsets.US_ASCII))
        out.flush()
    }

    /**
     * Determines IPv4 address specifically assigned to the newly created LocalOnlyHotspot interface (ap0, ap1, swlan0, softap0).
     */
    fun getHotspotInterfaceIpAddress(context: Context): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: return null
            val apIntfs = interfaces.filter {
                val n = it.name.lowercase()
                !isCellularOrVpn(n) && (n.startsWith("ap") || n.startsWith("swlan") || n.contains("hotspot") || n.contains("softap")) && it.isUp
            }
            for (ap in apIntfs) {
                for (addr in ap.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && !addr.isLinkLocalAddress) {
                        val host = addr.hostAddress
                        if (!host.isNullOrBlank() && !host.startsWith("127.") && !host.startsWith("169.254.")) {
                            return host
                        }
                    }
                }
            }
        } catch (e: Exception) {}
        return null
    }

    /**
     * Deterministic, secure IP address selection that completely filters out:
     * - Cellular/Mobile data interfaces (rmnet, ccmni, pdp, radio, etc.)
     * - VPN and virtual interfaces (tun, tap, ppp, ipsec, wg, etc.)
     * - Loopback (127.x) and link-local (169.254.x)
     * - IPv6 addresses
     */
    fun getHotspotOrWifiIpAddress(context: Context): String {
        // Priority 1: Direct active AP hotspot interface
        val apIp = getHotspotInterfaceIpAddress(context)
        if (!apIp.isNullOrBlank()) return apIp

        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: emptyList()

            // Priority 2: Active Wi-Fi interface (wlan0, wlan1) for LAN hosting
            val wlanIntfs = interfaces.filter {
                val n = it.name.lowercase()
                !isCellularOrVpn(n) && n.contains("wlan") && it.isUp
            }
            for (wlan in wlanIntfs) {
                for (addr in wlan.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && !addr.isLinkLocalAddress) {
                        val host = addr.hostAddress
                        if (!host.isNullOrBlank() && !host.startsWith("127.") && !host.startsWith("169.254.")) {
                            return host
                        }
                    }
                }
            }

            // Priority 3: Fallback to any active non-loopback, non-cellular, non-VPN private IPv4
            for (intf in interfaces) {
                if (intf.isUp && !isCellularOrVpn(intf.name)) {
                    for (addr in intf.inetAddresses) {
                        if (addr is Inet4Address && !addr.isLoopbackAddress && !addr.isLinkLocalAddress) {
                            val host = addr.hostAddress
                            if (!host.isNullOrBlank() && !host.startsWith("127.") && !host.startsWith("169.254.") && !host.startsWith("100.")) {
                                return host
                            }
                        }
                    }
                }
            }

            // Priority 4: Wi-Fi Manager connection info check
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val ipInt = wm?.connectionInfo?.ipAddress ?: 0
            if (ipInt != 0) {
                val ipStr = String.format(
                    "%d.%d.%d.%d",
                    ipInt and 0xff,
                    (ipInt shr 8) and 0xff,
                    (ipInt shr 16) and 0xff,
                    (ipInt shr 24) and 0xff
                )
                if (ipStr != "0.0.0.0") return ipStr
            }
        } catch (e: Exception) {}
        return "192.168.43.1" // Modern Android standard hotspot gateway IP
    }

    fun isCellularOrVpn(name: String): Boolean {
        val n = name.lowercase()
        return n.startsWith("rmnet") || n.startsWith("ccmni") ||
               n.startsWith("pdp") || n.startsWith("tun") ||
               n.startsWith("tap") || n.startsWith("ppp") ||
               n.startsWith("ipsec") || n.startsWith("wg") ||
               n.startsWith("dummy") || n.startsWith("radio") ||
               n.startsWith("sit") || n.startsWith("ip_vti") ||
               n.startsWith("v4-") || n.startsWith("usb") ||
               n.startsWith("clat")
    }

    private fun getMimeType(fileName: String): String {
        return when {
            fileName.endsWith(".mp4", true) -> "video/mp4"
            fileName.endsWith(".mkv", true) -> "video/x-matroska"
            fileName.endsWith(".mp3", true) -> "audio/mpeg"
            fileName.endsWith(".m4a", true) -> "audio/mp4"
            fileName.endsWith(".wav", true) -> "audio/wav"
            fileName.endsWith(".jpg", true) || fileName.endsWith(".jpeg", true) -> "image/jpeg"
            fileName.endsWith(".png", true) -> "image/png"
            fileName.endsWith(".apk", true) -> "application/vnd.android.package-archive"
            fileName.endsWith(".pdf", true) -> "application/pdf"
            fileName.endsWith(".zip", true) -> "application/zip"
            else -> "application/octet-stream"
        }
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val mb = bytes / (1024f * 1024f)
        return if (mb >= 1024) String.format("%.2f GB", mb / 1024f) else String.format("%.1f MB", mb)
    }
}

/**
 * Foreground Service for Universal WebShare to guarantee uninterrupted background transfers,
 * zero Wi-Fi throttling, and maximum 5GHz throughput with high-power WakeLock and WifiLock.
 */
class WebShareService : Service() {

    companion object {
        const val CHANNEL_ID = "cleanplayer_webshare_channel"
        const val NOTIFICATION_ID = 203
        const val ACTION_START_WEBSHARE = "com.cleanplayer.app.ACTION_START_WEBSHARE"
        const val ACTION_STOP_WEBSHARE = "com.cleanplayer.app.ACTION_STOP_WEBSHARE"

        private var instance: WebShareService? = null

        fun updateProgressNotification(fileName: String, percent: Int, speedMb: Float) {
            instance?.updateNotificationSpeed(fileName, percent, speedMb)
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
        startForegroundNotification("🌐 Universal WebShare Active", "Hosting high-speed local browser transfer...")
        acquireHighPowerLocks()
    }

    private fun acquireHighPowerLocks() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CleanPlayer:WebShareWakeLock")?.apply {
                setReferenceCounted(false)
                acquire(120 * 60 * 1000L)
            }
        } catch (e: Throwable) {}

        try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock = wifiManager?.createWifiLock(lockMode, "CleanPlayer:WebShareWifi")?.apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Throwable) {}
    }

    private fun releaseHighPowerLocks() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (e: Throwable) {}
        wakeLock = null

        try {
            if (wifiLock?.isHeld == true) wifiLock?.release()
        } catch (e: Throwable) {}
        wifiLock = null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_WEBSHARE -> {
                startForegroundNotification("🌐 Universal WebShare Active", "Hosting high-speed local browser transfer...")
            }
            ACTION_STOP_WEBSHARE -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Universal WebShare Server",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps high-speed WebShare server active in background"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun startForegroundNotification(title: String, content: String) {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("OPEN_TAB", "SHARE")
        }
        val pendingOpen = PendingIntent.getActivity(this, 21, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val stopIntent = Intent(this, WebShareService::class.java).apply { action = ACTION_STOP_WEBSHARE }
        val pendingStop = PendingIntent.getService(this, 20, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_share_transfer)
            .setContentTitle(title)
            .setContentText(content)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(R.drawable.ic_close, "Stop", pendingStop)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun updateNotificationSpeed(fileName: String, percent: Int, speedMb: Float) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("OPEN_TAB", "SHARE")
        }
        val pendingOpen = PendingIntent.getActivity(this, 21, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val stopIntent = Intent(this, WebShareService::class.java).apply { action = ACTION_STOP_WEBSHARE }
        val pendingStop = PendingIntent.getService(this, 20, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_share_transfer)
            .setContentTitle("🌐 WebShare: " + fileName + " (" + percent + "%)")
            .setContentText(String.format("%.1f", speedMb) + " MB/s • High-Speed 5GHz Transfer")
            .setProgress(100, percent, false)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_close, "Stop", pendingStop)
            .build()

        try {
            manager.notify(NOTIFICATION_ID, notification)
        } catch (e: Throwable) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseHighPowerLocks()
        instance = null
    }
}
