package com.cleanplayer.app

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

object WebShareManager {

    private var serverSocket: ServerSocket? = null
    private val executor = Executors.newFixedThreadPool(4)
    val isRunning = AtomicBoolean(false)
    private var sharedFiles: List<File> = emptyList()
    var currentPort: Int = 8080
    var currentServerUrl: String = ""

    var onFileDownloadProgress: ((fileName: String, progressPercent: Int, speedMb: Float) -> Unit)? = null
    var onFileDownloadCompleted: ((fileName: String) -> Unit)? = null

    fun startWebShare(context: Context, filePaths: List<String>, onStarted: (url: String) -> Unit) {
        stopWebShare()

        sharedFiles = filePaths.map { File(it) }.filter { it.exists() }
        if (sharedFiles.isEmpty()) return

        executor.execute {
            try {
                val candidatePorts = listOf(8080, 8081, 8888, 8990, 9090)
                var ss: ServerSocket? = null
                for (p in candidatePorts) {
                    try {
                        ss = ServerSocket(p)
                        currentPort = p
                        break
                    } catch (e: Exception) {}
                }
                if (ss == null) {
                    ss = ServerSocket(0)
                    currentPort = ss.localPort
                }
                serverSocket = ss
                isRunning.set(true)

                val ip = getDeviceIpAddress(context)
                currentServerUrl = "http://$ip:$currentPort"

                Handler(Looper.getMainLooper()).post {
                    onStarted(currentServerUrl)
                }

                while (isRunning.get() && !ss.isClosed) {
                    try {
                        val client = ss.accept()
                        executor.execute {
                            handleHttpClient(context, client)
                        }
                    } catch (e: Exception) {
                        break
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isRunning.set(false)
            }
        }
    }

    fun stopWebShare() {
        isRunning.set(false)
        try {
            serverSocket?.close()
        } catch (e: Exception) {}
        serverSocket = null
        sharedFiles = emptyList()
    }

    private fun handleHttpClient(context: Context, socket: Socket) {
        try {
            val input = BufferedReader(InputStreamReader(socket.getInputStream()))
            val output = BufferedOutputStream(socket.getOutputStream())

            val requestLine = input.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val rawPath = parts[1]
            val path = URLDecoder.decode(rawPath, "UTF-8")

            var headerLine: String?
            var rangeHeader: String? = null
            while (input.readLine().also { headerLine = it } != null) {
                if (headerLine.isNullOrBlank()) break
                if (headerLine!!.startsWith("Range:", ignoreCase = true)) {
                    rangeHeader = headerLine!!.substringAfter("Range:").trim()
                }
            }

            if (path == "/" || path == "/index.html") {
                serveIndexPage(output)
            } else if (path.startsWith("/download/")) {
                val indexStr = path.substringAfter("/download/").substringBefore("?").substringBefore("/")
                val index = indexStr.toIntOrNull() ?: 0
                if (index in sharedFiles.indices) {
                    serveFileDownload(sharedFiles[index], output, rangeHeader, isAttachment = true)
                } else {
                    serveNotFound(output)
                }
            } else if (path.startsWith("/stream/")) {
                val indexStr = path.substringAfter("/stream/").substringBefore("?").substringBefore("/")
                val index = indexStr.toIntOrNull() ?: 0
                if (index in sharedFiles.indices) {
                    serveFileDownload(sharedFiles[index], output, rangeHeader, isAttachment = false)
                } else {
                    serveNotFound(output)
                }
            } else {
                serveNotFound(output)
            }
        } catch (e: Exception) {
        } finally {
            try {
                socket.close()
            } catch (e: Exception) {}
        }
    }

    private fun serveIndexPage(out: OutputStream) {
        val totalBytes = sharedFiles.sumOf { it.length() }
        val totalMb = String.format("%.1f MB", totalBytes / (1024f * 1024f))

        val sb = StringBuilder()
        sb.append("<!DOCTYPE html><html lang='en'><head>")
        sb.append("<meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0'>")
        sb.append("<title>CleanPlayer WebShare</title>")
        sb.append("<style>")
        sb.append("body { background: #0E0F12; color: #FFFFFF; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 16px; }")
        sb.append(".header { text-align: center; padding: 24px 0 16px; }")
        sb.append(".logo { font-size: 24px; font-weight: 800; color: #00E5FF; letter-spacing: -0.5px; }")
        sb.append(".sub { color: #888899; font-size: 13px; margin-top: 6px; }")
        sb.append(".badge { display: inline-block; background: #1F2128; border: 1px solid #2F323D; border-radius: 12px; padding: 6px 14px; font-size: 12px; font-weight: 600; color: #00E5FF; margin-top: 10px; }")
        sb.append(".card-list { max-width: 600px; margin: 16px auto; }")
        sb.append(".card { background: #16171E; border: 1px solid #232530; border-radius: 14px; padding: 16px; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between; }")
        sb.append(".info { flex: 1; margin-right: 12px; min-width: 0; }")
        sb.append(".name { font-size: 14px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: #FFFFFF; }")
        sb.append(".meta { font-size: 12px; color: #888899; margin-top: 4px; }")
        sb.append(".btn { background: #00E5FF; color: #000000; padding: 10px 18px; border-radius: 20px; font-weight: 700; font-size: 13px; text-decoration: none; display: inline-block; border: none; cursor: pointer; }")
        sb.append(".btn:hover { background: #33EBFF; }")
        sb.append(".btn-play { background: #272727; color: #FFFFFF; margin-right: 8px; border: 1px solid #3A3A3A; }")
        sb.append(".footer { text-align: center; color: #555566; font-size: 11px; margin-top: 30px; }")
        sb.append("</style></head><body>")

        sb.append("<div class='header'>")
        sb.append("<div class='logo'>⚡ CleanPlayer WebShare</div>")
        sb.append("<div class='sub'>High-Speed Wi-Fi Offline Transfer • Direct to Browser</div>")
        sb.append("<div class='badge'>").append(sharedFiles.size).append(" Files Available • ").append(totalMb).append("</div>")
        sb.append("</div>")

        sb.append("<div class='card-list'>")
        for ((idx, f) in sharedFiles.withIndex()) {
            val fSize = formatFileSize(f.length())
            val name = f.name
            val isMedia = name.endsWith(".mp4", true) || name.endsWith(".mkv", true) || name.endsWith(".mp3", true) || name.endsWith(".m4a", true) || name.endsWith(".wav", true)
            val icon = when {
                name.endsWith(".mp4", true) || name.endsWith(".mkv", true) -> "🎬"
                name.endsWith(".mp3", true) || name.endsWith(".m4a", true) || name.endsWith(".wav", true) -> "🎵"
                name.endsWith(".apk", true) -> "📦"
                name.endsWith(".jpg", true) || name.endsWith(".png", true) || name.endsWith(".webp", true) -> "🖼️"
                else -> "📁"
            }

            sb.append("<div class='card'>")
            sb.append("<div class='info'>")
            sb.append("<div class='name'>").append(icon).append(" ").append(name).append("</div>")
            sb.append("<div class='meta'>").append(fSize).append("</div>")
            sb.append("</div>")
            sb.append("<div>")
            if (isMedia) {
                sb.append("<a href='/stream/").append(idx).append("' class='btn btn-play' target='_blank'>Play</a>")
            }
            sb.append("<a href='/download/").append(idx).append("' class='btn' download='").append(name).append("'>Download</a>")
            sb.append("</div>")
            sb.append("</div>")
        }
        sb.append("</div>")

        sb.append("<div class='footer'>Sent from CleanPlayer High-Speed P2P Engine</div>")
        sb.append("</body></html>")

        val bytes = sb.toString().toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${bytes.size}\r\n" +
                "Connection: close\r\n\r\n"
        out.write(header.toByteArray(Charsets.US_ASCII))
        out.write(bytes)
        out.flush()
    }

    private fun serveFileDownload(file: File, out: OutputStream, rangeHeader: String?, isAttachment: Boolean = true) {
        val fileLength = file.length()
        var start: Long = 0
        var end: Long = fileLength - 1

        if (!rangeHeader.isNullOrBlank() && rangeHeader.startsWith("bytes=")) {
            val range = rangeHeader.substringAfter("bytes=").trim()
            val dashIdx = range.indexOf('-')
            if (dashIdx != -1) {
                val sStr = range.substring(0, dashIdx).trim()
                val eStr = range.substring(dashIdx + 1).trim()
                if (sStr.isNotEmpty()) start = sStr.toLongOrNull() ?: 0L
                if (eStr.isNotEmpty()) end = eStr.toLongOrNull() ?: (fileLength - 1)
            }
        }

        val contentLength = end - start + 1
        val isPartial = start > 0 || end < (fileLength - 1)

        val disposition = if (isAttachment) "attachment; filename=\"${file.name}\"" else "inline"
        val statusLine = if (isPartial) "HTTP/1.1 206 Partial Content\r\n" else "HTTP/1.1 200 OK\r\n"

        val headers = statusLine +
                "Content-Type: ${getMimeType(file.name)}\r\n" +
                "Content-Length: $contentLength\r\n" +
                "Content-Disposition: $disposition\r\n" +
                "Accept-Ranges: bytes\r\n" +
                (if (isPartial) "Content-Range: bytes $start-$end/$fileLength\r\n" else "") +
                "Connection: close\r\n\r\n"

        out.write(headers.toByteArray(Charsets.US_ASCII))
        out.flush()

        val fis = FileInputStream(file)
        if (start > 0) {
            fis.skip(start)
        }

        val buffer = ByteArray(64 * 1024)
        var remaining = contentLength
        var totalSent = 0L
        val startTime = System.currentTimeMillis()

        while (remaining > 0) {
            val toRead = minOf(buffer.size.toLong(), remaining).toInt()
            val read = fis.read(buffer, 0, toRead)
            if (read == -1) break
            out.write(buffer, 0, read)
            remaining -= read
            totalSent += read

            val elapsedSec = (System.currentTimeMillis() - startTime) / 1000f
            val speedMb = if (elapsedSec > 0.2f) (totalSent / (1024f * 1024f)) / elapsedSec else 0f
            val percent = ((totalSent.toFloat() / contentLength.toFloat()) * 100).toInt()
            onFileDownloadProgress?.invoke(file.name, percent, speedMb)
        }
        out.flush()
        fis.close()
        onFileDownloadCompleted?.invoke(file.name)
    }

    private fun serveNotFound(out: OutputStream) {
        val resp = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\nContent-Length: 9\r\n\r\nNot Found"
        out.write(resp.toByteArray(Charsets.US_ASCII))
        out.flush()
    }

    fun getDeviceIpAddress(context: Context): String {
        try {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val ipInt = wm?.connectionInfo?.ipAddress ?: 0
            if (ipInt != 0) {
                return String.format(
                    "%d.%d.%d.%d",
                    ipInt and 0xff,
                    (ipInt shr 8) and 0xff,
                    (ipInt shr 16) and 0xff,
                    (ipInt shr 24) and 0xff
                )
            }
            val interfaces = NetworkInterface.getNetworkInterfaces()
            for (intf in interfaces) {
                for (addr in intf.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val host = addr.hostAddress
                        if (!host.isNullOrBlank() && !host.startsWith("127.")) {
                            return host
                        }
                    }
                }
            }
        } catch (e: Exception) {}
        return "192.168.49.1"
    }

    private fun getMimeType(fileName: String): String {
        return when {
            fileName.endsWith(".mp4", true) -> "video/mp4"
            fileName.endsWith(".mkv", true) -> "video/x-matroska"
            fileName.endsWith(".mp3", true) -> "audio/mpeg"
            fileName.endsWith(".m4a", true) -> "audio/mp4"
            fileName.endsWith(".wav", true) -> "audio/wav"
            fileName.endsWith(".jpg", true) || fileName.endsWith(".jpeg", true) -> "image/jpeg"
            fileName.endsWith(".png", true) -> "image/png"
            fileName.endsWith(".apk", true) -> "application/vnd.android.package-archive"
            fileName.endsWith(".pdf", true) -> "application/pdf"
            fileName.endsWith(".zip", true) -> "application/zip"
            else -> "application/octet-stream"
        }
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val mb = bytes / (1024f * 1024f)
        return if (mb >= 1024) String.format("%.2f GB", mb / 1024f) else String.format("%.1f MB", mb)
    }
}
