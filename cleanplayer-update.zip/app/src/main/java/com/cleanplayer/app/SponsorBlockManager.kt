package com.cleanplayer.app

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

data class SponsorSegment(
    val category: String,
    val actionType: String,
    val startMs: Long,
    val endMs: Long
)

object SponsorBlockManager {

    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentSegments: List<SponsorSegment> = emptyList()
    private var lastLoadedVideoId: String? = null
    private var lastSkippedSegmentEndMs: Long = -1L

    fun isCategoryEnabled(category: String): Boolean {
        if (!PlayerHolder.isSponsorBlockEnabled) return false
        return when (category.lowercase()) {
            "sponsor" -> PlayerHolder.isSponsorSkipSponsor
            "intro" -> PlayerHolder.isSponsorSkipIntro
            "outro" -> PlayerHolder.isSponsorSkipOutro
            "selfpromo" -> PlayerHolder.isSponsorSkipSelfPromo
            "interaction" -> PlayerHolder.isSponsorSkipInteraction
            else -> true
        }
    }

    fun fetchSegments(videoId: String, onLoaded: ((List<SponsorSegment>) -> Unit)? = null) {
        if (videoId.isBlank() || videoId == lastLoadedVideoId) {
            onLoaded?.invoke(currentSegments)
            return
        }

        currentSegments = emptyList()
        lastLoadedVideoId = videoId
        lastSkippedSegmentEndMs = -1L

        executor.execute {
            val segments = mutableListOf<SponsorSegment>()
            try {
                // Public SponsorBlock API (skip segments query)
                val categories = "[\"sponsor\",\"intro\",\"outro\",\"interaction\",\"selfpromo\",\"preview\"]"
                val encodedCat = java.net.URLEncoder.encode(categories, "UTF-8")
                val urlStr = "https://sponsor.ajay.app/api/skipSegments?videoID=${videoId}&categories=$encodedCat"
                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3000
                    readTimeout = 3000
                    setRequestProperty("User-Agent", "Mozilla/5.0 CleanPlayer-SponsorBlock/1.0")
                }

                if (conn.responseCode == 200) {
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    val arr = JSONArray(resp)
                    for (i in 0 until arr.length()) {
                        val obj = arr.getJSONObject(i)
                        val cat = obj.optString("category", "sponsor")
                        val action = obj.optString("actionType", "skip")
                        val segmentArr = obj.optJSONArray("segment")
                        if (segmentArr != null && segmentArr.length() >= 2) {
                            val startSec = segmentArr.getDouble(0)
                            val endSec = segmentArr.getDouble(1)
                            segments.add(
                                SponsorSegment(
                                    category = cat,
                                    actionType = action,
                                    startMs = (startSec * 1000).toLong(),
                                    endMs = (endSec * 1000).toLong()
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                // Fallback or network error
            }

            currentSegments = segments
            mainHandler.post {
                onLoaded?.invoke(segments)
            }
        }
    }

    /**
     * Checks if current position falls into any skip segment.
     * Returns target skip position if should skip, or null if no skip needed.
     */
    fun checkSkip(currentPositionMs: Long): Pair<Long, String>? {
        if (currentSegments.isEmpty() || currentPositionMs <= 0L || !PlayerHolder.isSponsorBlockEnabled) return null

        for (seg in currentSegments) {
            if (seg.actionType == "skip" && isCategoryEnabled(seg.category) && currentPositionMs in seg.startMs until (seg.endMs - 100L)) {
                if (lastSkippedSegmentEndMs != seg.endMs) {
                    lastSkippedSegmentEndMs = seg.endMs
                    val label = when (seg.category) {
                        "sponsor" -> "Sponsor"
                        "intro" -> "Intro"
                        "outro" -> "Outro"
                        "interaction" -> "Interaction"
                        "selfpromo" -> "Self Promotion"
                        else -> "Segment"
                    }
                    return Pair(seg.endMs, label)
                }
            }
        }
        return null
    }

    fun clear() {
        currentSegments = emptyList()
        lastLoadedVideoId = null
        lastSkippedSegmentEndMs = -1L
    }
}
