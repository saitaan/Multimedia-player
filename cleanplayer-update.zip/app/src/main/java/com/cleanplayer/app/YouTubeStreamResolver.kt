package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.util.concurrent.Executors

data class StreamQualityOption(
    val qualityLabel: String,
    val resolution: Int,
    val videoUrl: String,
    val audioUrl: String?
)

data class ResolvedYouTubeStream(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val videoUrl: String,
    val audioUrl: String?,
    val isMerged: Boolean,
    val qualityLabel: String,
    val resolution: Int,
    val availableQualities: List<StreamQualityOption>,
    val pureAudioUrl: String? = null,
    val allAudioUrls: List<String> = emptyList()
)

/**
 * High-Efficiency Stream Resolver using official TeamNewPipe NewPipeExtractor.
 * Implements intelligent adaptive data-saving (720p/480p default), user-defined audio bitrate,
 * and zero-buffering stream selection.
 */
object YouTubeStreamResolver {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isInitialized = false

    private val streamCache = object : LinkedHashMap<String, Pair<Long, ResolvedYouTubeStream>>(25, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Long, ResolvedYouTubeStream>>?): Boolean {
            return size > 35
        }
    }
    private var cacheTtlMs: Long = 4 * 60 * 60 * 1000L // Default 4 Hours TTL

    fun setCacheTtlHours(hours: Int) {
        cacheTtlMs = hours.toLong() * 60 * 60 * 1000L
    }

    fun setCacheTtlMs(ms: Long) {
        cacheTtlMs = ms
    }

    fun initNewPipe(context: Context? = null) {
        if (!isInitialized) {
            synchronized(this) {
                if (!isInitialized) {
                    try {
                        NewPipe.init(DownloaderImpl.getInstance())
                        isInitialized = true
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    fun resolveStreams(
        videoId: String,
        preferredResolution: Int = 720,
        callback: (ResolvedYouTubeStream?) -> Unit
    ) {
        val cached = synchronized(streamCache) { streamCache[videoId] }
        if (cached != null && (System.currentTimeMillis() - cached.first) < cacheTtlMs) {
            val stream = cached.second
            val adaptedOption = stream.availableQualities.firstOrNull { it.resolution == preferredResolution && it.audioUrl == null }
                ?: stream.availableQualities.firstOrNull { it.resolution == preferredResolution }
                ?: stream.availableQualities.firstOrNull { it.resolution <= preferredResolution }
                ?: stream.availableQualities.firstOrNull()
            val finalStream = if (adaptedOption != null && (adaptedOption.videoUrl != stream.videoUrl || adaptedOption.resolution != stream.resolution)) {
                stream.copy(
                    videoUrl = adaptedOption.videoUrl,
                    audioUrl = adaptedOption.audioUrl,
                    isMerged = !adaptedOption.audioUrl.isNullOrBlank(),
                    qualityLabel = adaptedOption.qualityLabel,
                    resolution = adaptedOption.resolution
                )
            } else stream
            mainHandler.post { callback(finalStream) }
            return
        }

        initNewPipe()
        executor.execute {
            try {
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)
                val watchUrl = "https://www.youtube.com/watch?v=$videoId"
                val streamInfo = StreamInfo.getInfo(service, watchUrl)

                // 1. Audio stream extraction according to user quality preference
                val audioStreams = streamInfo.audioStreams ?: emptyList()
                val sortedAudio = audioStreams.sortedByDescending { it.averageBitrate }

                val prefAudio = try {
                    CleanPlayerApp.instance.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
                        .getString("pref_yt_audio_quality", "Auto") ?: "Auto"
                } catch (e: Exception) {
                    "Auto"
                }

                val selectedAudioStream = when {
                    prefAudio.contains("Data Saver", ignoreCase = true) || prefAudio.contains("64", ignoreCase = true) -> {
                        sortedAudio.lastOrNull() ?: sortedAudio.firstOrNull()
                    }
                    prefAudio.contains("Normal", ignoreCase = true) || prefAudio.contains("128", ignoreCase = true) -> {
                        sortedAudio.firstOrNull { it.averageBitrate in 90..140 } ?: sortedAudio.firstOrNull()
                    }
                    prefAudio.contains("High", ignoreCase = true) || prefAudio.contains("160", ignoreCase = true) -> {
                        sortedAudio.firstOrNull()
                    }
                    else -> sortedAudio.firstOrNull()
                }

                val bestAudioUrl = selectedAudioStream?.content ?: sortedAudio.firstOrNull()?.content
                val allAudioUrls = sortedAudio.mapNotNull { it.content }.filter { it.isNotBlank() }

                val qualityOptions = mutableListOf<StreamQualityOption>()

                // 2. High-Res Video-only streams (1080p, 720p, 480p, 360p)
                for (vStream in (streamInfo.videoOnlyStreams ?: emptyList())) {
                    val res = vStream.resolution?.replace("p", "")?.toIntOrNull() ?: 720
                    val label = vStream.resolution ?: "${res}p"
                    val u = vStream.content
                    if (!u.isNullOrBlank()) {
                        qualityOptions.add(
                            StreamQualityOption(
                                qualityLabel = label,
                                resolution = res,
                                videoUrl = u,
                                audioUrl = bestAudioUrl
                            )
                        )
                    }
                }

                // 3. Progressive Muxed Streams (Audio + Video combined in 1 file - Zero buffering & low data)
                for (vStream in (streamInfo.videoStreams ?: emptyList())) {
                    val res = vStream.resolution?.replace("p", "")?.toIntOrNull() ?: 360
                    val label = vStream.resolution ?: "${res}p"
                    val u = vStream.content
                    if (!u.isNullOrBlank()) {
                        qualityOptions.add(
                            StreamQualityOption(
                                qualityLabel = "$label (Fast)",
                                resolution = res,
                                videoUrl = u,
                                audioUrl = null // Single unified stream
                            )
                        )
                    }
                }

                val distinctOptions = qualityOptions
                    .distinctBy { "${it.resolution}_${it.audioUrl == null}" }
                    .sortedWith(compareByDescending<StreamQualityOption> { it.resolution }.thenBy { it.audioUrl != null })

                // Adaptive selection: match preferred resolution or closest lower resolution to save data
                val selectedOption = distinctOptions.firstOrNull { it.resolution == preferredResolution && it.audioUrl == null }
                    ?: distinctOptions.firstOrNull { it.resolution == preferredResolution }
                    ?: distinctOptions.firstOrNull { it.resolution <= preferredResolution }
                    ?: distinctOptions.firstOrNull()

                if (selectedOption != null) {
                    val resolvedStream = ResolvedYouTubeStream(
                        videoId = videoId,
                        title = streamInfo.name ?: "YouTube Video",
                        channelTitle = streamInfo.uploaderName ?: "Creator",
                        videoUrl = selectedOption.videoUrl,
                        audioUrl = selectedOption.audioUrl,
                        isMerged = !selectedOption.audioUrl.isNullOrBlank(),
                        qualityLabel = selectedOption.qualityLabel,
                        resolution = selectedOption.resolution,
                        availableQualities = distinctOptions,
                        pureAudioUrl = bestAudioUrl ?: selectedOption.videoUrl,
                        allAudioUrls = allAudioUrls
                    )
                    synchronized(streamCache) {
                        streamCache[videoId] = Pair(System.currentTimeMillis(), resolvedStream)
                    }
                    mainHandler.post { callback(resolvedStream) }
                } else {
                    mainHandler.post { callback(null) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                mainHandler.post { callback(null) }
            }
        }
    }
}
