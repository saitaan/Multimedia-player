package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.util.concurrent.Executors

data class StreamQualityOption(
    val qualityLabel: String,
    val resolution: Int,
    val videoUrl: String,
    val audioUrl: String?
)

data class ResolvedYouTubeStream(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val videoUrl: String,
    val audioUrl: String?,
    val isMerged: Boolean,
    val qualityLabel: String,
    val resolution: Int,
    val availableQualities: List<StreamQualityOption>
)

/**
 * High-Efficiency Stream Resolver using official TeamNewPipe NewPipeExtractor.
 * Implements intelligent adaptive data-saving (720p/480p default) and low-latency stream selection.
 */
object YouTubeStreamResolver {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isInitialized = false

    fun initNewPipe(context: Context? = null) {
        if (!isInitialized) {
            synchronized(this) {
                if (!isInitialized) {
                    try {
                        NewPipe.init(DownloaderImpl.getInstance())
                        isInitialized = true
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    fun resolveStreams(
        videoId: String,
        preferredResolution: Int = 720,
        callback: (ResolvedYouTubeStream?) -> Unit
    ) {
        initNewPipe()
        executor.execute {
            try {
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)
                val watchUrl = "https://www.youtube.com/watch?v=$videoId"
                val streamInfo = StreamInfo.getInfo(service, watchUrl)

                // 1. Audio stream (m4a / audio/mp4 prioritized)
                val audioStreams = streamInfo.audioStreams
                val bestAudioStream = audioStreams?.maxByOrNull { it.averageBitrate }
                val bestAudioUrl = bestAudioStream?.content

                val qualityOptions = mutableListOf<StreamQualityOption>()

                // 2. High-Res Video-only streams (1080p, 720p, 480p, 360p)
                for (vStream in (streamInfo.videoOnlyStreams ?: emptyList())) {
                    val res = vStream.resolution?.replace("p", "")?.toIntOrNull() ?: 720
                    val label = vStream.resolution ?: "${res}p"
                    val u = vStream.content
                    if (!u.isNullOrBlank()) {
                        qualityOptions.add(
                            StreamQualityOption(
                                qualityLabel = label,
                                resolution = res,
                                videoUrl = u,
                                audioUrl = bestAudioUrl
                            )
                        )
                    }
                }

                // 3. Progressive Muxed Streams (Audio + Video combined in 1 file - Zero buffering & low data)
                for (vStream in (streamInfo.videoStreams ?: emptyList())) {
                    val res = vStream.resolution?.replace("p", "")?.toIntOrNull() ?: 360
                    val label = vStream.resolution ?: "${res}p"
                    val u = vStream.content
                    if (!u.isNullOrBlank()) {
                        qualityOptions.add(
                            StreamQualityOption(
                                qualityLabel = "$label (Fast)",
                                resolution = res,
                                videoUrl = u,
                                audioUrl = null // Single unified stream
                            )
                        )
                    }
                }

                val distinctOptions = qualityOptions
                    .distinctBy { "${it.resolution}_${it.audioUrl == null}" }
                    .sortedWith(compareByDescending<StreamQualityOption> { it.resolution }.thenBy { it.audioUrl != null })

                // Adaptive selection: match preferred resolution or closest lower resolution to save data
                val selectedOption = distinctOptions.firstOrNull { it.resolution == preferredResolution && it.audioUrl == null }
                    ?: distinctOptions.firstOrNull { it.resolution == preferredResolution }
                    ?: distinctOptions.firstOrNull { it.resolution <= preferredResolution }
                    ?: distinctOptions.firstOrNull()

                if (selectedOption != null) {
                    val resolvedStream = ResolvedYouTubeStream(
                        videoId = videoId,
                        title = streamInfo.name ?: "YouTube Video",
                        channelTitle = streamInfo.uploaderName ?: "Creator",
                        videoUrl = selectedOption.videoUrl,
                        audioUrl = selectedOption.audioUrl,
                        isMerged = !selectedOption.audioUrl.isNullOrBlank(),
                        qualityLabel = selectedOption.qualityLabel,
                        resolution = selectedOption.resolution,
                        availableQualities = distinctOptions
                    )
                    mainHandler.post { callback(resolvedStream) }
                } else {
                    mainHandler.post { callback(null) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                mainHandler.post { callback(null) }
            }
        }
    }
}
