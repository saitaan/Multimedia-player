package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.stream.StreamInfo
import java.util.concurrent.Executors

data class StreamQualityOption(
    val qualityLabel: String,
    val resolution: Int,
    val videoUrl: String,
    val audioUrl: String?
)

data class YouTubeAudioTrack(
    val id: String,
    val name: String,
    val language: String,
    val isOriginal: Boolean,
    val bitrate: Int,
    val url: String
)

data class ResolvedYouTubeStream(
    val videoId: String,
    val title: String,
    val channelTitle: String,
    val videoUrl: String,
    val audioUrl: String?,
    val isMerged: Boolean,
    val qualityLabel: String,
    val resolution: Int,
    val availableQualities: List<StreamQualityOption>,
    val pureAudioUrl: String? = null,
    val allAudioUrls: List<String> = emptyList(),
    val availableAudioTracks: List<YouTubeAudioTrack> = emptyList()
)

/**
 * High-Efficiency Stream Resolver using official TeamNewPipe NewPipeExtractor.
 * Implements intelligent adaptive data-saving (720p/480p default), user-defined audio bitrate,
 * and zero-buffering stream selection.
 */
object YouTubeStreamResolver {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isInitialized = false

    private val streamCache = object : LinkedHashMap<String, Pair<Long, ResolvedYouTubeStream>>(25, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Long, ResolvedYouTubeStream>>?): Boolean {
            return size > 35
        }
    }
    private var cacheTtlMs: Long = 4 * 60 * 60 * 1000L // Default 4 Hours TTL

    fun setCacheTtlHours(hours: Int) {
        cacheTtlMs = hours.toLong() * 60 * 60 * 1000L
    }

    fun setCacheTtlMs(ms: Long) {
        cacheTtlMs = ms
    }

    fun initNewPipe(context: Context? = null) {
        if (!isInitialized) {
            synchronized(this) {
                if (!isInitialized) {
                    try {
                        NewPipe.init(DownloaderImpl.getInstance())
                        isInitialized = true
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }

    fun resolveStreams(
        videoId: String,
        preferredResolution: Int = 720,
        callback: (ResolvedYouTubeStream?) -> Unit
    ) {
        val cached = synchronized(streamCache) { streamCache[videoId] }
        if (cached != null && (System.currentTimeMillis() - cached.first) < cacheTtlMs) {
            val stream = cached.second
            val adaptedOption = stream.availableQualities.firstOrNull { it.resolution == preferredResolution && it.audioUrl == null }
                ?: stream.availableQualities.firstOrNull { it.resolution == preferredResolution }
                ?: stream.availableQualities.firstOrNull { it.resolution <= preferredResolution }
                ?: stream.availableQualities.firstOrNull()
            val finalStream = if (adaptedOption != null && (adaptedOption.videoUrl != stream.videoUrl || adaptedOption.resolution != stream.resolution)) {
                stream.copy(
                    videoUrl = adaptedOption.videoUrl,
                    audioUrl = adaptedOption.audioUrl,
                    isMerged = !adaptedOption.audioUrl.isNullOrBlank(),
                    qualityLabel = adaptedOption.qualityLabel,
                    resolution = adaptedOption.resolution
                )
            } else stream
            mainHandler.post { callback(finalStream) }
            return
        }

        initNewPipe()
        executor.execute {
            try {
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)
                val watchUrl = "https://www.youtube.com/watch?v=$videoId"
                val streamInfo = StreamInfo.getInfo(service, watchUrl)

                // 1. Extract and categorize all available multi-language audio tracks
                val audioStreams = streamInfo.audioStreams ?: emptyList()
                val sortedAudio = audioStreams.sortedByDescending { it.averageBitrate }

                val allAudioTracks = mutableListOf<YouTubeAudioTrack>()
                val trackKeysSeen = mutableSetOf<String>()

                for (aStream in audioStreams) {
                    val trackUrl = aStream.content ?: continue
                    if (trackUrl.isBlank()) continue

                    val trackName = aStream.audioTrackName ?: ""
                    val locale = aStream.audioLocale
                    val lang = locale?.language ?: aStream.audioTrackId ?: "und"
                    val isOrig = aStream.audioTrackType?.name == "ORIGINAL" || trackName.contains("original", ignoreCase = true)

                    val trackKey = "${lang}_${trackName}"
                    if (trackKey in trackKeysSeen) continue
                    trackKeysSeen.add(trackKey)

                    val displayName = when {
                        trackName.isNotBlank() -> trackName
                        lang.equals("hi", true) || lang.equals("hin", true) -> if (isOrig) "Hindi (Original)" else "Hindi"
                        lang.equals("en", true) || lang.equals("eng", true) -> if (isOrig) "English (Original)" else "English"
                        lang.equals("es", true) -> "Spanish"
                        lang.equals("fr", true) -> "French"
                        lang.equals("de", true) -> "German"
                        lang.equals("ja", true) -> "Japanese"
                        lang.equals("ko", true) -> "Korean"
                        lang.equals("ru", true) -> "Russian"
                        else -> lang.uppercase()
                    }

                    allAudioTracks.add(
                        YouTubeAudioTrack(
                            id = aStream.audioTrackId ?: lang,
                            name = displayName,
                            language = lang,
                            isOriginal = isOrig,
                            bitrate = aStream.averageBitrate,
                            url = trackUrl
                        )
                    )
                }

                // Default preferred audio language: HINDI ("hi")
                val prefLang = try {
                    CleanPlayerApp.instance.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
                        .getString("pref_yt_audio_track_lang", "hi") ?: "hi"
                } catch (e: Exception) {
                    "hi"
                }

                // If Hindi requested or default, prioritize Hindi track; otherwise original or highest bitrate
                val selectedAudioTrack = if (prefLang.equals("hi", true) || prefLang.contains("hindi", ignoreCase = true)) {
                    allAudioTracks.firstOrNull { it.language.equals("hi", true) || it.name.contains("hindi", ignoreCase = true) }
                        ?: allAudioTracks.firstOrNull { it.isOriginal }
                        ?: allAudioTracks.firstOrNull()
                } else {
                    allAudioTracks.firstOrNull { it.language.equals(prefLang, true) || it.name.contains(prefLang, ignoreCase = true) }
                        ?: allAudioTracks.firstOrNull { it.isOriginal }
                        ?: allAudioTracks.firstOrNull()
                }

                val bestAudioUrl = selectedAudioTrack?.url ?: sortedAudio.firstOrNull()?.content
                val allAudioUrls = sortedAudio.mapNotNull { it.content }.filter { it.isNotBlank() }

                val qualityOptions = mutableListOf<StreamQualityOption>()

                // 2. High-Res Video-only streams (1080p, 720p, 480p, 360p)
                for (vStream in (streamInfo.videoOnlyStreams ?: emptyList())) {
                    val res = vStream.resolution?.replace("p", "")?.toIntOrNull() ?: 720
                    val label = vStream.resolution ?: "${res}p"
                    val u = vStream.content
                    if (!u.isNullOrBlank()) {
                        qualityOptions.add(
                            StreamQualityOption(
                                qualityLabel = label,
                                resolution = res,
                                videoUrl = u,
                                audioUrl = bestAudioUrl
                            )
                        )
                    }
                }

                // 3. Progressive Muxed Streams (Audio + Video combined in 1 file - Zero buffering & low data)
                for (vStream in (streamInfo.videoStreams ?: emptyList())) {
                    val res = vStream.resolution?.replace("p", "")?.toIntOrNull() ?: 360
                    val label = vStream.resolution ?: "${res}p"
                    val u = vStream.content
                    if (!u.isNullOrBlank()) {
                        qualityOptions.add(
                            StreamQualityOption(
                                qualityLabel = "$label (Fast)",
                                resolution = res,
                                videoUrl = u,
                                audioUrl = null // Single unified stream
                            )
                        )
                    }
                }

                val distinctOptions = qualityOptions
                    .distinctBy { "${it.resolution}_${it.audioUrl == null}" }
                    .sortedWith(compareByDescending<StreamQualityOption> { it.resolution }.thenBy { it.audioUrl != null })

                // Adaptive selection: match preferred resolution or closest lower resolution to save data
                val selectedOption = distinctOptions.firstOrNull { it.resolution == preferredResolution && it.audioUrl == null }
                    ?: distinctOptions.firstOrNull { it.resolution == preferredResolution }
                    ?: distinctOptions.firstOrNull { it.resolution <= preferredResolution }
                    ?: distinctOptions.firstOrNull()

                if (selectedOption != null) {
                    val resolvedStream = ResolvedYouTubeStream(
                        videoId = videoId,
                        title = streamInfo.name ?: "YouTube Video",
                        channelTitle = streamInfo.uploaderName ?: "Creator",
                        videoUrl = selectedOption.videoUrl,
                        audioUrl = selectedOption.audioUrl,
                        isMerged = !selectedOption.audioUrl.isNullOrBlank(),
                        qualityLabel = selectedOption.qualityLabel,
                        resolution = selectedOption.resolution,
                        availableQualities = distinctOptions,
                        pureAudioUrl = bestAudioUrl ?: selectedOption.videoUrl,
                        allAudioUrls = allAudioUrls,
                        availableAudioTracks = allAudioTracks
                    )
                    synchronized(streamCache) {
                        streamCache[videoId] = Pair(System.currentTimeMillis(), resolvedStream)
                    }
                    mainHandler.post { callback(resolvedStream) }
                } else {
                    mainHandler.post { callback(null) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                mainHandler.post { callback(null) }
            }
        }
    }
}
