package com.cleanplayer.app

import java.util.concurrent.Executors
import android.net.wifi.WifiManager
import android.hardware.Camera
import android.view.SurfaceView
import android.view.SurfaceHolder
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.WifiConfiguration
import com.google.zxing.MultiFormatReader
import com.google.zxing.DecodeHintType
import com.google.zxing.BarcodeFormat
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.BinaryBitmap
import com.google.zxing.common.HybridBinarizer

import android.media.AudioManager
import android.view.GestureDetector
import android.view.ScaleGestureDetector
import androidx.media3.ui.AspectRatioFrameLayout

import android.view.MotionEvent
import android.view.WindowInsets
import android.view.WindowInsetsController

import android.os.Handler
import android.os.Looper

import android.app.PictureInPictureParams
import android.util.Rational
import android.content.res.Configuration

import android.Manifest
import java.io.File
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import androidx.core.widget.NestedScrollView
import android.widget.Button
import android.widget.ProgressBar
import android.widget.HorizontalScrollView
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.ImageButton
import android.widget.ImageView
import com.google.android.material.card.MaterialCardView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.widget.FrameLayout
import android.widget.RelativeLayout

class MainActivity : AppCompatActivity() {
    private var activeSettingsBottomSheet: com.google.android.material.bottomsheet.BottomSheetDialog? = null

    private val ytPrefs by lazy { getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE) }

    // =========================================================================
    // 5GHz High-Speed Resumable P2P File Sharing Engine Implementation
    // =========================================================================

    // 5GHz High-Speed Share Tab Views & State
    private lateinit var tabShare: View
    private lateinit var tabShareTitleShare: TextView
    private lateinit var tabShareTitleHistory: TextView
    private lateinit var layoutShareMainContent: View
    private lateinit var layoutShareHistoryContent: View
    private lateinit var rvShareRecent: RecyclerView
    private lateinit var rvShareHistory: RecyclerView
    private lateinit var btnShareSend: View
    private lateinit var btnShareReceive: View
    private lateinit var btnShareMenu: ImageButton
    private lateinit var btnShareClearHistory: Button
    private lateinit var layoutShareEmptyRecent: View
    private lateinit var layoutShareEmptyHistory: View
    private var shareRecentAdapter: ShareRecordAdapter? = null
    private var shareHistoryAdapter: ShareRecordAdapter? = null
    private var cardActiveTransferBanner: View? = null
    private var tvActiveBannerTitle: TextView? = null
    private var tvActiveBannerSpeed: TextView? = null
    private var pbActiveBannerProgress: ProgressBar? = null
    private var tvActiveBannerFileName: TextView? = null
    private var btnActiveBannerView: Button? = null
    private var btnActiveBannerStop: Button? = null
    private var activeShareProgressDialog: AlertDialog? = null

    private fun setupShareTab() {
        tabShare = findViewById(R.id.tabShare)
        tabShareTitleShare = findViewById(R.id.tabShareTitleShare)
        tabShareTitleHistory = findViewById(R.id.tabShareTitleHistory)
        layoutShareMainContent = findViewById(R.id.layoutShareMainContent)
        layoutShareHistoryContent = findViewById(R.id.layoutShareHistoryContent)
        rvShareRecent = findViewById(R.id.rvShareRecent)
        rvShareHistory = findViewById(R.id.rvShareHistory)
        btnShareSend = findViewById(R.id.btnShareSend)
        btnShareReceive = findViewById(R.id.btnShareReceive)
        btnShareMenu = findViewById(R.id.btnShareMenu)
        btnShareClearHistory = findViewById(R.id.btnShareClearHistory)
        layoutShareEmptyRecent = findViewById(R.id.layoutShareEmptyRecent)
        layoutShareEmptyHistory = findViewById(R.id.layoutShareEmptyHistory)

        cardActiveTransferBanner = findViewById(R.id.cardActiveTransferBanner)
        tvActiveBannerTitle = findViewById(R.id.tvActiveBannerTitle)
        tvActiveBannerSpeed = findViewById(R.id.tvActiveBannerSpeed)
        pbActiveBannerProgress = findViewById(R.id.pbActiveBannerProgress)
        tvActiveBannerFileName = findViewById(R.id.tvActiveBannerFileName)
        btnActiveBannerView = findViewById(R.id.btnActiveBannerView)
        btnActiveBannerStop = findViewById(R.id.btnActiveBannerStop)

        btnActiveBannerStop?.setOnClickListener {
            FastShareManager.stopTransferService(this)
            FastShareService.isTransferActive.set(false)
            cardActiveTransferBanner?.visibility = View.GONE
            
        }

        btnActiveBannerView?.setOnClickListener {
            showShareProgressDialog(isSender = FastShareService.isSenderMode, filePaths = emptyList())
        }

        rvShareRecent.layoutManager = LinearLayoutManager(this)
        rvShareHistory.layoutManager = LinearLayoutManager(this)

        shareRecentAdapter = ShareRecordAdapter(emptyList()) { record ->
            handleRecordAction(record)
        }
        rvShareRecent.adapter = shareRecentAdapter

        shareHistoryAdapter = ShareRecordAdapter(emptyList()) { record ->
            handleRecordAction(record)
        }
        rvShareHistory.adapter = shareHistoryAdapter

        findViewById<View>(R.id.layoutShareBandBadge)?.setOnClickListener {
            showShareSettingsBottomSheet()
        }

        cardActiveTransferBanner?.setOnClickListener {
            showShareProgressDialog(isSender = FastShareService.isSenderMode, filePaths = emptyList())
        }

        layoutShareEmptyRecent.setOnClickListener {
            checkSharePermissionsAndRun {
                showShareSelectItemsDialog()
            }
        }

        layoutShareEmptyHistory.setOnClickListener {
            tabShareTitleShare.performClick()
        }

        tabShareTitleShare.setOnClickListener {
            tabShareTitleShare.setTextColor(Color.parseColor("#00E5FF"))
            tabShareTitleHistory.setTextColor(Color.parseColor("#888888"))
            layoutShareMainContent.visibility = View.VISIBLE
            layoutShareHistoryContent.visibility = View.GONE
            refreshShareTabUI()
        }

        tabShareTitleHistory.setOnClickListener {
            tabShareTitleHistory.setTextColor(Color.parseColor("#00E5FF"))
            tabShareTitleShare.setTextColor(Color.parseColor("#888888"))
            layoutShareMainContent.visibility = View.GONE
            layoutShareHistoryContent.visibility = View.VISIBLE
            refreshShareTabUI()
        }

        btnShareSend.setOnClickListener {
            checkSharePermissionsAndRun {
                showShareSelectItemsDialog()
            }
        }

        btnShareReceive.setOnClickListener {
            checkSharePermissionsAndRun {
                checkCameraPermissionAndScan {
                    showQrScannerDialog()
                }
            }
        }

        btnShareMenu.setOnClickListener {
            showShareSettingsBottomSheet()
        }

        btnShareClearHistory.setOnClickListener {
            ShareHistoryManager.clearHistory(this)
            refreshShareTabUI()
        }

        refreshShareTabUI()
    }

    private fun handleRecordAction(record: TransferRecord) {
        val file = File(record.filePath)
        if (!file.exists()) {
            Toast.makeText(this, "File not found on storage", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                this,
                "$packageName.provider",
                file
            )

            val name = record.fileName.lowercase()
            val isVid = record.type == ShareItemType.VIDEO || name.endsWith(".mp4") || name.endsWith(".mkv") || name.endsWith(".webm") || name.endsWith(".avi")
            val isAud = record.type == ShareItemType.AUDIO || name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".flac") || name.endsWith(".wav") || name.endsWith(".aac")

            if (isVid) {
                openPlayer(uri, record.fileName, isVideo = true, path = file.absolutePath)
            } else if (isAud) {
                openPlayer(uri, record.fileName, isVideo = false, path = file.absolutePath)
            } else if (name.endsWith(".apk")) {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            } else {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "*/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(Intent.createChooser(intent, "Open With"))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open file: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshShareTabUI() {
        if (!::tabShare.isInitialized) return
        val records = ShareHistoryManager.getRecords(this)
        val recent = records.take(8)

        shareRecentAdapter?.updateRecords(recent)
        layoutShareEmptyRecent.visibility = if (recent.isEmpty()) View.VISIBLE else View.GONE
        rvShareRecent.visibility = if (recent.isNotEmpty()) View.VISIBLE else View.GONE

        shareHistoryAdapter?.updateRecords(records)
        layoutShareEmptyHistory.visibility = if (records.isEmpty()) View.VISIBLE else View.GONE
        rvShareHistory.visibility = if (records.isNotEmpty()) View.VISIBLE else View.GONE

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val bandLabel = ytPrefs.getString("pref_share_band", "5GHz High-Speed Wi-Fi Turbo") ?: "5GHz High-Speed Wi-Fi Turbo"
        findViewById<TextView>(R.id.tvShareBandBadge)?.text = bandLabel

        if (FastShareService.isTransferActive.get()) {
            cardActiveTransferBanner?.visibility = View.VISIBLE
            tvActiveBannerTitle?.text = if (FastShareService.isSenderMode) "⚡ Sending in Background..." else "⚡ Receiving in Background..."
            tvActiveBannerSpeed?.text = "${String.format("%.1f", FastShareService.currentSpeedMb)} MB/s"
            pbActiveBannerProgress?.progress = FastShareService.currentProgressPercent
            val tMb = String.format("%.1f MB", FastShareService.currentTransferredBytes / (1024f * 1024f))
            val totMb = String.format("%.1f MB", FastShareService.currentTotalBytes / (1024f * 1024f))
            tvActiveBannerFileName?.text = "${FastShareService.currentFileName} (${FastShareService.currentProgressPercent}%) • $tMb / $totMb"
        } else {
            cardActiveTransferBanner?.visibility = View.GONE
        }
    }

    private fun showShareSelectItemsDialog() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_share_select_items, null)
        dialog.setContentView(view)

        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.let { sheet ->
                val behavior = com.google.android.material.bottomsheet.BottomSheetBehavior.from(sheet)
                behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
            }
        }

        view.findViewById<View>(R.id.btnSelectBack)?.setOnClickListener { dialog.dismiss() }

        val rvItems = view.findViewById<RecyclerView>(R.id.rvSelectableItems)
        val tvSelectedBadge = view.findViewById<TextView>(R.id.tvSelectedCountBadge)
        val btnSend = view.findViewById<Button>(R.id.btnStartSendTransfer)

        rvItems?.layoutManager = LinearLayoutManager(this)
        val allSelectedMap = mutableMapOf<String, ShareItem>()
        var currentLoadedCategoryItems = listOf<ShareItem>()

        fun updateSelectedBadge() {
            val count = allSelectedMap.size
            val totalBytes = allSelectedMap.values.sumOf { it.size }
            val mb = String.format("%.1f MB", totalBytes / (1024f * 1024f))
            tvSelectedBadge?.text = "$count files selected ($mb)"
        }

        lateinit var adapter: ShareSelectableAdapter
        adapter = ShareSelectableAdapter(emptyList()) { _ ->
            for (item in adapter.getItems()) {
                if (item.isSelected) {
                    allSelectedMap[item.path] = item
                } else {
                    allSelectedMap.remove(item.path)
                }
            }
            updateSelectedBadge()
        }
        rvItems?.adapter = adapter

        fun loadCategory(type: ShareItemType, activeTab: TextView) {
            val tabs = listOf(
                view.findViewById<TextView>(R.id.tabCatRecent),
                view.findViewById<TextView>(R.id.tabCatVideos),
                view.findViewById<TextView>(R.id.tabCatAudio),
                view.findViewById<TextView>(R.id.tabCatApps),
                view.findViewById<TextView>(R.id.tabCatImages),
                view.findViewById<TextView>(R.id.tabCatFiles)
            )
            for (t in tabs) {
                t?.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                t?.setTextColor(Color.WHITE)
                t?.setTypeface(null, android.graphics.Typeface.NORMAL)
            }
            activeTab.setBackgroundResource(R.drawable.bg_youtube_chip_active)
            activeTab.setTextColor(Color.BLACK)
            activeTab.setTypeface(null, android.graphics.Typeface.BOLD)

            FastShareManager.loadCategoryItems(this, type) { items ->
                currentLoadedCategoryItems = items
                for (item in items) {
                    item.isSelected = allSelectedMap.containsKey(item.path)
                }
                adapter.updateItems(items)
            }
        }

        view.findViewById<TextView>(R.id.tabCatRecent)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.RECENT, t) } }
        view.findViewById<TextView>(R.id.tabCatVideos)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.VIDEO, t) } }
        view.findViewById<TextView>(R.id.tabCatAudio)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.AUDIO, t) } }
        view.findViewById<TextView>(R.id.tabCatApps)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.APP, t) } }
        view.findViewById<TextView>(R.id.tabCatImages)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.IMAGE, t) } }
        view.findViewById<TextView>(R.id.tabCatFiles)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.FILE, t) } }

        view.findViewById<View>(R.id.btnSelectSearch)?.setOnClickListener {
            val searchInput = EditText(this).apply {
                hint = "Search files..."
                setSingleLine()
                setTextColor(Color.WHITE)
            }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Filter Files")
                .setView(searchInput)
                .setPositiveButton("Search") { _, _ ->
                    val query = searchInput.text.toString().trim().lowercase()
                    if (query.isNotBlank()) {
                        val filtered = currentLoadedCategoryItems.filter { it.name.lowercase().contains(query) }
                        adapter.updateItems(filtered)
                    } else {
                        adapter.updateItems(currentLoadedCategoryItems)
                    }
                }
                .setNegativeButton("Reset") { _, _ ->
                    adapter.updateItems(currentLoadedCategoryItems)
                }
                .show()
        }

        view.findViewById<TextView>(R.id.tabCatRecent)?.let { loadCategory(ShareItemType.RECENT, it) }

        btnSend?.setOnClickListener {
            if (allSelectedMap.isNotEmpty()) {
                val paths = allSelectedMap.values.map { it.path }
                val isParallel = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
                    .getBoolean("pref_share_is_parallel", true)
                FastShareManager.startSenderService(this, paths, isParallel)
                dialog.dismiss()
                showShareProgressDialog(isSender = true, filePaths = paths)
            } else {
                Toast.makeText(this, "Please select at least 1 file to send", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun showShareReceiveDialog() {
        FastShareManager.startReceiverService(this, "192.168.49.1")
        showShareProgressDialog(isSender = false, filePaths = emptyList())
    }

    @Suppress("DEPRECATION")
    private fun showQrScannerDialog() {
        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme).create()
        val view = layoutInflater.inflate(R.layout.dialog_qr_scanner, null)
        dialog.setView(view)
        dialog.setCancelable(true)

        val surfaceView = view.findViewById<SurfaceView>(R.id.svCameraPreview)
        val tvStatus = view.findViewById<TextView>(R.id.tvScannerStatus)
        val pbConnecting = view.findViewById<ProgressBar>(R.id.pbScannerConnecting)
        val btnFlash = view.findViewById<Button>(R.id.btnScannerFlash)
        val btnWifiSettings = view.findViewById<Button>(R.id.btnScannerWifiSettings)
        val btnCancel = view.findViewById<Button>(R.id.btnScannerCancel)

        var camera: android.hardware.Camera? = null
        var isFlashOn = false
        var isScanned = false

        btnCancel.setOnClickListener { dialog.dismiss() }

        btnWifiSettings.setOnClickListener {
            dialog.dismiss()
            try {
                startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))
                Toast.makeText(this, "Connect to sender's hotspot, then tap Receive", Toast.LENGTH_LONG).show()
                showShareProgressDialog(isSender = false, filePaths = emptyList())
                FastShareManager.startReceiverService(this, "192.168.49.1")
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        btnFlash.setOnClickListener {
            try {
                val cam = camera ?: return@setOnClickListener
                val params = cam.parameters
                if (isFlashOn) {
                    params.flashMode = android.hardware.Camera.Parameters.FLASH_MODE_OFF
                    btnFlash.text = "Flash"
                    isFlashOn = false
                } else {
                    params.flashMode = android.hardware.Camera.Parameters.FLASH_MODE_TORCH
                    btnFlash.text = "Flash On"
                    isFlashOn = true
                }
                cam.parameters = params
            } catch (e: Exception) {}
        }

        surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                try {
                    camera = android.hardware.Camera.open()
                    camera?.setDisplayOrientation(90)
                    camera?.setPreviewDisplay(holder)

                    val params = camera?.parameters
                    if (params?.supportedFocusModes?.contains(android.hardware.Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE) == true) {
                        params.focusMode = android.hardware.Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
                    }
                    try { camera?.parameters = params } catch (e: Exception) {}

                    val reader = MultiFormatReader()
                    val hints = mapOf(
                        DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
                        DecodeHintType.CHARACTER_SET to "UTF-8"
                    )
                    reader.setHints(hints)

                    var isDecoding = false

                    camera?.setPreviewCallback { data, cam ->
                        if (isScanned || isDecoding) return@setPreviewCallback
                        val size = cam.parameters.previewSize ?: return@setPreviewCallback
                        val w = size.width
                        val h = size.height

                        isDecoding = true
                        Executors.newSingleThreadExecutor().execute {
                            try {
                                val rotated = ByteArray(data.size)
                                for (y in 0 until h) {
                                    for (x in 0 until w) {
                                        rotated[x * h + h - y - 1] = data[x + y * w]
                                    }
                                }
                                val source = PlanarYUVLuminanceSource(
                                    rotated, h, w, 0, 0, h, w, false
                                )
                                val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
                                val result = reader.decodeWithState(binaryBitmap)
                                val text = result.text

                                if (!text.isNullOrBlank() && !isScanned) {
                                    isScanned = true
                                    runOnUiThread {
                                        pbConnecting.visibility = View.VISIBLE
                                        tvStatus.text = "QR Code Detected! Connecting..."
                                        dialog.dismiss()
                                        handleScannedWifiQr(text)
                                    }
                                }
                            } catch (e: Exception) {
                                // Keep scanning next frame
                            } finally {
                                reader.reset()
                                isDecoding = false
                            }
                        }
                    }
                    camera?.startPreview()
                } catch (e: Exception) {
                    e.printStackTrace()
                    tvStatus.text = "Camera preview unavailable"
                }
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                try {
                    camera?.setPreviewCallback(null)
                    camera?.stopPreview()
                    camera?.release()
                } catch (e: Exception) {}
                camera = null
            }
        })

        dialog.show()
    }

    private fun handleScannedWifiQr(qrText: String) {
        var ssid = ""
        var password = ""
        var hostIp = "192.168.49.1"

        try {
            val sMatch = Regex("S:([^;]+);").find(qrText)
            if (sMatch != null) ssid = sMatch.groupValues[1]

            val pMatch = Regex("P:([^;]+);").find(qrText)
            if (pMatch != null) password = pMatch.groupValues[1]

            val hMatch = Regex("H:([^;]+);").find(qrText)
            if (hMatch != null) hostIp = hMatch.groupValues[1]
        } catch (e: Exception) {
            e.printStackTrace()
        }

        Toast.makeText(this, "Connecting to sender: ${ssid.ifEmpty { "Hotspot" }}...", Toast.LENGTH_SHORT).show()

        connectToSenderWifi(ssid, password)
        FastShareManager.startReceiverService(this, hostIp)
        showShareProgressDialog(isSender = false, filePaths = emptyList())
    }

    private fun connectToSenderWifi(ssid: String, password: String) {
        if (ssid.isBlank()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val specifierBuilder = WifiNetworkSpecifier.Builder()
                    .setSsid(ssid)
                if (password.isNotBlank()) {
                    specifierBuilder.setWpa2Passphrase(password)
                }
                val request = NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .setNetworkSpecifier(specifierBuilder.build())
                    .build()

                connectivityManager.requestNetwork(request, object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        super.onAvailable(network)
                        try {
                            connectivityManager.bindProcessToNetwork(network)
                        } catch (e: Exception) {}
                    }
                })
            } else {
                @Suppress("DEPRECATION")
                val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val wifiConfig = WifiConfiguration().apply {
                    SSID = "\"" + ssid + "\""
                    preSharedKey = "\"" + password + "\""
                }
                @Suppress("DEPRECATION")
                val netId = wifiManager.addNetwork(wifiConfig)
                wifiManager.disconnect()
                wifiManager.enableNetwork(netId, true)
                wifiManager.reconnect()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showShareProgressDialog(isSender: Boolean, filePaths: List<String>) {
        if (activeShareProgressDialog?.isShowing == true) {
            try { activeShareProgressDialog?.dismiss() } catch (e: Exception) {}
        }

        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme).create()
        val view = layoutInflater.inflate(R.layout.dialog_share_progress, null)
        dialog.setView(view)
        dialog.setCancelable(true)

        activeShareProgressDialog = dialog
        dialog.setOnDismissListener {
            activeShareProgressDialog = null
            refreshShareTabUI()
        }

        val tvHeader = view.findViewById<TextView>(R.id.tvTransferHeader)
        val tvSubheader = view.findViewById<TextView>(R.id.tvTransferSubheader)
        val layoutQr = view.findViewById<View>(R.id.layoutQrContainer)
        val ivQr = view.findViewById<ImageView>(R.id.ivShareQrCode)
        val tvSpeed = view.findViewById<TextView>(R.id.tvTransferSpeed)
        val tvPercent = view.findViewById<TextView>(R.id.tvTransferPercent)
        val pbProgress = view.findViewById<ProgressBar>(R.id.pbTransferProgress)
        val tvFileName = view.findViewById<TextView>(R.id.tvTransferFileName)
        val tvBytes = view.findViewById<TextView>(R.id.tvTransferBytes)
        val btnMinimize = view.findViewById<Button>(R.id.btnMinimizeTransfer)
        val btnCancel = view.findViewById<Button>(R.id.btnCancelTransfer)

        val renderQr = { ssid: String, pwd: String, ip: String ->
            val pwdDisplay = if (pwd.isNotBlank()) " • Pass: $pwd" else ""
            tvSubheader.text = "Hotspot: $ssid$pwdDisplay • IP: $ip"
            val qrBitmap = QrCodeHelper.generateWifiQrCode(ssid, pwd, 512, 512)
            if (qrBitmap != null) {
                ivQr?.imageTintList = null
                ivQr?.colorFilter = null
                ivQr?.setImageBitmap(qrBitmap)
            }
        }

        if (isSender) {
            tvHeader.text = "Sending Files (5GHz Turbo)"
            tvSubheader.text = "Hotspot active • Ready to transfer"
            layoutQr.visibility = View.VISIBLE

            if (FastShareService.lastHotspotSsid.isNotBlank()) {
                renderQr(FastShareService.lastHotspotSsid, FastShareService.lastHotspotPassword, FastShareService.lastHotspotIp)
            }

            layoutQr.setOnClickListener {
                val pwdMsg = if (FastShareService.lastHotspotPassword.isNotBlank()) "\nPassword: ${FastShareService.lastHotspotPassword}" else ""
                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                    .setTitle("Wi-Fi Hotspot Connection Details")
                    .setMessage("Network (SSID): ${FastShareService.lastHotspotSsid.ifEmpty { "CleanPlayer Hotspot" }}$pwdMsg\nIP: ${FastShareService.lastHotspotIp}\n\nScan this QR code with any phone camera or Wi-Fi scanner to connect directly without typing password.")
                    .setPositiveButton("OK", null)
                    .show()
            }
        } else {
            tvHeader.text = "Receiving Files (5GHz Turbo)"
            tvSubheader.text = "Searching for 5GHz Hotspot..."
            layoutQr.visibility = View.GONE
        }

        if (FastShareService.isTransferActive.get() && FastShareService.currentFileName.isNotBlank()) {
            tvFileName.text = FastShareService.currentFileName
            tvPercent.text = "${FastShareService.currentProgressPercent}%"
            pbProgress.progress = FastShareService.currentProgressPercent
            tvSpeed.text = "⚡ ${String.format("%.1f", FastShareService.currentSpeedMb)} MB/s"
            val tMb = String.format("%.1f MB", FastShareService.currentTransferredBytes / (1024f * 1024f))
            val totMb = String.format("%.1f MB", FastShareService.currentTotalBytes / (1024f * 1024f))
            tvBytes?.text = "$tMb / $totMb"
        }

        FastShareService.onHotspotStarted = { ssid, pwd, ip, port ->
            runOnUiThread {
                renderQr(ssid, pwd, ip)
            }
        }

        FastShareService.onTransferProgressUpdate = { fileName, percent, speedMb, transferred, total, isCompleted ->
            runOnUiThread {
                tvFileName.text = fileName
                tvPercent.text = "$percent%"
                pbProgress.progress = percent
                tvSpeed.text = "⚡ ${String.format("%.1f", speedMb)} MB/s"
                val tMb = String.format("%.1f MB", transferred / (1024f * 1024f))
                val totMb = String.format("%.1f MB", total / (1024f * 1024f))
                tvBytes?.text = "$tMb / $totMb"

                if (FastShareService.isTransferActive.get()) {
                    cardActiveTransferBanner?.visibility = View.VISIBLE
                    tvActiveBannerTitle?.text = if (FastShareService.isSenderMode) "⚡ Sending in Background..." else "⚡ Receiving in Background..."
                    tvActiveBannerSpeed?.text = "${String.format("%.1f", speedMb)} MB/s"
                    pbActiveBannerProgress?.progress = percent
                    tvActiveBannerFileName?.text = "$fileName ($percent%) • $tMb / $totMb"
                }

                if (isCompleted) {
                    tvSubheader.text = "Transfer Complete!"
                    btnCancel.text = "Done"
                    btnMinimize?.visibility = View.GONE
                    cardActiveTransferBanner?.visibility = View.GONE
                    refreshShareTabUI()
                }
            }
        }

        FastShareService.onTransferError = { err ->
            runOnUiThread {
                tvSubheader.text = err
            }
        }

        btnMinimize?.setOnClickListener {
            dialog.dismiss()
            
            refreshShareTabUI()
        }

        btnCancel.setOnClickListener {
            if (FastShareService.isTransferActive.get()) {
                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                    .setTitle("Cancel Transfer?")
                    .setMessage("Kya aap transfer cancel karna chahte hain?")
                    .setPositiveButton("Stop Transfer") { _, _ ->
                        FastShareManager.stopTransferService(this)
                        dialog.dismiss()
                        refreshShareTabUI()
                    }
                    .setNegativeButton("Keep Running", null)
                    .show()
            } else {
                dialog.dismiss()
                refreshShareTabUI()
            }
        }

        dialog.show()
    }

    private fun showShareSettingsBottomSheet() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_share_settings, null)
        dialog.setContentView(view)

        view.findViewById<View>(R.id.btnShareSettingsClose)?.setOnClickListener { dialog.dismiss() }

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)

        // 1. Band
        val tvBand = view.findViewById<TextView>(R.id.tvShareBandVal)
        tvBand?.text = ytPrefs.getString("pref_share_band", "5GHz High-Speed Band (Recommended)")
        view.findViewById<View>(R.id.rowShareBand)?.setOnClickListener {
            val bands = arrayOf("5GHz High-Speed Band (Recommended)", "2.4GHz Compatibility Mode")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Hotspot Frequency Band")
                .setItems(bands) { _, which ->
                    val chosen = bands[which]
                    ytPrefs.edit().putString("pref_share_band", chosen).apply()
                    tvBand?.text = chosen
                    refreshShareTabUI()
                }
                .show()
        }

        // 2. Transfer Mode (Parallel vs Sequential)
        val tvMode = view.findViewById<TextView>(R.id.tvShareTransferModeVal)
        val curParallel = ytPrefs.getBoolean("pref_share_is_parallel", true)
        tvMode?.text = if (curParallel) "⚡ Multi Parallel Streams (Fastest for Batch Files)" else "🎯 One-by-One Sequential (Best for Large Movies)"
        view.findViewById<View>(R.id.rowShareTransferMode)?.setOnClickListener {
            val modes = arrayOf(
                "⚡ Multi Parallel Streams (Fastest for Batch Files)",
                "🎯 One-by-One Sequential (Best for Large Movies)"
            )
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Transfer Queue Mode")
                .setSingleChoiceItems(modes, if (curParallel) 0 else 1) { d, which ->
                    val isPar = (which == 0)
                    ytPrefs.edit().putBoolean("pref_share_is_parallel", isPar).apply()
                    tvMode?.text = modes[which]
                    d.dismiss()
                }
                .show()
        }

        // 3. Storage Save Directory
        val tvSaveDir = view.findViewById<TextView>(R.id.tvShareSaveDirVal)
        tvSaveDir?.text = FastShareManager.getSaveDirectoryDisplayName(this)
        view.findViewById<View>(R.id.rowShareSaveDir)?.setOnClickListener {
            val presetFolders = arrayOf(
                "Download/CleanPlayer (Default)",
                "Movies/CleanPlayer",
                "Music/CleanPlayer",
                "DCIM/CleanPlayer",
                "Documents/CleanPlayer",
                "Custom Folder..."
            )
            val currentDir = ytPrefs.getString("pref_share_save_dir", "Download/CleanPlayer") ?: "Download/CleanPlayer"
            var selectedIdx = when (currentDir) {
                "Download/CleanPlayer" -> 0
                "Movies/CleanPlayer" -> 1
                "Music/CleanPlayer" -> 2
                "DCIM/CleanPlayer" -> 3
                "Documents/CleanPlayer" -> 4
                else -> 5
            }

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Storage Save Location")
                .setSingleChoiceItems(presetFolders, selectedIdx) { dialogInterface, which ->
                    if (which == 5) {
                        dialogInterface.dismiss()
                        val customInput = EditText(this).apply {
                            hint = "e.g. Download/Shared"
                            setText(currentDir)
                            setSingleLine()
                            setTextColor(Color.WHITE)
                        }
                        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                            .setTitle("Enter Folder Name")
                            .setView(customInput)
                            .setPositiveButton("Save") { _, _ ->
                                val customPath = customInput.text.toString().trim()
                                if (customPath.isNotBlank()) {
                                    FastShareManager.setSaveDirectory(this, customPath)
                                    tvSaveDir?.text = FastShareManager.getSaveDirectoryDisplayName(this)
                                }
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    } else {
                        val chosenFolder = when (which) {
                            0 -> "Download/CleanPlayer"
                            1 -> "Movies/CleanPlayer"
                            2 -> "Music/CleanPlayer"
                            3 -> "DCIM/CleanPlayer"
                            4 -> "Documents/CleanPlayer"
                            else -> "Download/CleanPlayer"
                        }
                        FastShareManager.setSaveDirectory(this, chosenFolder)
                        tvSaveDir?.text = FastShareManager.getSaveDirectoryDisplayName(this)
                        dialogInterface.dismiss()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 4. Device Display Name
        val tvDevice = view.findViewById<TextView>(R.id.tvShareDeviceNameVal)
        val curName = ytPrefs.getString("pref_share_device_name", "CleanPlayer (" + Build.MODEL + ")") ?: "CleanPlayer"
        tvDevice?.text = curName
        view.findViewById<View>(R.id.rowShareDeviceName)?.setOnClickListener {
            val input = EditText(this).apply {
                setText(curName)
                setSingleLine()
                setTextColor(Color.WHITE)
            }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Device Display Name")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val newName = input.text.toString().trim()
                    if (newName.isNotBlank()) {
                        ytPrefs.edit().putString("pref_share_device_name", newName).apply()
                        tvDevice?.text = newName
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 5. Clear History
        view.findViewById<View>(R.id.rowShareClearHistory)?.setOnClickListener {
            ShareHistoryManager.clearHistory(this)
            refreshShareTabUI()
            dialog.dismiss()
        }

        dialog.show()
    }

    companion object {
        init {
            androidx.appcompat.app.AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        }
    }


    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnToolbarSearch: ImageButton
    private lateinit var btnToolbarSort: ImageButton
    private lateinit var btnToolbarOpen: ImageButton
    private lateinit var fabPlay: FloatingActionButton
    private lateinit var etSearch: EditText
    private lateinit var tabVideo: LinearLayout
    private lateinit var tabAudio: LinearLayout
    private lateinit var tabSettings: ScrollView
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var tabYouTube: FrameLayout
    private lateinit var layoutYtMainFeed: LinearLayout
        // YouTube Dedicated Settings Controls
    private lateinit var tvYtAdBlockStatus: TextView
    private lateinit var btnToggleYtAdBlock: Button
    private lateinit var tvYtSponsorBlockStatus: TextView
    private lateinit var btnConfigSponsorBlock: Button
    private lateinit var tvYtDefaultQualityStatus: TextView
    private lateinit var btnChangeYtQuality: Button
    private lateinit var tvYtExtractorBridgeStatus: TextView
    private lateinit var btnChangeYtExtractorBridge: Button
    private lateinit var tvYtClientSpoofingStatus: TextView
    private lateinit var btnChangeYtClient: Button
    private lateinit var tvYtBgAudioStatus: TextView
    private lateinit var btnToggleYtBgAudio: Button
    private lateinit var tvYtInterfaceStatus: TextView
    private lateinit var btnConfigYtUI: Button
    private lateinit var tvYtAccountStatus: TextView
    private lateinit var btnManageYtAccount: Button
    private lateinit var nsvYtFeed: NestedScrollView
    private lateinit var rvYouTubeFeed: RecyclerView
    private lateinit var rvYouTubeFeedSecondary: RecyclerView
    private lateinit var srlYouTubeFeed: androidx.swiperefreshlayout.widget.SwipeRefreshLayout
    private lateinit var pbYtFeedLoading: ProgressBar
    private lateinit var layoutYtEmpty: LinearLayout
    private lateinit var btnYtRetry: Button
    private lateinit var btnYtSearch: ImageButton
    private lateinit var btnYtAccount: ImageButton
    private lateinit var btnYtCast: ImageButton
    private lateinit var btnYtNotifications: ImageButton
    private lateinit var layoutYtSearchBar: LinearLayout
    private lateinit var etYtSearchQuery: EditText
    private lateinit var btnYtCloseSearch: ImageButton
    private lateinit var chipYtAll: TextView
    private lateinit var chipYtMusic: TextView
    private lateinit var chipYtGaming: TextView
    private lateinit var chipYtPodcasts: TextView
    private lateinit var chipYtLive: TextView
    private lateinit var chipYtTrending: TextView
    private lateinit var chipYtNews: TextView
        // YouTube You Tab & Fullscreen Fields
    private lateinit var rvYtHistory: RecyclerView
    private lateinit var rvYtDownloads: RecyclerView
    private var ytHistoryAdapter: YouTubeHistoryAdapter? = null
    private var ytDownloadsAdapter: YouTubeHistoryAdapter? = null
    private var isYtFullscreen = false
    // YouTube Overlay Controls Views (1:1 with Official YouTube)
    private lateinit var pbYtBottomMiniProgress: ProgressBar
    private lateinit var layoutYtPlayerOverlay: RelativeLayout
    private var btnYtAudioMode: ImageButton? = null
    private lateinit var layoutYtAudioModeVisual: LinearLayout
    private lateinit var ivYtAudioModeThumb: ImageView
    private lateinit var btnYtPlayerCC: ImageButton
    private lateinit var btnYtRewind10: ImageButton
    private lateinit var btnYtForward10: ImageButton
    private lateinit var tvYtPlayerCurrentTime: TextView
    private lateinit var sbYtPlayer: SeekBar
    private var isYtUserSeeking = false
    private var isYtAutoplayEnabled = true
    private val ytOverlayHandler = Handler(Looper.getMainLooper())
    private val ytOverlayHideRunnable = Runnable {
        if (YouTubeExoPlayerManager.isPlaying()) {
            layoutYtPlayerOverlay.animate()
                .alpha(0f)
                .setDuration(250)
                .withEndAction {
                    layoutYtPlayerOverlay.visibility = View.GONE
                    layoutYtPlayerOverlay.alpha = 1f
                }
                .start()
        }
    }

    private lateinit var youTubeFeedAdapter: YouTubeFeedAdapter
    private lateinit var youTubeFeedSecondaryAdapter: YouTubeFeedAdapter
    private var currentYtCategory: String = "All"
    private var isYtFeedLoaded = false
    private var lastActiveTabId = R.id.nav_video

    // YouTube Dedicated Bottom Nav
    private lateinit var btnYtNavHome: LinearLayout
    private lateinit var btnYtNavSubs: LinearLayout
    private lateinit var btnYtNavLibrary: LinearLayout

    // YouTube Portrait Detail Player (Matching Screenshot 5681.jpg)
    private lateinit var layoutYtPlayerDetail: LinearLayout
    private lateinit var playerViewYt: androidx.media3.ui.PlayerView
    private lateinit var pbYtBuffering: ProgressBar
    private lateinit var btnYtCenterPlayPause: ImageButton
    private lateinit var btnYtCollapsePlayer: ImageButton
    private lateinit var btnYtFullscreen: ImageButton
    private lateinit var tvYtDetailTitle: TextView
    private lateinit var tvYtDetailSubtitle: TextView
    private lateinit var ivYtDetailAvatar: ImageView
    private lateinit var tvYtDetailChannel: TextView
    private lateinit var btnYtSubscribe: TextView
    private lateinit var layoutYtLikePill: LinearLayout
    private lateinit var tvYtDetailLikes: TextView
    private lateinit var layoutYtSharePill: LinearLayout
    private lateinit var layoutYtDownloadPill: LinearLayout
    private lateinit var tvYtDownloadPill: TextView
    private lateinit var ivYtDownloadPill: ImageView
    private lateinit var tvYtAudioQualityStatus: TextView
    private lateinit var btnChangeYtAudioQuality: Button
    private lateinit var tvYtBufferLimitStatus: TextView
    private lateinit var btnChangeYtBufferLimit: Button



    // Audio Mode Visualizer View
    private lateinit var ytAudioVisualizerView: AudioVisualizerView
    private var ytMiniAudioVisualizerView: AudioVisualizerView? = null
    private var btnYtPrevVideo: ImageButton? = null
    private var btnYtNextVideo: ImageButton? = null
    private var layoutYtGestureOverlay: View? = null
    private var ivYtGestureIcon: ImageView? = null
    private var tvYtGestureText: TextView? = null
    private val ytGestureHideHandler = Handler(Looper.getMainLooper())
    private val ytGestureHideRunnable = Runnable {
        layoutYtGestureOverlay?.visibility = View.GONE
    }

    private fun showYtGestureFeedback(iconRes: Int, text: String) {
        layoutYtGestureOverlay?.bringToFront()
        layoutYtGestureOverlay?.visibility = View.VISIBLE
        ivYtGestureIcon?.setImageResource(iconRes)
        tvYtGestureText?.text = text
        ytGestureHideHandler.removeCallbacks(ytGestureHideRunnable)
        ytGestureHideHandler.postDelayed(ytGestureHideRunnable, 1200)
    }
    private var isYtLoadingMore = false
    private val allYtFeedVideos = mutableListOf<YouTubeVideo>()

    private val ytVisualizerHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val ytVisualizerRunnable = object : Runnable {
        override fun run() {
            val ytPlayer = YouTubeExoPlayerManager.exoPlayer
            if (ytPlayer != null && ytPlayer.isPlaying) {
                val cur = ytPlayer.currentPosition
                val dur = ytPlayer.duration
                if (::layoutYtAudioModeVisual.isInitialized && layoutYtAudioModeVisual.visibility == View.VISIBLE) {
                    ytAudioVisualizerView.onPlaybackProgress(cur, dur)
                }
                if (::cardYtMiniPlayer.isInitialized && cardYtMiniPlayer.visibility == View.VISIBLE && ytMiniAudioVisualizerView?.visibility == View.VISIBLE) {
                    ytMiniAudioVisualizerView?.onPlaybackProgress(cur, dur)
                }
            }
            ytVisualizerHandler.postDelayed(this, 100)
        }
    }

    private val ytMediaReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "com.cleanplayer.app.ACTION_YT_PLAY_NEXT" -> playNextYouTubeVideo()
                "com.cleanplayer.app.ACTION_YT_PLAY_PREV" -> playPreviousYouTubeVideo()
            }
        }
    }
    private lateinit var layoutYtSavePill: LinearLayout
    private lateinit var layoutYtCommentsCard: LinearLayout
    private lateinit var tvYtDetailCommentsCount: TextView
    private lateinit var rvYtRelatedVideos: RecyclerView

    // YouTube Floating Miniplayer (Matching Screenshots 5682.jpg & 5680.jpg)
    private lateinit var cardYtMiniPlayer: MaterialCardView
    private lateinit var ivYtMiniThumb: ImageView
    private lateinit var tvYtMiniTitle: TextView
    private lateinit var tvYtMiniChannel: TextView
    private lateinit var btnYtMiniPlayPause: ImageButton
    private lateinit var btnYtMiniClose: ImageButton
    private lateinit var layoutYtMiniControlsOverlay: View
    private lateinit var btnYtMiniExpand: ImageButton
    private val ytMiniControlsHideHandler = Handler(Looper.getMainLooper())
    private val ytMiniControlsHideRunnable = Runnable {
        if (::layoutYtMiniControlsOverlay.isInitialized) {
            layoutYtMiniControlsOverlay.visibility = View.GONE
        }
    }
    private lateinit var playerViewYtMini: androidx.media3.ui.PlayerView
    private lateinit var ytScaleGestureDetector: ScaleGestureDetector
    private var ytAspectRatioMode = 0 // 0: Fit, 1: Zoom to fill, 2: Stretch
    private var isYtPinchActive = false

    private var currentPlayingYtVideo: YouTubeVideo? = null
    private var isYtVideoPlaying: Boolean = false

    private lateinit var btnViewAllVideos: TextView
    private lateinit var btnViewFolders: TextView
    private lateinit var rvVideos: RecyclerView
    private lateinit var layoutFoldersContainer: LinearLayout
    private lateinit var rvFolders: RecyclerView
    private lateinit var layoutFolderDetailHeader: LinearLayout
    private lateinit var btnFolderBack: ImageButton
    private lateinit var tvFolderHeaderTitle: TextView
    private lateinit var tvFolderHeaderSubtitle: TextView
    private lateinit var rvFolderVideos: RecyclerView
    private lateinit var layoutEmptyVideo: LinearLayout
    private lateinit var btnBrowseVideo: Button

    private var isFolderViewActive: Boolean = false
    private var allFolders: List<MediaFolder> = emptyList()
    private var currentSelectedFolder: MediaFolder? = null
    private var folderAdapter: FolderAdapter? = null
    private var folderVideoAdapter: MediaAdapter? = null

    private lateinit var rvAudio: RecyclerView
    private lateinit var layoutEmptyAudio: LinearLayout
    private lateinit var btnBrowseAudio: Button

    // 1. Video Settings Views
    private lateinit var tvHighRefreshRateStatus: TextView
    private lateinit var btnToggleHighRefreshRate: Button
    private lateinit var tvDefaultOrientationStatus: TextView
    private lateinit var btnChangeOrientation: Button

    // Top Notch Mini-Player Views (matches 5203.jpg)
    private lateinit var cardNotchPlayer: MaterialCardView
    private lateinit var ivNotchIcon: ImageView
    private lateinit var tvNotchTitle: TextView
    private lateinit var tvNotchArtist: TextView
    private lateinit var btnNotchClose: ImageButton
    private lateinit var btnNotchRepeat: ImageButton
    private lateinit var btnNotchPrev: ImageButton
    private lateinit var btnNotchPlayPause: ImageButton
    private lateinit var btnNotchNext: ImageButton
    private lateinit var btnNotchOpen: ImageButton
    private lateinit var tvNotchCurrent: TextView
    private lateinit var sbNotch: SeekBar
    private lateinit var tvNotchTotal: TextView
    private lateinit var tvVideoColorStatus: TextView
    private lateinit var btnChangeVideoColor: Button
    private lateinit var tvWideColorStatus: TextView
    private lateinit var btnToggleWideColor: Button
    private lateinit var tvDeblockingStatus: TextView
    private lateinit var btnToggleDeblocking: Button
    private lateinit var tvHwDecodeStatus: TextView
    private lateinit var btnChangeHw: Button
    private lateinit var tvBgPipStatus: TextView
    private lateinit var btnChangeBgPip: Button
    private lateinit var tvResumeModeStatus: TextView
    private lateinit var btnChangeResumeMode: Button
    private lateinit var tvDoubleTapStatus: TextView
    private lateinit var btnChangeDoubleTap: Button
    private lateinit var tvAspectRatioStatus: TextView
    private lateinit var btnChangeAspectRatio: Button
    private lateinit var tvAudioBoostStatus: TextView
    private lateinit var btnToggleAudioBoost: Button

    // 2. Integrated Dolby, Spatial & Equalizer Audio Suite Views
    private lateinit var tvMasterProfileStatus: TextView
    private lateinit var btnChangeMasterProfile: Button
    private lateinit var tvDolbySurroundStatus: TextView
    private lateinit var btnChangeDolbySurround: Button
    private lateinit var tvEqualizerStatus: TextView
    private lateinit var btnChangeEqualizer: Button
    private lateinit var tvDialogueBoostStatus: TextView
    private lateinit var btnToggleDialogueBoost: Button
    private lateinit var tvDigitalPassthroughStatus: TextView
    private lateinit var btnTogglePassthrough: Button
    private lateinit var tvAudioOutputStatus: TextView
    private lateinit var btnChangeAudioOutput: Button
    private lateinit var tvHeadsetPauseStatus: TextView
    private lateinit var btnToggleHeadsetPause: Button
    private lateinit var tvTimeStretchStatus: TextView
    private lateinit var btnToggleTimeStretch: Button

    // 3. Subtitle Settings Views
    private lateinit var btnToggleSubAutoload: Button
    private lateinit var tvSubSizeStatus: TextView
    private lateinit var btnChangeSubSize: Button
    private lateinit var tvSubColorStatus: TextView
    private lateinit var btnChangeSubColor: Button
    private lateinit var tvSubBackgroundStatus: TextView
    private lateinit var btnChangeSubBackground: Button
    private lateinit var tvSubStyleStatus: TextView
    private lateinit var btnToggleSubStyle: Button
    private lateinit var tvSubEncodingStatus: TextView
    private lateinit var btnChangeSubEncoding: Button

    // 4. Gestures Settings Views
    private lateinit var tvGestureVolumeStatus: TextView
    private lateinit var btnToggleGestureVolume: Button
    private lateinit var tvGestureBrightnessStatus: TextView
    private lateinit var btnToggleGestureBrightness: Button
    private lateinit var tvGestureSeekStatus: TextView
    private lateinit var btnToggleGestureSeek: Button
    private lateinit var tvFastSeekStatus: TextView
    private lateinit var btnToggleFastSeek: Button

    // 5. Interface Settings Views
    private lateinit var tvAppThemeStatus: TextView
    private lateinit var btnChangeAppTheme: Button

    // 6. Advanced Settings Views
    private lateinit var btnClearCache: Button
    private lateinit var btnClearResume: Button
    private lateinit var btnResetSettings: Button
    private lateinit var tvCacheSizeStatus: TextView

    private var allVideos = listOf<MediaItem>()
    private var allAudio = listOf<MediaItem>()
    private var videoAdapter: MediaAdapter? = null
    private var audioAdapter: MediaAdapter? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val title = PlayerHolder.resolveMediaTitle(this, it, null)
            val type = contentResolver.getType(it) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(it, title, isVideo, null)
        }
    }

    private val subtitlePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            // Silent notification removed
        }
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        loadMediaFiles()
    }

    private var pendingCameraAction: (() -> Unit)? = null
    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            pendingCameraAction?.invoke()
        } else {
            Toast.makeText(this, "Camera permission needed to scan sender's QR code", Toast.LENGTH_SHORT).show()
            showShareReceiveDialog()
        }
        pendingCameraAction = null
    }

    private fun checkCameraPermissionAndScan(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            onGranted()
        } else {
            pendingCameraAction = onGranted
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private var pendingShareAction: (() -> Unit)? = null
    private val sharePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val nearbyGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions[Manifest.permission.NEARBY_WIFI_DEVICES] ?: (ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED)
        } else true
        val locationGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (nearbyGranted || locationGranted) {
            pendingShareAction?.invoke()
        } else {
            Toast.makeText(this, "Nearby devices permission required for 5GHz P2P Share", Toast.LENGTH_LONG).show()
        }
        pendingShareAction = null
    }

    private fun checkSharePermissionsAndRun(action: () -> Unit) {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_IMAGES)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (needed.isNotEmpty()) {
            pendingShareAction = action
            sharePermissionLauncher.launch(needed.toTypedArray())
        } else {
            action()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        PlayerHolder.loadPreferences(this)
        if (PlayerHolder.isMonochrome()) {
            setTheme(R.style.Theme_Multimedia_Monochrome)
        } else {
            setTheme(R.style.Theme_Multimedia)
        }
        super.onCreate(savedInstanceState)
        applyHighRefreshRate()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        setContentView(R.layout.activity_main)

        // Initialize Downloader instance
        try {
            // Eager engine warmup
        } catch (e: Throwable) {}

        onBackPressedDispatcher.addCallback(this) {
            if (!handleBackPress()) {
                moveTaskToBack(true)
            }
        }

        YouTubeStreamResolver.initNewPipe(this)
        initViews()
        setupBottomNav()
        setupShareTab()
        setupSearch()
        setupVideoSettings()
        setupAudioSuiteSettings()
        setupSubtitleSettings()
        setupGestureSettings()
        setupInterfaceAndAdvancedSettings()
        applyThemeUI()
                applyAppWideImmersiveMode()
        if (::tabShare.isInitialized) {
            refreshShareTabUI()
        }
        if (intent?.getStringExtra("OPEN_TAB") == "SHARE") {
            intent?.removeExtra("OPEN_TAB")
            showTab(video = false, audio = false, youtube = false, share = true, settings = false)
            bottomNav.selectedItemId = R.id.nav_share
            if (FastShareService.isTransferActive.get() && (activeShareProgressDialog == null || !activeShareProgressDialog!!.isShowing)) {
                showShareProgressDialog(isSender = FastShareService.isSenderMode, filePaths = emptyList())
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(window.decorView.findViewById(android.R.id.content)) { _, insets ->
            val navInsets = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            val bottomInset = if (isYtFullscreen) 0 else navInsets.bottom

            findViewById<View>(R.id.bottomNav)?.setPadding(0, 0, 0, bottomInset)
            findViewById<View>(R.id.layoutYtBottomBar)?.setPadding(0, 0, 0, bottomInset)

            if (::cardYtMiniPlayer.isInitialized) {
                val miniLp = cardYtMiniPlayer.layoutParams as? FrameLayout.LayoutParams
                if (miniLp != null) {
                    val baseMargin = (68 * resources.displayMetrics.density).toInt()
                    miniLp.bottomMargin = baseMargin + bottomInset
                    cardYtMiniPlayer.layoutParams = miniLp
                }
            }
            insets
        }

        val filter = android.content.IntentFilter().apply {
            addAction("com.cleanplayer.app.ACTION_YT_PLAY_NEXT")
            addAction("com.cleanplayer.app.ACTION_YT_PLAY_PREV")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(ytMediaReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(ytMediaReceiver, filter)
        }

        val ytPrefsInit = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        isYtAutoplayEnabled = ytPrefsInit.getBoolean("pref_yt_autoplay", true)
        YouTubeExoPlayerManager.onVideoEnded = {
            if (isYtAutoplayEnabled) {
                playNextYouTubeVideo()
            }
        }

        checkAndRequestPermissions()

        val openFullPlayer = {
            val uri = PlayerHolder.currentUri
            if (uri != null) {
                openPlayer(uri, PlayerHolder.currentTitle, isVideo = !PlayerHolder.isAudioOnly, path = PlayerHolder.currentPath)
            }
        }
        cardNotchPlayer.setOnClickListener {
            if (isLocalMediaActive()) {
                openFullPlayer()
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                showTab(video = false, audio = false, youtube = true, settings = false)
                layoutYtPlayerDetail.visibility = View.VISIBLE
                if (::playerViewYtMini.isInitialized) {
            YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
        }
        YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        applyYouTubeAspectRatio(ytAspectRatioMode)
            }
        }
        btnNotchOpen.setOnClickListener {
            if (isLocalMediaActive()) {
                openFullPlayer()
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                showTab(video = false, audio = false, youtube = true, settings = false)
                layoutYtPlayerDetail.visibility = View.VISIBLE
                YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
            }
        }

        btnNotchPlayPause.setOnClickListener {
            if (isLocalMediaActive()) {
                val audioPlayer = PlayerHolder.audioExoPlayer
                if (audioPlayer != null) {
                    if (audioPlayer.isPlaying) audioPlayer.pause() else audioPlayer.play()
                    btnNotchPlayPause.setImageResource(
                        if (audioPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                    MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = audioPlayer.isPlaying)
                } else {
                    PlayerHolder.mediaPlayer?.let { player ->
                        if (player.isPlaying) {
                            player.pause()
                            btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_play)
                            MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = false)
                        } else {
                            player.play()
                            btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_pause)
                            MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = true)
                        }
                    }
                }
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                YouTubeExoPlayerManager.togglePlayPause()
                val isPlaying = YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
                btnNotchPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            }
        }

        btnNotchPrev.setOnClickListener {
            if (isLocalMediaActive()) {
                PlayerHolder.playPrevious(this)
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                val current = YouTubeExoPlayerManager.getCurrentPosition()
                YouTubeExoPlayerManager.seekTo((current - 10000).coerceAtLeast(0))
            }
        }

        btnNotchNext.setOnClickListener {
            if (isLocalMediaActive()) {
                PlayerHolder.playNext(this)
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                val current = YouTubeExoPlayerManager.getCurrentPosition()
                val duration = YouTubeExoPlayerManager.getDuration()
                YouTubeExoPlayerManager.seekTo((current + 10000).coerceAtMost(duration))
            }
        }

        btnNotchRepeat.setOnClickListener {
            if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                val p = YouTubeExoPlayerManager.exoPlayer!!
                val nextMode = when (p.repeatMode) {
                    androidx.media3.common.Player.REPEAT_MODE_OFF -> androidx.media3.common.Player.REPEAT_MODE_ONE
                    androidx.media3.common.Player.REPEAT_MODE_ONE -> androidx.media3.common.Player.REPEAT_MODE_ALL
                    else -> androidx.media3.common.Player.REPEAT_MODE_OFF
                }
                p.repeatMode = nextMode
                val displayMode = when (nextMode) {
                    androidx.media3.common.Player.REPEAT_MODE_ONE -> 2
                    androidx.media3.common.Player.REPEAT_MODE_ALL -> 1
                    else -> 0
                }
                updateNotchRepeatUI(displayMode)
            } else {
                val mode = PlayerHolder.toggleRepeatMode()
                updateNotchRepeatUI(mode)
            }
        }

        btnNotchClose.setOnClickListener {
            if (isLocalMediaActive()) {
                PlayerHolder.release()
                MediaPlaybackService.stop(this)
                audioAdapter?.setPlayingUri(null)
            } else {
                YouTubeExoPlayerManager.pause()
                YouTubeExoPlayerManager.stop()
                YouTubeExoPlayerManager.currentPlayingVideo = null
                currentPlayingYtVideo = null
                isYtVideoPlaying = false
            }
            cardNotchPlayer.visibility = View.GONE
        }

        sbNotch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    tvNotchCurrent.text = formatTime(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                sb?.let {
                    val target = it.progress.toLong()
                    if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                        YouTubeExoPlayerManager.seekTo(target)
                    } else if (PlayerHolder.audioExoPlayer != null) {
                        PlayerHolder.audioExoPlayer?.seekTo(target)
                    } else {
                        PlayerHolder.mediaPlayer?.time = target
                    }
                }
            }
        })

        intent?.data?.let { uri ->
            val title = PlayerHolder.resolveMediaTitle(this, uri, null)
            val type = intent?.type ?: contentResolver.getType(uri) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(uri, title, isVideo, null)
        }
    }

    private val notchProgressHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val notchProgressRunnable = object : Runnable {
        override fun run() {
            // 1. YouTube Player Real-Time Progress & Time Tracking (independent of cardNotchPlayer)
            val ytPlayer = YouTubeExoPlayerManager.exoPlayer
            val ytVideo = YouTubeExoPlayerManager.currentPlayingVideo
            if (ytPlayer != null && ytVideo != null) {
                val current = ytPlayer.currentPosition.coerceAtLeast(0L)
                val duration = ytPlayer.duration.let { if (it > 0) it else 0L }

                if (::tvYtPlayerCurrentTime.isInitialized && !isYtUserSeeking) {
                    if (duration > 0) {
                        tvYtPlayerCurrentTime.text = "${formatTime(current)} / ${formatTime(duration)}"
                        sbYtPlayer.max = duration.toInt()
                        sbYtPlayer.progress = current.toInt()
                        if (::pbYtBottomMiniProgress.isInitialized && !YouTubeExoPlayerManager.isAudioOnlyMode) {
                            pbYtBottomMiniProgress.max = duration.toInt()
                            pbYtBottomMiniProgress.progress = current.toInt()
                        }
                    } else if (current > 0) {
                        tvYtPlayerCurrentTime.text = "${formatTime(current)} / --:--"
                    }
                }

                if (cardNotchPlayer.visibility == View.VISIBLE && duration > 0) {
                    sbNotch.max = duration.toInt()
                    sbNotch.progress = current.toInt()
                    tvNotchCurrent.text = formatTime(current)
                    tvNotchTotal.text = formatTime(duration)
                    btnNotchPlayPause.setImageResource(
                        if (ytPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                }
            }

            // 2. Local Media Player Progress (Audio / Video)
            if (cardNotchPlayer.visibility == View.VISIBLE && isLocalMediaActive()) {
                val audioPlayer = PlayerHolder.audioExoPlayer
                val vlcPlayer = PlayerHolder.mediaPlayer

                if (audioPlayer != null && PlayerHolder.currentUri != null) {
                    val current = audioPlayer.currentPosition
                    val duration = audioPlayer.duration
                    if (duration > 0) {
                        sbNotch.max = duration.toInt()
                        sbNotch.progress = current.toInt()
                        tvNotchCurrent.text = formatTime(current)
                        tvNotchTotal.text = formatTime(duration)
                    }
                    btnNotchPlayPause.setImageResource(
                        if (audioPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                } else if (vlcPlayer != null && PlayerHolder.currentUri != null) {
                    val current = vlcPlayer.time
                    val duration = vlcPlayer.length
                    if (duration > 0) {
                        sbNotch.max = duration.toInt()
                        sbNotch.progress = current.toInt()
                        tvNotchCurrent.text = formatTime(current)
                        tvNotchTotal.text = formatTime(duration)
                    }
                    btnNotchPlayPause.setImageResource(
                        if (vlcPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                }
            }
            notchProgressHandler.postDelayed(this, 1000)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(ytMediaReceiver) } catch (e: Exception) {}
        ytVisualizerHandler.removeCallbacks(ytVisualizerRunnable)
        try {
            if (::playerViewYt.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            }
            if (::playerViewYtMini.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
            }
        } catch (e: Exception) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applyAppWideImmersiveMode()
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applyAppWideImmersiveMode()
        if (::layoutYtPlayerDetail.isInitialized && layoutYtPlayerDetail.visibility == View.VISIBLE) {
            val surfaceContainer = findViewById<View>(R.id.layoutYtPlayerSurfaceContainer)
            val detailsScroll = (layoutYtPlayerDetail as? android.view.ViewGroup)?.getChildAt(1)

            if (newConfig.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
                isYtFullscreen = true
                detailsScroll?.visibility = View.GONE
                findViewById<View>(R.id.bottomNav)?.visibility = View.GONE
                if (::fabPlay.isInitialized) fabPlay.visibility = View.GONE
                val lp = surfaceContainer?.layoutParams
                if (lp != null) {
                    lp.height = LinearLayout.LayoutParams.MATCH_PARENT
                    lp.width = LinearLayout.LayoutParams.MATCH_PARENT
                    surfaceContainer.layoutParams = lp
                }
                btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen_exit)
                enableImmersiveNotchMode()
                applyYouTubeAspectRatio(ytAspectRatioMode)
                showYouTubeOverlay()
            } else if (newConfig.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT) {
                isYtFullscreen = false
                detailsScroll?.visibility = View.VISIBLE
                findViewById<View>(R.id.bottomNav)?.visibility = View.VISIBLE
                updateFabPlayVisibility()
                val lp = surfaceContainer?.layoutParams
                if (lp != null) {
                    lp.height = (230 * resources.displayMetrics.density).toInt()
                    lp.width = LinearLayout.LayoutParams.MATCH_PARENT
                    surfaceContainer.layoutParams = lp
                }
                btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen)
                window.statusBarColor = Color.parseColor("#0F0F0F")
                applyYouTubeAspectRatio(ytAspectRatioMode)
                showYouTubeOverlay()
            }
        }
    }

    private fun applyAppWideImmersiveMode() {
        try {
            window.navigationBarColor = Color.TRANSPARENT
            window.statusBarColor = Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.isNavigationBarContrastEnforced = false
                window.isStatusBarContrastEnforced = false
            }
            val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            val shouldHideNav = isYtFullscreen || (isLandscape && tabYouTube.visibility == View.VISIBLE && layoutYtPlayerDetail.visibility == View.VISIBLE)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.let { controller ->
                    if (shouldHideNav) {
                        controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                    } else {
                        controller.hide(WindowInsets.Type.statusBars())
                        controller.show(WindowInsets.Type.navigationBars())
                    }
                    controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            } else {
                @Suppress("DEPRECATION")
                if (shouldHideNav) {
                    window.decorView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    )
                } else {
                    window.decorView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    )
                }
            }
        } catch (e: Exception) {}
    }


    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getStringExtra("OPEN_TAB") == "SHARE") {
            showTab(video = false, audio = false, youtube = false, share = true, settings = false)
            bottomNav.selectedItemId = R.id.nav_share
            if (FastShareService.isTransferActive.get() && (activeShareProgressDialog == null || !activeShareProgressDialog!!.isShowing)) {
                showShareProgressDialog(isSender = FastShareService.isSenderMode, filePaths = emptyList())
            }
        }
    }

    override fun onResume() {
        super.onResume()
        applyAppWideImmersiveMode()

        YouTubeExoPlayerManager.onAudioModeChanged = { isAudioOnly ->
            runOnUiThread {
                updateAudioModeUI(isAudioOnly)
            }
        }

        notchProgressHandler.removeCallbacks(notchProgressRunnable)
        notchProgressHandler.post(notchProgressRunnable)

        YouTubeExoPlayerManager.onAppForegrounded(this)

        if (::playerViewYt.isInitialized) {
            if (!YouTubeExoPlayerManager.isAudioOnlyMode && currentPlayingYtVideo != null) {
                playerViewYt.visibility = View.VISIBLE
                YouTubeExoPlayerManager.reattachPlayerView(playerViewYt)
                updateAudioModeUI(false)
            } else {
                updateAudioModeUI(YouTubeExoPlayerManager.isAudioOnlyMode)
            }
        }
        YouTubeDownloaderHelper.onDownloadProgressChanged = { downloadId, percent, downStr, totalStr, status ->
            runOnUiThread {
                tvYtDownloadPill.text = "" + percent + "%"
                ivYtDownloadPill.setColorFilter(Color.parseColor("#3EA6FF"))
            }
        }

        YouTubeDownloaderHelper.onDownloadFinished = { downloadId, fileName, success ->
            runOnUiThread {
                if (success) {
                    tvYtDownloadPill.text = "Downloaded"
                    ivYtDownloadPill.setImageResource(R.drawable.ic_check_player)
                    ivYtDownloadPill.setColorFilter(Color.parseColor("#00E676"))
                } else {
                    tvYtDownloadPill.text = "Download"
                    ivYtDownloadPill.setImageResource(R.drawable.ic_download)
                    ivYtDownloadPill.setColorFilter(Color.WHITE)
                }
            }
        }

        YouTubeExoPlayerManager.onPlaybackStateChanged = { isPlaying ->
            runOnUiThread {
                isYtVideoPlaying = isPlaying
                btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                btnYtCenterPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                updateNotchPlayerUI()

                if (::ytAudioVisualizerView.isInitialized) {
                    ytAudioVisualizerView.setPlaying(isPlaying)
                    val sId = YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0
                    if (sId > 0) ytAudioVisualizerView.linkToAudio(sId)
                }
                ytMiniAudioVisualizerView?.let { mini ->
                    mini.setPlaying(isPlaying)
                    val sId = YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0
                    if (sId > 0) mini.linkToAudio(sId)
                }
                if (isPlaying) {
                    ytVisualizerHandler.removeCallbacks(ytVisualizerRunnable)
                    ytVisualizerHandler.post(ytVisualizerRunnable)
                }
            }
        }
        YouTubeExoPlayerManager.onBufferingStateChanged = { isBuffering ->
            runOnUiThread {
                pbYtBuffering.visibility = if (isBuffering) View.VISIBLE else View.GONE
                if (!isBuffering) {
                    if (layoutYtPlayerOverlay.visibility == View.VISIBLE) {
                        btnYtCenterPlayPause.visibility = View.VISIBLE
                    }
                } else {
                    btnYtCenterPlayPause.visibility = View.GONE
                }
            }
        }
        YouTubeExoPlayerManager.onSponsorSkipped = { label ->
            showYtGestureFeedback(R.drawable.ic_forward_10, "Skipped $label [SponsorBlock]")
        }
        YouTubeExoPlayerManager.onPlayerError = { error ->
            runOnUiThread {
                pbYtBuffering.visibility = View.GONE
                btnYtCenterPlayPause.visibility = View.VISIBLE
                btnYtCenterPlayPause.setImageResource(R.drawable.ic_play_player)
                val v = currentPlayingYtVideo
                if (v != null) {
                    // Unwanted popup removed
                    YouTubeStreamResolver.resolveStreams(v.id, 480) { resStream ->
                        if (resStream != null) {
                            val fastOpt = resStream.availableQualities.firstOrNull { it.audioUrl == null }
                            val url = fastOpt?.videoUrl ?: resStream.videoUrl
                            YouTubeExoPlayerManager.playVideo(
                                context = this,
                                video = v,
                                videoStreamUrl = url,
                                audioStreamUrl = null,
                                pureAudioUrl = resStream.pureAudioUrl,
                                allAudioUrls = resStream.allAudioUrls
                            )
                        } else {
                            // Unwanted popup removed
                        }
                    }
                }
            }
        }
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        }
        updateSettingsUI()
        updateNotchPlayerUI()
        audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
        notchProgressHandler.post(notchProgressRunnable)

        PlayerHolder.onTrackChangedListener = { item ->
            runOnUiThread {
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(item.uri)
            }
        }
        PlayerHolder.onPlaybackStateChangedListener = { isPlaying ->
            runOnUiThread {
                btnNotchPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
                audioAdapter?.notifyDataSetChanged()
                updateNotchPlayerUI()
            }
        }

    }

    private fun updateAudioModeUI(isAudioOnly: Boolean) {
        if (isAudioOnly) {
            layoutYtAudioModeVisual.visibility = View.VISIBLE
            btnYtAudioMode?.setImageResource(R.drawable.ic_video)
            btnYtAudioMode?.setColorFilter(Color.parseColor("#FF8800"))
            ivYtAudioModeThumb.visibility = View.VISIBLE
            currentPlayingYtVideo?.let { v ->
                ImageLoaderHelper.loadImage(v.thumbnailUrl, ivYtAudioModeThumb, R.drawable.ic_audio)
            }
            ytAudioVisualizerView.visibility = View.GONE
            ytAudioVisualizerView.setPlaying(false)
            ivYtMiniThumb.visibility = View.VISIBLE
            ytMiniAudioVisualizerView?.visibility = View.GONE
            playerViewYt.visibility = View.INVISIBLE
            if (::pbYtBottomMiniProgress.isInitialized) {
                pbYtBottomMiniProgress.visibility = View.GONE
            }
        } else {
            layoutYtAudioModeVisual.visibility = View.GONE
            ytAudioVisualizerView.visibility = View.GONE
            ytAudioVisualizerView.setPlaying(false)
            ivYtMiniThumb.visibility = View.VISIBLE
            ytMiniAudioVisualizerView?.visibility = View.GONE
            btnYtAudioMode?.setImageResource(R.drawable.ic_audio)
            btnYtAudioMode?.setColorFilter(Color.WHITE)
            playerViewYt.visibility = View.VISIBLE
            YouTubeExoPlayerManager.reattachPlayerView(playerViewYt)
        }
        showYouTubeOverlay()
    }

    override fun onStop() {
        super.onStop()
        val isPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        val isBackgroundAllowed = PlayerHolder.isBackgroundPlayEnabled || PlayerHolder.backgroundPipMode > 0
        if (!isPip && isBackgroundAllowed && YouTubeExoPlayerManager.isPlaying()) {
            YouTubeExoPlayerManager.onAppBackgrounded(this)
            currentPlayingYtVideo?.let { v ->
                MediaPlaybackService.start(
                    context = this,
                    title = v.title,
                    artist = v.channelTitle,
                    isPlaying = true,
                    isYouTube = true,
                    thumbUrl = v.thumbnailUrl
                )
            }
        }
    }

    override fun onPause() {
        super.onPause()
        notchProgressHandler.removeCallbacks(notchProgressRunnable)
        PlayerHolder.onTrackChangedListener = null
        PlayerHolder.onPlaybackStateChangedListener = null
        // Media3 ExoPlayer handles background audio playback and PiP
    }

    private fun updateNotchRepeatUI(mode: Int) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        when (mode) {
            1 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat_one)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            2 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            else -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(secondaryColor)
            }
        }
    }

    private fun isLocalMediaActive(): Boolean {
        val audioPlayer = PlayerHolder.audioExoPlayer
        val vlcPlayer = PlayerHolder.mediaPlayer
        val isAudioPlaying = audioPlayer != null && audioPlayer.isPlaying
        val isVlcPlaying = vlcPlayer != null && vlcPlayer.isPlaying
        if (isAudioPlaying || isVlcPlaying) return true
        if (PlayerHolder.currentUri != null && (audioPlayer != null || vlcPlayer != null)) {
            val ytPlayer = YouTubeExoPlayerManager.exoPlayer
            val isYtPlaying = ytPlayer != null && ytPlayer.isPlaying
            return !isYtPlaying
        }
        return false
    }

    private fun updateNotchPlayerUI() {
        if (::layoutYtPlayerDetail.isInitialized && layoutYtPlayerDetail.visibility == View.VISIBLE) {
            cardNotchPlayer.visibility = View.GONE
            return
        }
        val ytVideo = YouTubeExoPlayerManager.currentPlayingVideo
        val ytPlayer = YouTubeExoPlayerManager.exoPlayer
        val audioPlayer = PlayerHolder.audioExoPlayer
        val vlcPlayer = PlayerHolder.mediaPlayer

        if (ytPlayer != null && ytVideo != null && ytPlayer.playbackState != androidx.media3.common.Player.STATE_IDLE) {
            // 1. YouTube Online Streaming Active in Notch (Only while playing!)
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = ytVideo.title
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = ytVideo.channelTitle
            val isPlaying = ytPlayer.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = ytPlayer.duration
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                val current = ytPlayer.currentPosition
                sbNotch.progress = current.toInt()
                tvNotchCurrent.text = formatTime(current)
                tvNotchTotal.text = formatTime(duration)
            }
            if (!ytVideo.thumbnailUrl.isNullOrBlank()) {
                ImageLoaderHelper.load(this, ytVideo.thumbnailUrl, ivNotchIcon)
            } else {
                ivNotchIcon.setImageResource(R.drawable.ic_youtube)
            }
        } else if (audioPlayer != null && PlayerHolder.currentUri != null && audioPlayer.isPlaying) {
            // 2. Local Audio Media3 Active in Notch (Only while playing!)
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = PlayerHolder.currentTitle
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = PlayerHolder.currentArtist
            val isPlaying = audioPlayer.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = audioPlayer.duration
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                val current = audioPlayer.currentPosition
                sbNotch.progress = current.toInt()
                tvNotchCurrent.text = formatTime(current)
                tvNotchTotal.text = formatTime(duration)
            }
            ivNotchIcon.setImageResource(R.drawable.ic_audio)
        } else if (vlcPlayer != null && PlayerHolder.currentUri != null && vlcPlayer.isPlaying) {
            // 3. Local Video VLC Active in Notch (Only while playing!)
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = PlayerHolder.currentTitle
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = PlayerHolder.currentArtist
            val isPlaying = vlcPlayer.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = vlcPlayer.length
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                sbNotch.progress = vlcPlayer.time.toInt()
                tvNotchCurrent.text = formatTime(vlcPlayer.time)
                tvNotchTotal.text = formatTime(duration)
            }
            ivNotchIcon.setImageResource(R.drawable.ic_video)
        } else {
            cardNotchPlayer.visibility = View.GONE
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (hours > 0) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    private fun showSortDialog() {
        val sortOptions = arrayOf(
            getString(R.string.sort_name_asc),
            getString(R.string.sort_name_desc),
            getString(R.string.sort_date_newest),
            getString(R.string.sort_duration),
            getString(R.string.sort_size)
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle(R.string.sort_title)
            .setItems(sortOptions) { _, which ->
                when (which) {
                    0 -> {
                        allVideos = allVideos.sortedBy { it.title.lowercase() }
                        allAudio = allAudio.sortedBy { it.title.lowercase() }
                    }
                    1 -> {
                        allVideos = allVideos.sortedByDescending { it.title.lowercase() }
                        allAudio = allAudio.sortedByDescending { it.title.lowercase() }
                    }
                    2 -> {
                        allVideos = allVideos.sortedByDescending { it.id }
                        allAudio = allAudio.sortedByDescending { it.id }
                    }
                    3 -> {
                        allVideos = allVideos.sortedByDescending { it.durationMs }
                        allAudio = allAudio.sortedByDescending { it.durationMs }
                    }
                    4 -> {
                        allVideos = allVideos.sortedByDescending { it.sizeBytes }
                        allAudio = allAudio.sortedByDescending { it.sizeBytes }
                    }
                }
                videoAdapter?.updateList(allVideos)
                audioAdapter?.updateList(allAudio)
                updateFoldersData()
                // Silent notification removed
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        btnToolbarSearch = findViewById(R.id.btnToolbarSearch)
        btnToolbarSearch.setOnClickListener {
            val searchLayout = findViewById<View>(R.id.layoutSearch)
            searchLayout.visibility = if (searchLayout.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (searchLayout.visibility == View.VISIBLE) {
                etSearch.requestFocus()
            }
        }
        btnToolbarSort = findViewById(R.id.btnToolbarSort)
        btnToolbarSort.setOnClickListener { showSortDialog() }
        btnToolbarOpen = findViewById(R.id.btnToolbarOpen)
        fabPlay = findViewById(R.id.fabPlay)
        fabPlay.setOnClickListener {
            if (allVideos.isNotEmpty()) {
                val item = allVideos.first()
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } else if (allAudio.isNotEmpty()) {
                YouTubeExoPlayerManager.pause()
                YouTubeExoPlayerManager.stop()
                YouTubeExoPlayerManager.currentPlayingVideo = null
                currentPlayingYtVideo = null
                isYtVideoPlaying = false
                if (::cardYtMiniPlayer.isInitialized) cardYtMiniPlayer.visibility = View.GONE
                if (::layoutYtAudioModeVisual.isInitialized) layoutYtAudioModeVisual.visibility = View.GONE
                PlayerHolder.setPlaylistAndPlay(this, allAudio, 0)
                openPlayer(allAudio[0].uri, allAudio[0].title, isVideo = false, path = allAudio[0].filePath, artist = allAudio[0].artist)
            } else {
                Toast.makeText(this, "No media files found", Toast.LENGTH_SHORT).show()
            }
        }
        etSearch = findViewById(R.id.etSearch)
        tabVideo = findViewById(R.id.tabVideo)
        tabAudio = findViewById(R.id.tabAudio)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)
        tabYouTube = findViewById(R.id.tabYouTube)
        layoutYtMainFeed = findViewById(R.id.layoutYtMainFeed)
        // btnYtExitToLocal removed for clean official header
        nsvYtFeed = findViewById(R.id.nsvYtFeed)
        rvYouTubeFeed = findViewById(R.id.rvYouTubeFeed)
        rvYouTubeFeedSecondary = findViewById(R.id.rvYouTubeFeedSecondary)
        srlYouTubeFeed = findViewById(R.id.srlYouTubeFeed)
        pbYtFeedLoading = findViewById(R.id.pbYtFeedLoading)
        layoutYtEmpty = findViewById(R.id.layoutYtEmpty)
        btnYtRetry = findViewById(R.id.btnYtRetry)
        btnYtSearch = findViewById(R.id.btnYtSearch)
        btnYtAccount = findViewById(R.id.btnYtAccount)
        btnYtCast = findViewById(R.id.btnYtCast)
        btnYtNotifications = findViewById(R.id.btnYtNotifications)
        layoutYtSearchBar = findViewById(R.id.layoutYtSearchBar)
        etYtSearchQuery = findViewById(R.id.etYtSearchQuery)
        btnYtCloseSearch = findViewById(R.id.btnYtCloseSearch)
        chipYtAll = findViewById(R.id.chipYtAll)
        chipYtMusic = findViewById(R.id.chipYtMusic)
        chipYtGaming = findViewById(R.id.chipYtGaming)
        chipYtPodcasts = findViewById(R.id.chipYtPodcasts)
        chipYtLive = findViewById(R.id.chipYtLive)
        chipYtTrending = findViewById(R.id.chipYtTrending)
        chipYtNews = findViewById(R.id.chipYtNews)

        btnYtNavHome = findViewById(R.id.btnYtNavHome)
        btnYtNavSubs = findViewById(R.id.btnYtNavSubs)
        btnYtNavLibrary = findViewById(R.id.btnYtNavLibrary)

        layoutYtPlayerDetail = findViewById(R.id.layoutYtPlayerDetail)
        playerViewYt = findViewById(R.id.playerViewYt)
        pbYtBuffering = findViewById(R.id.pbYtBuffering)
        btnYtCenterPlayPause = findViewById(R.id.btnYtCenterPlayPause)
        YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        YouTubeExoPlayerManager.onPlaybackStateChanged = { isPlaying ->
            runOnUiThread {
                isYtVideoPlaying = isPlaying
                btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                btnYtCenterPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                updateNotchPlayerUI()

                if (::ytAudioVisualizerView.isInitialized) {
                    ytAudioVisualizerView.setPlaying(isPlaying)
                    val sId = YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0
                    if (sId > 0) ytAudioVisualizerView.linkToAudio(sId)
                }
                ytMiniAudioVisualizerView?.let { mini ->
                    mini.setPlaying(isPlaying)
                    val sId = YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0
                    if (sId > 0) mini.linkToAudio(sId)
                }
                if (isPlaying) {
                    ytVisualizerHandler.removeCallbacks(ytVisualizerRunnable)
                    ytVisualizerHandler.post(ytVisualizerRunnable)
                }
            }
        }
        YouTubeExoPlayerManager.onBufferingStateChanged = { isBuffering ->
            runOnUiThread {
                pbYtBuffering.visibility = if (isBuffering) View.VISIBLE else View.GONE
                if (!isBuffering) {
                    if (layoutYtPlayerOverlay.visibility == View.VISIBLE) {
                        btnYtCenterPlayPause.visibility = View.VISIBLE
                    }
                } else {
                    btnYtCenterPlayPause.visibility = View.GONE
                }
            }
        }
        YouTubeExoPlayerManager.onSponsorSkipped = { label ->
            showYtGestureFeedback(R.drawable.ic_forward_10, "Skipped $label [SponsorBlock]")
        }
        YouTubeExoPlayerManager.onPlayerError = { error ->
            runOnUiThread {
                pbYtBuffering.visibility = View.GONE
                btnYtCenterPlayPause.visibility = View.VISIBLE
                btnYtCenterPlayPause.setImageResource(R.drawable.ic_play_player)
                val v = currentPlayingYtVideo
                if (v != null) {
                    // Unwanted popup removed
                    YouTubeStreamResolver.resolveStreams(v.id, 480) { resStream ->
                        if (resStream != null) {
                            val fastOpt = resStream.availableQualities.firstOrNull { it.audioUrl == null }
                            val url = fastOpt?.videoUrl ?: resStream.videoUrl
                            YouTubeExoPlayerManager.playVideo(
                                context = this,
                                video = v,
                                videoStreamUrl = url,
                                audioStreamUrl = null,
                                pureAudioUrl = resStream.pureAudioUrl,
                                allAudioUrls = resStream.allAudioUrls
                            )
                        } else {
                            // Unwanted popup removed
                        }
                    }
                }
            }
        }
        btnYtCenterPlayPause.setOnClickListener {
            val player = YouTubeExoPlayerManager.exoPlayer
            if (player != null && (player.playbackState == androidx.media3.common.Player.STATE_IDLE || player.playerError != null)) {
                currentPlayingYtVideo?.let { playYouTubeVideoInApp(it) }
            } else {
                YouTubeExoPlayerManager.togglePlayPause()
            }
        }
        // Rogue play/pause hide click listener removed to prevent disappearing button
        btnYtCollapsePlayer = findViewById(R.id.btnYtCollapsePlayer)
        btnYtFullscreen = findViewById(R.id.btnYtFullscreen)
        tvYtDetailTitle = findViewById(R.id.tvYtDetailTitle)
        tvYtDetailSubtitle = findViewById(R.id.tvYtDetailSubtitle)
        ivYtDetailAvatar = findViewById(R.id.ivYtDetailAvatar)
        tvYtDetailChannel = findViewById(R.id.tvYtDetailChannel)
        btnYtSubscribe = findViewById(R.id.btnYtSubscribe)
        layoutYtLikePill = findViewById(R.id.layoutYtLikePill)
        tvYtDetailLikes = findViewById(R.id.tvYtDetailLikes)
        layoutYtSharePill = findViewById(R.id.layoutYtSharePill)
        layoutYtDownloadPill = findViewById(R.id.layoutYtDownloadPill)
        tvYtDownloadPill = findViewById(R.id.tvYtDownloadPill)
        ivYtDownloadPill = findViewById(R.id.ivYtDownloadPill)
        tvYtAudioQualityStatus = findViewById(R.id.tvYtAudioQualityStatus)
        btnChangeYtAudioQuality = findViewById(R.id.btnChangeYtAudioQuality)
        tvYtBufferLimitStatus = findViewById(R.id.tvYtBufferLimitStatus)
        btnChangeYtBufferLimit = findViewById(R.id.btnChangeYtBufferLimit)

        ytAudioVisualizerView = findViewById(R.id.ytAudioVisualizerView)
        ytAudioVisualizerView.onModelChangedListener = { model, _ ->
            ytMiniAudioVisualizerView?.setModel(model)
        }


        layoutYtSavePill = findViewById(R.id.layoutYtSavePill)
        layoutYtCommentsCard = findViewById(R.id.layoutYtCommentsCard)
        tvYtDetailCommentsCount = findViewById(R.id.tvYtDetailCommentsCount)
        rvYtRelatedVideos = findViewById(R.id.rvYtRelatedVideos)

        cardYtMiniPlayer = findViewById(R.id.cardYtMiniPlayer)
        ivYtMiniThumb = findViewById(R.id.ivYtMiniThumb)
        tvYtMiniTitle = findViewById(R.id.tvYtMiniTitle)
        tvYtMiniChannel = findViewById(R.id.tvYtMiniChannel)
        btnYtMiniPlayPause = findViewById(R.id.btnYtMiniPlayPause)
        btnYtMiniClose = findViewById(R.id.btnYtMiniClose)
        layoutYtMiniControlsOverlay = findViewById(R.id.layoutYtMiniControlsOverlay)
        btnYtMiniExpand = findViewById(R.id.btnYtMiniExpand)
        playerViewYtMini = findViewById(R.id.playerViewYtMini)


        ytScaleGestureDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private var lastScaleTime = 0L

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val scaleFactor = detector.scaleFactor
                val now = System.currentTimeMillis()
                if (now - lastScaleTime < 300) return true

                if (scaleFactor > 1.05f) {
                    if (ytAspectRatioMode != 1) {
                        applyYouTubeAspectRatio(1)
                        lastScaleTime = now
                    }
                } else if (scaleFactor < 0.95f) {
                    if (ytAspectRatioMode != 0) {
                        applyYouTubeAspectRatio(0)
                        lastScaleTime = now
                    }
                }
                return true
            }

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                isYtPinchActive = true
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                isYtPinchActive = false
            }
        })

        val initTtlHours = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE).getInt("pref_yt_stream_ttl_hours", 4)
        YouTubeStreamResolver.setCacheTtlHours(initTtlHours)
        initNativeYouTubeEngine()

        btnViewAllVideos = findViewById(R.id.btnViewAllVideos)
        btnViewFolders = findViewById(R.id.btnViewFolders)
        rvVideos = findViewById(R.id.rvVideos)
        layoutFoldersContainer = findViewById(R.id.layoutFoldersContainer)
        rvFolders = findViewById(R.id.rvFolders)
        layoutFolderDetailHeader = findViewById(R.id.layoutFolderDetailHeader)
        btnFolderBack = findViewById(R.id.btnFolderBack)
        tvFolderHeaderTitle = findViewById(R.id.tvFolderHeaderTitle)
        tvFolderHeaderSubtitle = findViewById(R.id.tvFolderHeaderSubtitle)
        rvFolderVideos = findViewById(R.id.rvFolderVideos)
        layoutEmptyVideo = findViewById(R.id.layoutEmptyVideo)
        btnBrowseVideo = findViewById(R.id.btnBrowseVideo)

        rvFolders.layoutManager = LinearLayoutManager(this)
        rvFolderVideos.layoutManager = LinearLayoutManager(this)

        btnViewAllVideos.setOnClickListener {
            switchVideoViewMode(folders = false)
        }

        btnViewFolders.setOnClickListener {
            switchVideoViewMode(folders = true)
        }

        btnFolderBack.setOnClickListener {
            closeFolderDetail()
        }

        rvAudio = findViewById(R.id.rvAudio)
        layoutEmptyAudio = findViewById(R.id.layoutEmptyAudio)
        btnBrowseAudio = findViewById(R.id.btnBrowseAudio)

        // YouTube Settings Views
        tvYtAdBlockStatus = findViewById(R.id.tvYtAdBlockStatus)
        btnToggleYtAdBlock = findViewById(R.id.btnToggleYtAdBlock)
        tvYtSponsorBlockStatus = findViewById(R.id.tvYtSponsorBlockStatus)
        btnConfigSponsorBlock = findViewById(R.id.btnConfigSponsorBlock)
        tvYtDefaultQualityStatus = findViewById(R.id.tvYtDefaultQualityStatus)
        btnChangeYtQuality = findViewById(R.id.btnChangeYtQuality)
        tvYtExtractorBridgeStatus = findViewById(R.id.tvYtExtractorBridgeStatus)
        btnChangeYtExtractorBridge = findViewById(R.id.btnChangeYtExtractorBridge)
        findViewById<View>(R.id.rowYtExtractorBridge)?.setOnClickListener {
            showExtractorBridgeDialog()
        }
        btnChangeYtExtractorBridge.setOnClickListener {
            showExtractorBridgeDialog()
        }

        findViewById<View>(R.id.rowYtClientSpoofing)?.setOnClickListener {
            showClientSpoofingDialog()
        }
        tvYtClientSpoofingStatus = findViewById(R.id.tvYtClientSpoofingStatus)
        btnChangeYtClient = findViewById(R.id.btnChangeYtClient)
        tvYtBgAudioStatus = findViewById(R.id.tvYtBgAudioStatus)
        btnToggleYtBgAudio = findViewById(R.id.btnToggleYtBgAudio)
        tvYtInterfaceStatus = findViewById(R.id.tvYtInterfaceStatus)
        btnConfigYtUI = findViewById(R.id.btnConfigYtUI)
        tvYtAccountStatus = findViewById(R.id.tvYtAccountStatus)
        btnManageYtAccount = findViewById(R.id.btnManageYtAccount)

        btnToggleYtAdBlock.setOnClickListener {
            val prefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
            val cur = prefs.getBoolean("pref_yt_adblock", true)
            prefs.edit().putBoolean("pref_yt_adblock", !cur).apply()
            updateSettingsUI()
        }

        btnConfigSponsorBlock.setOnClickListener {
            showSponsorBlockSettingsDialog()
        }

        btnChangeYtQuality.setOnClickListener {
            showYouTubeQualityDialog()
        }

        btnChangeYtClient.setOnClickListener {
            showClientSpoofingDialog()
        }

        btnToggleYtBgAudio.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            updateSettingsUI()
        }

        btnConfigYtUI.setOnClickListener {
            showYouTubeUiConfigDialog()
        }

        btnManageYtAccount.setOnClickListener {
            MicroGAuthManager.showAccountDialog(this) {
                updateMicroGAccountState()
                updateSettingsUI()
                loadYouTubeFeed(currentYtCategory)
            }
        }

        findViewById<View>(R.id.rowYtAdBlock)?.setOnClickListener {
            btnToggleYtAdBlock.performClick()
        }
        findViewById<View>(R.id.rowYtSponsorBlock)?.setOnClickListener {
            btnConfigSponsorBlock.performClick()
        }
        findViewById<View>(R.id.rowYtDefaultQuality)?.setOnClickListener {
            btnChangeYtQuality.performClick()
        }
        findViewById<View>(R.id.rowYtBgAudio)?.setOnClickListener {
            btnToggleYtBgAudio.performClick()
        }
        findViewById<View>(R.id.rowYtInterfaceCustomization)?.setOnClickListener {
            btnConfigYtUI.performClick()
        }
        findViewById<View>(R.id.rowYtAccountManagement)?.setOnClickListener {
            btnManageYtAccount.performClick()
        }

        // Video Settings
        tvHighRefreshRateStatus = findViewById(R.id.tvHighRefreshRateStatus)
        btnToggleHighRefreshRate = findViewById(R.id.btnToggleHighRefreshRate)
        tvDefaultOrientationStatus = findViewById(R.id.tvDefaultOrientationStatus)
        btnChangeOrientation = findViewById(R.id.btnChangeOrientation)

        // Notch Mini Player
        cardNotchPlayer = findViewById(R.id.cardNotchPlayer)
        ivNotchIcon = findViewById(R.id.ivNotchIcon)
        tvNotchTitle = findViewById(R.id.tvNotchTitle)
        tvNotchArtist = findViewById(R.id.tvNotchArtist)
        btnNotchClose = findViewById(R.id.btnNotchClose)
        btnNotchRepeat = findViewById(R.id.btnNotchRepeat)
        btnNotchPrev = findViewById(R.id.btnNotchPrev)
        btnNotchPlayPause = findViewById(R.id.btnNotchPlayPause)
        btnNotchNext = findViewById(R.id.btnNotchNext)
        btnNotchOpen = findViewById(R.id.btnNotchOpen)
        tvNotchCurrent = findViewById(R.id.tvNotchCurrent)
        sbNotch = findViewById(R.id.sbNotch)
        tvNotchTotal = findViewById(R.id.tvNotchTotal)
        tvVideoColorStatus = findViewById(R.id.tvVideoColorStatus)
        btnChangeVideoColor = findViewById(R.id.btnChangeVideoColor)
        tvWideColorStatus = findViewById(R.id.tvWideColorStatus)
        btnToggleWideColor = findViewById(R.id.btnToggleWideColor)
        tvDeblockingStatus = findViewById(R.id.tvDeblockingStatus)
        btnToggleDeblocking = findViewById(R.id.btnToggleDeblocking)
        tvHwDecodeStatus = findViewById(R.id.tvHwDecodeStatus)
        btnChangeHw = findViewById(R.id.btnChangeHw)
        tvBgPipStatus = findViewById(R.id.tvBgPipStatus)
        btnChangeBgPip = findViewById(R.id.btnChangeBgPip)
        tvResumeModeStatus = findViewById(R.id.tvResumeModeStatus)
        btnChangeResumeMode = findViewById(R.id.btnChangeResumeMode)
        tvDoubleTapStatus = findViewById(R.id.tvDoubleTapStatus)
        btnChangeDoubleTap = findViewById(R.id.btnChangeDoubleTap)
        tvAspectRatioStatus = findViewById(R.id.tvAspectRatioStatus)
        btnChangeAspectRatio = findViewById(R.id.btnChangeAspectRatio)
        tvAudioBoostStatus = findViewById(R.id.tvAudioBoostStatus)
        btnToggleAudioBoost = findViewById(R.id.btnToggleAudioBoost)

        // Audio Suite Settings
        tvMasterProfileStatus = findViewById(R.id.tvMasterProfileStatus)
        btnChangeMasterProfile = findViewById(R.id.btnChangeMasterProfile)
        tvDolbySurroundStatus = findViewById(R.id.tvDolbySurroundStatus)
        btnChangeDolbySurround = findViewById(R.id.btnChangeDolbySurround)
        tvEqualizerStatus = findViewById(R.id.tvEqualizerStatus)
        btnChangeEqualizer = findViewById(R.id.btnChangeEqualizer)
        tvDialogueBoostStatus = findViewById(R.id.tvDialogueBoostStatus)
        btnToggleDialogueBoost = findViewById(R.id.btnToggleDialogueBoost)
        tvDigitalPassthroughStatus = findViewById(R.id.tvDigitalPassthroughStatus)
        btnTogglePassthrough = findViewById(R.id.btnTogglePassthrough)
        tvAudioOutputStatus = findViewById(R.id.tvAudioOutputStatus)
        btnChangeAudioOutput = findViewById(R.id.btnChangeAudioOutput)
        tvHeadsetPauseStatus = findViewById(R.id.tvHeadsetPauseStatus)
        btnToggleHeadsetPause = findViewById(R.id.btnToggleHeadsetPause)
        tvTimeStretchStatus = findViewById(R.id.tvTimeStretchStatus)
        btnToggleTimeStretch = findViewById(R.id.btnToggleTimeStretch)

        // Subtitle Settings
        btnToggleSubAutoload = findViewById(R.id.btnToggleSubAutoload)
        tvSubSizeStatus = findViewById(R.id.tvSubSizeStatus)
        btnChangeSubSize = findViewById(R.id.btnChangeSubSize)
        tvSubColorStatus = findViewById(R.id.tvSubColorStatus)
        btnChangeSubColor = findViewById(R.id.btnChangeSubColor)
        tvSubBackgroundStatus = findViewById(R.id.tvSubBackgroundStatus)
        btnChangeSubBackground = findViewById(R.id.btnChangeSubBackground)
        tvSubStyleStatus = findViewById(R.id.tvSubStyleStatus)
        btnToggleSubStyle = findViewById(R.id.btnToggleSubStyle)
        tvSubEncodingStatus = findViewById(R.id.tvSubEncodingStatus)
        btnChangeSubEncoding = findViewById(R.id.btnChangeSubEncoding)

        // Gesture Settings
        tvGestureVolumeStatus = findViewById(R.id.tvGestureVolumeStatus)
        btnToggleGestureVolume = findViewById(R.id.btnToggleGestureVolume)
        tvGestureBrightnessStatus = findViewById(R.id.tvGestureBrightnessStatus)
        btnToggleGestureBrightness = findViewById(R.id.btnToggleGestureBrightness)
        tvGestureSeekStatus = findViewById(R.id.tvGestureSeekStatus)
        btnToggleGestureSeek = findViewById(R.id.btnToggleGestureSeek)
        tvFastSeekStatus = findViewById(R.id.tvFastSeekStatus)
        btnToggleFastSeek = findViewById(R.id.btnToggleFastSeek)

        // Interface Settings
        tvAppThemeStatus = findViewById(R.id.tvAppThemeStatus)
        btnChangeAppTheme = findViewById(R.id.btnChangeAppTheme)

        // Advanced Settings
        btnClearCache = findViewById(R.id.btnClearCache)
        btnClearResume = findViewById(R.id.btnClearResume)
        btnResetSettings = findViewById(R.id.btnResetSettings)
        tvCacheSizeStatus = findViewById(R.id.tvCacheSizeStatus)

        rvVideos.layoutManager = LinearLayoutManager(this)
        rvAudio.layoutManager = LinearLayoutManager(this)

        val openFileAction = {
            filePickerLauncher.launch(arrayOf("video/*", "audio/*"))
        }

        btnToolbarOpen.setOnClickListener { openFileAction() }
        btnBrowseVideo.setOnClickListener { openFileAction() }
        btnBrowseAudio.setOnClickListener { openFileAction() }

        // Dynamic App Version binding
        val vName = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "3.5" } catch (e: Exception) { "3.5" }
        findViewById<TextView>(R.id.badgeAppVersion)?.text = "v$vName"
        findViewById<TextView>(R.id.tvDeveloperName)?.text = "👨‍💻 Developer: Rajesh Shah"
        findViewById<TextView>(R.id.tvAppVersionCode)?.text = "Version $vName (Master Edition) • CleanPlayer"
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterMedia(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterMedia(query: String) {
        val q = query.trim().lowercase()
        val filteredVideos = if (q.isEmpty()) allVideos else allVideos.filter { it.title.lowercase().contains(q) }
        val filteredAudio = if (q.isEmpty()) allAudio else allAudio.filter {
            it.title.lowercase().contains(q) || (it.artist?.lowercase()?.contains(q) == true)
        }

        videoAdapter?.updateList(filteredVideos)
        audioAdapter?.updateList(filteredAudio)

        if (isFolderViewActive) {
            val filteredFolders = if (q.isEmpty()) allFolders else allFolders.filter { folder ->
                folder.folderName.lowercase().contains(q) || folder.videos.any { it.title.lowercase().contains(q) }
            }
            folderAdapter?.updateFolders(filteredFolders)
        }

        if (!isFolderViewActive) {
            rvVideos.visibility = if (filteredVideos.isNotEmpty()) View.VISIBLE else View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = if (filteredVideos.isEmpty()) View.VISIBLE else View.GONE
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            layoutEmptyVideo.visibility = if (allFolders.isEmpty()) View.VISIBLE else View.GONE
        }

        rvAudio.visibility = if (filteredAudio.isNotEmpty()) View.VISIBLE else View.GONE
        layoutEmptyAudio.visibility = if (filteredAudio.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_video -> {
                    showTab(video = true, audio = false, youtube = false, settings = false)
                    switchVideoViewMode(folders = false)
                    true
                }
                R.id.nav_audio -> {
                    showTab(video = false, audio = true, youtube = false, settings = false)
                    true
                }
                R.id.nav_youtube -> {
                    showTab(video = false, audio = false, youtube = true, share = false, settings = false)
                    true
                }
                R.id.nav_share -> {
                    showTab(video = false, audio = false, youtube = false, share = true, settings = false)
                    true
                }
                R.id.nav_more -> {
                    showTab(video = false, audio = false, youtube = false, settings = true)
                    true
                }
                else -> false
            }
        }
    }

    private fun showTab(video: Boolean, audio: Boolean, youtube: Boolean, share: Boolean = false, settings: Boolean = false) {
        tabVideo.visibility = if (video) View.VISIBLE else View.GONE
        tabAudio.visibility = if (audio) View.VISIBLE else View.GONE
        tabYouTube.visibility = if (youtube) View.VISIBLE else View.GONE
        if (::tabShare.isInitialized) tabShare.visibility = if (share) View.VISIBLE else View.GONE
        tabSettings.visibility = if (settings) View.VISIBLE else View.GONE

        if (youtube) {
            toolbar.visibility = View.GONE
            findViewById<View>(R.id.topBarContainer)?.visibility = View.GONE
            bottomNav.visibility = View.GONE
            fabPlay.visibility = View.GONE
            window.statusBarColor = Color.parseColor("#0F0F0F")

            if (!isYtFeedLoaded) {
                loadYouTubeFeed(currentYtCategory)
            }
        } else {
            lastActiveTabId = when {
                audio -> R.id.nav_audio
                share -> R.id.nav_share
                settings -> R.id.nav_more
                else -> R.id.nav_video
            }

            toolbar.visibility = View.VISIBLE
            findViewById<View>(R.id.topBarContainer)?.visibility = if (share || settings) View.GONE else View.VISIBLE
            bottomNav.visibility = View.VISIBLE
            updateFabPlayVisibility()
            window.statusBarColor = Color.parseColor("#000000")

            if (share) {
                refreshShareTabUI()
            }

            applyThemeUI()
        }
        updateNotchPlayerUI()
    }

    private fun initNativeYouTubeEngine() {
        rvYouTubeFeed.layoutManager = LinearLayoutManager(this)
        rvYouTubeFeedSecondary.layoutManager = LinearLayoutManager(this)

        youTubeFeedAdapter = YouTubeFeedAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        youTubeFeedAdapter.onChannelClick = { chTitle, avatar ->
            openYouTubeChannelPage(chTitle, avatar)
        }
        rvYouTubeFeed.adapter = youTubeFeedAdapter

        youTubeFeedSecondaryAdapter = YouTubeFeedAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        youTubeFeedSecondaryAdapter.onChannelClick = { chTitle, avatar ->
            openYouTubeChannelPage(chTitle, avatar)
        }
        rvYouTubeFeedSecondary.adapter = youTubeFeedSecondaryAdapter


        btnYtPrevVideo = findViewById(R.id.btnYtPrevVideo)
        btnYtNextVideo = findViewById(R.id.btnYtNextVideo)
        ytMiniAudioVisualizerView = findViewById(R.id.ytMiniAudioVisualizerView)
        ytMiniAudioVisualizerView?.onModelChangedListener = { model, _ ->
            ytAudioVisualizerView.setModel(model)
        }
        layoutYtGestureOverlay = findViewById(R.id.layoutYtGestureOverlay)
        ivYtGestureIcon = findViewById(R.id.ivYtGestureIcon)
        tvYtGestureText = findViewById(R.id.tvYtGestureText)

        btnYtPrevVideo?.setOnClickListener {
            playPreviousYouTubeVideo()
            showYouTubeOverlay()
        }
        btnYtNextVideo?.setOnClickListener {
            playNextYouTubeVideo()
            showYouTubeOverlay()
        }

        findViewById<View>(R.id.ivYtLogo)?.setOnClickListener {
            exitYouTubeToLocal()
        }
        findViewById<View>(R.id.btnYtViewAllHistory)?.setOnClickListener {
            showYouTubeFullHistoryDialog()
        }
        findViewById<View>(R.id.btnYtViewAllDownloads)?.setOnClickListener {
            showYouTubeFullDownloadsDialog()
        }

        nsvYtFeed.setOnScrollChangeListener(androidx.core.widget.NestedScrollView.OnScrollChangeListener { v, _, scrollY, _, _ ->
            val child = v.getChildAt(0)
            if (child != null && scrollY >= (child.measuredHeight - v.measuredHeight - 400)) {
                if (!isYtLoadingMore && isYtFeedLoaded) {
                    loadMoreYouTubeFeed()
                }
            }
        })

        srlYouTubeFeed.setColorSchemeColors(Color.parseColor("#FF0000"))
        srlYouTubeFeed.setProgressBackgroundColorSchemeColor(Color.parseColor("#1A1A1A"))
        srlYouTubeFeed.setOnRefreshListener {
            loadYouTubeFeed(currentYtCategory)
        }

        btnYtRetry.setOnClickListener {
            loadYouTubeFeed(currentYtCategory)
        }

// btnYtExitToLocal click removed

        btnYtNavHome.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            nsvYtFeed.smoothScrollTo(0, 0)
        }


        btnYtNavSubs.setOnClickListener {
            loadSubscriptionsFeed()
        }

        btnYtNavLibrary.setOnClickListener {
            exitYouTubeToLocal()
        }

        btnYtCast.setOnClickListener {
            showCastDevicesDialog()
        }

        btnYtNotifications.setOnClickListener {
            showNotificationsDialog()
        }

        btnYtAccount.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        btnYtSearch.setOnClickListener {
            if (layoutYtSearchBar.visibility == View.VISIBLE) {
                layoutYtSearchBar.visibility = View.GONE
            } else {
                layoutYtSearchBar.visibility = View.VISIBLE
                etYtSearchQuery.requestFocus()
            }
        }

        btnYtCloseSearch.setOnClickListener {
            layoutYtSearchBar.visibility = View.GONE
            etYtSearchQuery.text?.clear()
            loadYouTubeFeed(currentYtCategory)
        }

        etYtSearchQuery.setOnEditorActionListener { _, _, _ ->
            val query = etYtSearchQuery.text.toString().trim()
            if (query.isNotEmpty()) {
                performYouTubeSearch(query)
            }
            true
        }

        val chips = listOf(
            chipYtAll to "All",
            chipYtMusic to "Music",
            chipYtGaming to "Gaming",
            chipYtPodcasts to "Podcasts",
            chipYtLive to "Live",
            chipYtTrending to "Trending",
            chipYtNews to "News"
        )

        for ((chipView, cat) in chips) {
            chipView.setOnClickListener {
                for ((c, _) in chips) {
                    c.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                    c.setTextColor(Color.parseColor("#FFFFFF"))
                    c.setTypeface(null, android.graphics.Typeface.NORMAL)
                }
                chipView.setBackgroundResource(R.drawable.bg_youtube_chip_active)
                chipView.setTextColor(Color.parseColor("#000000"))
                chipView.setTypeface(null, android.graphics.Typeface.BOLD)

                currentYtCategory = cat
                loadYouTubeFeed(cat)
            }
        }

        setupYouTubeDetailPlayer()
        setupYouTubeMiniPlayer()

        findViewById<View>(R.id.btnYtPlayerSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.btnYtYouSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.rowYtReturnToLocal)?.setOnClickListener {
            exitYouTubeToLocal()
        }

        findViewById<View>(R.id.btnYtYouNavHome)?.setOnClickListener {
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
        }
        findViewById<View>(R.id.btnYtYouNavSubs)?.setOnClickListener { loadSubscriptionsFeed() }
        findViewById<View>(R.id.btnYtYouNavYou)?.setOnClickListener { updateYouTabUI() }
        findViewById<View>(R.id.btnYtYouCast)?.setOnClickListener { showCastDevicesDialog() }

        btnYtNavLibrary.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.VISIBLE
            updateYouTabUI()
        }

        rvYtHistory = findViewById(R.id.rvYtHistory)
        rvYtHistory.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        ytHistoryAdapter = YouTubeHistoryAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        rvYtHistory.adapter = ytHistoryAdapter

        rvYtDownloads = findViewById(R.id.rvYtDownloads)
        rvYtDownloads.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        ytDownloadsAdapter = YouTubeHistoryAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        rvYtDownloads.adapter = ytDownloadsAdapter

        findViewById<View>(R.id.cardYtPremiumBenefits)?.setOnClickListener { showYouTubePremiumBenefitsDialog() }
        findViewById<View>(R.id.cardYtYouAccount)?.setOnClickListener {
            val isLoggedIn = MicroGAuthManager.isLoggedIn(this)
            val loginActionText = if (isLoggedIn) "👤 Manage Google Account (${MicroGAuthManager.getAccountEmail(this)})" else "🔑 Sign In with Google (MicroG / GmsCore)"
            val subCount = YouTubeSubscriptionManager.getSubscriptions(this).size
            val options = arrayOf(
                loginActionText,
                "📑 Subscribed Channels ($subCount channels)",
                "✏️ Edit Profile Display Name",
                "🛡️ View YouTube Premium Benefits",
                "⚙️ YouTube Stream & Quality Settings",
                "🗑️ Clear Watch History"
            )
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Account & Subscriptions")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> {
                            MicroGAuthManager.showAccountDialog(this) {
                                updateMicroGAccountState()
                                updateYouTabUI()
                                updateSettingsUI()
                            }
                        }
                        1 -> {
                            val subs = YouTubeSubscriptionManager.getSubscriptions(this)
                            if (subs.isEmpty()) {
                                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                                    .setTitle("Subscribed Channels")
                                    .setMessage("Abhi koi subscription nahi hai.\n\nVideo player ya channel page par 'Subscribe' button daba kar channels add karein!")
                                    .setPositiveButton("OK", null)
                                    .show()
                            } else {
                                val names = subs.map { "• " + it.title }.toTypedArray()
                                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                                    .setTitle("Subscribed Channels (${subs.size})")
                                    .setItems(names) { _, idx ->
                                        val ch = subs[idx]
                                        openYouTubeChannelPage(ch.title, ch.avatarUrl)
                                    }
                                    .setPositiveButton("Close", null)
                                    .show()
                            }
                        }
                        2 -> showEditProfileDialog()
                        3 -> showYouTubePremiumBenefitsDialog()
                        4 -> showYouTubeDedicatedSettingsDialog()
                        5 -> {
                            YouTubeHistoryManager.clearHistory(this)
                            updateYouTabUI()
                            Toast.makeText(this, "Watch history cleared", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .setNegativeButton("Close", null)
                .show()
        }
        findViewById<View>(R.id.rowYtReturnToLocal)?.setOnClickListener {
            exitYouTubeToLocal()
        }
        updateYouTabUI()
        updateMicroGAccountState()
    }

    private fun setupYouTubeDetailPlayer() {
        rvYtRelatedVideos.layoutManager = LinearLayoutManager(this)
        rvYtRelatedVideos.adapter = youTubeFeedSecondaryAdapter

        pbYtBottomMiniProgress = findViewById(R.id.pbYtBottomMiniProgress)
        layoutYtPlayerOverlay = findViewById(R.id.layoutYtPlayerOverlay)
        btnYtAudioMode = findViewById(R.id.btnYtAudioMode)
        layoutYtAudioModeVisual = findViewById(R.id.layoutYtAudioModeVisual)
        layoutYtAudioModeVisual.setOnClickListener {
            if (layoutYtPlayerOverlay.visibility == View.VISIBLE) {
                hideYouTubeOverlay()
            } else {
                showYouTubeOverlay()
            }
        }
        ivYtAudioModeThumb = findViewById(R.id.ivYtAudioModeThumb)

        btnYtAudioMode?.setOnClickListener {
            val isNowAudioOnly = YouTubeExoPlayerManager.toggleAudioVideoMode(this)
            updateAudioModeUI(isNowAudioOnly)
        }
        btnYtPlayerCC = findViewById(R.id.btnYtPlayerCC)
        btnYtRewind10 = findViewById(R.id.btnYtRewind10)
        btnYtForward10 = findViewById(R.id.btnYtForward10)
        tvYtPlayerCurrentTime = findViewById(R.id.tvYtPlayerCurrentTime)
        sbYtPlayer = findViewById(R.id.sbYtPlayer)

        btnYtCollapsePlayer.setOnClickListener {
            handleBackPress()
        }

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        var ytGestureStartX = 0f
        var ytGestureStartY = 0f
        var isYtGestureActive = false
        var ytGestureType = 0 // 0: None, 1: Volume, 2: Brightness, 3: Seek
        var ytInitialVolume = 0
        var ytInitialBrightness = 0.5f
        var ytSeekStartPosition = 0L
        // showYtGestureFeedback moved to class member

        var ytLastTapTime = 0L
        var ytLastTapX = 0f
        var ytLastTapY = 0f
        var ytCumulativeScale = 1.0f

        val ytScaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                ytCumulativeScale = 1.0f
                isYtPinchActive = true
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                ytCumulativeScale *= detector.scaleFactor
                if (ytCumulativeScale > 1.12f) {
                    if (ytAspectRatioMode != 1) {
                        applyYouTubeAspectRatio(1) // Zoomed to fill (no black bars!)
                        ytCumulativeScale = 1.0f
                    }
                } else if (ytCumulativeScale < 0.88f) {
                    if (ytAspectRatioMode != 0) {
                        applyYouTubeAspectRatio(0) // Original Fit
                        ytCumulativeScale = 1.0f
                    }
                }
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                isYtPinchActive = false
                ytCumulativeScale = 1.0f
            }
        })

        fun handleYouTubeTouch(view: View, event: MotionEvent): Boolean {
            ytScaleDetector.onTouchEvent(event)
            if (event.pointerCount >= 2) {
                isYtGestureActive = false
                ytGestureType = 0
                return true
            }
            if (isYtPinchActive) {
                if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                    isYtPinchActive = false
                }
                return true
            }

            val w = view.width.toFloat().coerceAtLeast(1f)
            val h = view.height.toFloat().coerceAtLeast(1f)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ytGestureStartX = event.x
                    ytGestureStartY = event.y
                    isYtGestureActive = false
                    ytGestureType = 0
                    ytInitialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    ytInitialBrightness = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                    ytSeekStartPosition = YouTubeExoPlayerManager.getCurrentPosition()
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = event.x - ytGestureStartX
                    val deltaY = ytGestureStartY - event.y // up is positive
                    val absDeltaX = kotlin.math.abs(deltaX.toFloat())
                    val absDeltaY = kotlin.math.abs(deltaY.toFloat())

                    if (!isYtGestureActive && (absDeltaX > 25f || absDeltaY > 25f)) {
                        isYtGestureActive = true
                        ytGestureType = if (absDeltaX > absDeltaY) {
                            3 // Seek (Horizontal swipe)
                        } else if (ytGestureStartX >= w * 0.20f && ytGestureStartX <= w * 0.80f) {
                            4 // Fullscreen / Collapse (Vertical swipe from center 60% of video)
                        } else if (ytGestureStartX < w * 0.20f) {
                            2 // Brightness (Left vertical edge swipe)
                        } else {
                            1 // Volume (Right vertical edge swipe)
                        }
                    }

                    if (isYtGestureActive) {
                        when (ytGestureType) {
                            1 -> { // Volume
                                val change = ((deltaY / (h * 0.75f)) * maxVolume.toFloat()).toInt()
                                val newVol = (ytInitialVolume + change).coerceIn(0, maxVolume)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                                val percent = if (maxVolume > 0) (newVol * 100) / maxVolume else 0
                                showYtGestureFeedback(R.drawable.ic_equalizer, "Volume: $percent%")
                            }
                            2 -> { // Brightness
                                val change = deltaY / (h * 0.75f)
                                val newBrightness = (ytInitialBrightness + change).coerceIn(0.01f, 1.0f)
                                val lp = window.attributes
                                lp.screenBrightness = newBrightness
                                window.attributes = lp
                                val percent = (newBrightness * 100).toInt()
                                showYtGestureFeedback(android.R.drawable.ic_menu_view, "Brightness: $percent%")
                            }
                            3 -> { // Seek
                                val dur = YouTubeExoPlayerManager.getDuration()
                                if (dur > 0) {
                                    val seekOffsetMs = ((deltaX / w) * 90000).toLong()
                                    val targetMs = (ytSeekStartPosition + seekOffsetMs).coerceIn(0, dur)
                                    val sign = if (seekOffsetMs >= 0) "+" else ""
                                    showYtGestureFeedback(R.drawable.ic_speed, "$sign${seekOffsetMs / 1000}s (${formatTime(targetMs)})")
                                }
                            }
                            4 -> { // Center Vertical Swipe (Swipe Up -> Fullscreen, Swipe Down -> Exit/Collapse)
                                val minSwipeDist = 40f * resources.displayMetrics.density
                                if (deltaY > minSwipeDist) {
                                    if (!isYtFullscreen) {
                                        showYtGestureFeedback(R.drawable.ic_fullscreen, "Swipe Up for Fullscreen")
                                    }
                                } else if (deltaY < -minSwipeDist) {
                                    if (isYtFullscreen) {
                                        showYtGestureFeedback(R.drawable.ic_fullscreen_exit, "Swipe Down to Exit Fullscreen")
                                    } else {
                                        showYtGestureFeedback(R.drawable.ic_expand_more, "Swipe Down to Minimize")
                                    }
                                }
                            }
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isYtGestureActive) {
                        if (ytGestureType == 3) {
                            val deltaX = event.x - ytGestureStartX
                            val dur = YouTubeExoPlayerManager.getDuration()
                            if (dur > 0) {
                                val seekOffsetMs = ((deltaX / w) * 90000).toLong()
                                val targetMs = (ytSeekStartPosition + seekOffsetMs).coerceIn(0, dur)
                                YouTubeExoPlayerManager.seekTo(targetMs)
                            }
                        } else if (ytGestureType == 4) {
                            val deltaY = ytGestureStartY - event.y // up is positive
                            val minSwipeDist = 35f * resources.displayMetrics.density
                            if (deltaY > minSwipeDist) {
                                // Swiped UP: Automatically enter fullscreen landscape!
                                if (!isYtFullscreen) {
                                    toggleYouTubeFullscreen()
                                }
                            } else if (deltaY < -minSwipeDist) {
                                // Swiped DOWN: If fullscreen, exit to portrait; if portrait, collapse to miniplayer!
                                if (isYtFullscreen) {
                                    toggleYouTubeFullscreen()
                                } else {
                                    collapseYouTubePlayer()
                                }
                            }
                        }
                        isYtGestureActive = false
                        ytGestureType = 0
                    } else {
                        // Tap handling
                        val now = System.currentTimeMillis()
                        val tapDistX = kotlin.math.abs(event.x - ytLastTapX)
                        val tapDistY = kotlin.math.abs(event.y - ytLastTapY)

                        if (now - ytLastTapTime < 350 && tapDistX < 80f && tapDistY < 80f) {
                            // Double tap
                            ytLastTapTime = 0L
                            if (event.x < w * 0.35f) {
                                val cur = YouTubeExoPlayerManager.getCurrentPosition()
                                YouTubeExoPlayerManager.seekTo((cur - 10000).coerceAtLeast(0))
                                showYtGestureFeedback(R.drawable.ic_replay_10, "-10s")
                                showYouTubeOverlay()
                            } else if (event.x > w * 0.65f) {
                                val cur = YouTubeExoPlayerManager.getCurrentPosition()
                                val dur = YouTubeExoPlayerManager.getDuration()
                                YouTubeExoPlayerManager.seekTo((cur + 10000).coerceAtMost(dur))
                                showYtGestureFeedback(R.drawable.ic_forward_10, "+10s")
                                showYouTubeOverlay()
                            } else {
                                YouTubeExoPlayerManager.togglePlayPause()
                                showYouTubeOverlay()
                            }
                        } else {
                            // Single tap
                            ytLastTapTime = now
                            ytLastTapX = event.x
                            ytLastTapY = event.y
                            if (layoutYtPlayerOverlay.visibility == View.VISIBLE) {
                                hideYouTubeOverlay()
                            } else {
                                showYouTubeOverlay()
                            }
                        }
                    }
                }
            }
            return true
        }

        playerViewYt.setOnTouchListener { v, event -> handleYouTubeTouch(v, event) }
        layoutYtPlayerOverlay.setOnTouchListener { v, event -> handleYouTubeTouch(v, event) }

        btnYtRewind10.setOnClickListener {
            val cur = YouTubeExoPlayerManager.getCurrentPosition()
            YouTubeExoPlayerManager.seekTo((cur - 10000).coerceAtLeast(0))
            showYouTubeOverlay()
        }

        btnYtForward10.setOnClickListener {
            val cur = YouTubeExoPlayerManager.getCurrentPosition()
            val dur = YouTubeExoPlayerManager.getDuration()
            YouTubeExoPlayerManager.seekTo((cur + 10000).coerceAtMost(dur))
            showYouTubeOverlay()
        }



        btnYtPlayerCC.setOnClickListener {
            showYouTubeSubtitleDialog()
            showYouTubeOverlay()
        }

        sbYtPlayer.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    isYtUserSeeking = true
                    val dur = YouTubeExoPlayerManager.getDuration()
                    tvYtPlayerCurrentTime.text = "${formatTime(progress.toLong())} / ${formatTime(dur)}"
                    showYouTubeOverlay()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isYtUserSeeking = true
                ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isYtUserSeeking = false
                seekBar?.let {
                    YouTubeExoPlayerManager.seekTo(it.progress.toLong())
                }
                showYouTubeOverlay()
            }
        })

        btnYtFullscreen.setOnClickListener {
            toggleYouTubeFullscreen()
        }

        val openCurrentChannel = {
            currentPlayingYtVideo?.let { v ->
                openYouTubeChannelPage(v.channelTitle, v.channelAvatarUrl)
            }
        }
        tvYtDetailChannel.setOnClickListener { openCurrentChannel() }
        ivYtDetailAvatar.setOnClickListener { openCurrentChannel() }
        findViewById<View>(R.id.cardYtDetailAvatar)?.setOnClickListener { openCurrentChannel() }

        btnYtSubscribe.setOnClickListener {
            val v = currentPlayingYtVideo ?: return@setOnClickListener
            if (YouTubeSubscriptionManager.isSubscribed(this, v.channelTitle)) {
                YouTubeSubscriptionManager.unsubscribe(this, v.channelTitle)
                btnYtSubscribe.text = "Subscribe"
                btnYtSubscribe.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
                btnYtSubscribe.setTextColor(Color.BLACK)
                Toast.makeText(this, "Unsubscribed from ${v.channelTitle}", Toast.LENGTH_SHORT).show()
            } else {
                YouTubeSubscriptionManager.subscribe(this, v.channelTitle, null, v.channelAvatarUrl)
                btnYtSubscribe.text = "Subscribed ∨"
                btnYtSubscribe.setBackgroundColor(Color.parseColor("#272727"))
                btnYtSubscribe.setTextColor(Color.WHITE)
                Toast.makeText(this, "Subscribed to ${v.channelTitle}!", Toast.LENGTH_SHORT).show()
            }
        }

        layoutYtLikePill.setOnClickListener {
            val video = currentPlayingYtVideo ?: return@setOnClickListener
            val isLiked = YouTubeHistoryManager.toggleBookmark(this, video)
            val ivLike = findViewById<ImageView>(R.id.ivYtLikeIcon)
            val tvLikes = findViewById<TextView>(R.id.tvYtDetailLikes)
            if (isLiked) {
                ivLike?.setColorFilter(Color.parseColor("#FF0000"))
                tvLikes?.setTextColor(Color.parseColor("#FF0000"))
                // Silent notification removed
            } else {
                ivLike?.setColorFilter(Color.WHITE)
                tvLikes?.setTextColor(Color.WHITE)
                // Silent notification removed
            }
            updateYouTabUI()
        }

        layoutYtSharePill.setOnClickListener {
            val v = currentPlayingYtVideo ?: return@setOnClickListener
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, v.title)
                putExtra(Intent.EXTRA_TEXT, "Watch '${v.title}' on YouTube: https://youtu.be/${v.id}")
            }
            startActivity(Intent.createChooser(intent, "Share Video"))
        }

        layoutYtDownloadPill.setOnClickListener {
            currentPlayingYtVideo?.let { v ->
                YouTubeDownloaderHelper.showDownloadDialog(this, v)
            }
        }

        val openAudioQualityDialog = {
            val audioQualities = arrayOf(
                "Auto (Adaptive - Recommended)",
                "High Quality (160 kbps Opus - Studio Audio)",
                "Normal Quality (128 kbps M4A - Clear & Balanced)",
                "Data Saver (64 kbps - Ultra-Low Data)"
            )
            val curAudio = ytPrefs.getString("pref_yt_audio_quality", "Auto (Adaptive - Recommended)") ?: "Auto (Adaptive - Recommended)"
            val curIdx = audioQualities.indexOfFirst { it.startsWith(curAudio.substringBefore(" ")) }.coerceAtLeast(0)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Audio Streaming Quality")
                .setSingleChoiceItems(audioQualities, curIdx) { dialog, which ->
                    val selected = audioQualities[which]
                    ytPrefs.edit().putString("pref_yt_audio_quality", selected).apply()
                    updateSettingsUI()
                    val label = selected.substringBefore(" -")
                    // Silent notification removed
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeYtAudioQuality.setOnClickListener { openAudioQualityDialog() }
        findViewById<View>(R.id.rowYtAudioQuality).setOnClickListener { openAudioQualityDialog() }

        val openBufferLimitDialog = {
            val bufferOptions = arrayOf(
                "15s (Ultra Data Saver - Least Data)",
                "30s (Balanced Data Saver - Recommended)",
                "60s (Medium Buffer - Unstable Network)",
                "120s (Maximum Pre-Buffer - Wi-Fi & Travel)"
            )
            val curBuffer = ytPrefs.getString("pref_yt_buffer_limit", "30s (Balanced Data Saver - Recommended)") ?: "30s"
            val curIdx = bufferOptions.indexOfFirst { it.startsWith(curBuffer.substringBefore(" ")) }.coerceAtLeast(1)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Streaming Buffer Limit")
                .setSingleChoiceItems(bufferOptions, curIdx) { dialog, which ->
                    val selected = bufferOptions[which]
                    ytPrefs.edit().putString("pref_yt_buffer_limit", selected).apply()
                    YouTubeExoPlayerManager.applyBufferLimit(this, selected)
                    updateSettingsUI()
                    val label = selected.substringBefore(" -")
                    // Silent notification removed
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeYtBufferLimit.setOnClickListener { openBufferLimitDialog() }
        findViewById<View>(R.id.rowYtBufferLimit).setOnClickListener { openBufferLimitDialog() }

        val openMediaDiskCacheDialog = {
            val options = arrayOf(
                "256 MB (Balanced - Recommended)",
                "512 MB (High Performance)",
                "1 GB (Maximum Offline Buffer)",
                "2 GB (Heavy Usage & Travel)",
                "4 GB (Ultra Large Storage)"
            )
            val sizeValues = longArrayOf(256L, 512L, 1024L, 2048L, 4096L)
            val curSelected = ytPrefs.getString("pref_yt_disk_cache_label", "256 MB (Balanced - Recommended)") ?: "256 MB (Balanced - Recommended)"
            val curIdx = options.indexOf(curSelected).coerceAtLeast(0)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Media Disk Cache Size")
                .setSingleChoiceItems(options, curIdx) { dialog, which ->
                    val chosen = options[which]
                    val sizeMb = sizeValues[which]
                    ytPrefs.edit()
                        .putString("pref_yt_disk_cache_label", chosen)
                        .putLong("pref_yt_disk_cache_mb", sizeMb)
                        .apply()
                    YouTubeExoPlayerManager.updateDiskCacheSize(this, sizeMb)
                    updateSettingsUI()
                    // Silent notification removed
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.btnChangeYtMediaCache)?.setOnClickListener { openMediaDiskCacheDialog() }
        findViewById<View>(R.id.rowYtMediaCache)?.setOnClickListener { openMediaDiskCacheDialog() }

        val openStreamCacheTtlDialog = {
            val options = arrayOf(
                "2 Hours (Fast Refresh)",
                "4 Hours (Recommended)",
                "8 Hours (Extended Cache)",
                "12 Hours (All-Day Cache)",
                "24 Hours (Maximum Retention)",
                "48 Hours (Ultra Long Cache)"
            )
            val hoursValues = intArrayOf(2, 4, 8, 12, 24, 48)
            val curSelected = ytPrefs.getString("pref_yt_stream_ttl_label", "4 Hours (Recommended)") ?: "4 Hours (Recommended)"
            val curIdx = options.indexOf(curSelected).coerceAtLeast(1)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Stream URL Cache Duration")
                .setSingleChoiceItems(options, curIdx) { dialog, which ->
                    val chosen = options[which]
                    val hours = hoursValues[which]
                    ytPrefs.edit()
                        .putString("pref_yt_stream_ttl_label", chosen)
                        .putInt("pref_yt_stream_ttl_hours", hours)
                        .apply()
                    YouTubeStreamResolver.setCacheTtlHours(hours)
                    updateSettingsUI()
                    // Silent notification removed
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.btnChangeYtStreamCacheTtl)?.setOnClickListener { openStreamCacheTtlDialog() }
        findViewById<View>(R.id.rowYtStreamCacheTtl)?.setOnClickListener { openStreamCacheTtlDialog() }

        layoutYtSavePill.setOnClickListener {
            currentPlayingYtVideo?.let { v ->
                val saved = YouTubeHistoryManager.toggleBookmark(this, v)
                // Silent notification removed
            }
        }

        layoutYtCommentsCard.setOnClickListener {
            val title = currentPlayingYtVideo?.title ?: "Video"
            showCommentsBottomSheet(title)
        }
    }

    private fun setupYouTubeMiniPlayer() {

        findViewById<View>(R.id.btnYtPlayerSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.btnYtYouSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.rowYtReturnToLocal)?.setOnClickListener {
            exitYouTubeToLocal()
        }

        findViewById<View>(R.id.btnYtYouNavHome)?.setOnClickListener {
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
        }
        findViewById<View>(R.id.btnYtYouNavSubs)?.setOnClickListener { loadSubscriptionsFeed() }
        findViewById<View>(R.id.btnYtYouNavYou)?.setOnClickListener { updateYouTabUI() }
        findViewById<View>(R.id.btnYtYouCast)?.setOnClickListener { showCastDevicesDialog() }

        btnYtNavLibrary.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.VISIBLE
        }
        cardYtMiniPlayer.setOnClickListener {
            if (::layoutYtMiniControlsOverlay.isInitialized && layoutYtMiniControlsOverlay.visibility == View.VISIBLE) {
                expandYouTubePlayer()
            } else {
                showMiniPlayerControls()
            }
        }

        btnYtMiniExpand.setOnClickListener {
            expandYouTubePlayer()
        }

        btnYtMiniPlayPause.setOnClickListener {
            YouTubeExoPlayerManager.togglePlayPause()
            val isPlaying = YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
            btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
            showMiniPlayerControls()
        }

        btnYtMiniClose.setOnClickListener {
            ytMiniControlsHideHandler.removeCallbacks(ytMiniControlsHideRunnable)
            YouTubeExoPlayerManager.stop()
            if (::playerViewYtMini.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
            }
            YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            cardYtMiniPlayer.visibility = View.GONE
            if (::layoutYtMiniControlsOverlay.isInitialized) {
                layoutYtMiniControlsOverlay.visibility = View.GONE
            }
            currentPlayingYtVideo = null
            isYtVideoPlaying = false
        }
    }

    private fun updateMiniPlayerUI() {
        val video = currentPlayingYtVideo
        if (video != null) {
            cardYtMiniPlayer.visibility = View.VISIBLE
            tvYtMiniTitle.text = video.title
            tvYtMiniChannel.text = video.channelTitle
            val isAudioMode = YouTubeExoPlayerManager.isAudioOnlyMode
            if (isAudioMode) {
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.visibility = View.GONE
                    YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
                }
                ivYtMiniThumb.visibility = View.VISIBLE
                ImageLoaderHelper.loadImage(video.thumbnailUrl, ivYtMiniThumb, R.drawable.ic_audio)
                ytMiniAudioVisualizerView?.visibility = View.GONE
                ytMiniAudioVisualizerView?.setPlaying(false)
                YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            } else {
                ivYtMiniThumb.visibility = View.GONE
                ytMiniAudioVisualizerView?.visibility = View.GONE
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.visibility = View.VISIBLE
                    YouTubeExoPlayerManager.switchPlayerView(playerViewYt, playerViewYtMini)
                }
            }
            btnYtMiniPlayPause.setImageResource(if (YouTubeExoPlayerManager.exoPlayer?.isPlaying == true) R.drawable.ic_pause_player else R.drawable.ic_play_player)
        } else {
            cardYtMiniPlayer.visibility = View.GONE
        }
    }

    private fun openYouTubeChannelPage(channelTitle: String, avatarUrl: String?) {
        if (channelTitle.isBlank()) return

        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val view = layoutInflater.inflate(R.layout.dialog_youtube_channel, null)
        dialog.setContentView(view)

        dialog.window?.let { win ->
            win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            win.statusBarColor = Color.parseColor("#0F0F0F")
            win.navigationBarColor = Color.parseColor("#0F0F0F")
        }

        view.findViewById<View>(R.id.btnChannelClose)?.setOnClickListener { dialog.dismiss() }

        val tvHeaderTitle = view.findViewById<TextView>(R.id.tvChannelHeaderTitle)
        val tvName = view.findViewById<TextView>(R.id.tvChannelName)
        val tvHandle = view.findViewById<TextView>(R.id.tvChannelHandle)
        val tvStats = view.findViewById<TextView>(R.id.tvChannelStats)
        val tvDesc = view.findViewById<TextView>(R.id.tvChannelDesc)
        val ivAvatar = view.findViewById<ImageView>(R.id.ivChannelAvatar)
        val ivBanner = view.findViewById<ImageView>(R.id.ivChannelBanner)
        val btnSub = view.findViewById<TextView>(R.id.btnChannelSubscribe)
        val btnJoin = view.findViewById<TextView>(R.id.btnChannelJoin)
        val tabHome = view.findViewById<TextView>(R.id.tabChannelHome)
        val tabVideos = view.findViewById<TextView>(R.id.tabChannelVideos)
        val tabLive = view.findViewById<TextView>(R.id.tabChannelLive)
        val tabPlaylists = view.findViewById<TextView>(R.id.tabChannelPlaylists)
        val rvVideos = view.findViewById<RecyclerView>(R.id.rvChannelVideos)
        val pbLoading = view.findViewById<ProgressBar>(R.id.pbChannelLoading)
        val tvEmpty = view.findViewById<TextView>(R.id.tvChannelEmpty)

        tvHeaderTitle?.text = channelTitle
        tvName?.text = channelTitle
        val cleanHandle = "@" + channelTitle.replace(" ", "").lowercase()
        tvHandle?.text = cleanHandle

        if (ivAvatar != null && !avatarUrl.isNullOrBlank()) {
            ImageLoaderHelper.loadImage(avatarUrl, ivAvatar, R.drawable.ic_account_circle)
        }

        val updateSubState = { isSubbed: Boolean ->
            btnSub?.text = if (isSubbed) "Subscribed ∨" else "Subscribe"
            if (isSubbed) {
                btnSub?.setBackgroundResource(R.drawable.bg_chip_black)
                btnSub?.setTextColor(Color.WHITE)
            } else {
                btnSub?.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
                btnSub?.setTextColor(Color.BLACK)
            }
        }

        val isSubbed = YouTubeSubscriptionManager.isSubscribed(this, channelTitle)
        updateSubState(isSubbed)

        btnSub?.setOnClickListener {
            if (YouTubeSubscriptionManager.isSubscribed(this, channelTitle)) {
                YouTubeSubscriptionManager.unsubscribe(this, channelTitle)
                updateSubState(false)
                Toast.makeText(this, "Unsubscribed from $channelTitle", Toast.LENGTH_SHORT).show()
            } else {
                YouTubeSubscriptionManager.subscribe(this, channelTitle, null, avatarUrl)
                updateSubState(true)
                Toast.makeText(this, "Subscribed to $channelTitle!", Toast.LENGTH_SHORT).show()
            }
            if (currentPlayingYtVideo?.channelTitle?.equals(channelTitle, ignoreCase = true) == true) {
                val nowSub = YouTubeSubscriptionManager.isSubscribed(this, channelTitle)
                btnYtSubscribe.text = if (nowSub) "Subscribed ∨" else "Subscribe"
                if (nowSub) {
                    btnYtSubscribe.setBackgroundColor(Color.parseColor("#272727"))
                    btnYtSubscribe.setTextColor(Color.WHITE)
                } else {
                    btnYtSubscribe.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
                    btnYtSubscribe.setTextColor(Color.BLACK)
                }
            }
        }

        // Functional ★ Join Membership Feature
        val channelVipKey = "vip_channel_" + channelTitle.trim().lowercase().replace(" ", "_")
        val vipPrefs = getSharedPreferences("cleanplayer_vip_channels", Context.MODE_PRIVATE)

        val updateJoinState = {
            val isVip = vipPrefs.getBoolean(channelVipKey, false)
            if (isVip) {
                btnJoin?.text = "★ Joined"
                btnJoin?.setTextColor(Color.parseColor("#FFD700"))
                btnJoin?.setBackgroundResource(R.drawable.bg_speed_preset_selected)
            } else {
                btnJoin?.text = "★ Join"
                btnJoin?.setTextColor(Color.WHITE)
                btnJoin?.setBackgroundResource(R.drawable.bg_chip_black)
            }
        }
        updateJoinState()

        btnJoin?.setOnClickListener {
            val isCurrentlyVip = vipPrefs.getBoolean(channelVipKey, false)
            if (isCurrentlyVip) {
                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                    .setTitle("★ $channelTitle Membership")
                    .setMessage("You are an active VIP Member of $channelTitle.\n\nBenefits:\n• VIP badge on channel & playback\n• Priority updates for live concerts & streams\n• Free supporter status in CleanPlayer")
                    .setPositiveButton("Keep Membership", null)
                    .setNegativeButton("Leave Membership") { _, _ ->
                        vipPrefs.edit().putBoolean(channelVipKey, false).apply()
                        updateJoinState()
                        Toast.makeText(this, "VIP membership removed", Toast.LENGTH_SHORT).show()
                    }
                    .show()
            } else {
                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                    .setTitle("★ Join $channelTitle Membership")
                    .setMessage("Join as a VIP Channel Member:\n\n• ★ Exclusive VIP Member badge on this channel\n• 🎵 Priority access to live concert streams & audio\n• ❤️ Support $channelTitle directly\n\n(CleanPlayer VIP Supporter feature)")
                    .setPositiveButton("★ Join Membership") { _, _ ->
                        vipPrefs.edit().putBoolean(channelVipKey, true).apply()
                        updateJoinState()
                        Toast.makeText(this, "🎉 You are now a VIP Member of $channelTitle!", Toast.LENGTH_LONG).show()
                    }
                    .setNegativeButton("Not Now", null)
                    .show()
            }
        }

        view.findViewById<View>(R.id.btnChannelSearch)?.setOnClickListener {
            dialog.dismiss()
            if (::etYtSearchQuery.isInitialized) { etYtSearchQuery.setText(channelTitle) }
            performYouTubeSearch(channelTitle)
        }

        rvVideos?.layoutManager = LinearLayoutManager(this)
        val channelAdapter = YouTubeFeedAdapter(this, emptyList()) { selectedVideo ->
            dialog.dismiss()
            playYouTubeVideoInApp(selectedVideo)
        }
        rvVideos?.adapter = channelAdapter

        pbLoading?.visibility = View.VISIBLE
        tvEmpty?.visibility = View.GONE

        val selectTab = { selected: TextView? ->
            listOf(tabHome, tabVideos, tabLive, tabPlaylists).forEach { tab ->
                if (tab == selected) {
                    tab?.setTextColor(Color.WHITE)
                } else {
                    tab?.setTextColor(Color.parseColor("#888888"))
                }
            }
        }

        var allChannelVideos = emptyList<YouTubeVideo>()

        val parseViewsCount: (String) -> Long = { rawViews ->
            val raw = rawViews.lowercase()
            if (raw.contains("m")) {
                val num = raw.substringBefore("m").replace("views", "").trim().toDoubleOrNull() ?: 0.0
                (num * 1_000_000).toLong()
            } else if (raw.contains("k")) {
                val num = raw.substringBefore("k").replace("views", "").trim().toDoubleOrNull() ?: 0.0
                (num * 1_000).toLong()
            } else if (raw.contains("lakh")) {
                val num = raw.substringBefore("lakh").replace("views", "").trim().toDoubleOrNull() ?: 0.0
                (num * 100_000).toLong()
            } else if (raw.contains("cr")) {
                val num = raw.substringBefore("cr").replace("views", "").trim().toDoubleOrNull() ?: 0.0
                (num * 10_000_000).toLong()
            } else {
                raw.replace("views", "").replace(",", "").trim().toLongOrNull() ?: 0L
            }
        }

        // 1. Home Tab: Featured / Top videos + Recent
        tabHome?.setOnClickListener {
            selectTab(tabHome)
            if (allChannelVideos.isEmpty()) {
                tvEmpty?.visibility = View.VISIBLE
                tvEmpty?.text = "No videos available"
                channelAdapter.updateItems(emptyList())
            } else {
                tvEmpty?.visibility = View.GONE
                val sortedPopular = allChannelVideos.sortedByDescending { parseViewsCount(it.views) }
                val featured = sortedPopular.take(2)
                val rest = allChannelVideos.filterNot { it.id in featured.map { f -> f.id } }
                channelAdapter.updateItems(featured + rest)
            }
        }

        // 2. Videos Tab: Complete video catalog
        tabVideos?.setOnClickListener {
            selectTab(tabVideos)
            if (allChannelVideos.isEmpty()) {
                tvEmpty?.visibility = View.VISIBLE
                tvEmpty?.text = "No videos uploaded yet"
                channelAdapter.updateItems(emptyList())
            } else {
                tvEmpty?.visibility = View.GONE
                channelAdapter.updateItems(allChannelVideos)
            }
        }

        // 3. Live Tab: Live streams & Live concert recordings
        tabLive?.setOnClickListener {
            selectTab(tabLive)
            val liveFilter = allChannelVideos.filter { v ->
                val t = v.title.lowercase()
                t.contains("live") || t.contains("concert") || t.contains("stream") ||
                t.contains("performance") || t.contains("session") || t.contains("stage") ||
                t.contains("tour")
            }
            if (liveFilter.isNotEmpty()) {
                tvEmpty?.visibility = View.GONE
                channelAdapter.updateItems(liveFilter)
            } else {
                pbLoading?.visibility = View.VISIBLE
                tvEmpty?.visibility = View.GONE
                YouTubeFeedRepository.searchVideos("$channelTitle live concert") { fetchedLive ->
                    pbLoading?.visibility = View.GONE
                    if (fetchedLive.isNotEmpty()) {
                        tvEmpty?.visibility = View.GONE
                        channelAdapter.updateItems(fetchedLive)
                    } else {
                        tvEmpty?.visibility = View.VISIBLE
                        tvEmpty?.text = "No live streams found for $channelTitle"
                        channelAdapter.updateItems(emptyList())
                    }
                }
            }
        }

        // 4. Playlists Tab: Albums, Mixes & Compilations
        tabPlaylists?.setOnClickListener {
            selectTab(tabPlaylists)
            val playlistFilter = allChannelVideos.filter { v ->
                val t = v.title.lowercase()
                t.contains("playlist") || t.contains("album") || t.contains("mix") ||
                t.contains("jukebox") || t.contains("nonstop") || t.contains("full audio") ||
                t.contains("vol") || t.contains("ep") || t.contains("compilation")
            }
            if (playlistFilter.isNotEmpty()) {
                tvEmpty?.visibility = View.GONE
                channelAdapter.updateItems(playlistFilter)
            } else {
                pbLoading?.visibility = View.VISIBLE
                tvEmpty?.visibility = View.GONE
                YouTubeFeedRepository.searchVideos("$channelTitle full album playlist") { fetchedPlaylists ->
                    pbLoading?.visibility = View.GONE
                    if (fetchedPlaylists.isNotEmpty()) {
                        tvEmpty?.visibility = View.GONE
                        channelAdapter.updateItems(fetchedPlaylists)
                    } else {
                        tvEmpty?.visibility = View.VISIBLE
                        tvEmpty?.text = "No playlists found for $channelTitle"
                        channelAdapter.updateItems(emptyList())
                    }
                }
            }
        }

        YouTubeFeedRepository.getChannelDetails(channelTitle, avatarUrl) { chName, chHandle, chAvatar, chBanner, subCount, vidCount, description, channelVideos ->
            pbLoading?.visibility = View.GONE
            tvHandle?.text = chHandle
            tvStats?.text = "$subCount • $vidCount"
            tvDesc?.text = "$description ...more >"

            if (ivAvatar != null && !chAvatar.isNullOrBlank()) {
                ImageLoaderHelper.loadImage(chAvatar, ivAvatar, R.drawable.ic_account_circle)
            }
            if (ivBanner != null && !chBanner.isNullOrBlank()) {
                ImageLoaderHelper.loadImage(chBanner, ivBanner, R.drawable.bg_youtube_premium_badge)
            }

            allChannelVideos = channelVideos
            if (channelVideos.isEmpty()) {
                tvEmpty?.visibility = View.VISIBLE
            } else {
                tvEmpty?.visibility = View.GONE
                selectTab(tabHome)
                val sortedPopular = allChannelVideos.sortedByDescending { parseViewsCount(it.views) }
                val featured = sortedPopular.take(2)
                val rest = allChannelVideos.filterNot { it.id in featured.map { f -> f.id } }
                channelAdapter.updateItems(featured + rest)
            }
        }

        dialog.show()
    }

    private fun updateFabPlayVisibility() {
        if (!::fabPlay.isInitialized) return
        val isLocalMediaTab = (tabVideo.visibility == View.VISIBLE || tabAudio.visibility == View.VISIBLE)
        val isYtActive = (tabYouTube.visibility == View.VISIBLE || layoutYtPlayerDetail.visibility == View.VISIBLE || cardYtMiniPlayer.visibility == View.VISIBLE)
        fabPlay.visibility = if (isLocalMediaTab && !isYtActive) View.VISIBLE else View.GONE
    }

    private fun collapseYouTubePlayer() {
        hideYouTubeOverlay()
        layoutYtPlayerDetail.visibility = View.GONE
        findViewById<View>(R.id.bottomNav)?.visibility = View.VISIBLE
        updateFabPlayVisibility()
        findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
        findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE

        val video = currentPlayingYtVideo
        if (video != null) {
            cardYtMiniPlayer.visibility = View.VISIBLE
            tvYtMiniTitle.text = video.title
            tvYtMiniChannel.text = video.channelTitle
            val isAudioMode = YouTubeExoPlayerManager.isAudioOnlyMode
            if (isAudioMode) {
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.visibility = View.GONE
                    YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
                }
                ivYtMiniThumb.visibility = View.VISIBLE
                ImageLoaderHelper.loadImage(video.thumbnailUrl, ivYtMiniThumb, R.drawable.ic_audio)
                ytMiniAudioVisualizerView?.visibility = View.GONE
                ytMiniAudioVisualizerView?.setPlaying(false)
                YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            } else {
                ivYtMiniThumb.visibility = View.GONE
                ytMiniAudioVisualizerView?.visibility = View.GONE
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.visibility = View.VISIBLE
                    YouTubeExoPlayerManager.switchPlayerView(playerViewYt, playerViewYtMini)
                }
            }
            showMiniPlayerControls()
        } else {
            cardYtMiniPlayer.visibility = View.GONE
        }
    }


    private fun showMiniPlayerControls() {
        if (::layoutYtMiniControlsOverlay.isInitialized) {
            layoutYtMiniControlsOverlay.visibility = View.VISIBLE
            val isPlaying = YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
            btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
            ytMiniControlsHideHandler.removeCallbacks(ytMiniControlsHideRunnable)
            ytMiniControlsHideHandler.postDelayed(ytMiniControlsHideRunnable, 2500)
        }
    }

    private fun expandYouTubePlayer() {
        ytMiniControlsHideHandler.removeCallbacks(ytMiniControlsHideRunnable)
        if (::layoutYtMiniControlsOverlay.isInitialized) {
            layoutYtMiniControlsOverlay.visibility = View.GONE
        }
        cardYtMiniPlayer.visibility = View.GONE
        layoutYtPlayerDetail.visibility = View.VISIBLE
        if (YouTubeExoPlayerManager.isAudioOnlyMode) {
            updateAudioModeUI(true)
        } else {
            playerViewYt.visibility = View.VISIBLE
            YouTubeExoPlayerManager.switchPlayerView(playerViewYtMini, playerViewYt)
        }
        showYouTubeOverlay()
    }

    private fun toggleYouTubeAspectRatio() {
        ytAspectRatioMode = (ytAspectRatioMode + 1) % 3
        applyYouTubeAspectRatio(ytAspectRatioMode)
    }

    private fun applyYouTubeAspectRatio(mode: Int) {
        ytAspectRatioMode = mode
        when (mode) {
            0 -> {
                playerViewYt.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                showYtGestureFeedback(R.drawable.ic_aspect_ratio, "Original (Fit)")
            }
            1 -> {
                playerViewYt.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                showYtGestureFeedback(R.drawable.ic_aspect_ratio, "Zoomed to fill")
            }
            2 -> {
                playerViewYt.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
                showYtGestureFeedback(R.drawable.ic_aspect_ratio, "Stretch")
            }
        }
        showYouTubeOverlay()
    }

    private fun showYouTubeAspectRatioDialog() {
        val options = arrayOf(
            "Original (Fit to screen)",
            "Zoomed to fill (No black bars)",
            "Stretch to screen"
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Video Aspect Ratio & Zoom")
            .setSingleChoiceItems(options, ytAspectRatioMode.coerceIn(0, 2)) { dialog, which ->
                applyYouTubeAspectRatio(which)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exitYouTubeToLocal() {
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            layoutYtPlayerDetail.visibility = View.GONE
        }
        if (::cardYtMiniPlayer.isInitialized && cardYtMiniPlayer.visibility == View.VISIBLE) {
            cardYtMiniPlayer.visibility = View.GONE
        }
        if (::playerViewYtMini.isInitialized) {
            playerViewYtMini.visibility = View.GONE
            YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
        }
        if (YouTubeExoPlayerManager.isPlaying()) {
            currentPlayingYtVideo?.let { v ->
                MediaPlaybackService.start(
                    context = this,
                    title = v.title,
                    artist = v.channelTitle,
                    isPlaying = true,
                    isYouTube = true,
                    thumbUrl = v.thumbnailUrl
                )
            }
        }
        showTab(video = true, audio = false, youtube = false, settings = false)
        bottomNav.selectedItemId = R.id.nav_video
        updateNotchPlayerUI()
    }

    private fun playYouTubeVideoInApp(video: YouTubeVideo) {
        PlayerHolder.stopPlayback(this)
        PlayerHolder.currentUri = null
        audioAdapter?.setPlayingUri(null)
        currentPlayingYtVideo = video
        isYtVideoPlaying = true
        YouTubeHistoryManager.addWatchHistory(this, video)

        // Populate video details using verified declared properties
        tvYtDetailTitle.text = video.title
        tvYtDetailSubtitle.text = "${video.views} • ${video.uploadDate}"
        tvYtDetailChannel.text = video.channelTitle
        ImageLoaderHelper.loadImage(video.channelAvatarUrl, ivYtDetailAvatar, R.drawable.ic_account_circle)
        tvYtDetailLikes.text = video.likes
        tvYtDetailCommentsCount.text = video.commentsCount

        val isSubState = YouTubeSubscriptionManager.isSubscribed(this, video.channelTitle)
        btnYtSubscribe.text = if (isSubState) "Subscribed ∨" else "Subscribe"
        if (isSubState) {
            btnYtSubscribe.setBackgroundColor(Color.parseColor("#272727"))
            btnYtSubscribe.setTextColor(Color.WHITE)
        } else {
            btnYtSubscribe.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
            btnYtSubscribe.setTextColor(Color.BLACK)
        }

        // Populate related recommendations in portrait feed below player
        val feedItems = youTubeFeedAdapter.getItems()
        val related = if (feedItems.isNotEmpty()) {
            feedItems.filter { it.id != video.id }
        } else {
            YouTubeFeedRepository.defaultFeed.filter { it.id != video.id }
        }
        youTubeFeedSecondaryAdapter.updateItems(related)

        cardYtMiniPlayer.visibility = View.GONE
        layoutYtPlayerDetail.visibility = View.VISIBLE
        pbYtBuffering.visibility = View.VISIBLE
        btnYtCenterPlayPause.visibility = View.GONE
        tvYtDownloadPill.text = "Download"
        ivYtDownloadPill.setImageResource(R.drawable.ic_download)
        ivYtDownloadPill.setColorFilter(Color.WHITE)
        YouTubeExoPlayerManager.attachPlayerView(playerViewYt)

        // Resolve pure, untracked streams via official TeamNewPipe NewPipeExtractor
        val targetRes = when (PlayerHolder.currentVideoQuality) {
            "4K Ultra HD (2160p)", "4K (2160p)", "2160p" -> 2160
            "2K Quad HD (1440p)", "2K (1440p)", "1440p" -> 1440
            "1080p", "1080p Full HD" -> 1080
            "720p", "720p HD" -> 720
            "480p", "480p SD" -> 480
            "360p", "360p Data Saver" -> 360
            "240p", "240p Low" -> 240
            "144p", "144p Ultra Data Saver", "144p Data Saver" -> 144
            else -> 720 // Default Auto to 720p (Adaptive Data Saver)
        }
        YouTubeStreamResolver.resolveStreams(video.id, targetRes) { resolvedStream ->
            pbYtBuffering.visibility = View.GONE
            if (resolvedStream != null && resolvedStream.videoUrl.isNotBlank()) {
                YouTubeFeedRepository.currentAvailableFormats = resolvedStream.availableQualities.map { opt ->
                    VideoStreamFormat(opt.qualityLabel, opt.resolution, opt.videoUrl, opt.audioUrl)
                }
                YouTubeExoPlayerManager.playVideo(
                    context = this,
                    video = video,
                    videoStreamUrl = resolvedStream.videoUrl,
                    audioStreamUrl = resolvedStream.audioUrl,
                    pureAudioUrl = resolvedStream.pureAudioUrl,
                    allAudioUrls = resolvedStream.allAudioUrls,
                    startInAudioOnly = YouTubeExoPlayerManager.isAudioOnlyMode
                )
                updateAudioModeUI(YouTubeExoPlayerManager.isAudioOnlyMode)
                // Video color filter removed
                btnYtCenterPlayPause.visibility = View.VISIBLE
                updateNotchPlayerUI()
            } else {
                btnYtCenterPlayPause.visibility = View.VISIBLE
                Toast.makeText(
                    this,
                    "Playback error: Unable to load video. Please check internet connection.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun updateMicroGAccountState() {
        if (MicroGAuthManager.isLoggedIn(this)) {
            btnYtAccount.setColorFilter(Color.parseColor("#4CAF50"))
        } else {
            btnYtAccount.clearColorFilter()
        }
    }

    private fun loadYouTubeFeed(category: String) {
        pbYtFeedLoading.visibility = View.VISIBLE
        layoutYtEmpty.visibility = View.GONE
        YouTubeFeedRepository.getFeed(category) { videos ->
            pbYtFeedLoading.visibility = View.GONE
            srlYouTubeFeed.isRefreshing = false
            isYtFeedLoaded = true

            if (videos.isEmpty()) {
                layoutYtEmpty.visibility = View.VISIBLE
            } else {
                layoutYtEmpty.visibility = View.GONE
                allYtFeedVideos.clear()
                allYtFeedVideos.addAll(videos)
                youTubeFeedAdapter.updateItems(videos)
                youTubeFeedSecondaryAdapter.updateItems(emptyList())
            }
        }
    }

    private fun performYouTubeSearch(query: String) {
        pbYtFeedLoading.visibility = View.VISIBLE
        layoutYtEmpty.visibility = View.GONE
        YouTubeFeedRepository.searchVideos(query) { videos ->
            pbYtFeedLoading.visibility = View.GONE
            if (videos.isEmpty()) {
                layoutYtEmpty.visibility = View.VISIBLE
            } else {
                layoutYtEmpty.visibility = View.GONE
                youTubeFeedAdapter.updateItems(videos)
                youTubeFeedSecondaryAdapter.updateItems(emptyList())
            }
        }
    }


    private fun enableImmersiveNotchMode() {
        try {
            window.navigationBarColor = Color.TRANSPARENT
            window.statusBarColor = Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.isNavigationBarContrastEnforced = false
                window.isStatusBarContrastEnforced = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.let { controller ->
                    controller.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            }
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun toggleYouTubeFullscreen() {
        isYtFullscreen = !isYtFullscreen
        val surfaceContainer = findViewById<View>(R.id.layoutYtPlayerSurfaceContainer)
        val detailsScroll = layoutYtPlayerDetail.let { detail ->
            (detail as? android.view.ViewGroup)?.getChildAt(1)
        }

        if (isYtFullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            detailsScroll?.visibility = View.GONE
            findViewById<View>(R.id.bottomNav)?.visibility = View.GONE
            if (::fabPlay.isInitialized) fabPlay.visibility = View.GONE
            val lp = surfaceContainer?.layoutParams
            if (lp != null) {
                lp.height = LinearLayout.LayoutParams.MATCH_PARENT
                lp.width = LinearLayout.LayoutParams.MATCH_PARENT
                surfaceContainer.layoutParams = lp
            }
            btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen_exit)
            enableImmersiveNotchMode()
            applyYouTubeAspectRatio(ytAspectRatioMode)
            showYouTubeOverlay()
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            detailsScroll?.visibility = View.VISIBLE
            findViewById<View>(R.id.bottomNav)?.visibility = View.VISIBLE
            updateFabPlayVisibility()
            val lp = surfaceContainer?.layoutParams
            if (lp != null) {
                lp.height = (230 * resources.displayMetrics.density).toInt()
                lp.width = LinearLayout.LayoutParams.MATCH_PARENT
                surfaceContainer.layoutParams = lp
            }
            btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen)
            window.statusBarColor = Color.parseColor("#0F0F0F")
            applyYouTubeAspectRatio(ytAspectRatioMode)
            showYouTubeOverlay()
        }
    }

    private fun updateYouTabUI() {
        val historyList = YouTubeHistoryManager.getWatchHistory(this)
        ytHistoryAdapter?.updateItems(historyList)
        findViewById<View>(R.id.rvYtHistory)?.visibility = if (historyList.isNotEmpty()) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnYtViewAllHistory)?.visibility = if (historyList.isNotEmpty()) View.VISIBLE else View.GONE

        val bookmarks = YouTubeHistoryManager.getBookmarks(this)
        ytDownloadsAdapter?.updateItems(bookmarks)
        findViewById<View>(R.id.rvYtDownloads)?.visibility = if (bookmarks.isNotEmpty()) View.VISIBLE else View.GONE

        // Profile matching screenshot 6217.jpg & YouTube Premium (Customizable per device)
        val tvName = findViewById<TextView>(R.id.tvYtYouName)
        val tvStatus = findViewById<TextView>(R.id.tvYtYouStatus)
        val profPrefs = getSharedPreferences("yt_profile_prefs", Context.MODE_PRIVATE)
        val defaultName = profPrefs.getString("profile_name", "Rajesh Shah") ?: "Rajesh Shah"
        val defaultHandle = profPrefs.getString("profile_handle", "@Rps11") ?: "@Rps11"

        if (MicroGAuthManager.isLoggedIn(this)) {
            tvName?.text = MicroGAuthManager.getAccountName(this)
            tvStatus?.text = "${MicroGAuthManager.getAccountEmail(this)} • MicroG Connected"
            tvStatus?.setTextColor(Color.parseColor("#4CAF50"))
        } else {
            tvName?.text = defaultName
            tvStatus?.text = "$defaultHandle • Tap here to Sign In with Google"
            tvStatus?.setTextColor(Color.parseColor("#FF8800"))
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        try {
            activeSettingsBottomSheet?.dismiss()
            activeSettingsBottomSheet = null
        } catch (e: Exception) {}

        if (tabYouTube.visibility == View.VISIBLE &&
            (layoutYtPlayerDetail.visibility == View.VISIBLE || cardYtMiniPlayer.visibility == View.VISIBLE) &&
            YouTubeExoPlayerManager.isPlaying()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    if (cardYtMiniPlayer.visibility == View.VISIBLE) {
                        expandYouTubePlayer()
                    }
                    val aspectRatio = Rational(16, 9)
                    val params = PictureInPictureParams.Builder()
                        .setAspectRatio(aspectRatio)
                        .build()
                    enterPictureInPictureMode(params)
                } catch (e: Exception) {}
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        val surface = findViewById<View>(R.id.layoutYtPlayerSurfaceContainer)
        if (isInPictureInPictureMode) {
            hideYouTubeOverlay()
            if (::layoutYtPlayerOverlay.isInitialized) {
                layoutYtPlayerOverlay.visibility = View.GONE
            }
            layoutYtGestureOverlay?.visibility = View.GONE
            btnYtCenterPlayPause.visibility = View.GONE
            btnYtCollapsePlayer.visibility = View.GONE
            btnYtFullscreen.visibility = View.GONE
            pbYtBuffering.visibility = View.GONE
            layoutYtPlayerDetail.let { detail ->
                (detail as? android.view.ViewGroup)?.getChildAt(1)?.visibility = View.GONE
            }
            findViewById<View>(R.id.layoutYtHeader)?.visibility = View.GONE
            findViewById<View>(R.id.bottomNav)?.visibility = View.GONE
            if (::fabPlay.isInitialized) fabPlay.visibility = View.GONE
            val lp = surface?.layoutParams
            if (lp != null) {
                lp.height = LinearLayout.LayoutParams.MATCH_PARENT
                surface.layoutParams = lp
            }
        } else {
            if (tabYouTube.visibility == View.VISIBLE) {
                layoutYtPlayerDetail.let { detail ->
                    (detail as? android.view.ViewGroup)?.getChildAt(1)?.visibility = View.VISIBLE
                }
                findViewById<View>(R.id.layoutYtHeader)?.visibility = View.VISIBLE
                if (!isYtFullscreen) {
                    findViewById<View>(R.id.bottomNav)?.visibility = View.VISIBLE
                    updateFabPlayVisibility()
                }
                val lp = surface?.layoutParams
                if (lp != null && !isYtFullscreen) {
                    lp.height = (230 * resources.displayMetrics.density).toInt()
                    surface.layoutParams = lp
                }
                showYouTubeOverlay()
            }
        }
    }

    
    private fun showEditProfileDialog() {
        val profPrefs = getSharedPreferences("yt_profile_prefs", Context.MODE_PRIVATE)
        val currentName = profPrefs.getString("profile_name", "Rajesh Shah") ?: "Rajesh Shah"
        val currentHandle = profPrefs.getString("profile_handle", "@Rps11") ?: "@Rps11"

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 40, 60, 20)
        }

        val etName = EditText(this).apply {
            hint = "Display Name (e.g. Rajesh Shah)"
            setText(currentName)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }

        val etHandle = EditText(this).apply {
            hint = "Channel Handle (e.g. @Rps11)"
            setText(currentHandle)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 30 }
        }

        container.addView(etName)
        container.addView(etHandle)

        AlertDialog.Builder(this)
            .setTitle("Edit YouTube Profile")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                val newName = etName.text.toString().trim().ifBlank { "Rajesh Shah" }
                val newHandle = etHandle.text.toString().trim().ifBlank { "@Rps11" }
                profPrefs.edit()
                    .putString("profile_name", newName)
                    .putString("profile_handle", if (newHandle.startsWith("@")) newHandle else "@$newHandle")
                    .apply()
                updateYouTabUI()
                Toast.makeText(this, "Profile updated: $newName", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    
    private fun showYouTubeOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode) {
            hideYouTubeOverlay()
            return
        }
        ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
        if (::pbYtBottomMiniProgress.isInitialized) {
            pbYtBottomMiniProgress.visibility = View.GONE
        }
        if (::btnYtCenterPlayPause.isInitialized) {
            btnYtCenterPlayPause.visibility = View.VISIBLE
            btnYtCenterPlayPause.setImageResource(
                if (YouTubeExoPlayerManager.isPlaying()) R.drawable.ic_pause_player else R.drawable.ic_play_player
            )
        }
        if (layoutYtPlayerOverlay.visibility != View.VISIBLE) {
            layoutYtPlayerOverlay.alpha = 0f
            layoutYtPlayerOverlay.visibility = View.VISIBLE
            layoutYtPlayerOverlay.animate()
                .alpha(1f)
                .setDuration(180)
                .start()
        }
        if (YouTubeExoPlayerManager.isPlaying()) {
            ytOverlayHandler.postDelayed(ytOverlayHideRunnable, 3000)
        }
    }

    private fun hideYouTubeOverlay() {
        ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
        if (::layoutYtPlayerOverlay.isInitialized) {
            layoutYtPlayerOverlay.animate().cancel()
            layoutYtPlayerOverlay.visibility = View.GONE
        }
        if (::pbYtBottomMiniProgress.isInitialized && !YouTubeExoPlayerManager.isAudioOnlyMode) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode) {
                pbYtBottomMiniProgress.visibility = View.GONE
            } else {
                pbYtBottomMiniProgress.visibility = View.VISIBLE
            }
        }
    }


    // =========================================================================
    private fun handleBackPress(): Boolean {
        if (tabYouTube.visibility == View.VISIBLE) {
            if (isYtFullscreen) {
                toggleYouTubeFullscreen()
                return true
            }
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
                return true
            }
            if (findViewById<View>(R.id.layoutYtYouContainer)?.visibility == View.VISIBLE) {
                findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
                findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
                return true
            }
            if (layoutYtSearchBar.visibility == View.VISIBLE) {
                layoutYtSearchBar.visibility = View.GONE
                loadYouTubeFeed(currentYtCategory)
                return true
            }

            // When user presses Back from YouTube feed:
            // Smoothly navigate back to main screen (Video tab with toolbar & 3-dot menu)
            exitYouTubeToLocal()
            return true
        } else if (isFolderViewActive && currentSelectedFolder != null) {
            closeFolderDetail()
            return true
        }

        if (activeShareProgressDialog?.isShowing == true) {
            activeShareProgressDialog?.dismiss()
            activeShareProgressDialog = null
            
            refreshShareTabUI()
            return true
        }

        if (FastShareService.isTransferActive.get()) {
            
            moveTaskToBack(true)
            return true
        }

        if (YouTubeExoPlayerManager.isPlaying() || PlayerHolder.audioExoPlayer?.isPlaying == true || PlayerHolder.mediaPlayer?.isPlaying == true) {
            moveTaskToBack(true)
            return true
        }

        return false
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            if (handleBackPress()) return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (handleBackPress()) return
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    private fun showYouTubePremiumBenefitsDialog() {
        val benefits = arrayOf(
            "🛡️ Ad-Free Playback (Active - 0 Ads Encountered)",
            "🎧 Background Audio Playback (Screen Off / Minimized)",
            "📱 Picture-in-Picture Mode (Automatic Floating Window)",
            "⬇️ Smart Offline Downloads (High Quality Storage)",
            "⚡ 1080p Premium Enhanced Bitrate (Enabled)",
            "🎵 YouTube Music Ad-Free Streaming (Active)"
        )
        AlertDialog.Builder(this)
            .setTitle("YouTube Premium Benefits")
            .setItems(benefits) { _, _ -> }
            .setPositiveButton("Close", null)
            .setNeutralButton("Premium Settings") { _, _ ->
                showYouTubeDedicatedSettingsDialog()
            }
            .show()
    }

    private fun showYouTubeListeningControlsDialog() {
        val speeds = arrayOf("0.75x", "1.0x (Normal)", "1.25x", "1.5x", "2.0x")
        val speedValues = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val currentSpeed = YouTubeExoPlayerManager.exoPlayer?.playbackParameters?.speed ?: 1.0f

        val options = arrayOf(
            "⏪ Rewind 10 seconds",
            "⏩ Forward 10 seconds",
            "⚡ Speed: ${currentSpeed}x",
            "🎧 Background Play: Always Enabled (Premium)",
            "📱 Enter Picture-in-Picture Mode"
        )

        AlertDialog.Builder(this)
            .setTitle("🎧 YouTube Premium Listening Controls")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val p = (YouTubeExoPlayerManager.getCurrentPosition() - 10000).coerceAtLeast(0)
                        YouTubeExoPlayerManager.seekTo(p)
                        Toast.makeText(this, "Rewound 10s", Toast.LENGTH_SHORT).show()
                    }
                    1 -> {
                        val d = YouTubeExoPlayerManager.getDuration()
                        val p = (YouTubeExoPlayerManager.getCurrentPosition() + 10000).coerceAtMost(d)
                        YouTubeExoPlayerManager.seekTo(p)
                        Toast.makeText(this, "Forwarded 10s", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        AlertDialog.Builder(this)
                            .setTitle("Select Playback Speed")
                            .setItems(speeds) { _, sIdx ->
                                YouTubeExoPlayerManager.exoPlayer?.setPlaybackSpeed(speedValues[sIdx])
                                Toast.makeText(this, "Speed set to ${speeds[sIdx]}", Toast.LENGTH_SHORT).show()
                            }
                            .show()
                    }
                    3 -> {
                        // Unwanted popup removed
                    }
                    4 -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            try {
                                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
                            } catch (e: Exception) {}
                        }
                    }
                }
            }
            .setPositiveButton("Done", null)
            .show()
    }

    // --- 1. Video Settings Handlers ---
    private fun setupVideoSettings() {
        btnToggleHighRefreshRate.setOnClickListener {
            PlayerHolder.isHighRefreshRateEnabled = !PlayerHolder.isHighRefreshRateEnabled
            PlayerHolder.savePreferences(this)
            applyHighRefreshRate()
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHighRefreshRate).setOnClickListener {
            btnToggleHighRefreshRate.performClick()
        }

        val orientationOptions = arrayOf("Auto Sensor (Free Rotation)", "Direct Landscape (Recommended)", "Portrait (Vertical)")
        val openOrientationDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Default Video Orientation")
                .setSingleChoiceItems(orientationOptions, PlayerHolder.defaultOrientation) { dialog, which ->
                    PlayerHolder.defaultOrientation = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeOrientation.setOnClickListener { openOrientationDialog() }
        findViewById<View>(R.id.rowDefaultOrientation).setOnClickListener { openOrientationDialog() }

        btnToggleWideColor.setOnClickListener {
            PlayerHolder.isWideColorGamutEnabled = !PlayerHolder.isWideColorGamutEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowWideColor).setOnClickListener {
            btnToggleWideColor.performClick()
        }

        btnToggleDeblocking.setOnClickListener {
            PlayerHolder.isDeblockingFilterEnabled = !PlayerHolder.isDeblockingFilterEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDeblocking).setOnClickListener {
            btnToggleDeblocking.performClick()
        }
        val hwOptions = arrayOf("Disabled (Software)", "Automatic (Recommended)", "Decoding Only", "Full Acceleration")
        val openHwDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_hw_decoding)
                .setSingleChoiceItems(hwOptions, PlayerHolder.hwAccelerationMode) { dialog, which ->
                    PlayerHolder.hwAccelerationMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeHw.setOnClickListener { openHwDialog() }
        findViewById<View>(R.id.rowHwDecode).setOnClickListener { openHwDialog() }

        val bgPipOptions = arrayOf("Stop Playback", "Play in Background", "Picture-in-Picture (PiP)")
        val openBgPipDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_bg_pip)
                .setSingleChoiceItems(bgPipOptions, PlayerHolder.backgroundPipMode) { dialog, which ->
                    PlayerHolder.backgroundPipMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeBgPip.setOnClickListener { openBgPipDialog() }
        findViewById<View>(R.id.rowBgPip).setOnClickListener { openBgPipDialog() }

        val resumeOptions = arrayOf("Never (Always start from beginning)", "Ask confirmation on open", "Always resume automatically")
        val openResumeDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_resume)
                .setSingleChoiceItems(resumeOptions, PlayerHolder.resumeMode) { dialog, which ->
                    PlayerHolder.resumeMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeResumeMode.setOnClickListener { openResumeDialog() }
        findViewById<View>(R.id.rowResumeMode).setOnClickListener { openResumeDialog() }

        val seekOptions = arrayOf("5 seconds", "10 seconds", "20 seconds", "30 seconds")
        val seekValues = arrayOf(5, 10, 20, 30)
        val openSeekDialog = {
            val currentIdx = seekValues.indexOf(PlayerHolder.doubleTapSeekSeconds).coerceAtLeast(1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_double_tap)
                .setSingleChoiceItems(seekOptions, currentIdx) { dialog, which ->
                    PlayerHolder.doubleTapSeekSeconds = seekValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDoubleTap.setOnClickListener { openSeekDialog() }
        findViewById<View>(R.id.rowDoubleTap).setOnClickListener { openSeekDialog() }

        val aspectOptions = arrayOf("Best Fit (Default)", "Fit Screen", "Fill Screen", "16:9 Aspect Ratio", "4:3 Aspect Ratio")
        val openAspectDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_aspect_ratio)
                .setSingleChoiceItems(aspectOptions, PlayerHolder.defaultAspectRatio) { dialog, which ->
                    PlayerHolder.defaultAspectRatio = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAspectRatio.setOnClickListener { openAspectDialog() }
        findViewById<View>(R.id.rowAspectRatio).setOnClickListener { openAspectDialog() }

        btnToggleAudioBoost.setOnClickListener {
            PlayerHolder.isAudioBoostEnabled = !PlayerHolder.isAudioBoostEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowAudioBoost).setOnClickListener {
            btnToggleAudioBoost.performClick()
        }
    }

    // --- 2. Integrated Dolby, Spatial & Equalizer Audio Suite Handlers ---
    private fun setupAudioSuiteSettings() {
        // Master Profile Dialog
        val openMasterProfileDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Select Audio Profile")
                .setSingleChoiceItems(PlayerHolder.masterProfileNames, PlayerHolder.masterAudioProfile) { dialog, which ->
                    PlayerHolder.applyMasterProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeMasterProfile.setOnClickListener { openMasterProfileDialog() }
        findViewById<View>(R.id.rowMasterProfile).setOnClickListener { openMasterProfileDialog() }

        // Dolby & Spatial Virtualizer Mode
        val modes = arrayOf("Standard Stereo (Downmix)", "Dolby 3D Headphone (Binaural HRTF)", "Dolby ProLogic Surround (Matrix)", "Cinema 3D Soundstage (Wide Room)")
        val openDolbyDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_dolby_surround)
                .setSingleChoiceItems(modes, PlayerHolder.dolbySpatialMode) { dialog, which ->
                    PlayerHolder.dolbySpatialMode = which
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDolbySurround.setOnClickListener { openDolbyDialog() }
        findViewById<View>(R.id.rowDolbySurround).setOnClickListener { openDolbyDialog() }

        // 10-Band Equalizer Presets
        val openEqDialog = {
            val presets = PlayerHolder.equalizerPresets
            val currentIdx = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_equalizer)
                .setSingleChoiceItems(presets, currentIdx) { dialog, which ->
                    PlayerHolder.currentEqualizerPreset = which - 1
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeEqualizer.setOnClickListener { openEqDialog() }
        findViewById<View>(R.id.rowEqualizer).setOnClickListener { openEqDialog() }

        // Dialogue Boost (Night Mode) Toggle
        btnToggleDialogueBoost.setOnClickListener {
            PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
            PlayerHolder.masterAudioProfile = 4 // Custom
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDialogueBoost).setOnClickListener {
            btnToggleDialogueBoost.performClick()
        }

        // Digital Passthrough Toggle
        btnTogglePassthrough.setOnClickListener {
            PlayerHolder.isDolbyPassthroughEnabled = !PlayerHolder.isDolbyPassthroughEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDigitalPassthrough).setOnClickListener {
            btnTogglePassthrough.performClick()
        }

        // Audio Output Engine Dialog
        val engines = arrayOf("AudioTrack (Standard)", "OpenSL ES (Low Latency)", "AAudio (Modern NDK)")
        val openEngineDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_audio_output)
                .setSingleChoiceItems(engines, PlayerHolder.audioOutputEngine) { dialog, which ->
                    PlayerHolder.audioOutputEngine = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAudioOutput.setOnClickListener { openEngineDialog() }
        findViewById<View>(R.id.rowAudioOutput).setOnClickListener { openEngineDialog() }

        btnToggleHeadsetPause.setOnClickListener {
            PlayerHolder.isHeadsetPauseEnabled = !PlayerHolder.isHeadsetPauseEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHeadsetPause).setOnClickListener {
            btnToggleHeadsetPause.performClick()
        }

        btnToggleTimeStretch.setOnClickListener {
            PlayerHolder.isTimeStretchingEnabled = !PlayerHolder.isTimeStretchingEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowTimeStretching).setOnClickListener {
            btnToggleTimeStretch.performClick()
        }
    }

    // --- 3. Subtitle Settings Handlers ---
    
    private fun showSubtitleSettings() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        activeSettingsBottomSheet = dialog
        dialog.setOnDismissListener { activeSettingsBottomSheet = null }
        val view = layoutInflater.inflate(R.layout.dialog_subtitle_settings, null)
        dialog.setContentView(view)

        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.let { sheet ->
                val behavior = com.google.android.material.bottomsheet.BottomSheetBehavior.from(sheet)
                behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
            }
        }

        val isMono = PlayerHolder.isMonochrome()
        val accentColor = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        val accentTintList = ColorStateList.valueOf(accentColor)

        view.findViewById<TextView>(R.id.tvSubHeaderTitle)?.setTextColor(accentColor)
        view.findViewById<View>(R.id.btnSubBack).setOnClickListener { dialog.dismiss() }
        view.findViewById<View>(R.id.btnSubSearch)?.setOnClickListener { subtitlePickerLauncher.launch(arrayOf("*/*")); dialog.dismiss() }

        val subHeaders = listOf(
            R.id.tvHeaderFontStyle,
            R.id.tvHeaderBg,
            R.id.tvHeaderShadow,
            R.id.tvHeaderOutline,
            R.id.tvHeaderPos
        )
        for (hId in subHeaders) {
            view.findViewById<TextView>(hId)?.setTextColor(accentColor)
        }

        val checkBoxes = listOf(
            R.id.cbSubAutoLoad,
            R.id.cbSubBold,
            R.id.cbSubBgToggle,
            R.id.cbSubShadowToggle,
            R.id.cbSubOutlineToggle
        )
        for (cbId in checkBoxes) {
            view.findViewById<CheckBox>(cbId)?.buttonTintList = accentTintList
        }

        val seekBars = listOf(
            R.id.sbSubFontOpacity,
            R.id.sbSubBgOpacity,
            R.id.sbSubShadowOpacity,
            R.id.sbSubOutlineOpacity
        )
        for (sbId in seekBars) {
            view.findViewById<SeekBar>(sbId)?.apply {
                progressTintList = accentTintList
                thumbTintList = accentTintList
            }
        }

        // Presets
        view.findViewById<View>(R.id.rowSubPresets).setOnClickListener {
            val presets = arrayOf("Default (White + Shadow)", "Cinema (Yellow + Outline)", "High Contrast (Black Box)", "Clean Minimal")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles presets")
                .setItems(presets) { _, which ->
                    when (which) {
                        0 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBold = false
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = true
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        1 -> {
                            PlayerHolder.subFontColor = "16772155"
                            PlayerHolder.isSubBold = true
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        2 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = true
                            PlayerHolder.subBackgroundOpacity = 75
                        }
                        3 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = false
                            PlayerHolder.isSubOutlineEnabled = false
                        }
                    }
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                    showSubtitleSettings()
                }
                .show()
        }

        // Auto load subtitles
        val cbAutoLoad = view.findViewById<CheckBox>(R.id.cbSubAutoLoad)
        cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
        view.findViewById<View>(R.id.rowSubAutoLoad).setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }

        // Subtitle text encoding
        val tvEncoding = view.findViewById<TextView>(R.id.tvSubEncodingSub)
        tvEncoding.text = "Default (" + PlayerHolder.subEncoding + ")"
        view.findViewById<View>(R.id.rowSubEncoding).setOnClickListener {
            val encodings = arrayOf("UTF-8", "Windows-1252", "ISO-8859-1", "GBK", "Big5")
            val cur = encodings.indexOf(PlayerHolder.subEncoding).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitle text encoding")
                .setSingleChoiceItems(encodings, cur) { d, w ->
                    PlayerHolder.subEncoding = encodings[w]
                    tvEncoding.text = "Default (" + encodings[w] + ")"
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Preferred subtitle language
        val tvLang = view.findViewById<TextView>(R.id.tvSubLanguageSub)
        tvLang.text = PlayerHolder.subPreferredLanguage
        view.findViewById<View>(R.id.rowSubLanguage).setOnClickListener {
            val langs = arrayOf("No language preference", "English", "Hindi", "Spanish", "French", "German")
            val cur = langs.indexOf(PlayerHolder.subPreferredLanguage).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Preferred subtitle language")
                .setSingleChoiceItems(langs, cur) { d, w ->
                    PlayerHolder.subPreferredLanguage = langs[w]
                    tvLang.text = langs[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        // Subtitle Size
        val tvSize = view.findViewById<TextView>(R.id.tvSubSizeSub)
        val sizeLabel = when (PlayerHolder.subFontSize) {
            "14" -> "Small"
            "22" -> "Large"
            "26" -> "Extra large"
            else -> "Normal"
        }
        tvSize.text = sizeLabel
        view.findViewById<View>(R.id.rowSubSize).setOnClickListener {
            val sizes = arrayOf("Small", "Normal", "Large", "Extra large")
            val sizeVals = arrayOf("14", "18", "22", "26")
            val cur = sizeVals.indexOf(PlayerHolder.subFontSize).let { if (it < 0) 1 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles Size")
                .setSingleChoiceItems(sizes, cur) { d, w ->
                    PlayerHolder.subFontSize = sizeVals[w]
                    tvSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Bold subtitles
        val cbBold = view.findViewById<CheckBox>(R.id.cbSubBold)
        cbBold.isChecked = PlayerHolder.isSubBold
        view.findViewById<View>(R.id.rowSubBold).setOnClickListener {
            PlayerHolder.isSubBold = !PlayerHolder.isSubBold
            cbBold.isChecked = PlayerHolder.isSubBold
            PlayerHolder.savePreferences(this)
        }

        // Font Colour Badge
        val cardFontBadge = view.findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardSubFontColorBadge)
        val fontBadgeColor = try {
            val cL = PlayerHolder.subFontColor.toLongOrNull() ?: 16777215L
            if (cL <= 16777215L) (0xFF000000 or cL).toInt() else cL.toInt()
        } catch (e: Exception) { Color.WHITE }
        cardFontBadge.setCardBackgroundColor(fontBadgeColor)

        view.findViewById<View>(R.id.rowSubFontColor).setOnClickListener {
            val colors = arrayOf("White", "Yellow", "Cyan", "Green", "Amber")
            val colorVals = arrayOf("16777215", "16772155", "58879", "6942894", "16766720")
            val colorInts = arrayOf(Color.WHITE, Color.parseColor("#FFEB3B"), Color.parseColor("#00E5FF"), Color.parseColor("#69F0AE"), Color.parseColor("#FFD700"))
            val cur = colorVals.indexOf(PlayerHolder.subFontColor).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Colour")
                .setSingleChoiceItems(colors, cur) { d, w ->
                    PlayerHolder.subFontColor = colorVals[w]
                    cardFontBadge.setCardBackgroundColor(colorInts[w])
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Font Opacity
        val sbFontOpacity = view.findViewById<SeekBar>(R.id.sbSubFontOpacity)
        sbFontOpacity.progress = PlayerHolder.subFontOpacity
        sbFontOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subFontOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Background Checkbox & Slider
        val cbBg = view.findViewById<CheckBox>(R.id.cbSubBgToggle)
        cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
        view.findViewById<View>(R.id.rowSubBgToggle).setOnClickListener {
            PlayerHolder.isSubBackgroundEnabled = !PlayerHolder.isSubBackgroundEnabled
            cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
            PlayerHolder.savePreferences(this)
        }
        val sbBgOpacity = view.findViewById<SeekBar>(R.id.sbSubBgOpacity)
        sbBgOpacity.progress = PlayerHolder.subBackgroundOpacity
        sbBgOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subBackgroundOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Shadow Checkbox & Slider
        val cbShadow = view.findViewById<CheckBox>(R.id.cbSubShadowToggle)
        cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
        view.findViewById<View>(R.id.rowSubShadowToggle).setOnClickListener {
            PlayerHolder.isSubShadowEnabled = !PlayerHolder.isSubShadowEnabled
            cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
            PlayerHolder.savePreferences(this)
        }
        val sbShadowOpacity = view.findViewById<SeekBar>(R.id.sbSubShadowOpacity)
        sbShadowOpacity.progress = PlayerHolder.subShadowOpacity
        sbShadowOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subShadowOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Outline Checkbox & Slider
        val cbOutline = view.findViewById<CheckBox>(R.id.cbSubOutlineToggle)
        cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
        view.findViewById<View>(R.id.rowSubOutlineToggle).setOnClickListener {
            PlayerHolder.isSubOutlineEnabled = !PlayerHolder.isSubOutlineEnabled
            cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
            PlayerHolder.savePreferences(this)
        }
        val tvOutlineSize = view.findViewById<TextView>(R.id.tvSubOutlineSizeSub)
        tvOutlineSize.text = when (PlayerHolder.subOutlineSize) { 0 -> "Thin"; 2 -> "Thick"; else -> "Normal" }
        view.findViewById<View>(R.id.rowSubOutlineSize).setOnClickListener {
            val sizes = arrayOf("Thin", "Normal", "Thick")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Outline Size")
                .setSingleChoiceItems(sizes, PlayerHolder.subOutlineSize.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subOutlineSize = w
                    tvOutlineSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }
        val sbOutlineOpacity = view.findViewById<SeekBar>(R.id.sbSubOutlineOpacity)
        sbOutlineOpacity.progress = PlayerHolder.subOutlineOpacity
        sbOutlineOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subOutlineOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitle Screen Position & Elevation
        val tvPos = view.findViewById<TextView>(R.id.tvSubPositionSub)
        tvPos.text = when (PlayerHolder.subPosition) { 1 -> "Elevated (Above controls)"; 2 -> "Center Screen"; else -> "Standard Bottom (Default)" }
        view.findViewById<View>(R.id.rowSubPosition).setOnClickListener {
            val posNames = arrayOf("Standard Bottom (Default)", "Elevated (Above controls)", "Center Screen")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles position & elevation")
                .setSingleChoiceItems(posNames, PlayerHolder.subPosition.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subPosition = w
                    tvPos.text = posNames[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        dialog.show()
    }

    private fun setupSubtitleSettings() {
        findViewById<View>(R.id.rowSubtitles)?.setOnClickListener {
            showSubtitleSettings()
        }
        btnToggleSubAutoload.setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubAutoload).setOnClickListener {
            btnToggleSubAutoload.performClick()
        }

        val sizeLabels = arrayOf("Very Small (12sp)", "Small (14sp)", "Normal (18sp)", "Large (24sp)", "Huge (32sp)")
        val sizeValues = arrayOf("12", "14", "18", "24", "32")
        val openSizeDialog = {
            val currentIdx = sizeValues.indexOf(PlayerHolder.subFontSize).coerceAtLeast(2)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_size)
                .setSingleChoiceItems(sizeLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontSize = sizeValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubSize.setOnClickListener { openSizeDialog() }
        findViewById<View>(R.id.rowSubSize).setOnClickListener { openSizeDialog() }

        val colorLabels = arrayOf("White", "Yellow", "Cyan", "Green")
        val colorValues = arrayOf("16777215", "16776960", "65535", "65280")
        val openColorDialog = {
            val currentIdx = colorValues.indexOf(PlayerHolder.subFontColor).coerceAtLeast(0)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_color)
                .setSingleChoiceItems(colorLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontColor = colorValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubColor.setOnClickListener { openColorDialog() }
        findViewById<View>(R.id.rowSubColor).setOnClickListener { openColorDialog() }

        val bgLabels = arrayOf("Transparent / None", "Translucent Box", "Solid Black Box")
        val openBgDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_background)
                .setSingleChoiceItems(bgLabels, PlayerHolder.subBackgroundStyle) { dialog, which ->
                    PlayerHolder.subBackgroundStyle = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubBackground.setOnClickListener { openBgDialog() }
        findViewById<View>(R.id.rowSubBackground).setOnClickListener { openBgDialog() }

        btnToggleSubStyle.setOnClickListener {
            PlayerHolder.subFontStyle = if (PlayerHolder.subFontStyle == 1) 0 else 1
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubStyle).setOnClickListener {
            btnToggleSubStyle.performClick()
        }

        val encodings = arrayOf("UTF-8 (Default)", "Windows-1252 (Western)", "ISO-8859-1 (Latin)", "GBK (Chinese)", "Shift-JIS (Japanese)")
        val encValues = arrayOf("UTF-8", "WINDOWS-1252", "ISO-8859-1", "GBK", "SHIFT-JIS")
        val openEncDialog = {
            val currentIdx = encValues.indexOf(PlayerHolder.subEncoding).coerceAtLeast(0)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_encoding)
                .setSingleChoiceItems(encodings, currentIdx) { dialog, which ->
                    PlayerHolder.subEncoding = encValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubEncoding.setOnClickListener { openEncDialog() }
        findViewById<View>(R.id.rowSubEncoding).setOnClickListener { openEncDialog() }
    }

    // --- 4. Controls & Gestures Handlers ---
    private fun setupGestureSettings() {
        btnToggleGestureVolume.setOnClickListener {
            PlayerHolder.isVolumeGestureEnabled = !PlayerHolder.isVolumeGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureVolume).setOnClickListener { btnToggleGestureVolume.performClick() }

        btnToggleGestureBrightness.setOnClickListener {
            PlayerHolder.isBrightnessGestureEnabled = !PlayerHolder.isBrightnessGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureBrightness).setOnClickListener { btnToggleGestureBrightness.performClick() }

        btnToggleGestureSeek.setOnClickListener {
            PlayerHolder.isSeekGestureEnabled = !PlayerHolder.isSeekGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureSeek).setOnClickListener { btnToggleGestureSeek.performClick() }

        btnToggleFastSeek.setOnClickListener {
            PlayerHolder.isFastSeekEnabled = !PlayerHolder.isFastSeekEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowFastSeek).setOnClickListener { btnToggleFastSeek.performClick() }
    }

    // --- 5. Interface & Advanced Handlers ---
    private fun setupInterfaceAndAdvancedSettings() {
        val themes = arrayOf("Pure Black OLED (Default)", "Dark Charcoal", getString(R.string.theme_monochrome))
        val openThemeDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_app_theme)
                .setSingleChoiceItems(themes, PlayerHolder.appThemeMode) { dialog, which ->
                    if (PlayerHolder.appThemeMode != which) {
                        PlayerHolder.appThemeMode = which
                        PlayerHolder.savePreferences(this)
                        dialog.dismiss()
                        applyThemeUI()
                        recreate()
                    } else {
                        dialog.dismiss()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAppTheme.setOnClickListener { openThemeDialog() }
        findViewById<View>(R.id.rowAppTheme).setOnClickListener { openThemeDialog() }

        updateCacheSizeDisplay()
        btnClearCache.setOnClickListener {
            clearAppCache()
            updateCacheSizeDisplay()
            Toast.makeText(this, "Cache cleared successfully", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.rowClearCache).setOnClickListener { btnClearCache.performClick() }

        findViewById<View>(R.id.rowAppVersion)?.setOnClickListener {
            showAppVersionDialog()
        }

        btnClearResume.setOnClickListener {
            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            prefs.edit().clear().apply()
            Toast.makeText(this, "Playback history cleared", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.rowClearResume).setOnClickListener { btnClearResume.performClick() }

        btnResetSettings.setOnClickListener {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_reset_settings)
                .setMessage("Restore all player settings to default values?")
                .setPositiveButton("Reset") { _, _ ->
                    PlayerHolder.resetPreferences(this)
                    updateSettingsUI()
                    Toast.makeText(this, "Settings restored to defaults", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.rowResetSettings).setOnClickListener { btnResetSettings.performClick() }
    }

    private fun applyHighRefreshRate() {
        if (!PlayerHolder.isHighRefreshRateEnabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val modes = display?.supportedModes ?: emptyArray()
                val currentMode = display?.mode
                val targetMode = modes.filter {
                    currentMode == null || (it.physicalWidth == currentMode.physicalWidth && it.physicalHeight == currentMode.physicalHeight)
                }.maxByOrNull { it.refreshRate } ?: modes.maxByOrNull { it.refreshRate }

                targetMode?.let { mode ->
                    val params = window.attributes
                    params.preferredDisplayModeId = mode.modeId
                    window.attributes = params
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun updateToggleButton(btn: Button, isEnabled: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isEnabled) "ON" else "OFF"
        btn.setTextColor(if (isEnabled) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isEnabled) primaryColor else offStrokeColor)
    }

    private fun updateSubStyleButton(btn: Button, isBold: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isBold) "BOLD" else "REG"
        btn.setTextColor(if (isBold) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isBold) primaryColor else offStrokeColor)
    }

    private fun styleActionButton(btn: Button) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        btn.setTextColor(primaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(primaryColor)
    }

    private fun applyThemeUI() {
        val bgMain = when (PlayerHolder.appThemeMode) {
            PlayerHolder.THEME_CHARCOAL -> Color.parseColor("#181818")
            else -> Color.parseColor("#000000") // Pure Black for OLED and Monochrome
        }
        window.decorView.setBackgroundColor(bgMain)
        toolbar.setBackgroundColor(bgMain)
        bottomNav.setBackgroundColor(bgMain)
        tabVideo.setBackgroundColor(bgMain)
        tabAudio.setBackgroundColor(bgMain)
        tabSettings.setBackgroundColor(bgMain)
        if (::tabShare.isInitialized) {
            tabShare.setBackgroundColor(bgMain)
            val heroCard = findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardShareHero)
            val cardBg = if (PlayerHolder.appThemeMode == PlayerHolder.THEME_CHARCOAL) Color.parseColor("#1C1D24") else Color.parseColor("#16171D")
            heroCard?.setCardBackgroundColor(cardBg)
        }
        findViewById<View>(R.id.topBarContainer)?.setBackgroundColor(bgMain)

        val isMono = PlayerHolder.isMonochrome()
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()

        // 1. Bottom Navigation
        val navTint = if (isMono) {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint_mono)
        } else {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint)
        }
        bottomNav.itemIconTintList = navTint
        bottomNav.itemTextColor = navTint

        // 2. Floating Action Button (FAB)
        fabPlay.backgroundTintList = ColorStateList.valueOf(PlayerHolder.getFabBgColorInt())
        fabPlay.setColorFilter(PlayerHolder.getFabIconColorInt())

        // 3. Top Tabs (VIDEOS / FOLDERS)
        if (isFolderViewActive) {
            btnViewFolders.setTextColor(primaryColor)
            btnViewAllVideos.setTextColor(secondaryColor)
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)
        }

        // 4. Search Bar
        val layoutSearch = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.layoutSearch)
        layoutSearch?.boxStrokeColor = primaryColor
        layoutSearch?.hintTextColor = ColorStateList.valueOf(primaryColor)

        // 5. Notch Dynamic Island Player
        btnNotchPlayPause.setColorFilter(primaryColor)
        btnNotchOpen.setColorFilter(primaryColor)
        findViewById<ImageView>(R.id.ivNotchIcon)?.setColorFilter(primaryColor)
        sbNotch.progressTintList = ColorStateList.valueOf(primaryColor)
        sbNotch.thumbTintList = ColorStateList.valueOf(primaryColor)
        val notchStroke = if (isMono) Color.parseColor("#2E2E2E") else Color.parseColor("#2E3440")
        cardNotchPlayer.strokeColor = notchStroke

        // 6. Section Headers & App Name
        findViewById<TextView>(R.id.tvCatVideo)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatAudio)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatSubtitles)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatGestures)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatInterface)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvAppVersionTitle)?.setTextColor(primaryColor)
        val badgeAppVersion = findViewById<TextView>(R.id.badgeAppVersion)
        val cardAppVersion = findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardAppVersion)
        if (isMono) {
            badgeAppVersion?.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#333333"))
            badgeAppVersion?.setTextColor(Color.WHITE)
            cardAppVersion?.strokeColor = Color.parseColor("#2E2E2E")
        } else {
            badgeAppVersion?.backgroundTintList = ColorStateList.valueOf(primaryColor)
            badgeAppVersion?.setTextColor(Color.WHITE)
            cardAppVersion?.strokeColor = Color.parseColor("#2E3440")
        }
        findViewById<TextView>(R.id.tvMasterAudioTitle)?.setTextColor(primaryColor)
        tvVideoColorStatus.setTextColor(primaryColor)

        // 7. Browse Buttons
        btnBrowseVideo.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseVideo.setTextColor(if (isMono) Color.BLACK else Color.WHITE)
        btnBrowseAudio.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseAudio.setTextColor(if (isMono) Color.BLACK else Color.WHITE)

        // 8. Action Buttons ("Change", "Clear", "Reset")
        val actionButtons = listOf(
            btnChangeHw,
            btnChangeOrientation,
            btnChangeVideoColor,
            btnChangeMasterProfile,
            btnChangeDolbySurround,
            btnChangeEqualizer,
            btnChangeAudioOutput,
            btnChangeBgPip,
            btnChangeResumeMode,
            btnChangeDoubleTap,
            btnChangeAspectRatio,
            btnChangeSubSize,
            btnChangeSubColor,
            btnChangeSubBackground,
            btnChangeSubEncoding,
            btnChangeAppTheme,
            btnClearCache,
            btnClearResume,
            btnResetSettings
        )
        for (btn in actionButtons) {
            styleActionButton(btn)
        }

        // 9. Update Settings Toggle Buttons
        updateSettingsUI()

        // 10. Notify media adapters so list items update their colors
        videoAdapter?.notifyDataSetChanged()
        audioAdapter?.notifyDataSetChanged()
        folderVideoAdapter?.notifyDataSetChanged()
        folderAdapter?.notifyDataSetChanged()
    }

    private fun updateSettingsUI() {
        // Video UI
        updateToggleButton(btnToggleHighRefreshRate, PlayerHolder.isHighRefreshRateEnabled)
        tvHighRefreshRateStatus.text = if (PlayerHolder.isHighRefreshRateEnabled) "Enabled (Auto 120Hz / High Refresh Rate)" else "Disabled (Standard 60Hz)"

        tvDefaultOrientationStatus.text = when (PlayerHolder.defaultOrientation) {
            0 -> "Auto Sensor (Free Rotation)"
            2 -> "Portrait (Vertical)"
            else -> "Direct Landscape (Recommended)"
        }
        tvVideoColorStatus.text = when (PlayerHolder.videoColorProfile) {
            0 -> "Standard / Natural (Original)"
            1 -> "Vivid / AMOLED Boost (Recommended)"
            2 -> "Cinema / HDR Effect"
            3 -> "Sharp & Crisp Studio"
            else -> "Custom Color Tuning"
        }

        updateToggleButton(btnToggleWideColor, PlayerHolder.isWideColorGamutEnabled)
        tvWideColorStatus.text = if (PlayerHolder.isWideColorGamutEnabled) "Enabled (10-bit dynamic colors)" else "Disabled (Standard sRGB)"

        updateToggleButton(btnToggleDeblocking, PlayerHolder.isDeblockingFilterEnabled)
        tvDeblockingStatus.text = if (PlayerHolder.isDeblockingFilterEnabled) "Enabled (Crisp gradients & deblocking)" else "Disabled"

        tvHwDecodeStatus.text = when (PlayerHolder.hwAccelerationMode) {
            0 -> "Disabled (Software FFmpeg)"
            2 -> "Decoding Only"
            3 -> "Full Acceleration"
            else -> "Automatic (Recommended)"
        }
        tvBgPipStatus.text = when (PlayerHolder.backgroundPipMode) {
            0 -> "Stop Playback"
            2 -> "Picture-in-Picture (PiP)"
            else -> "Play in Background"
        }
        tvResumeModeStatus.text = when (PlayerHolder.resumeMode) {
            0 -> "Never (Always start over)"
            2 -> "Always resume automatically"
            else -> "Ask confirmation"
        }
        tvDoubleTapStatus.text = "${PlayerHolder.doubleTapSeekSeconds} seconds"
        tvAspectRatioStatus.text = when (PlayerHolder.defaultAspectRatio) {
            1 -> "Fit Screen"
            2 -> "Fill Screen"
            3 -> "16:9"
            4 -> "4:3"
            else -> "Best Fit"
        }

        updateToggleButton(btnToggleAudioBoost, PlayerHolder.isAudioBoostEnabled)
        tvAudioBoostStatus.text = if (PlayerHolder.isAudioBoostEnabled) "Enabled (Up to 200%)" else "Disabled (Standard 100%)"

        // Integrated Audio Suite UI
        tvMasterProfileStatus.text = PlayerHolder.masterProfileNames[PlayerHolder.masterAudioProfile.coerceIn(0, 4)]
        tvDolbySurroundStatus.text = when (PlayerHolder.dolbySpatialMode) {
            1 -> "Dolby 3D Headphone (Binaural HRTF)"
            2 -> "Dolby ProLogic Surround (Matrix)"
            3 -> "Cinema 3D Soundstage (Wide Room)"
            else -> "Standard Stereo (Downmix)"
        }
        val eqIdx = PlayerHolder.currentEqualizerPreset
        tvEqualizerStatus.text = if (eqIdx >= 0 && eqIdx < PlayerHolder.equalizerPresets.size - 1) {
            PlayerHolder.equalizerPresets[eqIdx + 1]
        } else {
            "Flat (Off)"
        }

        updateToggleButton(btnToggleDialogueBoost, PlayerHolder.isDialogueBoostEnabled)
        tvDialogueBoostStatus.text = if (PlayerHolder.isDialogueBoostEnabled) "Dynamic range compression: Clear speech (Enabled)" else "Disabled"

        updateToggleButton(btnTogglePassthrough, PlayerHolder.isDolbyPassthroughEnabled)
        tvDigitalPassthroughStatus.text = if (PlayerHolder.isDolbyPassthroughEnabled) "HDMI / S/PDIF Passthrough (Active)" else "Disabled"

        tvAudioOutputStatus.text = when (PlayerHolder.audioOutputEngine) {
            1 -> "OpenSL ES (Low Latency)"
            2 -> "AAudio (Modern NDK)"
            else -> "AudioTrack (Standard)"
        }

        updateToggleButton(btnToggleHeadsetPause, PlayerHolder.isHeadsetPauseEnabled)
        tvHeadsetPauseStatus.text = if (PlayerHolder.isHeadsetPauseEnabled) "Auto-pause when unplugged (Enabled)" else "Disabled"

        updateToggleButton(btnToggleTimeStretch, PlayerHolder.isTimeStretchingEnabled)
        tvTimeStretchStatus.text = if (PlayerHolder.isTimeStretchingEnabled) "Pitch lock active (Enabled)" else "Disabled"

        // Subtitle UI
        updateToggleButton(btnToggleSubAutoload, PlayerHolder.isSubAutoloadEnabled)

        tvSubSizeStatus.text = when (PlayerHolder.subFontSize) {
            "12" -> "Very Small (12sp)"
            "14" -> "Small (14sp)"
            "24" -> "Large (24sp)"
            "32" -> "Huge (32sp)"
            else -> "Normal (18sp)"
        }
        tvSubColorStatus.text = when (PlayerHolder.subFontColor) {
            "16776960" -> "Yellow"
            "65535" -> "Cyan"
            "65280" -> "Green"
            else -> "White"
        }
        tvSubBackgroundStatus.text = when (PlayerHolder.subBackgroundStyle) {
            1 -> "Translucent Box"
            2 -> "Solid Black Box"
            else -> "Transparent / None"
        }

        updateSubStyleButton(btnToggleSubStyle, PlayerHolder.subFontStyle == 1)
        tvSubStyleStatus.text = if (PlayerHolder.subFontStyle == 1) "Bold font weight" else "Normal font weight"

        tvSubEncodingStatus.text = PlayerHolder.subEncoding

        // Gestures UI
        updateToggleButton(btnToggleGestureVolume, PlayerHolder.isVolumeGestureEnabled)
        tvGestureVolumeStatus.text = if (PlayerHolder.isVolumeGestureEnabled) "Right side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureBrightness, PlayerHolder.isBrightnessGestureEnabled)
        tvGestureBrightnessStatus.text = if (PlayerHolder.isBrightnessGestureEnabled) "Left side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureSeek, PlayerHolder.isSeekGestureEnabled)
        tvGestureSeekStatus.text = if (PlayerHolder.isSeekGestureEnabled) "Horizontal drag (Enabled)" else "Disabled"

        updateToggleButton(btnToggleFastSeek, PlayerHolder.isFastSeekEnabled)
        tvFastSeekStatus.text = if (PlayerHolder.isFastSeekEnabled) "Seek to nearest keyframe (Enabled)" else "Exact frame seek (Disabled)"

        // Interface UI
        tvAppThemeStatus.text = when (PlayerHolder.appThemeMode) {
            PlayerHolder.THEME_MONOCHROME -> getString(R.string.theme_monochrome)
            PlayerHolder.THEME_CHARCOAL -> "Dark Charcoal"
            else -> "Pure Black OLED (Default)"
        }

        // Dedicated YouTube Premium & Advanced Streaming Settings UI
        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val isAdBlockOn = ytPrefs.getBoolean("pref_yt_adblock", true)
        updateToggleButton(btnToggleYtAdBlock, isAdBlockOn)
        tvYtAdBlockStatus.text = if (isAdBlockOn) "Active (100% Ad-Free Video & Feed)" else "Disabled (Standard YouTube)"

        tvYtSponsorBlockStatus.text = if (PlayerHolder.isSponsorBlockEnabled) "Enabled (Auto-skip sponsors/intros)" else "Disabled"
        tvYtDefaultQualityStatus.text = ytPrefs.getString("pref_yt_default_quality", "Auto (Adaptive High Bitrate)") ?: "Auto"
        tvYtAudioQualityStatus.text = ytPrefs.getString("pref_yt_audio_quality", "Auto (Adaptive - Recommended)") ?: "Auto"
        tvYtBufferLimitStatus.text = ytPrefs.getString("pref_yt_buffer_limit", "30s (Balanced Data Saver - Recommended)") ?: "30s"
        findViewById<TextView>(R.id.tvYtMediaCacheStatus)?.text = ytPrefs.getString("pref_yt_disk_cache_label", "256 MB (Balanced - Recommended)") ?: "256 MB (Balanced - Recommended)"
        findViewById<TextView>(R.id.tvYtStreamCacheTtlStatus)?.text = ytPrefs.getString("pref_yt_stream_ttl_label", "4 Hours (Recommended)") ?: "4 Hours (Recommended)"
        tvYtExtractorBridgeStatus.text = "NewPipe Extractor v0.26.5"
        val currentClient = ytPrefs.getString("pref_yt_client_spoof", "TVHTML5_SIMPLY_EMBEDDED_PLAYER") ?: "TVHTML5_SIMPLY_EMBEDDED_PLAYER"
        tvYtClientSpoofingStatus.text = when (currentClient) {
            "ANDROID_TESTSUITE" -> "Android Testsuite (Internal test - No Botguard)"
            "IOS" -> "iOS Official (Direct formats - Native Apple)"
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER" -> "TV HTML5 Embedded (High-bitrate DASH/HLS)"
            "ANDROID" -> "Android Official (Standard YouTube client)"
            else -> "Android VR (Oculus Quest - Zero PoToken Bypass)"
        }

        updateToggleButton(btnToggleYtBgAudio, PlayerHolder.isBackgroundPlayEnabled)
        tvYtBgAudioStatus.text = if (PlayerHolder.isBackgroundPlayEnabled) "Enabled with Lock Screen controls" else "Disabled"

        val showComments = ytPrefs.getBoolean("pref_yt_show_comments", true)
        val showCast = ytPrefs.getBoolean("pref_yt_show_cast", true)
        val commentsStatus = if (showComments) "ON" else "OFF"
        val castStatus = if (showCast) "ON" else "OFF"
        tvYtInterfaceStatus.text = "Comments: $commentsStatus • Cast: $castStatus"

        // Apply UI toggles to current YouTube views
        layoutYtCommentsCard.visibility = if (showComments) View.VISIBLE else View.GONE
        btnYtCast.visibility = if (showCast) View.VISIBLE else View.GONE

        tvYtAccountStatus.text = if (MicroGAuthManager.isLoggedIn(this)) "Signed In (${MicroGAuthManager.getAccountEmail(this)})" else "MicroG GmsCore Integration"
    }
    private fun showSponsorBlockSettingsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_sponsorblock_settings, null)
        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        view.findViewById<View>(R.id.btnSponsorClose)?.setOnClickListener { dialog.dismiss() }

        val cbMaster = view.findViewById<CheckBox>(R.id.cbSbMaster)
        val cbSponsor = view.findViewById<CheckBox>(R.id.cbSbSponsor)
        val cbIntro = view.findViewById<CheckBox>(R.id.cbSbIntro)
        val cbOutro = view.findViewById<CheckBox>(R.id.cbSbOutro)
        val cbPromo = view.findViewById<CheckBox>(R.id.cbSbPromo)
        val cbInteraction = view.findViewById<CheckBox>(R.id.cbSbInteraction)

        cbMaster?.isChecked = PlayerHolder.isSponsorBlockEnabled
        cbSponsor?.isChecked = PlayerHolder.sbSkipSponsor
        cbIntro?.isChecked = PlayerHolder.sbSkipIntro
        cbOutro?.isChecked = PlayerHolder.sbSkipOutro
        cbPromo?.isChecked = PlayerHolder.sbSkipPromo
        cbInteraction?.isChecked = PlayerHolder.sbSkipInteraction

        val updateStates = {
            PlayerHolder.isSponsorBlockEnabled = cbMaster?.isChecked == true
            PlayerHolder.sbSkipSponsor = cbSponsor?.isChecked == true
            PlayerHolder.sbSkipIntro = cbIntro?.isChecked == true
            PlayerHolder.sbSkipOutro = cbOutro?.isChecked == true
            PlayerHolder.sbSkipPromo = cbPromo?.isChecked == true
            PlayerHolder.sbSkipInteraction = cbInteraction?.isChecked == true
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }

        cbMaster?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbSponsor?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbIntro?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbOutro?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbPromo?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbInteraction?.setOnCheckedChangeListener { _, _ -> updateStates() }

        dialog.show()
    }

    private fun showYouTubeQualityDialog() {
        val qualities = arrayOf(
            "Auto (Adaptive High Bitrate)",
            "4K Ultra HD (2160p)",
            "2K Quad HD (1440p)",
            "1080p Full HD",
            "720p HD",
            "480p SD",
            "360p Data Saver",
            "240p Low",
            "144p Ultra Data Saver"
        )
        val qualityHeights = intArrayOf(0, 2160, 1440, 1080, 720, 480, 360, 240, 144)
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Default Streaming Quality")
            .setItems(qualities) { _, which ->
                val chosen = qualities[which]
                val prefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
                prefs.edit().putString("pref_yt_default_quality", chosen).apply()
                val maxHeight = qualityHeights[which]
                PlayerHolder.currentVideoQuality = chosen
                PlayerHolder.savePreferences(this)
                YouTubeExoPlayerManager.setVideoQuality(maxHeight)
                updateSettingsUI()
                // Silent notification removed
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showClientSpoofingDialog() {
        val clients = arrayOf(
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER" to "TV HTML5 Embedded (High-bitrate DASH/HLS - Highly Permissive)",
            "IOS" to "iOS Official (Direct formats - Native Apple client)",
            "ANDROID_TESTSUITE" to "Android Testsuite (Internal test client - No Botguard)",
            "ANDROID_VR" to "Android VR (Oculus Quest 2 - Zero PoToken)",
            "ANDROID" to "Android Official (Standard YouTube client)"
        )

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val currentClient = ytPrefs.getString("pref_yt_client_spoof", "TVHTML5_SIMPLY_EMBEDDED_PLAYER") ?: "TVHTML5_SIMPLY_EMBEDDED_PLAYER"
        val currentIndex = clients.indexOfFirst { it.first.equals(currentClient, ignoreCase = true) }.coerceAtLeast(0)

        val displayOptions = clients.map { it.second }.toTypedArray()

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Client Spoofing Profile")
            .setSingleChoiceItems(displayOptions, currentIndex) { dialog, which ->
                val (clientId, _) = clients[which]
                ytPrefs.edit().putString("pref_yt_client_spoof", clientId).apply()
                updateSettingsUI()
                val clientName = clients[which].second.substringBefore(" (")
                // Silent notification removed
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExtractorBridgeDialog() {
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Extractor Engine")
            .setMessage("Engine: Official TeamNewPipe Extractor (v0.26.5)\nMode: 100% Native Ad-Free Playback\nStatus: Active")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showYouTubeUiConfigDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_youtube_ui_settings, null)
        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val prefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val cbComments = view.findViewById<CheckBox>(R.id.cbYtUiShowComments)
        val cbCast = view.findViewById<CheckBox>(R.id.cbYtUiShowCast)
        val btnDone = view.findViewById<Button>(R.id.btnYtUiSaveClose)

        cbComments?.isChecked = prefs.getBoolean("pref_yt_show_comments", true)
        cbCast?.isChecked = prefs.getBoolean("pref_yt_show_cast", true)

        btnDone?.setOnClickListener {
            prefs.edit()
                .putBoolean("pref_yt_show_comments", cbComments?.isChecked == true)
                .putBoolean("pref_yt_show_cast", cbCast?.isChecked == true)
                .apply()
            updateSettingsUI()
            dialog.dismiss()
        }

        dialog.show()
    }


    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }

        if (permissionsToRequest.isNotEmpty()) {
            storagePermissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            loadMediaFiles()
        }
    }

    private fun switchVideoViewMode(folders: Boolean) {
        isFolderViewActive = folders
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        if (folders) {
            btnViewAllVideos.setTextColor(secondaryColor)
            btnViewFolders.setTextColor(primaryColor)

            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            updateFoldersData()
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)

            rvVideos.visibility = View.VISIBLE
            layoutFoldersContainer.visibility = View.GONE
            closeFolderDetail()
        }
    }

    private fun closeFolderDetail() {
        currentSelectedFolder = null
        layoutFolderDetailHeader.visibility = View.GONE
        rvFolderVideos.visibility = View.GONE
        rvFolders.visibility = View.VISIBLE
    }

    private fun updateFoldersData() {
        val folderMap = linkedMapOf<String, MediaFolder>()
        for (video in allVideos) {
            val key = if (video.folderPath.isNotEmpty()) video.folderPath else video.folderName
            val folder = folderMap.getOrPut(key) {
                MediaFolder(video.folderName, video.folderPath)
            }
            folder.videos.add(video)
        }
        allFolders = folderMap.values.toList()

        btnViewFolders.text = "FOLDERS"
        btnViewAllVideos.text = "VIDEOS"

        if (folderAdapter == null) {
            folderAdapter = FolderAdapter(allFolders) { folder ->
                openFolderDetail(folder)
            }
            rvFolders.adapter = folderAdapter
        } else {
            folderAdapter?.updateFolders(allFolders)
        }
    }

    private fun openFolderDetail(folder: MediaFolder) {
        currentSelectedFolder = folder
        rvFolders.visibility = View.GONE
        layoutFolderDetailHeader.visibility = View.VISIBLE
        rvFolderVideos.visibility = View.VISIBLE

        tvFolderHeaderTitle.text = folder.folderName
        tvFolderHeaderSubtitle.text = "${folder.count} videos • ${folder.getFormattedSize()}"

        folderVideoAdapter = MediaAdapter(folder.videos) { item, _ ->
            try {
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
        rvFolderVideos.adapter = folderVideoAdapter
    }

    private fun loadMediaFiles() {
        allVideos = MediaScanner.scanVideos(this)
        if (allVideos.isNotEmpty()) {
            layoutEmptyVideo.visibility = View.GONE
            if (videoAdapter == null) {
                videoAdapter = MediaAdapter(allVideos) { item, _ ->
                    try {
                        openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
                rvVideos.adapter = videoAdapter
            } else {
                videoAdapter?.updateList(allVideos)
            }
            updateFoldersData()
            if (isFolderViewActive) {
                rvVideos.visibility = View.GONE
                layoutFoldersContainer.visibility = View.VISIBLE
            } else {
                rvVideos.visibility = View.VISIBLE
                layoutFoldersContainer.visibility = View.GONE
            }
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = View.VISIBLE
        }

        allAudio = MediaScanner.scanAudio(this)
        if (allAudio.isNotEmpty()) {
            rvAudio.visibility = View.VISIBLE
            layoutEmptyAudio.visibility = View.GONE
            if (audioAdapter == null) {
                audioAdapter = MediaAdapter(allAudio) { item, pos ->
                    try {
                        YouTubeExoPlayerManager.pause()
                        YouTubeExoPlayerManager.stop()
                        YouTubeExoPlayerManager.currentPlayingVideo = null
                        currentPlayingYtVideo = null
                        isYtVideoPlaying = false
                        if (::cardYtMiniPlayer.isInitialized) cardYtMiniPlayer.visibility = View.GONE
                        if (::layoutYtAudioModeVisual.isInitialized) layoutYtAudioModeVisual.visibility = View.GONE

                        PlayerHolder.setPlaylistAndPlay(this, allAudio, pos)
                        audioAdapter?.setPlayingUri(item.uri)
                        updateNotchPlayerUI()
                        openPlayer(item.uri, item.title, isVideo = false, path = item.filePath, artist = item.artist)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
                rvAudio.adapter = audioAdapter
            } else {
                audioAdapter?.updateList(allAudio)
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            }
        } else {
            rvAudio.visibility = View.GONE
            layoutEmptyAudio.visibility = View.VISIBLE
        }
    }

    private fun openPlayer(uri: Uri, title: String, isVideo: Boolean = true, path: String? = null, artist: String? = null) {
        PlayerHolder.isAudioOnly = !isVideo
        PlayerHolder.currentArtist = artist ?: "Unknown artist"
        val intent = Intent(this, PlayerActivity::class.java).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra("media_uri", uri.toString())
            putExtra("media_title", title)
            putExtra("media_artist", PlayerHolder.currentArtist)
            putExtra("is_video", isVideo)
            if (!path.isNullOrEmpty()) {
                putExtra("media_path", path)
            }
        }
        startActivity(intent)
    }

    private fun updateCacheSizeDisplay() {
        try {
            var size = getDirSize(cacheDir)
            size += getDirSize(codeCacheDir)
            externalCacheDir?.let { size += getDirSize(it) }
            val formatted = if (size <= 0) "0 B (Clean)" else android.text.format.Formatter.formatFileSize(this, size)
            tvCacheSizeStatus.text = "$formatted • YouTube stream & thumbnail cache (Files safe)"
        } catch (e: Exception) {
            tvCacheSizeStatus.text = "0 B (Clean) • Free up temporary cache"
        }
    }

    private fun getDirSize(dir: java.io.File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var bytes = 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            bytes += if (f.isDirectory) getDirSize(f) else f.length()
        }
        return bytes
    }

    private fun clearAppCache() {
        try {
            cacheDir.deleteRecursively()
            codeCacheDir.deleteRecursively()
            externalCacheDir?.deleteRecursively()
            // Cache cleared
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAppVersionDialog() {
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle(R.string.app_name)
            .setMessage("Version 3.0 (Master Edition)\nBuild: 300\n\nLead Developer: Rajesh Shah\nEngine: Universal Hardware Core with Dolby Surround\n\nStatus: Up to date")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showYouTubeDedicatedSettingsDialog() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_youtube_app_settings, null)
        dialog.setContentView(view)
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.let { sheet ->
                val behavior = com.google.android.material.bottomsheet.BottomSheetBehavior.from(sheet)
                behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
            }
        }

        view.findViewById<View>(R.id.btnYtSettingsClose)?.setOnClickListener { dialog.dismiss() }

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)

        // 0. Autoplay Next Video
        val tvAutoplay = view.findViewById<TextView>(R.id.tvYtSettingAutoplayVal)
        val updateAutoplayText = {
            tvAutoplay?.text = if (isYtAutoplayEnabled) "Enabled (Next video plays automatically)" else "Disabled (Pause when video ends)"
        }
        updateAutoplayText()
        view.findViewById<View>(R.id.rowYtSettingAutoplay)?.setOnClickListener {
            isYtAutoplayEnabled = !isYtAutoplayEnabled
            ytPrefs.edit().putBoolean("pref_yt_autoplay", isYtAutoplayEnabled).apply()
            updateAutoplayText()
        }

        // 1. Video Quality
        val tvQuality = view.findViewById<TextView>(R.id.tvYtSettingQualityVal)
        tvQuality?.setText(ytPrefs.getString("pref_yt_default_quality", "Auto (Adaptive High Bitrate)") ?: "Auto")
        view.findViewById<View>(R.id.rowYtSettingQuality)?.setOnClickListener {
            showYouTubeQualityDialog()
            dialog.dismiss()
        }

        // 1b. Streaming Buffer Limit (Smart Data Saver)
        val tvBuffer = view.findViewById<TextView>(R.id.tvYtSettingBufferVal)
        tvBuffer?.setText(ytPrefs.getString("pref_yt_buffer_limit", "30s (Balanced Data Saver - Recommended)") ?: "30s")
                // Cache Size Setting
        val tvCacheSize = view.findViewById<TextView>(R.id.tvYtSettingCacheSizeVal)
        tvCacheSize?.text = ytPrefs.getString("pref_yt_disk_cache_label", "256 MB (Balanced - Recommended)") ?: "256 MB"
        view.findViewById<View>(R.id.rowYtSettingCacheSize)?.setOnClickListener {
            val options = arrayOf(
                "256 MB (Balanced - Recommended)",
                "512 MB (High Performance)",
                "1 GB (Maximum Offline Buffer)",
                "2 GB (Heavy Usage & Travel)",
                "4 GB (Ultra Large Storage)"
            )
            val sizeValues = longArrayOf(256L, 512L, 1024L, 2048L, 4096L)
            val curSelected = ytPrefs.getString("pref_yt_disk_cache_label", "256 MB (Balanced - Recommended)") ?: "256 MB"
            val curIdx = options.indexOf(curSelected).coerceAtLeast(0)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Media Disk Cache Size")
                .setSingleChoiceItems(options, curIdx) { d, which ->
                    val chosen = options[which]
                    val sizeMb = sizeValues[which]
                    ytPrefs.edit().putString("pref_yt_disk_cache_label", chosen).putLong("pref_yt_disk_cache_mb", sizeMb).apply()
                    YouTubeExoPlayerManager.updateDiskCacheSize(this, sizeMb)
                    tvCacheSize?.text = chosen
                    updateSettingsUI()
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Cache TTL Setting
        val tvCacheTtl = view.findViewById<TextView>(R.id.tvYtSettingCacheTtlVal)
        tvCacheTtl?.text = ytPrefs.getString("pref_yt_stream_ttl_label", "4 Hours (Recommended)") ?: "4 Hours"
        view.findViewById<View>(R.id.rowYtSettingCacheTtl)?.setOnClickListener {
            val options = arrayOf(
                "2 Hours (Fast Refresh)",
                "4 Hours (Recommended)",
                "8 Hours (Extended Cache)",
                "12 Hours (All-Day Cache)",
                "24 Hours (Maximum Retention)",
                "48 Hours (Ultra Long Cache)"
            )
            val hoursValues = intArrayOf(2, 4, 8, 12, 24, 48)
            val curSelected = ytPrefs.getString("pref_yt_stream_ttl_label", "4 Hours (Recommended)") ?: "4 Hours"
            val curIdx = options.indexOf(curSelected).coerceAtLeast(1)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Stream URL Cache Duration")
                .setSingleChoiceItems(options, curIdx) { d, which ->
                    val chosen = options[which]
                    val hours = hoursValues[which]
                    ytPrefs.edit().putString("pref_yt_stream_ttl_label", chosen).putInt("pref_yt_stream_ttl_hours", hours).apply()
                    YouTubeStreamResolver.setCacheTtlHours(hours)
                    tvCacheTtl?.text = chosen
                    updateSettingsUI()
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        view.findViewById<View>(R.id.rowYtSettingBuffer)?.setOnClickListener {
            val bufferOptions = arrayOf(
                "15s (Ultra Data Saver - Least Data)",
                "30s (Balanced Data Saver - Recommended)",
                "60s (Medium Buffer - Unstable Network)",
                "120s (Maximum Pre-Buffer - Wi-Fi & Travel)"
            )
            val curBuffer = ytPrefs.getString("pref_yt_buffer_limit", "30s (Balanced Data Saver - Recommended)") ?: "30s"
            val curIdx = bufferOptions.indexOfFirst { it.startsWith(curBuffer.substringBefore(" ")) }.coerceAtLeast(1)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Streaming Buffer Limit")
                .setSingleChoiceItems(bufferOptions, curIdx) { d, which ->
                    val selected = bufferOptions[which]
                    ytPrefs.edit().putString("pref_yt_buffer_limit", selected).apply()
                    YouTubeExoPlayerManager.applyBufferLimit(this, selected)
                    tvBuffer?.setText(selected)
                    updateSettingsUI()
                    val label = selected.substringBefore(" -")
                    // Silent notification removed
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 1c. Audio Streaming Quality
        val tvAudioQuality = view.findViewById<TextView>(R.id.tvYtSettingAudioQualityVal)
        tvAudioQuality?.setText(ytPrefs.getString("pref_yt_audio_quality", "Auto (Adaptive - Recommended)") ?: "Auto")
        view.findViewById<View>(R.id.rowYtSettingAudioQuality)?.setOnClickListener {
            val audioQualities = arrayOf(
                "Auto (Adaptive - Recommended)",
                "High Quality (160 kbps Opus - Studio Audio)",
                "Normal Quality (128 kbps M4A - Clear & Balanced)",
                "Data Saver (64 kbps - Ultra-Low Data)"
            )
            val curAudio = ytPrefs.getString("pref_yt_audio_quality", "Auto (Adaptive - Recommended)") ?: "Auto"
            val curIdx = audioQualities.indexOfFirst { it.startsWith(curAudio.substringBefore(" ")) }.coerceAtLeast(0)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Audio Streaming Quality")
                .setSingleChoiceItems(audioQualities, curIdx) { d, which ->
                    val selected = audioQualities[which]
                    ytPrefs.edit().putString("pref_yt_audio_quality", selected).apply()
                    tvAudioQuality?.setText(selected)
                    updateSettingsUI()
                    val label = selected.substringBefore(" -")
                    // Silent notification removed
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 2. Decoder
        val tvDecoder = view.findViewById<TextView>(R.id.tvYtSettingDecoderVal)
        tvDecoder?.setText(if (PlayerHolder.isHardwareDecoding) "Hardware Decoder (HW MediaCodec)" else "Software Decoder (SW)")
        view.findViewById<View>(R.id.rowYtSettingDecoder)?.setOnClickListener {
            val options = arrayOf("Automatic (HW MediaCodec - Recommended)", "Software (SW)")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Hardware Acceleration")
                .setSingleChoiceItems(options, if (PlayerHolder.isHardwareDecoding) 0 else 1) { d, which ->
                    PlayerHolder.isHardwareDecoding = (which == 0)
                    PlayerHolder.savePreferences(this)
                    tvDecoder?.setText(if (PlayerHolder.isHardwareDecoding) "Hardware Decoder (HW MediaCodec)" else "Software Decoder (SW)")
                    d.dismiss()
                }
                .show()
        }

        // 3. Sound & 10-Band EQ
        val tvEq = view.findViewById<TextView>(R.id.tvYtSettingEqVal)
        val eqIdx = PlayerHolder.currentEqualizerPreset
        tvEq?.setText(if (eqIdx >= 0 && eqIdx < PlayerHolder.equalizerPresets.size - 1) PlayerHolder.equalizerPresets[eqIdx + 1] else "Flat (Off)")
        view.findViewById<View>(R.id.rowYtSettingEq)?.setOnClickListener {
            val presets = PlayerHolder.equalizerPresets
            val cur = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("10-Band Equalizer Presets")
                .setSingleChoiceItems(presets, cur) { d, which ->
                    PlayerHolder.currentEqualizerPreset = which - 1
                    PlayerHolder.savePreferences(this)
                    tvEq?.setText(presets[which])
                    d.dismiss()
                }
                .show()
        }

        // 4. Audio Lipsync & Delay
        val tvAudioDelay = view.findViewById<TextView>(R.id.tvYtSettingAudioDelayVal)
        tvAudioDelay?.setText("${PlayerHolder.currentAudioDelayMs} ms (Synchronized)")
        view.findViewById<View>(R.id.rowYtSettingAudioDelay)?.setOnClickListener {
            val del = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(40, 20, 40, 20)
            }
            val tvD = TextView(this).apply {
                text = "${PlayerHolder.currentAudioDelayMs} ms"
                textSize = 18f
                setTextColor(Color.WHITE)
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val btnMinus = Button(this).apply {
                text = "-50ms"
                setOnClickListener {
                    PlayerHolder.currentAudioDelayMs -= 50
                    tvD.text = "${PlayerHolder.currentAudioDelayMs} ms"
                }
            }
            val btnPlus = Button(this).apply {
                text = "+50ms"
                setOnClickListener {
                    PlayerHolder.currentAudioDelayMs += 50
                    tvD.text = "${PlayerHolder.currentAudioDelayMs} ms"
                }
            }
            del.addView(btnMinus)
            del.addView(tvD)
            del.addView(btnPlus)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Audio Delay / Lipsync")
                .setView(del)
                .setPositiveButton("Done") { _, _ ->
                    tvAudioDelay?.setText("${PlayerHolder.currentAudioDelayMs} ms")
                    PlayerHolder.savePreferences(this)
                }
                .show()
        }

        // 5. Subtitles & Styling
        view.findViewById<View>(R.id.rowYtSettingSubtitles)?.setOnClickListener {
            dialog.dismiss()
            showSubtitleSettings()
        }

        // Audio Track & Multi-Language
        view.findViewById<View>(R.id.rowYtSettingAudioTrack)?.setOnClickListener {
            showAudioTrackSelectionDialog()
            dialog.dismiss()
        }

        // 6. SponsorBlock
        val tvSb = view.findViewById<TextView>(R.id.tvYtSettingSponsorBlockVal)
        tvSb?.setText(if (PlayerHolder.isSponsorBlockEnabled) "Enabled (Auto-skip sponsors/intros)" else "Disabled")
        view.findViewById<View>(R.id.rowYtSettingSponsorBlock)?.setOnClickListener {
            dialog.dismiss()
            showSponsorBlockSettingsDialog()
        }

        // 7. Background Audio Playback
        val tvBg = view.findViewById<TextView>(R.id.tvYtSettingBgPlayVal)
        tvBg?.setText(if (PlayerHolder.isBackgroundPlayEnabled) "Enabled with Lock Screen controls" else "Disabled")
        view.findViewById<View>(R.id.rowYtSettingBgPlay)?.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            PlayerHolder.savePreferences(this)
            tvBg?.setText(if (PlayerHolder.isBackgroundPlayEnabled) "Enabled with Lock Screen controls" else "Disabled")
        }

        dialog.show()
    }


    private fun playNextYouTubeVideo() {
        val currentList = if (allYtFeedVideos.isNotEmpty()) allYtFeedVideos else youTubeFeedAdapter.getItems()
        if (currentList.isEmpty()) return
        val curId = currentPlayingYtVideo?.id
        val curIdx = currentList.indexOfFirst { it.id == curId }
        val nextIdx = if (curIdx >= 0) (curIdx + 1) % currentList.size else 0
        val nextVideo = currentList[nextIdx]
        playYouTubeVideoInApp(nextVideo)
        // Silent notification removed
    }

    private fun playPreviousYouTubeVideo() {
        val currentList = if (allYtFeedVideos.isNotEmpty()) allYtFeedVideos else youTubeFeedAdapter.getItems()
        if (currentList.isEmpty()) return
        val curId = currentPlayingYtVideo?.id
        val curIdx = currentList.indexOfFirst { it.id == curId }
        val prevIdx = if (curIdx > 0) curIdx - 1 else currentList.size - 1
        val prevVideo = currentList[prevIdx]
        playYouTubeVideoInApp(prevVideo)
        // Silent notification removed
    }

    private fun loadMoreYouTubeFeed() {
        if (isYtLoadingMore) return
        isYtLoadingMore = true
        findViewById<ProgressBar?>(R.id.pbYtFeedLoadMore)?.visibility = View.VISIBLE
        YouTubeFeedRepository.loadMoreFeed(currentYtCategory) { moreVideos ->
            findViewById<ProgressBar?>(R.id.pbYtFeedLoadMore)?.visibility = View.GONE
            isYtLoadingMore = false
            if (moreVideos.isNotEmpty()) {
                val current = youTubeFeedSecondaryAdapter.getItems().toMutableList()
                current.addAll(moreVideos)
                youTubeFeedSecondaryAdapter.updateItems(current)
                allYtFeedVideos.addAll(moreVideos)
            }
        }
    }

    private fun showYouTubeFullHistoryDialog() {
        val history = YouTubeHistoryManager.getWatchHistory(this)
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_media_queue, null)
        dialog.setContentView(view)
        view.findViewById<TextView>(R.id.tvQueueHeaderTitle)?.text = "Watch History (${history.size})"
        val btnClear = view.findViewById<View>(R.id.btnQueueClear)
        btnClear?.visibility = View.VISIBLE
        btnClear?.setOnClickListener {
            YouTubeHistoryManager.clearHistory(this)
            updateYouTabUI()
            dialog.dismiss()
            Toast.makeText(this, "Watch history cleared", Toast.LENGTH_SHORT).show()
        }
        val rv = view.findViewById<RecyclerView>(R.id.rvQueueList)
        rv?.layoutManager = LinearLayoutManager(this)
        val adapter = YouTubeHistoryAdapter(this, history) { video ->
            dialog.dismiss()
            playYouTubeVideoInApp(video)
        }
        rv?.adapter = adapter
        dialog.show()
    }

    private fun showYouTubeFullDownloadsDialog() {
        val bookmarks = YouTubeHistoryManager.getBookmarks(this)
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_media_queue, null)
        dialog.setContentView(view)
        view.findViewById<TextView>(R.id.tvQueueHeaderTitle)?.text = "Downloads & Library (${bookmarks.size})"
        view.findViewById<View>(R.id.btnQueueClear)?.visibility = View.GONE
        val rv = view.findViewById<RecyclerView>(R.id.rvQueueList)
        rv?.layoutManager = LinearLayoutManager(this)
        val adapter = YouTubeHistoryAdapter(this, bookmarks) { video ->
            dialog.dismiss()
            playYouTubeVideoInApp(video)
        }
        rv?.adapter = adapter
        dialog.show()
    }


    private fun scheduleOverlayHide(delayMs: Long = 3000L) {
        ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
        if (YouTubeExoPlayerManager.isPlaying()) {
            ytOverlayHandler.postDelayed(ytOverlayHideRunnable, delayMs)
        }
    }

    private fun showAudioTrackSelectionDialog() {
        val tracks = YouTubeExoPlayerManager.getAvailableAudioTracks()
        if (tracks.isEmpty()) {
            Toast.makeText(this, "Standard Single Audio Track Active", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = tracks.map { if (it.isSelected) "✓  " + it.label else "    " + it.label }.toTypedArray()
        val selectedIdx = tracks.indexOfFirst { it.isSelected }.coerceAtLeast(0)

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Audio Language / Multi-Tracks")
            .setSingleChoiceItems(labels, selectedIdx) { dialog, which ->
                val chosen = tracks[which]
                YouTubeExoPlayerManager.selectAudioTrack(chosen)
                getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .putString("pref_yt_audio_track_lang", chosen.language ?: "default")
                    .apply()
                Toast.makeText(this, "Switched Audio to: " + chosen.label, Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showYouTubeSubtitleDialog() {
        val options = arrayOf(
            "Turn Off Subtitles",
            "English Subtitles (Auto)",
            "Hindi Subtitles (Auto)",
            "Spanish Subtitles",
            "⚙ Subtitle Styling & Customization..."
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Captions & Subtitles")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> {
                        btnYtPlayerCC.setColorFilter(Color.WHITE)
                        Toast.makeText(this, "Subtitles: Off", Toast.LENGTH_SHORT).show()
                    }
                    1 -> {
                        btnYtPlayerCC.setColorFilter(Color.parseColor("#3EA6FF"))
                        Toast.makeText(this, "Subtitles: English Active", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        btnYtPlayerCC.setColorFilter(Color.parseColor("#3EA6FF"))
                        Toast.makeText(this, "Subtitles: Hindi Active", Toast.LENGTH_SHORT).show()
                    }
                    3 -> {
                        btnYtPlayerCC.setColorFilter(Color.parseColor("#3EA6FF"))
                        Toast.makeText(this, "Subtitles: Spanish Active", Toast.LENGTH_SHORT).show()
                    }
                    4 -> {
                        showSubtitleSettings()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCastDevicesDialog() {
        val devices = arrayOf(
            "Living Room TV (Chromecast)",
            "Bedroom Android TV",
            "Kitchen Smart Display",
            "Nearby Wireless Display..."
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Connect to a Device")
            .setItems(devices) { d, which ->
                val selected = devices[which]
                Toast.makeText(this, "Connecting to ...", Toast.LENGTH_SHORT).show()
                d.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showNotificationsDialog() {
        val notifications = arrayOf(
            "🔔 New video uploaded from Arijit Singh",
            "🔔 Trending: Romantic Bollywood Mashup 2026",
            "🔔 CleanPlayer v3.8.0 Active & Ad-Free",
            "🔔 Offline downloads ready for background play"
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Notifications")
            .setItems(notifications) { d, which ->
                // Unwanted popup removed
                d.dismiss()
            }
            .setPositiveButton("Clear All", null)
            .setNegativeButton("Close", null)
            .show()
    }

    private fun loadSubscriptionsFeed() {
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            collapseYouTubePlayer()
        }
        findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
        findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
        val allChips = listOf(chipYtAll, chipYtMusic, chipYtGaming, chipYtPodcasts, chipYtLive, chipYtTrending, chipYtNews)
        for (chip in allChips) {
            chip.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
            chip.setTextColor(Color.WHITE)
            chip.setTypeface(null, android.graphics.Typeface.NORMAL)
        }
        chipYtTrending.setBackgroundResource(R.drawable.bg_youtube_chip_active)
        chipYtTrending.setTextColor(Color.BLACK)
        chipYtTrending.setTypeface(null, android.graphics.Typeface.BOLD)
        currentYtCategory = "Subscriptions"

        pbYtFeedLoading.visibility = View.VISIBLE
        layoutYtEmpty.visibility = View.GONE

        val subs = YouTubeSubscriptionManager.getSubscriptions(this)
        if (subs.isEmpty()) {
            YouTubeFeedRepository.getFeed("all") { fallbackVideos ->
                pbYtFeedLoading.visibility = View.GONE
                if (fallbackVideos.isNotEmpty()) {
                    allYtFeedVideos.clear()
                    allYtFeedVideos.addAll(fallbackVideos)
                    youTubeFeedAdapter.updateItems(fallbackVideos)
                    layoutYtEmpty.visibility = View.GONE
                } else {
                    layoutYtEmpty.visibility = View.VISIBLE
                }
                Toast.makeText(this, "Channels ko Subscribe karein taaki unki videos Subscriptions feed me dikhein!", Toast.LENGTH_LONG).show()
            }
        } else {
            YouTubeSubscriptionManager.fetchSubscriptionsFeed(this) { subsVideos ->
                pbYtFeedLoading.visibility = View.GONE
                if (subsVideos.isNotEmpty()) {
                    allYtFeedVideos.clear()
                    allYtFeedVideos.addAll(subsVideos)
                    youTubeFeedAdapter.updateItems(subsVideos)
                    layoutYtEmpty.visibility = View.GONE
                } else {
                    layoutYtEmpty.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun showCommentsBottomSheet(videoTitle: String) {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 24, 40, 32)
            setBackgroundColor(Color.parseColor("#1C1C1E"))
        }
        val tvHead = TextView(this).apply {
            text = "Comments • 234"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, 16)
        }
        sheet.addView(tvHead)

        val comments = listOf(
            "Awesome song! Listening on loop in CleanPlayer 🎵",
            "Audio quality in 320kbps is pure perfection!",
            "No ads, clean interface, absolutely love this player ❤️",
            "One of the best mixes ever produced!"
        )
        for (comment in comments) {
            val tvC = TextView(this).apply {
                text = "👤 "
                setTextColor(Color.parseColor("#E0E0E0"))
                textSize = 13f
                setPadding(0, 8, 0, 12)
            }
            sheet.addView(tvC)
        }
        val etComment = EditText(this).apply {
            hint = "Add a public comment..."
            setHintTextColor(Color.parseColor("#888888"))
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(20, 16, 20, 16)
            setBackgroundResource(R.drawable.bg_youtube_search_box)
        }
        val btnPost = Button(this).apply {
            text = "Comment"
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.WHITE)
            setOnClickListener {
                val txt = etComment.text.toString().trim()
                if (txt.isNotEmpty()) {
                    Toast.makeText(this@MainActivity, "Comment posted!", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            }
        }
        sheet.addView(etComment)
        sheet.addView(btnPost)
        dialog.setContentView(sheet)
        dialog.show()
    }

    private fun showPlaybackSpeedDialog() {
        val speeds = arrayOf("0.25x", "0.5x", "0.75x", "1.0x (Normal)", "1.25x", "1.5x", "1.75x", "2.0x")
        val speedValues = floatArrayOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        val currentSpeed = YouTubeExoPlayerManager.exoPlayer?.playbackParameters?.speed ?: 1.0f
        val currentIdx = speedValues.indexOfFirst { kotlin.math.abs(it.toDouble() - currentSpeed.toDouble()) < 0.05 }.coerceAtLeast(3)

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Playback Speed")
            .setSingleChoiceItems(speeds, currentIdx) { dialog, which ->
                val speed = speedValues[which]
                YouTubeExoPlayerManager.setPlaybackSpeed(speed)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


}
