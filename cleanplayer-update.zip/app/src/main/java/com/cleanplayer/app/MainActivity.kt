package com.cleanplayer.app

import android.os.Handler
import android.os.Looper

import android.app.PictureInPictureParams
import android.util.Rational
import android.content.res.Configuration

import android.Manifest
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import androidx.core.widget.NestedScrollView
import android.widget.Button
import android.widget.ProgressBar
import android.widget.HorizontalScrollView
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.ImageButton
import android.widget.ImageView
import com.google.android.material.card.MaterialCardView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.widget.FrameLayout
import android.widget.RelativeLayout

class MainActivity : AppCompatActivity() {

    private val ytPrefs by lazy { getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE) }
    companion object {
        init {
            androidx.appcompat.app.AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        }
    }


    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnToolbarSearch: ImageButton
    private lateinit var btnToolbarSort: ImageButton
    private lateinit var btnToolbarOpen: ImageButton
    private lateinit var fabPlay: FloatingActionButton
    private lateinit var etSearch: EditText
    private lateinit var tabVideo: LinearLayout
    private lateinit var tabAudio: LinearLayout
    private lateinit var tabSettings: ScrollView
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var tabYouTube: FrameLayout
    private lateinit var layoutYtMainFeed: LinearLayout
        // YouTube Dedicated Settings Controls
    private lateinit var tvYtAdBlockStatus: TextView
    private lateinit var btnToggleYtAdBlock: Button
    private lateinit var tvYtSponsorBlockStatus: TextView
    private lateinit var btnConfigSponsorBlock: Button
    private lateinit var tvYtDefaultQualityStatus: TextView
    private lateinit var btnChangeYtQuality: Button
    private lateinit var tvYtExtractorBridgeStatus: TextView
    private lateinit var btnChangeYtExtractorBridge: Button
    private lateinit var tvYtClientSpoofingStatus: TextView
    private lateinit var btnChangeYtClient: Button
    private lateinit var tvYtBgAudioStatus: TextView
    private lateinit var btnToggleYtBgAudio: Button
    private lateinit var tvYtInterfaceStatus: TextView
    private lateinit var btnConfigYtUI: Button
    private lateinit var tvYtAccountStatus: TextView
    private lateinit var btnManageYtAccount: Button
    private lateinit var nsvYtFeed: NestedScrollView
    private lateinit var rvYouTubeFeed: RecyclerView
    private lateinit var rvYouTubeShorts: RecyclerView
    private lateinit var rvYouTubeFeedSecondary: RecyclerView
    private lateinit var youTubeShortsAdapter: YouTubeShortsAdapter
    private lateinit var srlYouTubeFeed: androidx.swiperefreshlayout.widget.SwipeRefreshLayout
    private lateinit var pbYtFeedLoading: ProgressBar
    private lateinit var layoutYtEmpty: LinearLayout
    private lateinit var btnYtRetry: Button
    private lateinit var btnYtSearch: ImageButton
    private lateinit var btnYtAccount: ImageButton
    private lateinit var btnYtCast: ImageButton
    private lateinit var btnYtNotifications: ImageButton
    private lateinit var layoutYtSearchBar: LinearLayout
    private lateinit var etYtSearchQuery: EditText
    private lateinit var btnYtCloseSearch: ImageButton
    private lateinit var chipYtAll: TextView
    private lateinit var chipYtMusic: TextView
    private lateinit var chipYtGaming: TextView
    private lateinit var chipYtPodcasts: TextView
    private lateinit var chipYtLive: TextView
    private lateinit var chipYtTrending: TextView
    private lateinit var chipYtNews: TextView
        // YouTube You Tab & Fullscreen Fields
    private lateinit var rvYtHistory: RecyclerView
    private lateinit var rvYtDownloads: RecyclerView
    private var ytHistoryAdapter: YouTubeHistoryAdapter? = null
    private var ytDownloadsAdapter: YouTubeHistoryAdapter? = null
    private var isYtFullscreen = false
    // YouTube Overlay Controls Views (1:1 with Official YouTube)
    private lateinit var pbYtBottomMiniProgress: ProgressBar
    private lateinit var layoutYtPlayerOverlay: RelativeLayout
    private lateinit var btnYtAutoplay: ImageButton
    private lateinit var btnYtAudioMode: ImageButton
    private lateinit var layoutYtAudioModeVisual: LinearLayout
    private lateinit var ivYtAudioModeThumb: ImageView
    private lateinit var btnYtPlayerCast: ImageButton
    private lateinit var btnYtPlayerCC: ImageButton
    private lateinit var btnYtRewind10: ImageButton
    private lateinit var btnYtForward10: ImageButton
    private lateinit var tvYtPlayerCurrentTime: TextView
    private lateinit var sbYtPlayer: SeekBar
    private var isYtUserSeeking = false
    private var isYtAutoplayEnabled = true
    private val ytOverlayHandler = Handler(Looper.getMainLooper())
    private val ytOverlayHideRunnable = Runnable {
        if (YouTubeExoPlayerManager.isPlaying()) {
            layoutYtPlayerOverlay.animate()
                .alpha(0f)
                .setDuration(250)
                .withEndAction {
                    layoutYtPlayerOverlay.visibility = View.GONE
                    layoutYtPlayerOverlay.alpha = 1f
                }
                .start()
        }
    }

    private lateinit var youTubeFeedAdapter: YouTubeFeedAdapter
    private lateinit var youTubeFeedSecondaryAdapter: YouTubeFeedAdapter
    private var currentYtCategory: String = "All"
    private var isYtFeedLoaded = false
    private var lastActiveTabId = R.id.nav_video

    // YouTube Dedicated Bottom Nav
    private lateinit var btnYtNavHome: LinearLayout
    private lateinit var btnYtNavShorts: LinearLayout
    private lateinit var btnYtNavSubs: LinearLayout
    private lateinit var btnYtNavLibrary: LinearLayout

    // YouTube Portrait Detail Player (Matching Screenshot 5681.jpg)
    private lateinit var layoutYtPlayerDetail: LinearLayout
    private lateinit var playerViewYt: androidx.media3.ui.PlayerView
    private lateinit var pbYtBuffering: ProgressBar
    private lateinit var btnYtCenterPlayPause: ImageButton
    private lateinit var btnYtCollapsePlayer: ImageButton
    private lateinit var btnYtFullscreen: ImageButton
    private lateinit var tvYtDetailTitle: TextView
    private lateinit var tvYtDetailSubtitle: TextView
    private lateinit var ivYtDetailAvatar: ImageView
    private lateinit var tvYtDetailChannel: TextView
    private lateinit var btnYtSubscribe: TextView
    private lateinit var layoutYtLikePill: LinearLayout
    private lateinit var tvYtDetailLikes: TextView
    private lateinit var layoutYtSharePill: LinearLayout
    private lateinit var layoutYtDownloadPill: LinearLayout
    private lateinit var tvYtDownloadPill: TextView
    private lateinit var ivYtDownloadPill: ImageView
    private lateinit var tvYtAudioQualityStatus: TextView
    private lateinit var btnChangeYtAudioQuality: Button
    private lateinit var layoutYtSavePill: LinearLayout
    private lateinit var layoutYtCommentsCard: LinearLayout
    private lateinit var layoutYtShortsShelf: LinearLayout
    private lateinit var tvYtDetailCommentsCount: TextView
    private lateinit var rvYtRelatedVideos: RecyclerView

    // YouTube Floating Miniplayer (Matching Screenshots 5682.jpg & 5680.jpg)
    private lateinit var cardYtMiniPlayer: MaterialCardView
    private lateinit var ivYtMiniThumb: ImageView
    private lateinit var tvYtMiniTitle: TextView
    private lateinit var tvYtMiniChannel: TextView
    private lateinit var btnYtMiniPlayPause: ImageButton
    private lateinit var btnYtMiniClose: ImageButton

    private var currentPlayingYtVideo: YouTubeVideo? = null
    private var isYtVideoPlaying: Boolean = false

    private lateinit var btnViewAllVideos: TextView
    private lateinit var btnViewFolders: TextView
    private lateinit var rvVideos: RecyclerView
    private lateinit var layoutFoldersContainer: LinearLayout
    private lateinit var rvFolders: RecyclerView
    private lateinit var layoutFolderDetailHeader: LinearLayout
    private lateinit var btnFolderBack: ImageButton
    private lateinit var tvFolderHeaderTitle: TextView
    private lateinit var tvFolderHeaderSubtitle: TextView
    private lateinit var rvFolderVideos: RecyclerView
    private lateinit var layoutEmptyVideo: LinearLayout
    private lateinit var btnBrowseVideo: Button

    private var isFolderViewActive: Boolean = false
    private var allFolders: List<MediaFolder> = emptyList()
    private var currentSelectedFolder: MediaFolder? = null
    private var folderAdapter: FolderAdapter? = null
    private var folderVideoAdapter: MediaAdapter? = null

    private lateinit var rvAudio: RecyclerView
    private lateinit var layoutEmptyAudio: LinearLayout
    private lateinit var btnBrowseAudio: Button

    // 1. Video Settings Views
    private lateinit var tvHighRefreshRateStatus: TextView
    private lateinit var btnToggleHighRefreshRate: Button
    private lateinit var tvDefaultOrientationStatus: TextView
    private lateinit var btnChangeOrientation: Button

    // Top Notch Mini-Player Views (matches 5203.jpg)
    private lateinit var cardNotchPlayer: MaterialCardView
    private lateinit var ivNotchIcon: ImageView
    private lateinit var tvNotchTitle: TextView
    private lateinit var tvNotchArtist: TextView
    private lateinit var btnNotchClose: ImageButton
    private lateinit var btnNotchRepeat: ImageButton
    private lateinit var btnNotchPrev: ImageButton
    private lateinit var btnNotchPlayPause: ImageButton
    private lateinit var btnNotchNext: ImageButton
    private lateinit var btnNotchOpen: ImageButton
    private lateinit var tvNotchCurrent: TextView
    private lateinit var sbNotch: SeekBar
    private lateinit var tvNotchTotal: TextView
    private lateinit var tvVideoColorStatus: TextView
    private lateinit var btnChangeVideoColor: Button
    private lateinit var tvWideColorStatus: TextView
    private lateinit var btnToggleWideColor: Button
    private lateinit var tvDeblockingStatus: TextView
    private lateinit var btnToggleDeblocking: Button
    private lateinit var tvHwDecodeStatus: TextView
    private lateinit var btnChangeHw: Button
    private lateinit var tvBgPipStatus: TextView
    private lateinit var btnChangeBgPip: Button
    private lateinit var tvResumeModeStatus: TextView
    private lateinit var btnChangeResumeMode: Button
    private lateinit var tvDoubleTapStatus: TextView
    private lateinit var btnChangeDoubleTap: Button
    private lateinit var tvAspectRatioStatus: TextView
    private lateinit var btnChangeAspectRatio: Button
    private lateinit var tvAudioBoostStatus: TextView
    private lateinit var btnToggleAudioBoost: Button

    // 2. Integrated Dolby, Spatial & Equalizer Audio Suite Views
    private lateinit var tvMasterProfileStatus: TextView
    private lateinit var btnChangeMasterProfile: Button
    private lateinit var tvDolbySurroundStatus: TextView
    private lateinit var btnChangeDolbySurround: Button
    private lateinit var tvEqualizerStatus: TextView
    private lateinit var btnChangeEqualizer: Button
    private lateinit var tvDialogueBoostStatus: TextView
    private lateinit var btnToggleDialogueBoost: Button
    private lateinit var tvDigitalPassthroughStatus: TextView
    private lateinit var btnTogglePassthrough: Button
    private lateinit var tvAudioOutputStatus: TextView
    private lateinit var btnChangeAudioOutput: Button
    private lateinit var tvHeadsetPauseStatus: TextView
    private lateinit var btnToggleHeadsetPause: Button
    private lateinit var tvTimeStretchStatus: TextView
    private lateinit var btnToggleTimeStretch: Button

    // 3. Subtitle Settings Views
    private lateinit var btnToggleSubAutoload: Button
    private lateinit var tvSubSizeStatus: TextView
    private lateinit var btnChangeSubSize: Button
    private lateinit var tvSubColorStatus: TextView
    private lateinit var btnChangeSubColor: Button
    private lateinit var tvSubBackgroundStatus: TextView
    private lateinit var btnChangeSubBackground: Button
    private lateinit var tvSubStyleStatus: TextView
    private lateinit var btnToggleSubStyle: Button
    private lateinit var tvSubEncodingStatus: TextView
    private lateinit var btnChangeSubEncoding: Button

    // 4. Gestures Settings Views
    private lateinit var tvGestureVolumeStatus: TextView
    private lateinit var btnToggleGestureVolume: Button
    private lateinit var tvGestureBrightnessStatus: TextView
    private lateinit var btnToggleGestureBrightness: Button
    private lateinit var tvGestureSeekStatus: TextView
    private lateinit var btnToggleGestureSeek: Button
    private lateinit var tvFastSeekStatus: TextView
    private lateinit var btnToggleFastSeek: Button

    // 5. Interface Settings Views
    private lateinit var tvAppThemeStatus: TextView
    private lateinit var btnChangeAppTheme: Button

    // 6. Advanced Settings Views
    private lateinit var btnClearCache: Button
    private lateinit var btnClearResume: Button
    private lateinit var btnResetSettings: Button
    private lateinit var tvCacheSizeStatus: TextView

    private var allVideos = listOf<MediaItem>()
    private var allAudio = listOf<MediaItem>()
    private var videoAdapter: MediaAdapter? = null
    private var audioAdapter: MediaAdapter? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val title = PlayerHolder.resolveMediaTitle(this, it, null)
            val type = contentResolver.getType(it) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(it, title, isVideo, null)
        }
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        loadMediaFiles()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        PlayerHolder.loadPreferences(this)
        if (PlayerHolder.isMonochrome()) {
            setTheme(R.style.Theme_Multimedia_Monochrome)
        } else {
            setTheme(R.style.Theme_Multimedia)
        }
        super.onCreate(savedInstanceState)
        applyHighRefreshRate()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        setContentView(R.layout.activity_main)

        // Initialize Downloader instance
        try {
            // Eager engine warmup
        } catch (e: Throwable) {}

        onBackPressedDispatcher.addCallback(this) {
            if (!handleBackPress()) {
                finish()
            }
        }

        YouTubeStreamResolver.initNewPipe(this)
        initViews()
        setupBottomNav()
        setupSearch()
        setupVideoSettings()
        setupAudioSuiteSettings()
        setupSubtitleSettings()
        setupGestureSettings()
        setupInterfaceAndAdvancedSettings()
        applyThemeUI()
        checkAndRequestPermissions()

        val openFullPlayer = {
            val uri = PlayerHolder.currentUri
            if (uri != null) {
                openPlayer(uri, PlayerHolder.currentTitle, isVideo = !PlayerHolder.isAudioOnly, path = PlayerHolder.currentPath)
            }
        }
        cardNotchPlayer.setOnClickListener {
            if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                showTab(video = false, audio = false, youtube = true, settings = false)
                layoutYtPlayerDetail.visibility = View.VISIBLE
                YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
            } else {
                openFullPlayer()
            }
        }
        btnNotchOpen.setOnClickListener {
            if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                showTab(video = false, audio = false, youtube = true, settings = false)
                layoutYtPlayerDetail.visibility = View.VISIBLE
                YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
            } else {
                openFullPlayer()
            }
        }

        btnNotchPlayPause.setOnClickListener {
            if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                YouTubeExoPlayerManager.togglePlayPause()
                val isPlaying = YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
                btnNotchPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            } else if (PlayerHolder.audioExoPlayer != null) {
                val p = PlayerHolder.audioExoPlayer!!
                if (p.isPlaying) p.pause() else p.play()
                btnNotchPlayPause.setImageResource(
                    if (p.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            } else {
                PlayerHolder.mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        player.pause()
                        btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_play)
                        MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = false)
                    } else {
                        player.play()
                        btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_pause)
                        MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = true)
                    }
                }
            }
        }

        btnNotchPrev.setOnClickListener {
            if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                val current = YouTubeExoPlayerManager.getCurrentPosition()
                YouTubeExoPlayerManager.seekTo((current - 10000).coerceAtLeast(0))
                Toast.makeText(this, "Rewound 10s", Toast.LENGTH_SHORT).show()
            } else {
                PlayerHolder.playPrevious(this)
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            }
        }

        btnNotchNext.setOnClickListener {
            if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                val current = YouTubeExoPlayerManager.getCurrentPosition()
                val duration = YouTubeExoPlayerManager.getDuration()
                YouTubeExoPlayerManager.seekTo((current + 10000).coerceAtMost(duration))
                Toast.makeText(this, "Forwarded 10s", Toast.LENGTH_SHORT).show()
            } else {
                PlayerHolder.playNext(this)
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            }
        }

        btnNotchRepeat.setOnClickListener {
            if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                val p = YouTubeExoPlayerManager.exoPlayer!!
                val nextMode = when (p.repeatMode) {
                    androidx.media3.common.Player.REPEAT_MODE_OFF -> androidx.media3.common.Player.REPEAT_MODE_ONE
                    androidx.media3.common.Player.REPEAT_MODE_ONE -> androidx.media3.common.Player.REPEAT_MODE_ALL
                    else -> androidx.media3.common.Player.REPEAT_MODE_OFF
                }
                p.repeatMode = nextMode
                val displayMode = when (nextMode) {
                    androidx.media3.common.Player.REPEAT_MODE_ONE -> 2
                    androidx.media3.common.Player.REPEAT_MODE_ALL -> 1
                    else -> 0
                }
                updateNotchRepeatUI(displayMode)
            } else {
                val mode = PlayerHolder.toggleRepeatMode()
                updateNotchRepeatUI(mode)
            }
        }

        btnNotchClose.setOnClickListener {
            if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                YouTubeExoPlayerManager.pause()
                currentPlayingYtVideo = null
                isYtVideoPlaying = false
            } else {
                PlayerHolder.release()
                MediaPlaybackService.stop(this)
                audioAdapter?.setPlayingUri(null)
            }
            cardNotchPlayer.visibility = View.GONE
        }

        sbNotch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    tvNotchCurrent.text = formatTime(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                sb?.let {
                    val target = it.progress.toLong()
                    if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                        YouTubeExoPlayerManager.seekTo(target)
                    } else if (PlayerHolder.audioExoPlayer != null) {
                        PlayerHolder.audioExoPlayer?.seekTo(target)
                    } else {
                        PlayerHolder.mediaPlayer?.time = target
                    }
                }
            }
        })

        intent?.data?.let { uri ->
            val title = PlayerHolder.resolveMediaTitle(this, uri, null)
            val type = intent?.type ?: contentResolver.getType(uri) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(uri, title, isVideo, null)
        }
    }

    private val notchProgressHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val notchProgressRunnable = object : Runnable {
        override fun run() {
            if (cardNotchPlayer.visibility == View.VISIBLE) {
                val ytPlayer = YouTubeExoPlayerManager.exoPlayer
                val audioPlayer = PlayerHolder.audioExoPlayer
                val vlcPlayer = PlayerHolder.mediaPlayer

                when {
                    ytPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null -> {
                        val current = ytPlayer.currentPosition
                        val duration = ytPlayer.duration
                        if (duration > 0) {
                            sbNotch.max = duration.toInt()
                            sbNotch.progress = current.toInt()
                            tvNotchCurrent.text = formatTime(current)
                            tvNotchTotal.text = formatTime(duration)

                            if (::tvYtPlayerCurrentTime.isInitialized && !isYtUserSeeking) {
                                tvYtPlayerCurrentTime.text = "${formatTime(current)} / ${formatTime(duration)}"
                                sbYtPlayer.max = duration.toInt()
                                sbYtPlayer.progress = current.toInt()
                                pbYtBottomMiniProgress.max = duration.toInt()
                                pbYtBottomMiniProgress.progress = current.toInt()
                            }
                        }
                        btnNotchPlayPause.setImageResource(
                            if (ytPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                        )
                    }
                    audioPlayer != null && PlayerHolder.currentUri != null -> {
                        val current = audioPlayer.currentPosition
                        val duration = audioPlayer.duration
                        if (duration > 0) {
                            sbNotch.max = duration.toInt()
                            sbNotch.progress = current.toInt()
                            tvNotchCurrent.text = formatTime(current)
                            tvNotchTotal.text = formatTime(duration)
                        }
                        btnNotchPlayPause.setImageResource(
                            if (audioPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                        )
                    }
                    vlcPlayer != null && PlayerHolder.currentUri != null -> {
                        val current = vlcPlayer.time
                        val duration = vlcPlayer.length
                        if (duration > 0) {
                            sbNotch.max = duration.toInt()
                            sbNotch.progress = current.toInt()
                            tvNotchCurrent.text = formatTime(current)
                            tvNotchTotal.text = formatTime(duration)
                        }
                        btnNotchPlayPause.setImageResource(
                            if (vlcPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                        )
                    }
                }
            }
            notchProgressHandler.postDelayed(this, 1000)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            if (::playerViewYt.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            }
        } catch (e: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        YouTubeExoPlayerManager.onAppForegrounded(this)
        YouTubeExoPlayerManager.onAudioModeChanged = { isAudioOnly ->
            runOnUiThread {
                updateAudioModeUI(isAudioOnly)
            }
        }
        YouTubeDownloaderHelper.onDownloadProgressChanged = { downloadId, percent, downStr, totalStr, status ->
            runOnUiThread {
                tvYtDownloadPill.text = "" + percent + "%"
                ivYtDownloadPill.setColorFilter(Color.parseColor("#3EA6FF"))
            }
        }

        YouTubeDownloaderHelper.onDownloadFinished = { downloadId, fileName, success ->
            runOnUiThread {
                if (success) {
                    tvYtDownloadPill.text = "Downloaded"
                    ivYtDownloadPill.setImageResource(R.drawable.ic_check_player)
                    ivYtDownloadPill.setColorFilter(Color.parseColor("#00E676"))
                } else {
                    tvYtDownloadPill.text = "Download"
                    ivYtDownloadPill.setImageResource(R.drawable.ic_download)
                    ivYtDownloadPill.setColorFilter(Color.WHITE)
                }
            }
        }

        YouTubeExoPlayerManager.onPlaybackStateChanged = { isPlaying ->
            runOnUiThread {
                isYtVideoPlaying = isPlaying
                btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                btnYtCenterPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                btnNotchPlayPause.setImageResource(if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
                updateNotchPlayerUI()
            }
        }
        YouTubeExoPlayerManager.onBufferingStateChanged = { isBuffering ->
            runOnUiThread {
                pbYtBuffering.visibility = if (isBuffering) View.VISIBLE else View.GONE
            }
        }
        YouTubeExoPlayerManager.onSponsorSkipped = { label ->
            Toast.makeText(this, "Skipped $label segment [SponsorBlock]", Toast.LENGTH_SHORT).show()
        }
        YouTubeExoPlayerManager.onPlayerError = { error ->
            runOnUiThread {
                pbYtBuffering.visibility = View.GONE
                btnYtCenterPlayPause.visibility = View.VISIBLE
                btnYtCenterPlayPause.setImageResource(R.drawable.ic_play_player)
                val v = currentPlayingYtVideo
                if (v != null) {
                    Toast.makeText(this, "Optimizing stream: switching to fast adaptive channel...", Toast.LENGTH_SHORT).show()
                    YouTubeStreamResolver.resolveStreams(v.id, 480) { resStream ->
                        if (resStream != null) {
                            val fastOpt = resStream.availableQualities.firstOrNull { it.audioUrl == null }
                            val url = fastOpt?.videoUrl ?: resStream.videoUrl
                            YouTubeExoPlayerManager.playVideo(
                                context = this,
                                video = v,
                                videoStreamUrl = url,
                                audioStreamUrl = null,
                                pureAudioUrl = resStream.pureAudioUrl,
                                allAudioUrls = resStream.allAudioUrls
                            )
                        } else {
                            Toast.makeText(this, "Playback notice: Tap to retry", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        }
        updateSettingsUI()
        updateNotchPlayerUI()
        audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
        notchProgressHandler.post(notchProgressRunnable)

        PlayerHolder.onTrackChangedListener = { item ->
            runOnUiThread {
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(item.uri)
            }
        }
        PlayerHolder.onPlaybackStateChangedListener = { isPlaying ->
            runOnUiThread {
                btnNotchPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
                audioAdapter?.notifyDataSetChanged()
                updateNotchPlayerUI()
            }
        }

    }

    private fun updateAudioModeUI(isAudioOnly: Boolean) {
        if (isAudioOnly) {
            layoutYtAudioModeVisual.visibility = View.VISIBLE
            btnYtAudioMode.setImageResource(R.drawable.ic_video)
            btnYtAudioMode.setColorFilter(Color.parseColor("#00E676"))
            currentPlayingYtVideo?.let { v ->
                ImageLoaderHelper.loadImage(v.thumbnailUrl, ivYtAudioModeThumb)
            }
        } else {
            layoutYtAudioModeVisual.visibility = View.GONE
            btnYtAudioMode.setImageResource(R.drawable.ic_audio)
            btnYtAudioMode.setColorFilter(Color.WHITE)
            YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        }
    }

    override fun onStop() {
        super.onStop()
        val isPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        val isBackgroundAllowed = PlayerHolder.isBackgroundPlayEnabled || PlayerHolder.backgroundPipMode > 0
        if (!isPip && isBackgroundAllowed && YouTubeExoPlayerManager.isPlaying()) {
            YouTubeExoPlayerManager.onAppBackgrounded(this)
        }
    }

    override fun onPause() {
        super.onPause()
        notchProgressHandler.removeCallbacks(notchProgressRunnable)
        PlayerHolder.onTrackChangedListener = null
        PlayerHolder.onPlaybackStateChangedListener = null
        // Media3 ExoPlayer handles background audio playback and PiP
    }

    private fun updateNotchRepeatUI(mode: Int) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        when (mode) {
            1 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat_one)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            2 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            else -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(secondaryColor)
            }
        }
    }

    private fun updateNotchPlayerUI() {
        val ytVideo = YouTubeExoPlayerManager.currentPlayingVideo
        val ytPlayer = YouTubeExoPlayerManager.exoPlayer
        val audioPlayer = PlayerHolder.audioExoPlayer
        val vlcPlayer = PlayerHolder.mediaPlayer

        if (ytPlayer != null && ytVideo != null && ytPlayer.isPlaying) {
            // 1. YouTube Online Streaming Active in Notch (Only while playing!)
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = ytVideo.title
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = ytVideo.channelTitle
            val isPlaying = ytPlayer.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = ytPlayer.duration
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                val current = ytPlayer.currentPosition
                sbNotch.progress = current.toInt()
                tvNotchCurrent.text = formatTime(current)
                tvNotchTotal.text = formatTime(duration)
            }
            if (!ytVideo.thumbnailUrl.isNullOrBlank()) {
                ImageLoaderHelper.load(this, ytVideo.thumbnailUrl, ivNotchIcon)
            } else {
                ivNotchIcon.setImageResource(R.drawable.ic_youtube)
            }
        } else if (audioPlayer != null && PlayerHolder.currentUri != null && audioPlayer.isPlaying) {
            // 2. Local Audio Media3 Active in Notch (Only while playing!)
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = PlayerHolder.currentTitle
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = PlayerHolder.currentArtist
            val isPlaying = audioPlayer.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = audioPlayer.duration
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                val current = audioPlayer.currentPosition
                sbNotch.progress = current.toInt()
                tvNotchCurrent.text = formatTime(current)
                tvNotchTotal.text = formatTime(duration)
            }
            ivNotchIcon.setImageResource(R.drawable.ic_audio)
        } else if (vlcPlayer != null && PlayerHolder.currentUri != null && vlcPlayer.isPlaying) {
            // 3. Local Video VLC Active in Notch (Only while playing!)
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = PlayerHolder.currentTitle
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = PlayerHolder.currentArtist
            val isPlaying = vlcPlayer.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = vlcPlayer.length
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                sbNotch.progress = vlcPlayer.time.toInt()
                tvNotchCurrent.text = formatTime(vlcPlayer.time)
                tvNotchTotal.text = formatTime(duration)
            }
            ivNotchIcon.setImageResource(R.drawable.ic_video)
        } else {
            cardNotchPlayer.visibility = View.GONE
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (hours > 0) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    private fun showSortDialog() {
        val sortOptions = arrayOf(
            getString(R.string.sort_name_asc),
            getString(R.string.sort_name_desc),
            getString(R.string.sort_date_newest),
            getString(R.string.sort_duration),
            getString(R.string.sort_size)
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle(R.string.sort_title)
            .setItems(sortOptions) { _, which ->
                when (which) {
                    0 -> {
                        allVideos = allVideos.sortedBy { it.title.lowercase() }
                        allAudio = allAudio.sortedBy { it.title.lowercase() }
                    }
                    1 -> {
                        allVideos = allVideos.sortedByDescending { it.title.lowercase() }
                        allAudio = allAudio.sortedByDescending { it.title.lowercase() }
                    }
                    2 -> {
                        allVideos = allVideos.sortedByDescending { it.id }
                        allAudio = allAudio.sortedByDescending { it.id }
                    }
                    3 -> {
                        allVideos = allVideos.sortedByDescending { it.durationMs }
                        allAudio = allAudio.sortedByDescending { it.durationMs }
                    }
                    4 -> {
                        allVideos = allVideos.sortedByDescending { it.sizeBytes }
                        allAudio = allAudio.sortedByDescending { it.sizeBytes }
                    }
                }
                videoAdapter?.updateList(allVideos)
                audioAdapter?.updateList(allAudio)
                updateFoldersData()
                Toast.makeText(this, "Sorted by ${sortOptions[which]}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        btnToolbarSearch = findViewById(R.id.btnToolbarSearch)
        btnToolbarSearch.setOnClickListener {
            val searchLayout = findViewById<View>(R.id.layoutSearch)
            searchLayout.visibility = if (searchLayout.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (searchLayout.visibility == View.VISIBLE) {
                etSearch.requestFocus()
            }
        }
        btnToolbarSort = findViewById(R.id.btnToolbarSort)
        btnToolbarSort.setOnClickListener { showSortDialog() }
        btnToolbarOpen = findViewById(R.id.btnToolbarOpen)
        fabPlay = findViewById(R.id.fabPlay)
        fabPlay.setOnClickListener {
            if (allVideos.isNotEmpty()) {
                val item = allVideos.first()
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } else if (allAudio.isNotEmpty()) {
                PlayerHolder.setPlaylistAndPlay(this, allAudio, 0)
                openPlayer(allAudio[0].uri, allAudio[0].title, isVideo = false, path = allAudio[0].filePath, artist = allAudio[0].artist)
            } else {
                Toast.makeText(this, "No media files found", Toast.LENGTH_SHORT).show()
            }
        }
        etSearch = findViewById(R.id.etSearch)
        tabVideo = findViewById(R.id.tabVideo)
        tabAudio = findViewById(R.id.tabAudio)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)
        tabYouTube = findViewById(R.id.tabYouTube)
        layoutYtMainFeed = findViewById(R.id.layoutYtMainFeed)
        // btnYtExitToLocal removed for clean official header
        nsvYtFeed = findViewById(R.id.nsvYtFeed)
        rvYouTubeFeed = findViewById(R.id.rvYouTubeFeed)
        rvYouTubeShorts = findViewById(R.id.rvYouTubeShorts)
        rvYouTubeFeedSecondary = findViewById(R.id.rvYouTubeFeedSecondary)
        srlYouTubeFeed = findViewById(R.id.srlYouTubeFeed)
        pbYtFeedLoading = findViewById(R.id.pbYtFeedLoading)
        layoutYtEmpty = findViewById(R.id.layoutYtEmpty)
        btnYtRetry = findViewById(R.id.btnYtRetry)
        btnYtSearch = findViewById(R.id.btnYtSearch)
        btnYtAccount = findViewById(R.id.btnYtAccount)
        btnYtCast = findViewById(R.id.btnYtCast)
        btnYtNotifications = findViewById(R.id.btnYtNotifications)
        layoutYtSearchBar = findViewById(R.id.layoutYtSearchBar)
        etYtSearchQuery = findViewById(R.id.etYtSearchQuery)
        btnYtCloseSearch = findViewById(R.id.btnYtCloseSearch)
        chipYtAll = findViewById(R.id.chipYtAll)
        chipYtMusic = findViewById(R.id.chipYtMusic)
        chipYtGaming = findViewById(R.id.chipYtGaming)
        chipYtPodcasts = findViewById(R.id.chipYtPodcasts)
        chipYtLive = findViewById(R.id.chipYtLive)
        chipYtTrending = findViewById(R.id.chipYtTrending)
        chipYtNews = findViewById(R.id.chipYtNews)

        btnYtNavHome = findViewById(R.id.btnYtNavHome)
        btnYtNavShorts = findViewById(R.id.btnYtNavShorts)
        btnYtNavSubs = findViewById(R.id.btnYtNavSubs)
        btnYtNavLibrary = findViewById(R.id.btnYtNavLibrary)

        layoutYtPlayerDetail = findViewById(R.id.layoutYtPlayerDetail)
        playerViewYt = findViewById(R.id.playerViewYt)
        pbYtBuffering = findViewById(R.id.pbYtBuffering)
        btnYtCenterPlayPause = findViewById(R.id.btnYtCenterPlayPause)
        YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        YouTubeExoPlayerManager.onPlaybackStateChanged = { isPlaying ->
            runOnUiThread {
                isYtVideoPlaying = isPlaying
                btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                btnYtCenterPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                btnNotchPlayPause.setImageResource(if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
                updateNotchPlayerUI()
            }
        }
        YouTubeExoPlayerManager.onBufferingStateChanged = { isBuffering ->
            runOnUiThread {
                pbYtBuffering.visibility = if (isBuffering) View.VISIBLE else View.GONE
            }
        }
        YouTubeExoPlayerManager.onSponsorSkipped = { label ->
            Toast.makeText(this, "Skipped $label segment [SponsorBlock]", Toast.LENGTH_SHORT).show()
        }
        YouTubeExoPlayerManager.onPlayerError = { error ->
            runOnUiThread {
                pbYtBuffering.visibility = View.GONE
                btnYtCenterPlayPause.visibility = View.VISIBLE
                btnYtCenterPlayPause.setImageResource(R.drawable.ic_play_player)
                val v = currentPlayingYtVideo
                if (v != null) {
                    Toast.makeText(this, "Optimizing stream: switching to fast adaptive channel...", Toast.LENGTH_SHORT).show()
                    YouTubeStreamResolver.resolveStreams(v.id, 480) { resStream ->
                        if (resStream != null) {
                            val fastOpt = resStream.availableQualities.firstOrNull { it.audioUrl == null }
                            val url = fastOpt?.videoUrl ?: resStream.videoUrl
                            YouTubeExoPlayerManager.playVideo(
                                context = this,
                                video = v,
                                videoStreamUrl = url,
                                audioStreamUrl = null,
                                pureAudioUrl = resStream.pureAudioUrl,
                                allAudioUrls = resStream.allAudioUrls
                            )
                        } else {
                            Toast.makeText(this, "Playback notice: Tap to retry", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
        btnYtCenterPlayPause.setOnClickListener {
            val player = YouTubeExoPlayerManager.exoPlayer
            if (player != null && (player.playbackState == androidx.media3.common.Player.STATE_IDLE || player.playerError != null)) {
                currentPlayingYtVideo?.let { playYouTubeVideoInApp(it) }
            } else {
                YouTubeExoPlayerManager.togglePlayPause()
            }
        }
        playerViewYt.setOnClickListener {
            val isVis = btnYtCenterPlayPause.visibility == View.VISIBLE
            btnYtCenterPlayPause.visibility = if (isVis) View.GONE else View.VISIBLE
            if (!isVis) {
                playerViewYt.postDelayed({
                    btnYtCenterPlayPause.visibility = View.GONE
                }, 3000)
            }
        }
        btnYtCollapsePlayer = findViewById(R.id.btnYtCollapsePlayer)
        btnYtFullscreen = findViewById(R.id.btnYtFullscreen)
        tvYtDetailTitle = findViewById(R.id.tvYtDetailTitle)
        tvYtDetailSubtitle = findViewById(R.id.tvYtDetailSubtitle)
        ivYtDetailAvatar = findViewById(R.id.ivYtDetailAvatar)
        tvYtDetailChannel = findViewById(R.id.tvYtDetailChannel)
        btnYtSubscribe = findViewById(R.id.btnYtSubscribe)
        layoutYtLikePill = findViewById(R.id.layoutYtLikePill)
        tvYtDetailLikes = findViewById(R.id.tvYtDetailLikes)
        layoutYtSharePill = findViewById(R.id.layoutYtSharePill)
        layoutYtDownloadPill = findViewById(R.id.layoutYtDownloadPill)
        tvYtDownloadPill = findViewById(R.id.tvYtDownloadPill)
        ivYtDownloadPill = findViewById(R.id.ivYtDownloadPill)
        tvYtAudioQualityStatus = findViewById(R.id.tvYtAudioQualityStatus)
        btnChangeYtAudioQuality = findViewById(R.id.btnChangeYtAudioQuality)
        layoutYtSavePill = findViewById(R.id.layoutYtSavePill)
        layoutYtCommentsCard = findViewById(R.id.layoutYtCommentsCard)
        layoutYtShortsShelf = findViewById(R.id.layoutYtShortsShelf)
        tvYtDetailCommentsCount = findViewById(R.id.tvYtDetailCommentsCount)
        rvYtRelatedVideos = findViewById(R.id.rvYtRelatedVideos)

        cardYtMiniPlayer = findViewById(R.id.cardYtMiniPlayer)
        ivYtMiniThumb = findViewById(R.id.ivYtMiniThumb)
        tvYtMiniTitle = findViewById(R.id.tvYtMiniTitle)
        tvYtMiniChannel = findViewById(R.id.tvYtMiniChannel)
        btnYtMiniPlayPause = findViewById(R.id.btnYtMiniPlayPause)
        btnYtMiniClose = findViewById(R.id.btnYtMiniClose)

        initNativeYouTubeEngine()

        btnViewAllVideos = findViewById(R.id.btnViewAllVideos)
        btnViewFolders = findViewById(R.id.btnViewFolders)
        rvVideos = findViewById(R.id.rvVideos)
        layoutFoldersContainer = findViewById(R.id.layoutFoldersContainer)
        rvFolders = findViewById(R.id.rvFolders)
        layoutFolderDetailHeader = findViewById(R.id.layoutFolderDetailHeader)
        btnFolderBack = findViewById(R.id.btnFolderBack)
        tvFolderHeaderTitle = findViewById(R.id.tvFolderHeaderTitle)
        tvFolderHeaderSubtitle = findViewById(R.id.tvFolderHeaderSubtitle)
        rvFolderVideos = findViewById(R.id.rvFolderVideos)
        layoutEmptyVideo = findViewById(R.id.layoutEmptyVideo)
        btnBrowseVideo = findViewById(R.id.btnBrowseVideo)

        rvFolders.layoutManager = LinearLayoutManager(this)
        rvFolderVideos.layoutManager = LinearLayoutManager(this)

        btnViewAllVideos.setOnClickListener {
            switchVideoViewMode(folders = false)
        }

        btnViewFolders.setOnClickListener {
            switchVideoViewMode(folders = true)
        }

        btnFolderBack.setOnClickListener {
            closeFolderDetail()
        }

        rvAudio = findViewById(R.id.rvAudio)
        layoutEmptyAudio = findViewById(R.id.layoutEmptyAudio)
        btnBrowseAudio = findViewById(R.id.btnBrowseAudio)

        // YouTube Settings Views
        tvYtAdBlockStatus = findViewById(R.id.tvYtAdBlockStatus)
        btnToggleYtAdBlock = findViewById(R.id.btnToggleYtAdBlock)
        tvYtSponsorBlockStatus = findViewById(R.id.tvYtSponsorBlockStatus)
        btnConfigSponsorBlock = findViewById(R.id.btnConfigSponsorBlock)
        tvYtDefaultQualityStatus = findViewById(R.id.tvYtDefaultQualityStatus)
        btnChangeYtQuality = findViewById(R.id.btnChangeYtQuality)
        tvYtExtractorBridgeStatus = findViewById(R.id.tvYtExtractorBridgeStatus)
        btnChangeYtExtractorBridge = findViewById(R.id.btnChangeYtExtractorBridge)
        findViewById<View>(R.id.rowYtExtractorBridge)?.setOnClickListener {
            showExtractorBridgeDialog()
        }
        btnChangeYtExtractorBridge.setOnClickListener {
            showExtractorBridgeDialog()
        }

        findViewById<View>(R.id.rowYtClientSpoofing)?.setOnClickListener {
            showClientSpoofingDialog()
        }
        tvYtClientSpoofingStatus = findViewById(R.id.tvYtClientSpoofingStatus)
        btnChangeYtClient = findViewById(R.id.btnChangeYtClient)
        tvYtBgAudioStatus = findViewById(R.id.tvYtBgAudioStatus)
        btnToggleYtBgAudio = findViewById(R.id.btnToggleYtBgAudio)
        tvYtInterfaceStatus = findViewById(R.id.tvYtInterfaceStatus)
        btnConfigYtUI = findViewById(R.id.btnConfigYtUI)
        tvYtAccountStatus = findViewById(R.id.tvYtAccountStatus)
        btnManageYtAccount = findViewById(R.id.btnManageYtAccount)

        btnToggleYtAdBlock.setOnClickListener {
            val prefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
            val cur = prefs.getBoolean("pref_yt_adblock", true)
            prefs.edit().putBoolean("pref_yt_adblock", !cur).apply()
            updateSettingsUI()
        }

        btnConfigSponsorBlock.setOnClickListener {
            showSponsorBlockSettingsDialog()
        }

        btnChangeYtQuality.setOnClickListener {
            showYouTubeQualityDialog()
        }

        btnChangeYtClient.setOnClickListener {
            showClientSpoofingDialog()
        }

        btnToggleYtBgAudio.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            updateSettingsUI()
        }

        btnConfigYtUI.setOnClickListener {
            showYouTubeUiConfigDialog()
        }

        btnManageYtAccount.setOnClickListener {
            MicroGAuthManager.showAccountDialog(this) {
                updateMicroGAccountState()
                updateSettingsUI()
                loadYouTubeFeed(currentYtCategory)
            }
        }

        // Video Settings
        tvHighRefreshRateStatus = findViewById(R.id.tvHighRefreshRateStatus)
        btnToggleHighRefreshRate = findViewById(R.id.btnToggleHighRefreshRate)
        tvDefaultOrientationStatus = findViewById(R.id.tvDefaultOrientationStatus)
        btnChangeOrientation = findViewById(R.id.btnChangeOrientation)

        // Notch Mini Player
        cardNotchPlayer = findViewById(R.id.cardNotchPlayer)
        ivNotchIcon = findViewById(R.id.ivNotchIcon)
        tvNotchTitle = findViewById(R.id.tvNotchTitle)
        tvNotchArtist = findViewById(R.id.tvNotchArtist)
        btnNotchClose = findViewById(R.id.btnNotchClose)
        btnNotchRepeat = findViewById(R.id.btnNotchRepeat)
        btnNotchPrev = findViewById(R.id.btnNotchPrev)
        btnNotchPlayPause = findViewById(R.id.btnNotchPlayPause)
        btnNotchNext = findViewById(R.id.btnNotchNext)
        btnNotchOpen = findViewById(R.id.btnNotchOpen)
        tvNotchCurrent = findViewById(R.id.tvNotchCurrent)
        sbNotch = findViewById(R.id.sbNotch)
        tvNotchTotal = findViewById(R.id.tvNotchTotal)
        tvVideoColorStatus = findViewById(R.id.tvVideoColorStatus)
        btnChangeVideoColor = findViewById(R.id.btnChangeVideoColor)
        tvWideColorStatus = findViewById(R.id.tvWideColorStatus)
        btnToggleWideColor = findViewById(R.id.btnToggleWideColor)
        tvDeblockingStatus = findViewById(R.id.tvDeblockingStatus)
        btnToggleDeblocking = findViewById(R.id.btnToggleDeblocking)
        tvHwDecodeStatus = findViewById(R.id.tvHwDecodeStatus)
        btnChangeHw = findViewById(R.id.btnChangeHw)
        tvBgPipStatus = findViewById(R.id.tvBgPipStatus)
        btnChangeBgPip = findViewById(R.id.btnChangeBgPip)
        tvResumeModeStatus = findViewById(R.id.tvResumeModeStatus)
        btnChangeResumeMode = findViewById(R.id.btnChangeResumeMode)
        tvDoubleTapStatus = findViewById(R.id.tvDoubleTapStatus)
        btnChangeDoubleTap = findViewById(R.id.btnChangeDoubleTap)
        tvAspectRatioStatus = findViewById(R.id.tvAspectRatioStatus)
        btnChangeAspectRatio = findViewById(R.id.btnChangeAspectRatio)
        tvAudioBoostStatus = findViewById(R.id.tvAudioBoostStatus)
        btnToggleAudioBoost = findViewById(R.id.btnToggleAudioBoost)

        // Audio Suite Settings
        tvMasterProfileStatus = findViewById(R.id.tvMasterProfileStatus)
        btnChangeMasterProfile = findViewById(R.id.btnChangeMasterProfile)
        tvDolbySurroundStatus = findViewById(R.id.tvDolbySurroundStatus)
        btnChangeDolbySurround = findViewById(R.id.btnChangeDolbySurround)
        tvEqualizerStatus = findViewById(R.id.tvEqualizerStatus)
        btnChangeEqualizer = findViewById(R.id.btnChangeEqualizer)
        tvDialogueBoostStatus = findViewById(R.id.tvDialogueBoostStatus)
        btnToggleDialogueBoost = findViewById(R.id.btnToggleDialogueBoost)
        tvDigitalPassthroughStatus = findViewById(R.id.tvDigitalPassthroughStatus)
        btnTogglePassthrough = findViewById(R.id.btnTogglePassthrough)
        tvAudioOutputStatus = findViewById(R.id.tvAudioOutputStatus)
        btnChangeAudioOutput = findViewById(R.id.btnChangeAudioOutput)
        tvHeadsetPauseStatus = findViewById(R.id.tvHeadsetPauseStatus)
        btnToggleHeadsetPause = findViewById(R.id.btnToggleHeadsetPause)
        tvTimeStretchStatus = findViewById(R.id.tvTimeStretchStatus)
        btnToggleTimeStretch = findViewById(R.id.btnToggleTimeStretch)

        // Subtitle Settings
        btnToggleSubAutoload = findViewById(R.id.btnToggleSubAutoload)
        tvSubSizeStatus = findViewById(R.id.tvSubSizeStatus)
        btnChangeSubSize = findViewById(R.id.btnChangeSubSize)
        tvSubColorStatus = findViewById(R.id.tvSubColorStatus)
        btnChangeSubColor = findViewById(R.id.btnChangeSubColor)
        tvSubBackgroundStatus = findViewById(R.id.tvSubBackgroundStatus)
        btnChangeSubBackground = findViewById(R.id.btnChangeSubBackground)
        tvSubStyleStatus = findViewById(R.id.tvSubStyleStatus)
        btnToggleSubStyle = findViewById(R.id.btnToggleSubStyle)
        tvSubEncodingStatus = findViewById(R.id.tvSubEncodingStatus)
        btnChangeSubEncoding = findViewById(R.id.btnChangeSubEncoding)

        // Gesture Settings
        tvGestureVolumeStatus = findViewById(R.id.tvGestureVolumeStatus)
        btnToggleGestureVolume = findViewById(R.id.btnToggleGestureVolume)
        tvGestureBrightnessStatus = findViewById(R.id.tvGestureBrightnessStatus)
        btnToggleGestureBrightness = findViewById(R.id.btnToggleGestureBrightness)
        tvGestureSeekStatus = findViewById(R.id.tvGestureSeekStatus)
        btnToggleGestureSeek = findViewById(R.id.btnToggleGestureSeek)
        tvFastSeekStatus = findViewById(R.id.tvFastSeekStatus)
        btnToggleFastSeek = findViewById(R.id.btnToggleFastSeek)

        // Interface Settings
        tvAppThemeStatus = findViewById(R.id.tvAppThemeStatus)
        btnChangeAppTheme = findViewById(R.id.btnChangeAppTheme)

        // Advanced Settings
        btnClearCache = findViewById(R.id.btnClearCache)
        btnClearResume = findViewById(R.id.btnClearResume)
        btnResetSettings = findViewById(R.id.btnResetSettings)
        tvCacheSizeStatus = findViewById(R.id.tvCacheSizeStatus)

        rvVideos.layoutManager = LinearLayoutManager(this)
        rvAudio.layoutManager = LinearLayoutManager(this)

        val openFileAction = {
            filePickerLauncher.launch(arrayOf("video/*", "audio/*"))
        }

        btnToolbarOpen.setOnClickListener { openFileAction() }
        btnBrowseVideo.setOnClickListener { openFileAction() }
        btnBrowseAudio.setOnClickListener { openFileAction() }

        // Dynamic App Version binding
        val vName = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "3.5" } catch (e: Exception) { "3.5" }
        findViewById<TextView>(R.id.badgeAppVersion)?.text = "v$vName"
        findViewById<TextView>(R.id.tvAppVersionCode)?.text = "Version $vName (Master Edition) • Developer: Rajesh Shah"
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterMedia(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterMedia(query: String) {
        val q = query.trim().lowercase()
        val filteredVideos = if (q.isEmpty()) allVideos else allVideos.filter { it.title.lowercase().contains(q) }
        val filteredAudio = if (q.isEmpty()) allAudio else allAudio.filter {
            it.title.lowercase().contains(q) || (it.artist?.lowercase()?.contains(q) == true)
        }

        videoAdapter?.updateList(filteredVideos)
        audioAdapter?.updateList(filteredAudio)

        if (isFolderViewActive) {
            val filteredFolders = if (q.isEmpty()) allFolders else allFolders.filter { folder ->
                folder.folderName.lowercase().contains(q) || folder.videos.any { it.title.lowercase().contains(q) }
            }
            folderAdapter?.updateFolders(filteredFolders)
        }

        if (!isFolderViewActive) {
            rvVideos.visibility = if (filteredVideos.isNotEmpty()) View.VISIBLE else View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = if (filteredVideos.isEmpty()) View.VISIBLE else View.GONE
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            layoutEmptyVideo.visibility = if (allFolders.isEmpty()) View.VISIBLE else View.GONE
        }

        rvAudio.visibility = if (filteredAudio.isNotEmpty()) View.VISIBLE else View.GONE
        layoutEmptyAudio.visibility = if (filteredAudio.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_video -> {
                    showTab(video = true, audio = false, youtube = false, settings = false)
                    switchVideoViewMode(folders = false)
                    true
                }
                R.id.nav_audio -> {
                    showTab(video = false, audio = true, youtube = false, settings = false)
                    true
                }
                R.id.nav_youtube -> {
                    showTab(video = false, audio = false, youtube = true, settings = false)
                    true
                }
                R.id.nav_more -> {
                    showTab(video = false, audio = false, youtube = false, settings = true)
                    true
                }
                else -> false
            }
        }
    }

        private fun showTab(video: Boolean, audio: Boolean, youtube: Boolean, settings: Boolean) {
        tabVideo.visibility = if (video) View.VISIBLE else View.GONE
        tabAudio.visibility = if (audio) View.VISIBLE else View.GONE
        tabYouTube.visibility = if (youtube) View.VISIBLE else View.GONE
        tabSettings.visibility = if (settings) View.VISIBLE else View.GONE

        if (youtube) {
            toolbar.visibility = View.GONE
            findViewById<View>(R.id.topBarContainer)?.visibility = View.GONE
            bottomNav.visibility = View.GONE
            fabPlay.visibility = View.GONE
            window.statusBarColor = Color.parseColor("#0F0F0F")

            if (!isYtFeedLoaded) {
                loadYouTubeFeed(currentYtCategory)
            }
        } else {
            lastActiveTabId = when {
                audio -> R.id.nav_audio
                settings -> R.id.nav_more
                else -> R.id.nav_video
            }

            toolbar.visibility = View.VISIBLE
            findViewById<View>(R.id.topBarContainer)?.visibility = View.VISIBLE
            bottomNav.visibility = View.VISIBLE
            fabPlay.visibility = View.VISIBLE
            window.statusBarColor = Color.parseColor("#000000")

            applyThemeUI()
        }
        updateNotchPlayerUI()
    }

    private fun initNativeYouTubeEngine() {
        rvYouTubeFeed.layoutManager = LinearLayoutManager(this)
        rvYouTubeFeedSecondary.layoutManager = LinearLayoutManager(this)
        rvYouTubeShorts.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        youTubeFeedAdapter = YouTubeFeedAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        rvYouTubeFeed.adapter = youTubeFeedAdapter

        youTubeFeedSecondaryAdapter = YouTubeFeedAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        rvYouTubeFeedSecondary.adapter = youTubeFeedSecondaryAdapter

        youTubeShortsAdapter = YouTubeShortsAdapter(this, YouTubeFeedRepository.defaultShorts) { shortVideo ->
            playYouTubeVideoInApp(shortVideo)
        }
        rvYouTubeShorts.adapter = youTubeShortsAdapter

        srlYouTubeFeed.setColorSchemeColors(Color.parseColor("#FF0000"))
        srlYouTubeFeed.setProgressBackgroundColorSchemeColor(Color.parseColor("#1A1A1A"))
        srlYouTubeFeed.setOnRefreshListener {
            loadYouTubeFeed(currentYtCategory)
        }

        btnYtRetry.setOnClickListener {
            loadYouTubeFeed(currentYtCategory)
        }

// btnYtExitToLocal click removed

        btnYtNavHome.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            nsvYtFeed.smoothScrollTo(0, 0)
        }

        btnYtNavShorts.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            Toast.makeText(this, "Loading YouTube Shorts...", Toast.LENGTH_SHORT).show()
            YouTubeFeedRepository.getShorts { shorts ->
                if (shorts.isNotEmpty()) {
                    playYouTubeVideoInApp(shorts[0])
                } else if (YouTubeFeedRepository.defaultShorts.isNotEmpty()) {
                    playYouTubeVideoInApp(YouTubeFeedRepository.defaultShorts[0])
                }
            }
        }

        btnYtNavSubs.setOnClickListener {
            Toast.makeText(this, "Subscriptions updated", Toast.LENGTH_SHORT).show()
        }

        btnYtNavLibrary.setOnClickListener {
            exitYouTubeToLocal()
        }

        btnYtCast.setOnClickListener {
            Toast.makeText(this, "Searching for Cast devices on local Wi-Fi...", Toast.LENGTH_SHORT).show()
        }

        btnYtNotifications.setOnClickListener {
            Toast.makeText(this, "No new notifications", Toast.LENGTH_SHORT).show()
        }

        btnYtAccount.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        btnYtSearch.setOnClickListener {
            if (layoutYtSearchBar.visibility == View.VISIBLE) {
                layoutYtSearchBar.visibility = View.GONE
            } else {
                layoutYtSearchBar.visibility = View.VISIBLE
                etYtSearchQuery.requestFocus()
            }
        }

        btnYtCloseSearch.setOnClickListener {
            layoutYtSearchBar.visibility = View.GONE
            etYtSearchQuery.text?.clear()
            loadYouTubeFeed(currentYtCategory)
        }

        etYtSearchQuery.setOnEditorActionListener { _, _, _ ->
            val query = etYtSearchQuery.text.toString().trim()
            if (query.isNotEmpty()) {
                performYouTubeSearch(query)
            }
            true
        }

        val chips = listOf(
            chipYtAll to "All",
            chipYtMusic to "Music",
            chipYtGaming to "Gaming",
            chipYtPodcasts to "Podcasts",
            chipYtLive to "Live",
            chipYtTrending to "Trending",
            chipYtNews to "News"
        )

        for ((chipView, cat) in chips) {
            chipView.setOnClickListener {
                for ((c, _) in chips) {
                    c.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                    c.setTextColor(Color.parseColor("#FFFFFF"))
                    c.setTypeface(null, android.graphics.Typeface.NORMAL)
                }
                chipView.setBackgroundResource(R.drawable.bg_youtube_chip_active)
                chipView.setTextColor(Color.parseColor("#000000"))
                chipView.setTypeface(null, android.graphics.Typeface.BOLD)

                currentYtCategory = cat
                loadYouTubeFeed(cat)
            }
        }

        setupYouTubeDetailPlayer()
        setupYouTubeMiniPlayer()

        findViewById<View>(R.id.btnYtPlayerSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.btnYtYouSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.rowYtReturnToLocal)?.setOnClickListener {
            exitYouTubeToLocal()
        }

        findViewById<View>(R.id.btnYtYouNavHome)?.setOnClickListener {
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
        }

        btnYtNavLibrary.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.VISIBLE
            updateYouTabUI()
        }

        rvYtHistory = findViewById(R.id.rvYtHistory)
        rvYtHistory.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        ytHistoryAdapter = YouTubeHistoryAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        rvYtHistory.adapter = ytHistoryAdapter

        rvYtDownloads = findViewById(R.id.rvYtDownloads)
        rvYtDownloads.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        ytDownloadsAdapter = YouTubeHistoryAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        rvYtDownloads.adapter = ytDownloadsAdapter

        findViewById<View>(R.id.cardYtPremiumBenefits)?.setOnClickListener { showYouTubePremiumBenefitsDialog() }
        findViewById<View>(R.id.cardYtYouAccount)?.setOnClickListener {
            val options = arrayOf(
                "✏️ Edit Profile Name & Handle",
                "🛡️ View YouTube Premium Benefits",
                "⚙️ YouTube Stream & Quality Settings",
                "🗑️ Clear Watch History",
                "🔑 MicroG Google Account Sign-In"
            )
            AlertDialog.Builder(this)
                .setTitle("Account & Profile Options")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> showEditProfileDialog()
                        1 -> showYouTubePremiumBenefitsDialog()
                        2 -> showYouTubeDedicatedSettingsDialog()
                        3 -> {
                            YouTubeHistoryManager.clearHistory(this)
                            updateYouTabUI()
                            Toast.makeText(this, "Watch history cleared", Toast.LENGTH_SHORT).show()
                        }
                        4 -> showYouTubeDedicatedSettingsDialog()
                    }
                }
                .setNegativeButton("Close", null)
                .show()
        }
        findViewById<View>(R.id.rowYtReturnToLocal)?.setOnClickListener {
            exitYouTubeToLocal()
        }
        updateYouTabUI()
        updateMicroGAccountState()
    }

    private fun setupYouTubeDetailPlayer() {
        rvYtRelatedVideos.layoutManager = LinearLayoutManager(this)
        rvYtRelatedVideos.adapter = youTubeFeedSecondaryAdapter

        pbYtBottomMiniProgress = findViewById(R.id.pbYtBottomMiniProgress)
        layoutYtPlayerOverlay = findViewById(R.id.layoutYtPlayerOverlay)
        btnYtAutoplay = findViewById(R.id.btnYtAutoplay)
        btnYtAudioMode = findViewById(R.id.btnYtAudioMode)
        layoutYtAudioModeVisual = findViewById(R.id.layoutYtAudioModeVisual)
        ivYtAudioModeThumb = findViewById(R.id.ivYtAudioModeThumb)

        btnYtAudioMode.setOnClickListener {
            val isNowAudioOnly = YouTubeExoPlayerManager.toggleAudioVideoMode(this)
            updateAudioModeUI(isNowAudioOnly)
            if (isNowAudioOnly) {
                Toast.makeText(this, "🎧 Audio Mode: Video streaming stopped (Data Saver Active)", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "🎬 Video Mode: Resuming video stream", Toast.LENGTH_SHORT).show()
            }
        }
        btnYtPlayerCast = findViewById(R.id.btnYtPlayerCast)
        btnYtPlayerCC = findViewById(R.id.btnYtPlayerCC)
        btnYtRewind10 = findViewById(R.id.btnYtRewind10)
        btnYtForward10 = findViewById(R.id.btnYtForward10)
        tvYtPlayerCurrentTime = findViewById(R.id.tvYtPlayerCurrentTime)
        sbYtPlayer = findViewById(R.id.sbYtPlayer)

        btnYtCollapsePlayer.setOnClickListener {
            handleBackPress()
        }

        playerViewYt.setOnClickListener {
            if (layoutYtPlayerOverlay.visibility == View.VISIBLE) {
                hideYouTubeOverlay()
            } else {
                showYouTubeOverlay()
            }
        }

        layoutYtPlayerOverlay.setOnClickListener {
            hideYouTubeOverlay()
        }

        btnYtRewind10.setOnClickListener {
            val cur = YouTubeExoPlayerManager.getCurrentPosition()
            YouTubeExoPlayerManager.seekTo((cur - 10000).coerceAtLeast(0))
            showYouTubeOverlay()
        }

        btnYtForward10.setOnClickListener {
            val cur = YouTubeExoPlayerManager.getCurrentPosition()
            val dur = YouTubeExoPlayerManager.getDuration()
            YouTubeExoPlayerManager.seekTo((cur + 10000).coerceAtMost(dur))
            showYouTubeOverlay()
        }

        btnYtAutoplay.setOnClickListener {
            isYtAutoplayEnabled = !isYtAutoplayEnabled
            btnYtAutoplay.setColorFilter(if (isYtAutoplayEnabled) Color.parseColor("#3EA6FF") else Color.WHITE)
            Toast.makeText(this, if (isYtAutoplayEnabled) "Autoplay is on" else "Autoplay is off", Toast.LENGTH_SHORT).show()
            showYouTubeOverlay()
        }

        btnYtPlayerCast.setOnClickListener {
            Toast.makeText(this, "Searching for Cast devices...", Toast.LENGTH_SHORT).show()
            showYouTubeOverlay()
        }

        btnYtPlayerCC.setOnClickListener {
            Toast.makeText(this, "Captions / Subtitles: Auto", Toast.LENGTH_SHORT).show()
            showYouTubeOverlay()
        }

        sbYtPlayer.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    isYtUserSeeking = true
                    val dur = YouTubeExoPlayerManager.getDuration()
                    tvYtPlayerCurrentTime.text = "${formatTime(progress.toLong())} / ${formatTime(dur)}"
                    showYouTubeOverlay()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isYtUserSeeking = true
                ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isYtUserSeeking = false
                seekBar?.let {
                    YouTubeExoPlayerManager.seekTo(it.progress.toLong())
                }
                showYouTubeOverlay()
            }
        })

        btnYtFullscreen.setOnClickListener {
            toggleYouTubeFullscreen()
        }

        btnYtSubscribe.setOnClickListener {
            if (btnYtSubscribe.text == "Subscribe") {
                btnYtSubscribe.text = "Subscribed"
                btnYtSubscribe.setBackgroundColor(Color.parseColor("#272727"))
                btnYtSubscribe.setTextColor(Color.WHITE)
                Toast.makeText(this, "Subscribed to channel", Toast.LENGTH_SHORT).show()
            } else {
                btnYtSubscribe.text = "Subscribe"
                btnYtSubscribe.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
                btnYtSubscribe.setTextColor(Color.BLACK)
                Toast.makeText(this, "Unsubscribed", Toast.LENGTH_SHORT).show()
            }
        }

        layoutYtLikePill.setOnClickListener {
            Toast.makeText(this, "Added to Liked Videos", Toast.LENGTH_SHORT).show()
        }

        layoutYtSharePill.setOnClickListener {
            val v = currentPlayingYtVideo ?: return@setOnClickListener
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, v.title)
                putExtra(Intent.EXTRA_TEXT, "Watch '${v.title}' on YouTube: https://youtu.be/${v.id}")
            }
            startActivity(Intent.createChooser(intent, "Share Video"))
        }

        layoutYtDownloadPill.setOnClickListener {
            currentPlayingYtVideo?.let { v ->
                YouTubeDownloaderHelper.showDownloadDialog(this, v)
            }
        }

        val openAudioQualityDialog = {
            val audioQualities = arrayOf(
                "Auto (Adaptive - Recommended)",
                "High Quality (160 kbps Opus - Studio Audio)",
                "Normal Quality (128 kbps M4A - Clear & Balanced)",
                "Data Saver (64 kbps - Ultra-Low Data)"
            )
            val curAudio = ytPrefs.getString("pref_yt_audio_quality", "Auto (Adaptive - Recommended)") ?: "Auto (Adaptive - Recommended)"
            val curIdx = audioQualities.indexOfFirst { it.startsWith(curAudio.substringBefore(" ")) }.coerceAtLeast(0)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Audio Streaming Quality")
                .setSingleChoiceItems(audioQualities, curIdx) { dialog, which ->
                    val selected = audioQualities[which]
                    ytPrefs.edit().putString("pref_yt_audio_quality", selected).apply()
                    updateSettingsUI()
                    val label = selected.substringBefore(" -")
                    Toast.makeText(this, "Audio quality set to: " + label, Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeYtAudioQuality.setOnClickListener { openAudioQualityDialog() }
        findViewById<View>(R.id.rowYtAudioQuality).setOnClickListener { openAudioQualityDialog() }

        layoutYtSavePill.setOnClickListener {
            currentPlayingYtVideo?.let { v ->
                val saved = YouTubeHistoryManager.toggleBookmark(this, v)
                Toast.makeText(this, if (saved) "Saved to Library" else "Removed from Library", Toast.LENGTH_SHORT).show()
            }
        }

        layoutYtCommentsCard.setOnClickListener {
            Toast.makeText(this, "Comments: 234 community replies", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupYouTubeMiniPlayer() {

        findViewById<View>(R.id.btnYtPlayerSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.btnYtYouSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.rowYtReturnToLocal)?.setOnClickListener {
            exitYouTubeToLocal()
        }

        findViewById<View>(R.id.btnYtYouNavHome)?.setOnClickListener {
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
        }

        btnYtNavLibrary.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.VISIBLE
        }
        cardYtMiniPlayer.setOnClickListener {
            cardYtMiniPlayer.visibility = View.GONE
            layoutYtPlayerDetail.visibility = View.VISIBLE
            YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        }

        btnYtMiniClose.setOnClickListener {
            YouTubeExoPlayerManager.pause()
            cardYtMiniPlayer.visibility = View.GONE
            currentPlayingYtVideo = null
            isYtVideoPlaying = false
        }

        btnYtMiniPlayPause.setOnClickListener {
            YouTubeExoPlayerManager.togglePlayPause()
        }
    }

    private fun collapseYouTubePlayer() {
        hideYouTubeOverlay()
        layoutYtPlayerDetail.visibility = View.GONE
        findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
        findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE

        val video = currentPlayingYtVideo
        if (video != null) {
            cardYtMiniPlayer.visibility = View.VISIBLE
            tvYtMiniTitle.text = video.title
            tvYtMiniChannel.text = video.channelTitle
            ImageLoaderHelper.loadImage(video.thumbnailUrl, ivYtMiniThumb, R.drawable.ic_video)
            btnYtMiniPlayPause.setImageResource(if (YouTubeExoPlayerManager.exoPlayer?.isPlaying == true) R.drawable.ic_pause_player else R.drawable.ic_play_player)
        } else {
            cardYtMiniPlayer.visibility = View.GONE
        }
    }

    private fun exitYouTubeToLocal() {
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            layoutYtPlayerDetail.visibility = View.GONE
        }
        if (cardYtMiniPlayer.visibility == View.VISIBLE) {
            cardYtMiniPlayer.visibility = View.GONE
        }
        YouTubeExoPlayerManager.pause()
        currentPlayingYtVideo = null
        isYtVideoPlaying = false
        showTab(video = true, audio = false, youtube = false, settings = false)
        bottomNav.selectedItemId = R.id.nav_video
    }

    private fun playYouTubeVideoInApp(video: YouTubeVideo) {
        currentPlayingYtVideo = video
        isYtVideoPlaying = true
        YouTubeHistoryManager.addWatchHistory(this, video)

        // Populate video details using verified declared properties
        tvYtDetailTitle.text = video.title
        tvYtDetailSubtitle.text = "${video.views} • ${video.uploadDate}"
        tvYtDetailChannel.text = video.channelTitle
        ImageLoaderHelper.loadImage(video.channelAvatarUrl, ivYtDetailAvatar, R.drawable.ic_account_circle)
        tvYtDetailLikes.text = video.likes
        tvYtDetailCommentsCount.text = video.commentsCount

        // Populate related recommendations in portrait feed below player
        val feedItems = youTubeFeedAdapter.getItems()
        val related = if (feedItems.isNotEmpty()) {
            feedItems.filter { it.id != video.id }
        } else {
            YouTubeFeedRepository.defaultFeed.filter { it.id != video.id }
        }
        youTubeFeedSecondaryAdapter.updateItems(related)

        cardYtMiniPlayer.visibility = View.GONE
        layoutYtPlayerDetail.visibility = View.VISIBLE
        pbYtBuffering.visibility = View.VISIBLE
        btnYtCenterPlayPause.visibility = View.GONE
        tvYtDownloadPill.text = "Download"
        ivYtDownloadPill.setImageResource(R.drawable.ic_download)
        ivYtDownloadPill.setColorFilter(Color.WHITE)
        YouTubeExoPlayerManager.attachPlayerView(playerViewYt)

        // Resolve pure, untracked streams via official TeamNewPipe NewPipeExtractor
        val targetRes = when (PlayerHolder.currentVideoQuality) {
            "1080p", "1080p Full HD" -> 1080
            "720p", "720p HD" -> 720
            "480p", "480p SD" -> 480
            "360p", "360p Data Saver" -> 360
            else -> 720 // Default Auto to 720p (Adaptive Data Saver)
        }
        YouTubeStreamResolver.resolveStreams(video.id, targetRes) { resolvedStream ->
            pbYtBuffering.visibility = View.GONE
            if (resolvedStream != null && resolvedStream.videoUrl.isNotBlank()) {
                YouTubeFeedRepository.currentAvailableFormats = resolvedStream.availableQualities.map { opt ->
                    VideoStreamFormat(opt.qualityLabel, opt.resolution, opt.videoUrl, opt.audioUrl)
                }
                YouTubeExoPlayerManager.playVideo(
                    context = this,
                    video = video,
                    videoStreamUrl = resolvedStream.videoUrl,
                    audioStreamUrl = resolvedStream.audioUrl,
                    pureAudioUrl = resolvedStream.pureAudioUrl,
                    allAudioUrls = resolvedStream.allAudioUrls,
                    startInAudioOnly = YouTubeExoPlayerManager.isAudioOnlyMode
                )
                updateAudioModeUI(YouTubeExoPlayerManager.isAudioOnlyMode)
                btnYtCenterPlayPause.visibility = View.VISIBLE
                updateNotchPlayerUI()
            } else {
                btnYtCenterPlayPause.visibility = View.VISIBLE
                Toast.makeText(
                    this,
                    "Playback error: Unable to load video. Please check internet connection.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun updateMicroGAccountState() {
        if (MicroGAuthManager.isLoggedIn(this)) {
            btnYtAccount.setColorFilter(Color.parseColor("#4CAF50"))
        } else {
            btnYtAccount.clearColorFilter()
        }
    }

    private fun loadYouTubeFeed(category: String) {
        pbYtFeedLoading.visibility = View.VISIBLE
        layoutYtEmpty.visibility = View.GONE
        YouTubeFeedRepository.getFeed(category) { videos ->
            pbYtFeedLoading.visibility = View.GONE
            srlYouTubeFeed.isRefreshing = false
            isYtFeedLoaded = true

            if (videos.isEmpty()) {
                layoutYtEmpty.visibility = View.VISIBLE
            } else {
                layoutYtEmpty.visibility = View.GONE
                val topFeed = if (videos.size > 2) videos.subList(0, 2) else videos
                val secondaryFeed = if (videos.size > 2) videos.subList(2, videos.size) else emptyList()
                youTubeFeedAdapter.updateItems(topFeed)
                youTubeFeedSecondaryAdapter.updateItems(secondaryFeed)
            }
        }

        YouTubeFeedRepository.getShorts { shorts ->
            if (shorts.isNotEmpty()) {
                youTubeShortsAdapter.updateItems(shorts)
            }
        }
    }

    private fun performYouTubeSearch(query: String) {
        pbYtFeedLoading.visibility = View.VISIBLE
        layoutYtEmpty.visibility = View.GONE
        YouTubeFeedRepository.searchVideos(query) { videos ->
            pbYtFeedLoading.visibility = View.GONE
            if (videos.isEmpty()) {
                layoutYtEmpty.visibility = View.VISIBLE
            } else {
                layoutYtEmpty.visibility = View.GONE
                youTubeFeedAdapter.updateItems(videos)
                youTubeFeedSecondaryAdapter.updateItems(emptyList())
            }
        }
    }


    private fun enableImmersiveNotchMode() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.let { controller ->
                    controller.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            }
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun toggleYouTubeFullscreen() {
        isYtFullscreen = !isYtFullscreen
        val surfaceContainer = findViewById<View>(R.id.layoutYtPlayerSurfaceContainer)
        val detailsScroll = layoutYtPlayerDetail.let { detail ->
            (detail as? android.view.ViewGroup)?.getChildAt(1)
        }

        if (isYtFullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            detailsScroll?.visibility = View.GONE
            val lp = surfaceContainer?.layoutParams
            if (lp != null) {
                lp.height = FrameLayout.LayoutParams.MATCH_PARENT
                surfaceContainer.layoutParams = lp
            }
            btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen)
            enableImmersiveNotchMode()
            showYouTubeOverlay()
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            detailsScroll?.visibility = View.VISIBLE
            val lp = surfaceContainer?.layoutParams
            if (lp != null) {
                lp.height = (230 * resources.displayMetrics.density).toInt()
                surfaceContainer.layoutParams = lp
            }
            btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen)
            window.statusBarColor = Color.parseColor("#0F0F0F")
            showYouTubeOverlay()
        }
    }

    private fun updateYouTabUI() {
        val historyList = YouTubeHistoryManager.getWatchHistory(this)
        ytHistoryAdapter?.updateItems(historyList)
        findViewById<View>(R.id.rvYtHistory)?.visibility = if (historyList.isNotEmpty()) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnYtViewAllHistory)?.visibility = if (historyList.isNotEmpty()) View.VISIBLE else View.GONE

        val bookmarks = YouTubeHistoryManager.getBookmarks(this)
        ytDownloadsAdapter?.updateItems(bookmarks)
        findViewById<View>(R.id.rvYtDownloads)?.visibility = if (bookmarks.isNotEmpty()) View.VISIBLE else View.GONE

        // Profile matching screenshot 6217.jpg & YouTube Premium (Customizable per device)
        val tvName = findViewById<TextView>(R.id.tvYtYouName)
        val tvStatus = findViewById<TextView>(R.id.tvYtYouStatus)
        val profPrefs = getSharedPreferences("yt_profile_prefs", Context.MODE_PRIVATE)
        val defaultName = profPrefs.getString("profile_name", "Rajesh Shah") ?: "Rajesh Shah"
        val defaultHandle = profPrefs.getString("profile_handle", "@Rps11") ?: "@Rps11"

        if (MicroGAuthManager.isLoggedIn(this)) {
            tvName?.text = MicroGAuthManager.getAccountName(this)
            tvStatus?.text = "${MicroGAuthManager.getAccountEmail(this)} • Premium member"
        } else {
            tvName?.text = defaultName
            tvStatus?.text = "$defaultHandle • Premium member"
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (tabYouTube.visibility == View.VISIBLE &&
            (layoutYtPlayerDetail.visibility == View.VISIBLE || cardYtMiniPlayer.visibility == View.VISIBLE) &&
            YouTubeExoPlayerManager.isPlaying()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    val aspectRatio = Rational(16, 9)
                    val params = PictureInPictureParams.Builder()
                        .setAspectRatio(aspectRatio)
                        .build()
                    enterPictureInPictureMode(params)
                } catch (e: Exception) {}
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        val surface = findViewById<View>(R.id.layoutYtPlayerSurfaceContainer)
        if (isInPictureInPictureMode) {
            btnYtCenterPlayPause.visibility = View.GONE
            btnYtCollapsePlayer.visibility = View.GONE
            btnYtFullscreen.visibility = View.GONE
            pbYtBuffering.visibility = View.GONE
            layoutYtPlayerDetail.let { detail ->
                (detail as? android.view.ViewGroup)?.getChildAt(1)?.visibility = View.GONE
            }
            findViewById<View>(R.id.layoutYtHeader)?.visibility = View.GONE
            findViewById<View>(R.id.bottomNav)?.visibility = View.GONE
            val lp = surface?.layoutParams
            if (lp != null) {
                lp.height = FrameLayout.LayoutParams.MATCH_PARENT
                surface.layoutParams = lp
            }
        } else {
            if (tabYouTube.visibility == View.VISIBLE) {
                layoutYtPlayerDetail.let { detail ->
                    (detail as? android.view.ViewGroup)?.getChildAt(1)?.visibility = View.VISIBLE
                }
                findViewById<View>(R.id.layoutYtHeader)?.visibility = View.VISIBLE
                findViewById<View>(R.id.bottomNav)?.visibility = View.VISIBLE
                val lp = surface?.layoutParams
                if (lp != null && !isYtFullscreen) {
                    lp.height = (230 * resources.displayMetrics.density).toInt()
                    surface.layoutParams = lp
                }
            }
        }
    }

    
    private fun showEditProfileDialog() {
        val profPrefs = getSharedPreferences("yt_profile_prefs", Context.MODE_PRIVATE)
        val currentName = profPrefs.getString("profile_name", "Rajesh Shah") ?: "Rajesh Shah"
        val currentHandle = profPrefs.getString("profile_handle", "@Rps11") ?: "@Rps11"

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 40, 60, 20)
        }

        val etName = EditText(this).apply {
            hint = "Display Name (e.g. Rajesh Shah)"
            setText(currentName)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }

        val etHandle = EditText(this).apply {
            hint = "Channel Handle (e.g. @Rps11)"
            setText(currentHandle)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 30 }
        }

        container.addView(etName)
        container.addView(etHandle)

        AlertDialog.Builder(this)
            .setTitle("Edit YouTube Profile")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                val newName = etName.text.toString().trim().ifBlank { "Rajesh Shah" }
                val newHandle = etHandle.text.toString().trim().ifBlank { "@Rps11" }
                profPrefs.edit()
                    .putString("profile_name", newName)
                    .putString("profile_handle", if (newHandle.startsWith("@")) newHandle else "@$newHandle")
                    .apply()
                updateYouTabUI()
                Toast.makeText(this, "Profile updated: $newName", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    
    private fun showYouTubeOverlay() {
        ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
        if (layoutYtPlayerOverlay.visibility != View.VISIBLE) {
            layoutYtPlayerOverlay.alpha = 0f
            layoutYtPlayerOverlay.visibility = View.VISIBLE
            layoutYtPlayerOverlay.animate()
                .alpha(1f)
                .setDuration(180)
                .start()
        }
        if (YouTubeExoPlayerManager.isPlaying()) {
            ytOverlayHandler.postDelayed(ytOverlayHideRunnable, 3000)
        }
    }

    private fun hideYouTubeOverlay() {
        ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
        layoutYtPlayerOverlay.visibility = View.GONE
    }

    private fun handleBackPress(): Boolean {
        if (tabYouTube.visibility == View.VISIBLE) {
            if (isYtFullscreen) {
                toggleYouTubeFullscreen()
                return true
            }
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
                return true
            }
            if (findViewById<View>(R.id.layoutYtYouContainer)?.visibility == View.VISIBLE) {
                findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
                findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
                return true
            }
            if (cardYtMiniPlayer.visibility == View.VISIBLE) {
                YouTubeExoPlayerManager.pause()
                cardYtMiniPlayer.visibility = View.GONE
                currentPlayingYtVideo = null
                isYtVideoPlaying = false
                return true
            }
            if (layoutYtSearchBar.visibility == View.VISIBLE) {
                layoutYtSearchBar.visibility = View.GONE
                loadYouTubeFeed(currentYtCategory)
                return true
            }
            exitYouTubeToLocal()
            return true
        } else if (isFolderViewActive && currentSelectedFolder != null) {
            closeFolderDetail()
            return true
        }
        return false
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            if (handleBackPress()) return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (handleBackPress()) return
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    private fun showYouTubePremiumBenefitsDialog() {
        val benefits = arrayOf(
            "🛡️ Ad-Free Playback (Active - 0 Ads Encountered)",
            "🎧 Background Audio Playback (Screen Off / Minimized)",
            "📱 Picture-in-Picture Mode (Automatic Floating Window)",
            "⬇️ Smart Offline Downloads (High Quality Storage)",
            "⚡ 1080p Premium Enhanced Bitrate (Enabled)",
            "🎵 YouTube Music Ad-Free Streaming (Active)"
        )
        AlertDialog.Builder(this)
            .setTitle("YouTube Premium Benefits")
            .setItems(benefits) { _, _ -> }
            .setPositiveButton("Close", null)
            .setNeutralButton("Premium Settings") { _, _ ->
                showYouTubeDedicatedSettingsDialog()
            }
            .show()
    }

    private fun showYouTubeListeningControlsDialog() {
        val speeds = arrayOf("0.75x", "1.0x (Normal)", "1.25x", "1.5x", "2.0x")
        val speedValues = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val currentSpeed = YouTubeExoPlayerManager.exoPlayer?.playbackParameters?.speed ?: 1.0f

        val options = arrayOf(
            "⏪ Rewind 10 seconds",
            "⏩ Forward 10 seconds",
            "⚡ Speed: ${currentSpeed}x",
            "🎧 Background Play: Always Enabled (Premium)",
            "📱 Enter Picture-in-Picture Mode"
        )

        AlertDialog.Builder(this)
            .setTitle("🎧 YouTube Premium Listening Controls")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val p = (YouTubeExoPlayerManager.getCurrentPosition() - 10000).coerceAtLeast(0)
                        YouTubeExoPlayerManager.seekTo(p)
                        Toast.makeText(this, "Rewound 10s", Toast.LENGTH_SHORT).show()
                    }
                    1 -> {
                        val d = YouTubeExoPlayerManager.getDuration()
                        val p = (YouTubeExoPlayerManager.getCurrentPosition() + 10000).coerceAtMost(d)
                        YouTubeExoPlayerManager.seekTo(p)
                        Toast.makeText(this, "Forwarded 10s", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        AlertDialog.Builder(this)
                            .setTitle("Select Playback Speed")
                            .setItems(speeds) { _, sIdx ->
                                YouTubeExoPlayerManager.exoPlayer?.setPlaybackSpeed(speedValues[sIdx])
                                Toast.makeText(this, "Speed set to ${speeds[sIdx]}", Toast.LENGTH_SHORT).show()
                            }
                            .show()
                    }
                    3 -> {
                        Toast.makeText(this, "Background playback is active with screen locked", Toast.LENGTH_SHORT).show()
                    }
                    4 -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            try {
                                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
                            } catch (e: Exception) {}
                        }
                    }
                }
            }
            .setPositiveButton("Done", null)
            .show()
    }

    // --- 1. Video Settings Handlers ---
    private fun setupVideoSettings() {
        btnToggleHighRefreshRate.setOnClickListener {
            PlayerHolder.isHighRefreshRateEnabled = !PlayerHolder.isHighRefreshRateEnabled
            PlayerHolder.savePreferences(this)
            applyHighRefreshRate()
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHighRefreshRate).setOnClickListener {
            btnToggleHighRefreshRate.performClick()
        }

        val orientationOptions = arrayOf("Auto Sensor (Free Rotation)", "Direct Landscape (Recommended)", "Portrait (Vertical)")
        val openOrientationDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Default Video Orientation")
                .setSingleChoiceItems(orientationOptions, PlayerHolder.defaultOrientation) { dialog, which ->
                    PlayerHolder.defaultOrientation = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeOrientation.setOnClickListener { openOrientationDialog() }
        findViewById<View>(R.id.rowDefaultOrientation).setOnClickListener { openOrientationDialog() }
        val openVideoColorDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Picture Mode & Color Boost")
                .setSingleChoiceItems(PlayerHolder.videoProfileNames, PlayerHolder.videoColorProfile.coerceIn(0, 4)) { dialog, which ->
                    PlayerHolder.applyVideoColorProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeVideoColor.setOnClickListener { openVideoColorDialog() }
        findViewById<View>(R.id.rowVideoColor).setOnClickListener { openVideoColorDialog() }

        btnToggleWideColor.setOnClickListener {
            PlayerHolder.isWideColorGamutEnabled = !PlayerHolder.isWideColorGamutEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowWideColor).setOnClickListener {
            btnToggleWideColor.performClick()
        }

        btnToggleDeblocking.setOnClickListener {
            PlayerHolder.isDeblockingFilterEnabled = !PlayerHolder.isDeblockingFilterEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDeblocking).setOnClickListener {
            btnToggleDeblocking.performClick()
        }
        val hwOptions = arrayOf("Disabled (Software)", "Automatic (Recommended)", "Decoding Only", "Full Acceleration")
        val openHwDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_hw_decoding)
                .setSingleChoiceItems(hwOptions, PlayerHolder.hwAccelerationMode) { dialog, which ->
                    PlayerHolder.hwAccelerationMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeHw.setOnClickListener { openHwDialog() }
        findViewById<View>(R.id.rowHwDecode).setOnClickListener { openHwDialog() }

        val bgPipOptions = arrayOf("Stop Playback", "Play in Background", "Picture-in-Picture (PiP)")
        val openBgPipDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_bg_pip)
                .setSingleChoiceItems(bgPipOptions, PlayerHolder.backgroundPipMode) { dialog, which ->
                    PlayerHolder.backgroundPipMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeBgPip.setOnClickListener { openBgPipDialog() }
        findViewById<View>(R.id.rowBgPip).setOnClickListener { openBgPipDialog() }

        val resumeOptions = arrayOf("Never (Always start from beginning)", "Ask confirmation on open", "Always resume automatically")
        val openResumeDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_resume)
                .setSingleChoiceItems(resumeOptions, PlayerHolder.resumeMode) { dialog, which ->
                    PlayerHolder.resumeMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeResumeMode.setOnClickListener { openResumeDialog() }
        findViewById<View>(R.id.rowResumeMode).setOnClickListener { openResumeDialog() }

        val seekOptions = arrayOf("5 seconds", "10 seconds", "20 seconds", "30 seconds")
        val seekValues = arrayOf(5, 10, 20, 30)
        val openSeekDialog = {
            val currentIdx = seekValues.indexOf(PlayerHolder.doubleTapSeekSeconds).coerceAtLeast(1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_double_tap)
                .setSingleChoiceItems(seekOptions, currentIdx) { dialog, which ->
                    PlayerHolder.doubleTapSeekSeconds = seekValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDoubleTap.setOnClickListener { openSeekDialog() }
        findViewById<View>(R.id.rowDoubleTap).setOnClickListener { openSeekDialog() }

        val aspectOptions = arrayOf("Best Fit (Default)", "Fit Screen", "Fill Screen", "16:9 Aspect Ratio", "4:3 Aspect Ratio")
        val openAspectDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_aspect_ratio)
                .setSingleChoiceItems(aspectOptions, PlayerHolder.defaultAspectRatio) { dialog, which ->
                    PlayerHolder.defaultAspectRatio = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAspectRatio.setOnClickListener { openAspectDialog() }
        findViewById<View>(R.id.rowAspectRatio).setOnClickListener { openAspectDialog() }

        btnToggleAudioBoost.setOnClickListener {
            PlayerHolder.isAudioBoostEnabled = !PlayerHolder.isAudioBoostEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowAudioBoost).setOnClickListener {
            btnToggleAudioBoost.performClick()
        }
    }

    // --- 2. Integrated Dolby, Spatial & Equalizer Audio Suite Handlers ---
    private fun setupAudioSuiteSettings() {
        // Master Profile Dialog
        val openMasterProfileDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Select Audio Profile")
                .setSingleChoiceItems(PlayerHolder.masterProfileNames, PlayerHolder.masterAudioProfile) { dialog, which ->
                    PlayerHolder.applyMasterProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeMasterProfile.setOnClickListener { openMasterProfileDialog() }
        findViewById<View>(R.id.rowMasterProfile).setOnClickListener { openMasterProfileDialog() }

        // Dolby & Spatial Virtualizer Mode
        val modes = arrayOf("Standard Stereo (Downmix)", "Dolby 3D Headphone (Binaural HRTF)", "Dolby ProLogic Surround (Matrix)", "Cinema 3D Soundstage (Wide Room)")
        val openDolbyDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_dolby_surround)
                .setSingleChoiceItems(modes, PlayerHolder.dolbySpatialMode) { dialog, which ->
                    PlayerHolder.dolbySpatialMode = which
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDolbySurround.setOnClickListener { openDolbyDialog() }
        findViewById<View>(R.id.rowDolbySurround).setOnClickListener { openDolbyDialog() }

        // 10-Band Equalizer Presets
        val openEqDialog = {
            val presets = PlayerHolder.equalizerPresets
            val currentIdx = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_equalizer)
                .setSingleChoiceItems(presets, currentIdx) { dialog, which ->
                    PlayerHolder.currentEqualizerPreset = which - 1
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeEqualizer.setOnClickListener { openEqDialog() }
        findViewById<View>(R.id.rowEqualizer).setOnClickListener { openEqDialog() }

        // Dialogue Boost (Night Mode) Toggle
        btnToggleDialogueBoost.setOnClickListener {
            PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
            PlayerHolder.masterAudioProfile = 4 // Custom
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDialogueBoost).setOnClickListener {
            btnToggleDialogueBoost.performClick()
        }

        // Digital Passthrough Toggle
        btnTogglePassthrough.setOnClickListener {
            PlayerHolder.isDolbyPassthroughEnabled = !PlayerHolder.isDolbyPassthroughEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDigitalPassthrough).setOnClickListener {
            btnTogglePassthrough.performClick()
        }

        // Audio Output Engine Dialog
        val engines = arrayOf("AudioTrack (Standard)", "OpenSL ES (Low Latency)", "AAudio (Modern NDK)")
        val openEngineDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_audio_output)
                .setSingleChoiceItems(engines, PlayerHolder.audioOutputEngine) { dialog, which ->
                    PlayerHolder.audioOutputEngine = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAudioOutput.setOnClickListener { openEngineDialog() }
        findViewById<View>(R.id.rowAudioOutput).setOnClickListener { openEngineDialog() }

        btnToggleHeadsetPause.setOnClickListener {
            PlayerHolder.isHeadsetPauseEnabled = !PlayerHolder.isHeadsetPauseEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHeadsetPause).setOnClickListener {
            btnToggleHeadsetPause.performClick()
        }

        btnToggleTimeStretch.setOnClickListener {
            PlayerHolder.isTimeStretchingEnabled = !PlayerHolder.isTimeStretchingEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowTimeStretching).setOnClickListener {
            btnToggleTimeStretch.performClick()
        }
    }

    // --- 3. Subtitle Settings Handlers ---
    
    private fun showSubtitleSettings() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_subtitle_settings, null)
        dialog.setContentView(view)

        val isMono = PlayerHolder.isMonochrome()
        val accentColor = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        val accentTintList = ColorStateList.valueOf(accentColor)

        view.findViewById<TextView>(R.id.tvSubHeaderTitle)?.setTextColor(accentColor)
        view.findViewById<View>(R.id.btnSubBack).setOnClickListener { dialog.dismiss() }
        view.findViewById<View>(R.id.btnSubSearch)?.setOnClickListener { dialog.dismiss() }

        val subHeaders = listOf(
            R.id.tvHeaderFontStyle,
            R.id.tvHeaderBg,
            R.id.tvHeaderShadow,
            R.id.tvHeaderOutline,
            R.id.tvHeaderPos
        )
        for (hId in subHeaders) {
            view.findViewById<TextView>(hId)?.setTextColor(accentColor)
        }

        val checkBoxes = listOf(
            R.id.cbSubAutoLoad,
            R.id.cbSubBold,
            R.id.cbSubBgToggle,
            R.id.cbSubShadowToggle,
            R.id.cbSubOutlineToggle
        )
        for (cbId in checkBoxes) {
            view.findViewById<CheckBox>(cbId)?.buttonTintList = accentTintList
        }

        val seekBars = listOf(
            R.id.sbSubFontOpacity,
            R.id.sbSubBgOpacity,
            R.id.sbSubShadowOpacity,
            R.id.sbSubOutlineOpacity
        )
        for (sbId in seekBars) {
            view.findViewById<SeekBar>(sbId)?.apply {
                progressTintList = accentTintList
                thumbTintList = accentTintList
            }
        }

        // Presets
        view.findViewById<View>(R.id.rowSubPresets).setOnClickListener {
            val presets = arrayOf("Default (White + Shadow)", "Cinema (Yellow + Outline)", "High Contrast (Black Box)", "Clean Minimal")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles presets")
                .setItems(presets) { _, which ->
                    when (which) {
                        0 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBold = false
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = true
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        1 -> {
                            PlayerHolder.subFontColor = "16772155"
                            PlayerHolder.isSubBold = true
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        2 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = true
                            PlayerHolder.subBackgroundOpacity = 75
                        }
                        3 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = false
                            PlayerHolder.isSubOutlineEnabled = false
                        }
                    }
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                    showSubtitleSettings()
                }
                .show()
        }

        // Auto load subtitles
        val cbAutoLoad = view.findViewById<CheckBox>(R.id.cbSubAutoLoad)
        cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
        view.findViewById<View>(R.id.rowSubAutoLoad).setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }

        // Subtitle text encoding
        val tvEncoding = view.findViewById<TextView>(R.id.tvSubEncodingSub)
        tvEncoding.text = "Default (" + PlayerHolder.subEncoding + ")"
        view.findViewById<View>(R.id.rowSubEncoding).setOnClickListener {
            val encodings = arrayOf("UTF-8", "Windows-1252", "ISO-8859-1", "GBK", "Big5")
            val cur = encodings.indexOf(PlayerHolder.subEncoding).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitle text encoding")
                .setSingleChoiceItems(encodings, cur) { d, w ->
                    PlayerHolder.subEncoding = encodings[w]
                    tvEncoding.text = "Default (" + encodings[w] + ")"
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Preferred subtitle language
        val tvLang = view.findViewById<TextView>(R.id.tvSubLanguageSub)
        tvLang.text = PlayerHolder.subPreferredLanguage
        view.findViewById<View>(R.id.rowSubLanguage).setOnClickListener {
            val langs = arrayOf("No language preference", "English", "Hindi", "Spanish", "French", "German")
            val cur = langs.indexOf(PlayerHolder.subPreferredLanguage).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Preferred subtitle language")
                .setSingleChoiceItems(langs, cur) { d, w ->
                    PlayerHolder.subPreferredLanguage = langs[w]
                    tvLang.text = langs[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        // Subtitle Size
        val tvSize = view.findViewById<TextView>(R.id.tvSubSizeSub)
        val sizeLabel = when (PlayerHolder.subFontSize) {
            "14" -> "Small"
            "22" -> "Large"
            "26" -> "Extra large"
            else -> "Normal"
        }
        tvSize.text = sizeLabel
        view.findViewById<View>(R.id.rowSubSize).setOnClickListener {
            val sizes = arrayOf("Small", "Normal", "Large", "Extra large")
            val sizeVals = arrayOf("14", "18", "22", "26")
            val cur = sizeVals.indexOf(PlayerHolder.subFontSize).let { if (it < 0) 1 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles Size")
                .setSingleChoiceItems(sizes, cur) { d, w ->
                    PlayerHolder.subFontSize = sizeVals[w]
                    tvSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Bold subtitles
        val cbBold = view.findViewById<CheckBox>(R.id.cbSubBold)
        cbBold.isChecked = PlayerHolder.isSubBold
        view.findViewById<View>(R.id.rowSubBold).setOnClickListener {
            PlayerHolder.isSubBold = !PlayerHolder.isSubBold
            cbBold.isChecked = PlayerHolder.isSubBold
            PlayerHolder.savePreferences(this)
        }

        // Font Colour Badge
        val cardFontBadge = view.findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardSubFontColorBadge)
        val fontBadgeColor = try {
            val cL = PlayerHolder.subFontColor.toLongOrNull() ?: 16777215L
            if (cL <= 16777215L) (0xFF000000 or cL).toInt() else cL.toInt()
        } catch (e: Exception) { Color.WHITE }
        cardFontBadge.setCardBackgroundColor(fontBadgeColor)

        view.findViewById<View>(R.id.rowSubFontColor).setOnClickListener {
            val colors = arrayOf("White", "Yellow", "Cyan", "Green", "Amber")
            val colorVals = arrayOf("16777215", "16772155", "58879", "6942894", "16766720")
            val colorInts = arrayOf(Color.WHITE, Color.parseColor("#FFEB3B"), Color.parseColor("#00E5FF"), Color.parseColor("#69F0AE"), Color.parseColor("#FFD700"))
            val cur = colorVals.indexOf(PlayerHolder.subFontColor).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Colour")
                .setSingleChoiceItems(colors, cur) { d, w ->
                    PlayerHolder.subFontColor = colorVals[w]
                    cardFontBadge.setCardBackgroundColor(colorInts[w])
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Font Opacity
        val sbFontOpacity = view.findViewById<SeekBar>(R.id.sbSubFontOpacity)
        sbFontOpacity.progress = PlayerHolder.subFontOpacity
        sbFontOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subFontOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Background Checkbox & Slider
        val cbBg = view.findViewById<CheckBox>(R.id.cbSubBgToggle)
        cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
        view.findViewById<View>(R.id.rowSubBgToggle).setOnClickListener {
            PlayerHolder.isSubBackgroundEnabled = !PlayerHolder.isSubBackgroundEnabled
            cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
            PlayerHolder.savePreferences(this)
        }
        val sbBgOpacity = view.findViewById<SeekBar>(R.id.sbSubBgOpacity)
        sbBgOpacity.progress = PlayerHolder.subBackgroundOpacity
        sbBgOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subBackgroundOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Shadow Checkbox & Slider
        val cbShadow = view.findViewById<CheckBox>(R.id.cbSubShadowToggle)
        cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
        view.findViewById<View>(R.id.rowSubShadowToggle).setOnClickListener {
            PlayerHolder.isSubShadowEnabled = !PlayerHolder.isSubShadowEnabled
            cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
            PlayerHolder.savePreferences(this)
        }
        val sbShadowOpacity = view.findViewById<SeekBar>(R.id.sbSubShadowOpacity)
        sbShadowOpacity.progress = PlayerHolder.subShadowOpacity
        sbShadowOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subShadowOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Outline Checkbox & Slider
        val cbOutline = view.findViewById<CheckBox>(R.id.cbSubOutlineToggle)
        cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
        view.findViewById<View>(R.id.rowSubOutlineToggle).setOnClickListener {
            PlayerHolder.isSubOutlineEnabled = !PlayerHolder.isSubOutlineEnabled
            cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
            PlayerHolder.savePreferences(this)
        }
        val tvOutlineSize = view.findViewById<TextView>(R.id.tvSubOutlineSizeSub)
        tvOutlineSize.text = when (PlayerHolder.subOutlineSize) { 0 -> "Thin"; 2 -> "Thick"; else -> "Normal" }
        view.findViewById<View>(R.id.rowSubOutlineSize).setOnClickListener {
            val sizes = arrayOf("Thin", "Normal", "Thick")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Outline Size")
                .setSingleChoiceItems(sizes, PlayerHolder.subOutlineSize.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subOutlineSize = w
                    tvOutlineSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }
        val sbOutlineOpacity = view.findViewById<SeekBar>(R.id.sbSubOutlineOpacity)
        sbOutlineOpacity.progress = PlayerHolder.subOutlineOpacity
        sbOutlineOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subOutlineOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitle Screen Position & Elevation
        val tvPos = view.findViewById<TextView>(R.id.tvSubPositionSub)
        tvPos.text = when (PlayerHolder.subPosition) { 1 -> "Elevated (Above controls)"; 2 -> "Center Screen"; else -> "Standard Bottom (Default)" }
        view.findViewById<View>(R.id.rowSubPosition).setOnClickListener {
            val posNames = arrayOf("Standard Bottom (Default)", "Elevated (Above controls)", "Center Screen")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles position & elevation")
                .setSingleChoiceItems(posNames, PlayerHolder.subPosition.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subPosition = w
                    tvPos.text = posNames[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        dialog.show()
    }

    private fun setupSubtitleSettings() {
        findViewById<View>(R.id.rowSubtitles)?.setOnClickListener {
            showSubtitleSettings()
        }
        btnToggleSubAutoload.setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubAutoload).setOnClickListener {
            btnToggleSubAutoload.performClick()
        }

        val sizeLabels = arrayOf("Very Small (12sp)", "Small (14sp)", "Normal (18sp)", "Large (24sp)", "Huge (32sp)")
        val sizeValues = arrayOf("12", "14", "18", "24", "32")
        val openSizeDialog = {
            val currentIdx = sizeValues.indexOf(PlayerHolder.subFontSize).coerceAtLeast(2)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_size)
                .setSingleChoiceItems(sizeLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontSize = sizeValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubSize.setOnClickListener { openSizeDialog() }
        findViewById<View>(R.id.rowSubSize).setOnClickListener { openSizeDialog() }

        val colorLabels = arrayOf("White", "Yellow", "Cyan", "Green")
        val colorValues = arrayOf("16777215", "16776960", "65535", "65280")
        val openColorDialog = {
            val currentIdx = colorValues.indexOf(PlayerHolder.subFontColor).coerceAtLeast(0)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_color)
                .setSingleChoiceItems(colorLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontColor = colorValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubColor.setOnClickListener { openColorDialog() }
        findViewById<View>(R.id.rowSubColor).setOnClickListener { openColorDialog() }

        val bgLabels = arrayOf("Transparent / None", "Translucent Box", "Solid Black Box")
        val openBgDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_background)
                .setSingleChoiceItems(bgLabels, PlayerHolder.subBackgroundStyle) { dialog, which ->
                    PlayerHolder.subBackgroundStyle = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubBackground.setOnClickListener { openBgDialog() }
        findViewById<View>(R.id.rowSubBackground).setOnClickListener { openBgDialog() }

        btnToggleSubStyle.setOnClickListener {
            PlayerHolder.subFontStyle = if (PlayerHolder.subFontStyle == 1) 0 else 1
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubStyle).setOnClickListener {
            btnToggleSubStyle.performClick()
        }

        val encodings = arrayOf("UTF-8 (Default)", "Windows-1252 (Western)", "ISO-8859-1 (Latin)", "GBK (Chinese)", "Shift-JIS (Japanese)")
        val encValues = arrayOf("UTF-8", "WINDOWS-1252", "ISO-8859-1", "GBK", "SHIFT-JIS")
        val openEncDialog = {
            val currentIdx = encValues.indexOf(PlayerHolder.subEncoding).coerceAtLeast(0)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_encoding)
                .setSingleChoiceItems(encodings, currentIdx) { dialog, which ->
                    PlayerHolder.subEncoding = encValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubEncoding.setOnClickListener { openEncDialog() }
        findViewById<View>(R.id.rowSubEncoding).setOnClickListener { openEncDialog() }
    }

    // --- 4. Controls & Gestures Handlers ---
    private fun setupGestureSettings() {
        btnToggleGestureVolume.setOnClickListener {
            PlayerHolder.isVolumeGestureEnabled = !PlayerHolder.isVolumeGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureVolume).setOnClickListener { btnToggleGestureVolume.performClick() }

        btnToggleGestureBrightness.setOnClickListener {
            PlayerHolder.isBrightnessGestureEnabled = !PlayerHolder.isBrightnessGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureBrightness).setOnClickListener { btnToggleGestureBrightness.performClick() }

        btnToggleGestureSeek.setOnClickListener {
            PlayerHolder.isSeekGestureEnabled = !PlayerHolder.isSeekGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureSeek).setOnClickListener { btnToggleGestureSeek.performClick() }

        btnToggleFastSeek.setOnClickListener {
            PlayerHolder.isFastSeekEnabled = !PlayerHolder.isFastSeekEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowFastSeek).setOnClickListener { btnToggleFastSeek.performClick() }
    }

    // --- 5. Interface & Advanced Handlers ---
    private fun setupInterfaceAndAdvancedSettings() {
        val themes = arrayOf("Pure Black OLED (Default)", "Dark Charcoal", getString(R.string.theme_monochrome))
        val openThemeDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_app_theme)
                .setSingleChoiceItems(themes, PlayerHolder.appThemeMode) { dialog, which ->
                    if (PlayerHolder.appThemeMode != which) {
                        PlayerHolder.appThemeMode = which
                        PlayerHolder.savePreferences(this)
                        dialog.dismiss()
                        applyThemeUI()
                        recreate()
                    } else {
                        dialog.dismiss()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAppTheme.setOnClickListener { openThemeDialog() }
        findViewById<View>(R.id.rowAppTheme).setOnClickListener { openThemeDialog() }

        updateCacheSizeDisplay()
        btnClearCache.setOnClickListener {
            clearAppCache()
            updateCacheSizeDisplay()
            Toast.makeText(this, "Cache cleared successfully", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.rowClearCache).setOnClickListener { btnClearCache.performClick() }

        findViewById<View>(R.id.rowAppVersion)?.setOnClickListener {
            showAppVersionDialog()
        }

        btnClearResume.setOnClickListener {
            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            prefs.edit().clear().apply()
            Toast.makeText(this, "Playback history cleared", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.rowClearResume).setOnClickListener { btnClearResume.performClick() }

        btnResetSettings.setOnClickListener {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_reset_settings)
                .setMessage("Restore all player settings to default values?")
                .setPositiveButton("Reset") { _, _ ->
                    PlayerHolder.resetPreferences(this)
                    updateSettingsUI()
                    Toast.makeText(this, "Settings restored to defaults", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.rowResetSettings).setOnClickListener { btnResetSettings.performClick() }
    }

    private fun applyHighRefreshRate() {
        if (!PlayerHolder.isHighRefreshRateEnabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val modes = display?.supportedModes ?: emptyArray()
                val currentMode = display?.mode
                val targetMode = modes.filter {
                    currentMode == null || (it.physicalWidth == currentMode.physicalWidth && it.physicalHeight == currentMode.physicalHeight)
                }.maxByOrNull { it.refreshRate } ?: modes.maxByOrNull { it.refreshRate }

                targetMode?.let { mode ->
                    val params = window.attributes
                    params.preferredDisplayModeId = mode.modeId
                    window.attributes = params
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun updateToggleButton(btn: Button, isEnabled: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isEnabled) "ON" else "OFF"
        btn.setTextColor(if (isEnabled) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isEnabled) primaryColor else offStrokeColor)
    }

    private fun updateSubStyleButton(btn: Button, isBold: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isBold) "BOLD" else "REG"
        btn.setTextColor(if (isBold) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isBold) primaryColor else offStrokeColor)
    }

    private fun styleActionButton(btn: Button) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        btn.setTextColor(primaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(primaryColor)
    }

    private fun applyThemeUI() {
        val isMono = PlayerHolder.isMonochrome()
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()

        // 1. Bottom Navigation
        val navTint = if (isMono) {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint_mono)
        } else {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint)
        }
        bottomNav.itemIconTintList = navTint
        bottomNav.itemTextColor = navTint

        // 2. Floating Action Button (FAB)
        fabPlay.backgroundTintList = ColorStateList.valueOf(PlayerHolder.getFabBgColorInt())
        fabPlay.setColorFilter(PlayerHolder.getFabIconColorInt())

        // 3. Top Tabs (VIDEOS / FOLDERS)
        if (isFolderViewActive) {
            btnViewFolders.setTextColor(primaryColor)
            btnViewAllVideos.setTextColor(secondaryColor)
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)
        }

        // 4. Search Bar
        val layoutSearch = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.layoutSearch)
        layoutSearch?.boxStrokeColor = primaryColor
        layoutSearch?.hintTextColor = ColorStateList.valueOf(primaryColor)

        // 5. Notch Dynamic Island Player
        btnNotchPlayPause.setColorFilter(primaryColor)
        btnNotchOpen.setColorFilter(primaryColor)
        findViewById<ImageView>(R.id.ivNotchIcon)?.setColorFilter(primaryColor)
        sbNotch.progressTintList = ColorStateList.valueOf(primaryColor)
        sbNotch.thumbTintList = ColorStateList.valueOf(primaryColor)
        val notchStroke = if (isMono) Color.parseColor("#2E2E2E") else Color.parseColor("#2E3440")
        cardNotchPlayer.strokeColor = notchStroke

        // 6. Section Headers & App Name
        findViewById<TextView>(R.id.tvCatVideo)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatAudio)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatSubtitles)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatGestures)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatInterface)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvAppVersionTitle)?.setTextColor(primaryColor)
        val badgeAppVersion = findViewById<TextView>(R.id.badgeAppVersion)
        val cardAppVersion = findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardAppVersion)
        if (isMono) {
            badgeAppVersion?.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#333333"))
            badgeAppVersion?.setTextColor(Color.WHITE)
            cardAppVersion?.strokeColor = Color.parseColor("#2E2E2E")
        } else {
            badgeAppVersion?.backgroundTintList = ColorStateList.valueOf(primaryColor)
            badgeAppVersion?.setTextColor(Color.WHITE)
            cardAppVersion?.strokeColor = Color.parseColor("#2E3440")
        }
        findViewById<TextView>(R.id.tvMasterAudioTitle)?.setTextColor(primaryColor)
        tvVideoColorStatus.setTextColor(primaryColor)

        // 7. Browse Buttons
        btnBrowseVideo.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseVideo.setTextColor(if (isMono) Color.BLACK else Color.WHITE)
        btnBrowseAudio.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseAudio.setTextColor(if (isMono) Color.BLACK else Color.WHITE)

        // 8. Action Buttons ("Change", "Clear", "Reset")
        val actionButtons = listOf(
            btnChangeHw,
            btnChangeOrientation,
            btnChangeVideoColor,
            btnChangeMasterProfile,
            btnChangeDolbySurround,
            btnChangeEqualizer,
            btnChangeAudioOutput,
            btnChangeBgPip,
            btnChangeResumeMode,
            btnChangeDoubleTap,
            btnChangeAspectRatio,
            btnChangeSubSize,
            btnChangeSubColor,
            btnChangeSubBackground,
            btnChangeSubEncoding,
            btnChangeAppTheme,
            btnClearCache,
            btnClearResume,
            btnResetSettings
        )
        for (btn in actionButtons) {
            styleActionButton(btn)
        }

        // 9. Update Settings Toggle Buttons
        updateSettingsUI()

        // 10. Notify media adapters so list items update their colors
        videoAdapter?.notifyDataSetChanged()
        audioAdapter?.notifyDataSetChanged()
        folderVideoAdapter?.notifyDataSetChanged()
        folderAdapter?.notifyDataSetChanged()
    }

    private fun updateSettingsUI() {
        // Video UI
        updateToggleButton(btnToggleHighRefreshRate, PlayerHolder.isHighRefreshRateEnabled)
        tvHighRefreshRateStatus.text = if (PlayerHolder.isHighRefreshRateEnabled) "Enabled (Auto 120Hz / High Refresh Rate)" else "Disabled (Standard 60Hz)"

        tvDefaultOrientationStatus.text = when (PlayerHolder.defaultOrientation) {
            0 -> "Auto Sensor (Free Rotation)"
            2 -> "Portrait (Vertical)"
            else -> "Direct Landscape (Recommended)"
        }
        tvVideoColorStatus.text = when (PlayerHolder.videoColorProfile) {
            0 -> "Standard / Natural (Original)"
            1 -> "Vivid / AMOLED Boost (Recommended)"
            2 -> "Cinema / HDR Effect"
            3 -> "Sharp & Crisp Studio"
            else -> "Custom Color Tuning"
        }

        updateToggleButton(btnToggleWideColor, PlayerHolder.isWideColorGamutEnabled)
        tvWideColorStatus.text = if (PlayerHolder.isWideColorGamutEnabled) "Enabled (10-bit dynamic colors)" else "Disabled (Standard sRGB)"

        updateToggleButton(btnToggleDeblocking, PlayerHolder.isDeblockingFilterEnabled)
        tvDeblockingStatus.text = if (PlayerHolder.isDeblockingFilterEnabled) "Enabled (Crisp gradients & deblocking)" else "Disabled"

        tvHwDecodeStatus.text = when (PlayerHolder.hwAccelerationMode) {
            0 -> "Disabled (Software FFmpeg)"
            2 -> "Decoding Only"
            3 -> "Full Acceleration"
            else -> "Automatic (Recommended)"
        }
        tvBgPipStatus.text = when (PlayerHolder.backgroundPipMode) {
            0 -> "Stop Playback"
            2 -> "Picture-in-Picture (PiP)"
            else -> "Play in Background"
        }
        tvResumeModeStatus.text = when (PlayerHolder.resumeMode) {
            0 -> "Never (Always start over)"
            2 -> "Always resume automatically"
            else -> "Ask confirmation"
        }
        tvDoubleTapStatus.text = "${PlayerHolder.doubleTapSeekSeconds} seconds"
        tvAspectRatioStatus.text = when (PlayerHolder.defaultAspectRatio) {
            1 -> "Fit Screen"
            2 -> "Fill Screen"
            3 -> "16:9"
            4 -> "4:3"
            else -> "Best Fit"
        }

        updateToggleButton(btnToggleAudioBoost, PlayerHolder.isAudioBoostEnabled)
        tvAudioBoostStatus.text = if (PlayerHolder.isAudioBoostEnabled) "Enabled (Up to 200%)" else "Disabled (Standard 100%)"

        // Integrated Audio Suite UI
        tvMasterProfileStatus.text = PlayerHolder.masterProfileNames[PlayerHolder.masterAudioProfile.coerceIn(0, 4)]
        tvDolbySurroundStatus.text = when (PlayerHolder.dolbySpatialMode) {
            1 -> "Dolby 3D Headphone (Binaural HRTF)"
            2 -> "Dolby ProLogic Surround (Matrix)"
            3 -> "Cinema 3D Soundstage (Wide Room)"
            else -> "Standard Stereo (Downmix)"
        }
        val eqIdx = PlayerHolder.currentEqualizerPreset
        tvEqualizerStatus.text = if (eqIdx >= 0 && eqIdx < PlayerHolder.equalizerPresets.size - 1) {
            PlayerHolder.equalizerPresets[eqIdx + 1]
        } else {
            "Flat (Off)"
        }

        updateToggleButton(btnToggleDialogueBoost, PlayerHolder.isDialogueBoostEnabled)
        tvDialogueBoostStatus.text = if (PlayerHolder.isDialogueBoostEnabled) "Dynamic range compression: Clear speech (Enabled)" else "Disabled"

        updateToggleButton(btnTogglePassthrough, PlayerHolder.isDolbyPassthroughEnabled)
        tvDigitalPassthroughStatus.text = if (PlayerHolder.isDolbyPassthroughEnabled) "HDMI / S/PDIF Passthrough (Active)" else "Disabled"

        tvAudioOutputStatus.text = when (PlayerHolder.audioOutputEngine) {
            1 -> "OpenSL ES (Low Latency)"
            2 -> "AAudio (Modern NDK)"
            else -> "AudioTrack (Standard)"
        }

        updateToggleButton(btnToggleHeadsetPause, PlayerHolder.isHeadsetPauseEnabled)
        tvHeadsetPauseStatus.text = if (PlayerHolder.isHeadsetPauseEnabled) "Auto-pause when unplugged (Enabled)" else "Disabled"

        updateToggleButton(btnToggleTimeStretch, PlayerHolder.isTimeStretchingEnabled)
        tvTimeStretchStatus.text = if (PlayerHolder.isTimeStretchingEnabled) "Pitch lock active (Enabled)" else "Disabled"

        // Subtitle UI
        updateToggleButton(btnToggleSubAutoload, PlayerHolder.isSubAutoloadEnabled)

        tvSubSizeStatus.text = when (PlayerHolder.subFontSize) {
            "12" -> "Very Small (12sp)"
            "14" -> "Small (14sp)"
            "24" -> "Large (24sp)"
            "32" -> "Huge (32sp)"
            else -> "Normal (18sp)"
        }
        tvSubColorStatus.text = when (PlayerHolder.subFontColor) {
            "16776960" -> "Yellow"
            "65535" -> "Cyan"
            "65280" -> "Green"
            else -> "White"
        }
        tvSubBackgroundStatus.text = when (PlayerHolder.subBackgroundStyle) {
            1 -> "Translucent Box"
            2 -> "Solid Black Box"
            else -> "Transparent / None"
        }

        updateSubStyleButton(btnToggleSubStyle, PlayerHolder.subFontStyle == 1)
        tvSubStyleStatus.text = if (PlayerHolder.subFontStyle == 1) "Bold font weight" else "Normal font weight"

        tvSubEncodingStatus.text = PlayerHolder.subEncoding

        // Gestures UI
        updateToggleButton(btnToggleGestureVolume, PlayerHolder.isVolumeGestureEnabled)
        tvGestureVolumeStatus.text = if (PlayerHolder.isVolumeGestureEnabled) "Right side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureBrightness, PlayerHolder.isBrightnessGestureEnabled)
        tvGestureBrightnessStatus.text = if (PlayerHolder.isBrightnessGestureEnabled) "Left side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureSeek, PlayerHolder.isSeekGestureEnabled)
        tvGestureSeekStatus.text = if (PlayerHolder.isSeekGestureEnabled) "Horizontal drag (Enabled)" else "Disabled"

        updateToggleButton(btnToggleFastSeek, PlayerHolder.isFastSeekEnabled)
        tvFastSeekStatus.text = if (PlayerHolder.isFastSeekEnabled) "Seek to nearest keyframe (Enabled)" else "Exact frame seek (Disabled)"

        // Interface UI
        tvAppThemeStatus.text = when (PlayerHolder.appThemeMode) {
            PlayerHolder.THEME_MONOCHROME -> getString(R.string.theme_monochrome)
            PlayerHolder.THEME_CHARCOAL -> "Dark Charcoal"
            else -> "Pure Black OLED (Default)"
        }

        // Dedicated YouTube Premium & Advanced Streaming Settings UI
        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val isAdBlockOn = ytPrefs.getBoolean("pref_yt_adblock", true)
        updateToggleButton(btnToggleYtAdBlock, isAdBlockOn)
        tvYtAdBlockStatus.text = if (isAdBlockOn) "Active (100% Ad-Free Video & Feed)" else "Disabled (Standard YouTube)"

        tvYtSponsorBlockStatus.text = if (PlayerHolder.isSponsorBlockEnabled) "Enabled (Auto-skip sponsors/intros)" else "Disabled"
        tvYtDefaultQualityStatus.text = ytPrefs.getString("pref_yt_default_quality", "Auto (Adaptive High Bitrate)") ?: "Auto"
        tvYtAudioQualityStatus.text = ytPrefs.getString("pref_yt_audio_quality", "Auto (Adaptive - Recommended)") ?: "Auto"
        tvYtExtractorBridgeStatus.text = "NewPipe Extractor v0.26.5"
        val currentClient = ytPrefs.getString("pref_yt_client_spoof", "TVHTML5_SIMPLY_EMBEDDED_PLAYER") ?: "TVHTML5_SIMPLY_EMBEDDED_PLAYER"
        tvYtClientSpoofingStatus.text = when (currentClient) {
            "ANDROID_TESTSUITE" -> "Android Testsuite (Internal test - No Botguard)"
            "IOS" -> "iOS Official (Direct formats - Native Apple)"
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER" -> "TV HTML5 Embedded (High-bitrate DASH/HLS)"
            "ANDROID" -> "Android Official (Standard YouTube client)"
            else -> "Android VR (Oculus Quest - Zero PoToken Bypass)"
        }

        updateToggleButton(btnToggleYtBgAudio, PlayerHolder.isBackgroundPlayEnabled)
        tvYtBgAudioStatus.text = if (PlayerHolder.isBackgroundPlayEnabled) "Enabled with Lock Screen controls" else "Disabled"

        val showShorts = ytPrefs.getBoolean("pref_yt_show_shorts", true)
        val showComments = ytPrefs.getBoolean("pref_yt_show_comments", true)
        val showCast = ytPrefs.getBoolean("pref_yt_show_cast", true)
        tvYtInterfaceStatus.text = "Shorts: ${if (showShorts) "ON" else "OFF"} • Comments: ${if (showComments) "ON" else "OFF"} • Cast: ${if (showCast) "ON" else "OFF"}"

        // Apply UI toggles to current YouTube views
        layoutYtShortsShelf.visibility = if (showShorts) View.VISIBLE else View.GONE
        layoutYtCommentsCard.visibility = if (showComments) View.VISIBLE else View.GONE
        btnYtCast.visibility = if (showCast) View.VISIBLE else View.GONE

        tvYtAccountStatus.text = if (MicroGAuthManager.isLoggedIn(this)) "Signed In (${MicroGAuthManager.getAccountEmail(this)})" else "MicroG GmsCore Integration"
    }
    private fun showSponsorBlockSettingsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_sponsorblock_settings, null)
        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        view.findViewById<View>(R.id.btnSponsorClose)?.setOnClickListener { dialog.dismiss() }

        val cbMaster = view.findViewById<CheckBox>(R.id.cbSbMaster)
        val cbSponsor = view.findViewById<CheckBox>(R.id.cbSbSponsor)
        val cbIntro = view.findViewById<CheckBox>(R.id.cbSbIntro)
        val cbOutro = view.findViewById<CheckBox>(R.id.cbSbOutro)
        val cbPromo = view.findViewById<CheckBox>(R.id.cbSbPromo)
        val cbInteraction = view.findViewById<CheckBox>(R.id.cbSbInteraction)

        cbMaster?.isChecked = PlayerHolder.isSponsorBlockEnabled
        cbSponsor?.isChecked = PlayerHolder.sbSkipSponsor
        cbIntro?.isChecked = PlayerHolder.sbSkipIntro
        cbOutro?.isChecked = PlayerHolder.sbSkipOutro
        cbPromo?.isChecked = PlayerHolder.sbSkipPromo
        cbInteraction?.isChecked = PlayerHolder.sbSkipInteraction

        val updateStates = {
            PlayerHolder.isSponsorBlockEnabled = cbMaster?.isChecked == true
            PlayerHolder.sbSkipSponsor = cbSponsor?.isChecked == true
            PlayerHolder.sbSkipIntro = cbIntro?.isChecked == true
            PlayerHolder.sbSkipOutro = cbOutro?.isChecked == true
            PlayerHolder.sbSkipPromo = cbPromo?.isChecked == true
            PlayerHolder.sbSkipInteraction = cbInteraction?.isChecked == true
            updateSettingsUI()
        }

        cbMaster?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbSponsor?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbIntro?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbOutro?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbPromo?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbInteraction?.setOnCheckedChangeListener { _, _ -> updateStates() }

        dialog.show()
    }

    private fun showYouTubeQualityDialog() {
        val qualities = arrayOf("Auto (Adaptive High Bitrate)", "1080p Full HD", "720p HD", "480p SD", "360p Data Saver")
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Default Streaming Quality")
            .setItems(qualities) { _, which ->
                val chosen = qualities[which]
                val prefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
                prefs.edit().putString("pref_yt_default_quality", chosen).apply()
                val maxHeight = when (which) {
                    1 -> 1080
                    2 -> 720
                    3 -> 480
                    4 -> 360
                    else -> 0
                }
                YouTubeExoPlayerManager.setVideoQuality(maxHeight)
                updateSettingsUI()
                Toast.makeText(this, "Default Quality set to $chosen", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showClientSpoofingDialog() {
        val clients = arrayOf(
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER" to "TV HTML5 Embedded (High-bitrate DASH/HLS - Highly Permissive)",
            "IOS" to "iOS Official (Direct formats - Native Apple client)",
            "ANDROID_TESTSUITE" to "Android Testsuite (Internal test client - No Botguard)",
            "ANDROID_VR" to "Android VR (Oculus Quest 2 - Zero PoToken)",
            "ANDROID" to "Android Official (Standard YouTube client)"
        )

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val currentClient = ytPrefs.getString("pref_yt_client_spoof", "TVHTML5_SIMPLY_EMBEDDED_PLAYER") ?: "TVHTML5_SIMPLY_EMBEDDED_PLAYER"
        val currentIndex = clients.indexOfFirst { it.first.equals(currentClient, ignoreCase = true) }.coerceAtLeast(0)

        val displayOptions = clients.map { it.second }.toTypedArray()

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Client Spoofing Profile")
            .setSingleChoiceItems(displayOptions, currentIndex) { dialog, which ->
                val (clientId, _) = clients[which]
                ytPrefs.edit().putString("pref_yt_client_spoof", clientId).apply()
                updateSettingsUI()
                val clientName = clients[which].second.substringBefore(" (")
                Toast.makeText(this, "Client spoof switched to " + clientName, Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExtractorBridgeDialog() {
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Extractor Engine")
            .setMessage("Engine: Official TeamNewPipe Extractor (v0.26.5)\nMode: 100% Native Ad-Free Playback\nStatus: Active")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showYouTubeUiConfigDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_youtube_ui_settings, null)
        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val prefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val cbShorts = view.findViewById<CheckBox>(R.id.cbYtUiShowShorts)
        val cbComments = view.findViewById<CheckBox>(R.id.cbYtUiShowComments)
        val cbCast = view.findViewById<CheckBox>(R.id.cbYtUiShowCast)
        val btnDone = view.findViewById<Button>(R.id.btnYtUiSaveClose)

        cbShorts?.isChecked = prefs.getBoolean("pref_yt_show_shorts", true)
        cbComments?.isChecked = prefs.getBoolean("pref_yt_show_comments", true)
        cbCast?.isChecked = prefs.getBoolean("pref_yt_show_cast", true)

        btnDone?.setOnClickListener {
            prefs.edit()
                .putBoolean("pref_yt_show_shorts", cbShorts?.isChecked == true)
                .putBoolean("pref_yt_show_comments", cbComments?.isChecked == true)
                .putBoolean("pref_yt_show_cast", cbCast?.isChecked == true)
                .apply()
            updateSettingsUI()
            dialog.dismiss()
        }

        dialog.show()
    }


    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            storagePermissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            loadMediaFiles()
        }
    }

    private fun switchVideoViewMode(folders: Boolean) {
        isFolderViewActive = folders
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        if (folders) {
            btnViewAllVideos.setTextColor(secondaryColor)
            btnViewFolders.setTextColor(primaryColor)

            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            updateFoldersData()
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)

            rvVideos.visibility = View.VISIBLE
            layoutFoldersContainer.visibility = View.GONE
            closeFolderDetail()
        }
    }

    private fun closeFolderDetail() {
        currentSelectedFolder = null
        layoutFolderDetailHeader.visibility = View.GONE
        rvFolderVideos.visibility = View.GONE
        rvFolders.visibility = View.VISIBLE
    }

    private fun updateFoldersData() {
        val folderMap = linkedMapOf<String, MediaFolder>()
        for (video in allVideos) {
            val key = if (video.folderPath.isNotEmpty()) video.folderPath else video.folderName
            val folder = folderMap.getOrPut(key) {
                MediaFolder(video.folderName, video.folderPath)
            }
            folder.videos.add(video)
        }
        allFolders = folderMap.values.toList()

        btnViewFolders.text = "FOLDERS"
        btnViewAllVideos.text = "VIDEOS"

        if (folderAdapter == null) {
            folderAdapter = FolderAdapter(allFolders) { folder ->
                openFolderDetail(folder)
            }
            rvFolders.adapter = folderAdapter
        } else {
            folderAdapter?.updateFolders(allFolders)
        }
    }

    private fun openFolderDetail(folder: MediaFolder) {
        currentSelectedFolder = folder
        rvFolders.visibility = View.GONE
        layoutFolderDetailHeader.visibility = View.VISIBLE
        rvFolderVideos.visibility = View.VISIBLE

        tvFolderHeaderTitle.text = folder.folderName
        tvFolderHeaderSubtitle.text = "${folder.count} videos • ${folder.getFormattedSize()}"

        folderVideoAdapter = MediaAdapter(folder.videos) { item, _ ->
            try {
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
        rvFolderVideos.adapter = folderVideoAdapter
    }

    private fun loadMediaFiles() {
        allVideos = MediaScanner.scanVideos(this)
        if (allVideos.isNotEmpty()) {
            layoutEmptyVideo.visibility = View.GONE
            if (videoAdapter == null) {
                videoAdapter = MediaAdapter(allVideos) { item, _ ->
                    try {
                        openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
                rvVideos.adapter = videoAdapter
            } else {
                videoAdapter?.updateList(allVideos)
            }
            updateFoldersData()
            if (isFolderViewActive) {
                rvVideos.visibility = View.GONE
                layoutFoldersContainer.visibility = View.VISIBLE
            } else {
                rvVideos.visibility = View.VISIBLE
                layoutFoldersContainer.visibility = View.GONE
            }
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = View.VISIBLE
        }

        allAudio = MediaScanner.scanAudio(this)
        if (allAudio.isNotEmpty()) {
            rvAudio.visibility = View.VISIBLE
            layoutEmptyAudio.visibility = View.GONE
            if (audioAdapter == null) {
                audioAdapter = MediaAdapter(allAudio) { item, pos ->
                    try {
                        PlayerHolder.setPlaylistAndPlay(this, allAudio, pos)
                        audioAdapter?.setPlayingUri(item.uri)
                        updateNotchPlayerUI()
                        openPlayer(item.uri, item.title, isVideo = false, path = item.filePath, artist = item.artist)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
                rvAudio.adapter = audioAdapter
            } else {
                audioAdapter?.updateList(allAudio)
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            }
        } else {
            rvAudio.visibility = View.GONE
            layoutEmptyAudio.visibility = View.VISIBLE
        }
    }

    private fun openPlayer(uri: Uri, title: String, isVideo: Boolean = true, path: String? = null, artist: String? = null) {
        PlayerHolder.isAudioOnly = !isVideo
        PlayerHolder.currentArtist = artist ?: "Unknown artist"
        val intent = Intent(this, PlayerActivity::class.java).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra("media_uri", uri.toString())
            putExtra("media_title", title)
            putExtra("media_artist", PlayerHolder.currentArtist)
            putExtra("is_video", isVideo)
            if (!path.isNullOrEmpty()) {
                putExtra("media_path", path)
            }
        }
        startActivity(intent)
    }

    private fun updateCacheSizeDisplay() {
        try {
            var size = getDirSize(cacheDir)
            size += getDirSize(codeCacheDir)
            externalCacheDir?.let { size += getDirSize(it) }
            val formatted = if (size <= 0) "0 B (Clean)" else android.text.format.Formatter.formatFileSize(this, size)
            tvCacheSizeStatus.text = "$formatted • Free up temporary cache & thumbnails"
        } catch (e: Exception) {
            tvCacheSizeStatus.text = "0 B (Clean) • Free up temporary cache"
        }
    }

    private fun getDirSize(dir: java.io.File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var bytes = 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            bytes += if (f.isDirectory) getDirSize(f) else f.length()
        }
        return bytes
    }

    private fun clearAppCache() {
        try {
            cacheDir.deleteRecursively()
            codeCacheDir.deleteRecursively()
            externalCacheDir?.deleteRecursively()
            // Cache cleared
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAppVersionDialog() {
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle(R.string.app_name)
            .setMessage("Version 3.0 (Master Edition)\nBuild: 300\n\nLead Developer: Rajesh Shah\nEngine: Universal Hardware Core with Dolby Surround\n\nStatus: Up to date")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showYouTubeDedicatedSettingsDialog() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_youtube_app_settings, null)
        dialog.setContentView(view)

        view.findViewById<View>(R.id.btnYtSettingsClose)?.setOnClickListener { dialog.dismiss() }

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)

        // 1. Video Quality
        val tvQuality = view.findViewById<TextView>(R.id.tvYtSettingQualityVal)
        tvQuality?.setText(ytPrefs.getString("pref_yt_default_quality", "Auto (Adaptive High Bitrate)") ?: "Auto")
        view.findViewById<View>(R.id.rowYtSettingQuality)?.setOnClickListener {
            showYouTubeQualityDialog()
            dialog.dismiss()
        }

        // 2. Decoder
        val tvDecoder = view.findViewById<TextView>(R.id.tvYtSettingDecoderVal)
        tvDecoder?.setText(if (PlayerHolder.isHardwareDecoding) "Hardware Decoder (HW MediaCodec)" else "Software Decoder (SW)")
        view.findViewById<View>(R.id.rowYtSettingDecoder)?.setOnClickListener {
            val options = arrayOf("Automatic (HW MediaCodec - Recommended)", "Software (SW)")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Hardware Acceleration")
                .setSingleChoiceItems(options, if (PlayerHolder.isHardwareDecoding) 0 else 1) { d, which ->
                    PlayerHolder.isHardwareDecoding = (which == 0)
                    PlayerHolder.savePreferences(this)
                    tvDecoder?.setText(if (PlayerHolder.isHardwareDecoding) "Hardware Decoder (HW MediaCodec)" else "Software Decoder (SW)")
                    d.dismiss()
                }
                .show()
        }

        // 3. Sound & 10-Band EQ
        val tvEq = view.findViewById<TextView>(R.id.tvYtSettingEqVal)
        val eqIdx = PlayerHolder.currentEqualizerPreset
        tvEq?.setText(if (eqIdx >= 0 && eqIdx < PlayerHolder.equalizerPresets.size - 1) PlayerHolder.equalizerPresets[eqIdx + 1] else "Flat (Off)")
        view.findViewById<View>(R.id.rowYtSettingEq)?.setOnClickListener {
            val presets = PlayerHolder.equalizerPresets
            val cur = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("10-Band Equalizer Presets")
                .setSingleChoiceItems(presets, cur) { d, which ->
                    PlayerHolder.currentEqualizerPreset = which - 1
                    PlayerHolder.savePreferences(this)
                    tvEq?.setText(presets[which])
                    d.dismiss()
                }
                .show()
        }

        // 4. Audio Lipsync & Delay
        val tvAudioDelay = view.findViewById<TextView>(R.id.tvYtSettingAudioDelayVal)
        tvAudioDelay?.setText("${PlayerHolder.currentAudioDelayMs} ms (Synchronized)")
        view.findViewById<View>(R.id.rowYtSettingAudioDelay)?.setOnClickListener {
            val del = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(40, 20, 40, 20)
            }
            val tvD = TextView(this).apply {
                text = "${PlayerHolder.currentAudioDelayMs} ms"
                textSize = 18f
                setTextColor(Color.WHITE)
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val btnMinus = Button(this).apply {
                text = "-50ms"
                setOnClickListener {
                    PlayerHolder.currentAudioDelayMs -= 50
                    tvD.text = "${PlayerHolder.currentAudioDelayMs} ms"
                }
            }
            val btnPlus = Button(this).apply {
                text = "+50ms"
                setOnClickListener {
                    PlayerHolder.currentAudioDelayMs += 50
                    tvD.text = "${PlayerHolder.currentAudioDelayMs} ms"
                }
            }
            del.addView(btnMinus)
            del.addView(tvD)
            del.addView(btnPlus)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Audio Delay / Lipsync")
                .setView(del)
                .setPositiveButton("Done") { _, _ ->
                    tvAudioDelay?.setText("${PlayerHolder.currentAudioDelayMs} ms")
                    PlayerHolder.savePreferences(this)
                }
                .show()
        }

        // 5. Subtitles & Styling
        view.findViewById<View>(R.id.rowYtSettingSubtitles)?.setOnClickListener {
            dialog.dismiss()
            showSubtitleSettings()
        }

        // 6. SponsorBlock
        val tvSb = view.findViewById<TextView>(R.id.tvYtSettingSponsorBlockVal)
        tvSb?.setText(if (PlayerHolder.isSponsorBlockEnabled) "Enabled (Auto-skip sponsors/intros)" else "Disabled")
        view.findViewById<View>(R.id.rowYtSettingSponsorBlock)?.setOnClickListener {
            dialog.dismiss()
            showSponsorBlockSettingsDialog()
        }

        // 7. Background Audio Playback
        val tvBg = view.findViewById<TextView>(R.id.tvYtSettingBgPlayVal)
        tvBg?.setText(if (PlayerHolder.isBackgroundPlayEnabled) "Enabled with Lock Screen controls" else "Disabled")
        view.findViewById<View>(R.id.rowYtSettingBgPlay)?.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            PlayerHolder.savePreferences(this)
            tvBg?.setText(if (PlayerHolder.isBackgroundPlayEnabled) "Enabled with Lock Screen controls" else "Disabled")
        }

        dialog.show()
    }

}
