package com.cleanplayer.app

import java.util.concurrent.Executors
import android.net.wifi.WifiManager
import android.hardware.Camera
import android.view.SurfaceView
import android.view.SurfaceHolder
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.WifiConfiguration
import com.google.zxing.MultiFormatReader
import com.google.zxing.DecodeHintType
import com.google.zxing.BarcodeFormat
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.BinaryBitmap
import com.google.zxing.common.HybridBinarizer

import android.media.AudioManager
import android.view.GestureDetector
import android.view.ScaleGestureDetector
import androidx.media3.ui.AspectRatioFrameLayout

import android.view.MotionEvent
import android.view.WindowInsets
import android.view.WindowInsetsController

import android.os.Handler
import android.os.Looper

import android.app.PictureInPictureParams
import android.util.Rational
import android.content.res.Configuration

import android.Manifest
import java.io.File
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.Gravity
import android.graphics.Typeface
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.webkit.WebSettings
import android.webkit.WebChromeClient
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import androidx.core.widget.NestedScrollView
import android.widget.Button
import android.widget.ProgressBar
import android.widget.HorizontalScrollView
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.ImageButton
import android.widget.ImageView
import com.google.android.material.card.MaterialCardView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.widget.FrameLayout
import android.widget.RelativeLayout

class MainActivity : AppCompatActivity() {
    private var activeSettingsBottomSheet: com.google.android.material.bottomsheet.BottomSheetDialog? = null

    private val ytPrefs by lazy { getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE) }

    // =========================================================================
    // 5GHz High-Speed Resumable P2P File Sharing Engine Implementation
    // =========================================================================

    // 5GHz High-Speed Share Tab Views & State
    private lateinit var tabShare: View
    private lateinit var tabShareTitleShare: TextView
    private lateinit var tabShareTitleHistory: TextView
    private lateinit var layoutShareMainContent: View
    private lateinit var layoutShareHistoryContent: View
    private lateinit var rvShareRecent: RecyclerView
    private lateinit var rvShareHistory: RecyclerView
    private lateinit var btnShareSend: View
    private lateinit var btnShareReceive: View
    private lateinit var btnShareMenu: ImageButton
    private lateinit var btnShareClearHistory: Button
    private lateinit var layoutShareEmptyRecent: View
    private lateinit var layoutShareEmptyHistory: View
    private var shareRecentAdapter: ShareRecordAdapter? = null
    private var shareHistoryAdapter: ShareRecordAdapter? = null
    private var cardActiveTransferBanner: View? = null
    private var tvActiveBannerTitle: TextView? = null
    private var tvActiveBannerSpeed: TextView? = null
    private var pbActiveBannerProgress: ProgressBar? = null
    private var tvActiveBannerFileName: TextView? = null
    private var btnActiveBannerView: Button? = null
    private var btnActiveBannerStop: Button? = null
    private var activeShareProgressDialog: AlertDialog? = null

    private fun setupShareTab() {
        tabShare = findViewById(R.id.tabShare)
        tabShareTitleShare = findViewById(R.id.tabShareTitleShare)
        tabShareTitleHistory = findViewById(R.id.tabShareTitleHistory)
        layoutShareMainContent = findViewById(R.id.layoutShareMainContent)
        layoutShareHistoryContent = findViewById(R.id.layoutShareHistoryContent)
        rvShareRecent = findViewById(R.id.rvShareRecent)
        rvShareHistory = findViewById(R.id.rvShareHistory)
        btnShareSend = findViewById(R.id.btnShareSend)
        btnShareReceive = findViewById(R.id.btnShareReceive)
        btnShareMenu = findViewById(R.id.btnShareMenu)
        btnShareClearHistory = findViewById(R.id.btnShareClearHistory)
        layoutShareEmptyRecent = findViewById(R.id.layoutShareEmptyRecent)
        layoutShareEmptyHistory = findViewById(R.id.layoutShareEmptyHistory)

        cardActiveTransferBanner = findViewById(R.id.cardActiveTransferBanner)
        tvActiveBannerTitle = findViewById(R.id.tvActiveBannerTitle)
        tvActiveBannerSpeed = findViewById(R.id.tvActiveBannerSpeed)
        pbActiveBannerProgress = findViewById(R.id.pbActiveBannerProgress)
        tvActiveBannerFileName = findViewById(R.id.tvActiveBannerFileName)
        btnActiveBannerView = findViewById(R.id.btnActiveBannerView)
        btnActiveBannerStop = findViewById(R.id.btnActiveBannerStop)

        btnActiveBannerStop?.setOnClickListener {
            FastShareManager.stopTransferService(this)
            FastShareService.isTransferActive.set(false)
            cardActiveTransferBanner?.visibility = View.GONE
            
        }

        btnActiveBannerView?.setOnClickListener {
            showShareProgressDialog(isSender = FastShareService.isSenderMode, filePaths = emptyList())
        }

        rvShareRecent.layoutManager = LinearLayoutManager(this)
        rvShareHistory.layoutManager = LinearLayoutManager(this)

        shareRecentAdapter = ShareRecordAdapter(emptyList()) { record ->
            handleRecordAction(record)
        }
        rvShareRecent.adapter = shareRecentAdapter

        shareHistoryAdapter = ShareRecordAdapter(emptyList()) { record ->
            handleRecordAction(record)
        }
        rvShareHistory.adapter = shareHistoryAdapter

        findViewById<View>(R.id.layoutShareBandBadge)?.setOnClickListener {
            showShareSettingsBottomSheet()
        }

        cardActiveTransferBanner?.setOnClickListener {
            showShareProgressDialog(isSender = FastShareService.isSenderMode, filePaths = emptyList())
        }

        layoutShareEmptyRecent.setOnClickListener {
            checkSharePermissionsAndRun {
                showShareSelectItemsDialog()
            }
        }

        layoutShareEmptyHistory.setOnClickListener {
            tabShareTitleShare.performClick()
        }

        tabShareTitleShare.setOnClickListener {
            tabShareTitleShare.setTextColor(Color.parseColor("#00E5FF"))
            tabShareTitleHistory.setTextColor(Color.parseColor("#888888"))
            layoutShareMainContent.visibility = View.VISIBLE
            layoutShareHistoryContent.visibility = View.GONE
            refreshShareTabUI()
        }

        tabShareTitleHistory.setOnClickListener {
            tabShareTitleHistory.setTextColor(Color.parseColor("#00E5FF"))
            tabShareTitleShare.setTextColor(Color.parseColor("#888888"))
            layoutShareMainContent.visibility = View.GONE
            layoutShareHistoryContent.visibility = View.VISIBLE
            refreshShareTabUI()
        }

        btnShareSend.setOnClickListener {
            checkSharePermissionsAndRun {
                showShareSelectItemsDialog()
            }
        }

        findViewById<View>(R.id.btnShareWebShareCard)?.setOnClickListener {
            checkSharePermissionsAndRun {
                showShareSelectItemsDialog()
            }
        }

        btnShareReceive.setOnClickListener {
            checkSharePermissionsAndRun {
                checkCameraPermissionAndScan {
                    showQrScannerDialog()
                }
            }
        }

        btnShareMenu.setOnClickListener {
            showShareSettingsBottomSheet()
        }

        btnShareClearHistory.setOnClickListener {
            ShareHistoryManager.clearHistory(this)
            refreshShareTabUI()
        }

        refreshShareTabUI()
    }

    private fun handleRecordAction(record: TransferRecord) {
        val file = File(record.filePath)
        if (!file.exists()) {
            CleanToast.show(this, "File not found on storage")
            return
        }

        try {
            val uri = androidx.core.content.FileProvider.getUriForFile(
                this,
                "$packageName.provider",
                file
            )

            val name = record.fileName.lowercase()
            val isVid = record.type == ShareItemType.VIDEO || name.endsWith(".mp4") || name.endsWith(".mkv") || name.endsWith(".webm") || name.endsWith(".avi")
            val isAud = record.type == ShareItemType.AUDIO || name.endsWith(".mp3") || name.endsWith(".m4a") || name.endsWith(".flac") || name.endsWith(".wav") || name.endsWith(".aac")

            if (isVid) {
                openPlayer(uri, record.fileName, isVideo = true, path = file.absolutePath)
            } else if (isAud) {
                openPlayer(uri, record.fileName, isVideo = false, path = file.absolutePath)
            } else if (name.endsWith(".apk")) {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            } else {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "*/*")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(Intent.createChooser(intent, "Open With"))
            }
        } catch (e: Exception) {
            CleanToast.show(this, "Unable to open file: ${e.localizedMessage}")
        }
    }

    private fun refreshShareTabUI() {
        if (!::tabShare.isInitialized) return
        val records = ShareHistoryManager.getRecords(this)
        val recent = records.take(8)

        shareRecentAdapter?.updateRecords(recent)
        layoutShareEmptyRecent.visibility = if (recent.isEmpty()) View.VISIBLE else View.GONE
        rvShareRecent.visibility = if (recent.isNotEmpty()) View.VISIBLE else View.GONE

        shareHistoryAdapter?.updateRecords(records)
        layoutShareEmptyHistory.visibility = if (records.isEmpty()) View.VISIBLE else View.GONE
        rvShareHistory.visibility = if (records.isNotEmpty()) View.VISIBLE else View.GONE

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val bandLabel = ytPrefs.getString("pref_share_band", "5GHz High-Speed Wi-Fi Turbo") ?: "5GHz High-Speed Wi-Fi Turbo"
        findViewById<TextView>(R.id.tvShareBandBadge)?.text = bandLabel

        if (FastShareService.isTransferActive.get()) {
            cardActiveTransferBanner?.visibility = View.VISIBLE
            tvActiveBannerTitle?.text = if (FastShareService.isSenderMode) "⚡ Sending in Background..." else "⚡ Receiving in Background..."
            tvActiveBannerSpeed?.text = "${String.format("%.1f", FastShareService.currentSpeedMb)} MB/s"
            pbActiveBannerProgress?.progress = FastShareService.currentProgressPercent
            val tMb = String.format("%.1f MB", FastShareService.currentTransferredBytes / (1024f * 1024f))
            val totMb = String.format("%.1f MB", FastShareService.currentTotalBytes / (1024f * 1024f))
            tvActiveBannerFileName?.text = "${FastShareService.currentFileName} (${FastShareService.currentProgressPercent}%) • $tMb / $totMb"
        } else if (WebShareManager.isRunning.get()) {
            cardActiveTransferBanner?.visibility = View.VISIBLE
            tvActiveBannerTitle?.text = "🌐 WebShare Active (${WebShareManager.sharedFiles.size} files)"
            tvActiveBannerSpeed?.text = WebShareManager.currentServerUrl
            pbActiveBannerProgress?.progress = 100
            tvActiveBannerFileName?.text = "Serving via Wi-Fi • Tap to view QR or manage"
            cardActiveTransferBanner?.setOnClickListener {
                showWebShareDialog(WebShareManager.sharedFiles.map { it.absolutePath })
            }
            btnActiveBannerStop?.setOnClickListener {
                WebShareManager.stopWebShare(this)
                refreshShareTabUI()
            }
        } else {
            cardActiveTransferBanner?.visibility = View.GONE
        }
    }

    private fun showShareSelectItemsDialog() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_share_select_items, null)
        dialog.setContentView(view)

        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.let { sheet ->
                val behavior = com.google.android.material.bottomsheet.BottomSheetBehavior.from(sheet)
                behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
            }
        }

        view.findViewById<View>(R.id.btnSelectBack)?.setOnClickListener { dialog.dismiss() }

        val rvItems = view.findViewById<RecyclerView>(R.id.rvSelectableItems)
        val tvSelectedBadge = view.findViewById<TextView>(R.id.tvSelectedCountBadge)
        val btnSend = view.findViewById<Button>(R.id.btnStartSendTransfer)

        rvItems?.layoutManager = LinearLayoutManager(this)
        val allSelectedMap = mutableMapOf<String, ShareItem>()
        var currentLoadedCategoryItems = listOf<ShareItem>()

        fun updateSelectedBadge() {
            val count = allSelectedMap.size
            val totalBytes = allSelectedMap.values.sumOf { it.size }
            val mb = String.format("%.1f MB", totalBytes / (1024f * 1024f))
            tvSelectedBadge?.text = "$count files selected ($mb)"
        }

        lateinit var adapter: ShareSelectableAdapter
        adapter = ShareSelectableAdapter(emptyList()) { _ ->
            for (item in adapter.getItems()) {
                if (item.isSelected) {
                    allSelectedMap[item.path] = item
                } else {
                    allSelectedMap.remove(item.path)
                }
            }
            updateSelectedBadge()
        }
        rvItems?.adapter = adapter

        fun loadCategory(type: ShareItemType, activeTab: TextView) {
            val tabs = listOf(
                view.findViewById<TextView>(R.id.tabCatRecent),
                view.findViewById<TextView>(R.id.tabCatVideos),
                view.findViewById<TextView>(R.id.tabCatAudio),
                view.findViewById<TextView>(R.id.tabCatApps),
                view.findViewById<TextView>(R.id.tabCatImages),
                view.findViewById<TextView>(R.id.tabCatFiles)
            )
            for (t in tabs) {
                t?.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                t?.setTextColor(Color.WHITE)
                t?.setTypeface(null, android.graphics.Typeface.NORMAL)
            }
            activeTab.setBackgroundResource(R.drawable.bg_youtube_chip_active)
            activeTab.setTextColor(Color.BLACK)
            activeTab.setTypeface(null, android.graphics.Typeface.BOLD)

            FastShareManager.loadCategoryItems(this, type) { items ->
                currentLoadedCategoryItems = items
                for (item in items) {
                    item.isSelected = allSelectedMap.containsKey(item.path)
                }
                adapter.updateItems(items)
            }
        }

        view.findViewById<TextView>(R.id.tabCatRecent)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.RECENT, t) } }
        view.findViewById<TextView>(R.id.tabCatVideos)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.VIDEO, t) } }
        view.findViewById<TextView>(R.id.tabCatAudio)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.AUDIO, t) } }
        view.findViewById<TextView>(R.id.tabCatApps)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.APP, t) } }
        view.findViewById<TextView>(R.id.tabCatImages)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.IMAGE, t) } }
        view.findViewById<TextView>(R.id.tabCatFiles)?.let { t -> t.setOnClickListener { loadCategory(ShareItemType.FILE, t) } }

        view.findViewById<View>(R.id.btnSelectSearch)?.setOnClickListener {
            val searchInput = EditText(this).apply {
                hint = "Search files..."
                setSingleLine()
                setTextColor(Color.WHITE)
            }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Filter Files")
                .setView(searchInput)
                .setPositiveButton("Search") { _, _ ->
                    val query = searchInput.text.toString().trim().lowercase()
                    if (query.isNotBlank()) {
                        val filtered = currentLoadedCategoryItems.filter { it.name.lowercase().contains(query) }
                        adapter.updateItems(filtered)
                    } else {
                        adapter.updateItems(currentLoadedCategoryItems)
                    }
                }
                .setNegativeButton("Reset") { _, _ ->
                    adapter.updateItems(currentLoadedCategoryItems)
                }
                .show()
        }

        view.findViewById<TextView>(R.id.tabCatRecent)?.let { loadCategory(ShareItemType.RECENT, it) }

        btnSend?.setOnClickListener {
            if (allSelectedMap.isNotEmpty()) {
                val paths = allSelectedMap.values.map { it.path }
                val isParallel = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
                    .getBoolean("pref_share_is_parallel", true)
                FastShareManager.startSenderService(this, paths, isParallel)
                dialog.dismiss()
                showShareProgressDialog(isSender = true, filePaths = paths)
            } else {
                CleanToast.show(this, "Please select at least 1 file to send")
            }
        }

        val btnWebShare = view.findViewById<Button>(R.id.btnStartWebShare)
        btnWebShare?.setOnClickListener {
            if (allSelectedMap.isNotEmpty()) {
                val paths = allSelectedMap.values.map { it.path }
                dialog.dismiss()
                showWebShareDialog(paths)
            } else {
                CleanToast.show(this, "Please select at least 1 file to share via browser")
            }
        }

        dialog.show()
    }

    private var activeWebShareDialog: AlertDialog? = null
    private var backPressedOnce: Boolean = false

    private fun showWebShareDialog(paths: List<String>) {
        if (paths.isEmpty()) {
            CleanToast.show(this, "Please select at least 1 file to share via browser")
            return
        }

        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme).create()
        val view = layoutInflater.inflate(R.layout.dialog_share_webshare, null)
        dialog.setView(view)
        dialog.setCancelable(true)
        dialog.setOnDismissListener {
            activeWebShareDialog = null
            refreshShareTabUI()
        }
        activeWebShareDialog = dialog

        val tvSubheader = view.findViewById<TextView>(R.id.tvWebShareSubheader)
        val tabStep1 = view.findViewById<TextView>(R.id.tabWebShareStep1)
        val tabStep2 = view.findViewById<TextView>(R.id.tabWebShareStep2)
        val layoutStep1 = view.findViewById<LinearLayout>(R.id.layoutWebShareStep1)
        val layoutStep2 = view.findViewById<LinearLayout>(R.id.layoutWebShareStep2)

        val tvSsid = view.findViewById<TextView>(R.id.tvWebShareHotspotSsid)
        val tvPwd = view.findViewById<TextView>(R.id.tvWebShareHotspotPwd)
        val btnCopyPwd = view.findViewById<Button>(R.id.btnWebShareCopyPwd)
        val ivWifiQr = view.findViewById<ImageView>(R.id.ivWebShareWifiQrCode)
        val btnNextStep = view.findViewById<Button>(R.id.btnWebShareNextStep)

        val tvUrl = view.findViewById<TextView>(R.id.tvWebShareUrl)
        val btnCopyUrl = view.findViewById<Button>(R.id.btnWebShareCopyUrl)
        val ivUrlQr = view.findViewById<ImageView>(R.id.ivWebShareUrlQrCode)
        val btnPrevStep = view.findViewById<Button>(R.id.btnWebSharePrevStep)

        val tvStatus = view.findViewById<TextView>(R.id.tvWebShareStatus)
        val tvPercent = view.findViewById<TextView>(R.id.tvWebSharePercent)
        val tvSizeStats = view.findViewById<TextView>(R.id.tvWebShareSizeStats)
        val tvSpeed = view.findViewById<TextView>(R.id.tvWebShareSpeed)
        val pbProgress = view.findViewById<ProgressBar>(R.id.pbWebShareProgress)
        val btnStop = view.findViewById<Button>(R.id.btnWebShareStop)

        fun showStep(step: Int) {
            if (step == 1) {
                layoutStep1?.visibility = View.VISIBLE
                layoutStep2?.visibility = View.GONE
                tabStep1?.setBackgroundColor(Color.parseColor("#00E5FF"))
                tabStep1?.setTextColor(Color.BLACK)
                tabStep2?.setBackgroundColor(Color.TRANSPARENT)
                tabStep2?.setTextColor(Color.parseColor("#888899"))
                tvSubheader?.text = "Step 1 of 2 • Connect Device to Hotspot"
            } else {
                layoutStep1?.visibility = View.GONE
                layoutStep2?.visibility = View.VISIBLE
                tabStep1?.setBackgroundColor(Color.TRANSPARENT)
                tabStep1?.setTextColor(Color.parseColor("#888899"))
                tabStep2?.setBackgroundColor(Color.parseColor("#00E5FF"))
                tabStep2?.setTextColor(Color.BLACK)
                tvSubheader?.text = "Step 2 of 2 • Open in Browser"
            }
        }

        tabStep1?.setOnClickListener { showStep(1) }
        tabStep2?.setOnClickListener { showStep(2) }
        btnNextStep?.setOnClickListener { showStep(2) }
        btnPrevStep?.setOnClickListener { showStep(1) }

        tvUrl?.text = "Starting WebShare server..."
        tvSsid?.text = "Detecting Wi-Fi / Hotspot..."
        tvPwd?.text = "..."

        WebShareManager.onFileDownloadProgress = { fileName, percent, speedMb, transferred, total ->
            runOnUiThread {
                tvStatus?.text = "Transferring: $fileName"
                tvPercent?.text = "$percent%"
                tvSpeed?.text = "⚡ ${String.format("%.1f", speedMb)} MB/s"
                val transMb = String.format("%.1f MB", transferred / (1024f * 1024f))
                val totalMb = String.format("%.1f MB", total / (1024f * 1024f))
                tvSizeStats?.text = "$transMb / $totalMb"
                pbProgress?.progress = percent
            }
        }

        WebShareManager.onFileDownloadCompleted = { fileName ->
            runOnUiThread {
                tvStatus?.text = "✅ Completed: $fileName"
                tvSpeed?.text = "⚡ Done"
                tvPercent?.text = "100%"
                pbProgress?.progress = 100
                CleanToast.show(this, "File '$fileName' transferred successfully via WebShare!")
            }
        }

        val pbWifiLoading = view.findViewById<ProgressBar>(R.id.pbWebShareWifiLoading)
        val pbUrlLoading = view.findViewById<ProgressBar>(R.id.pbWebShareUrlLoading)

        WebShareManager.startWebShare(this, paths) { serverUrl, ssid, pwd ->
            runOnUiThread {
                tvUrl?.text = serverUrl
                if (ssid.isNotBlank()) {
                    tvSsid?.text = ssid
                    tvPwd?.text = pwd.ifBlank { "(No password)" }
                    showStep(1)
                } else {
                    tvSsid?.text = "Connected Wi-Fi / Local Network"
                    tvPwd?.text = "(Already Connected)"
                    showStep(2)
                }
            }

            // Generate QR codes on dedicated background thread so main thread NEVER lags or crashes
            Executors.newSingleThreadExecutor().execute {
                val wifiQr = if (ssid.isNotBlank()) {
                    QrCodeHelper.generateWifiQrCode(ssid, pwd, 512, 512)
                } else {
                    null
                }
                val urlQr = QrCodeHelper.generateQrBitmap(serverUrl, 512, 512)

                runOnUiThread {
                    if (wifiQr != null) {
                        ivWifiQr?.setImageBitmap(wifiQr)
                        ivWifiQr?.visibility = View.VISIBLE
                        pbWifiLoading?.visibility = View.GONE
                    } else {
                        showStep(2)
                    }
                    if (urlQr != null) {
                        ivUrlQr?.setImageBitmap(urlQr)
                        ivUrlQr?.visibility = View.VISIBLE
                        pbUrlLoading?.visibility = View.GONE
                    }
                    tvStatus?.text = if (ssid.isNotBlank()) {
                        "Ready • Step 1: Connect Wi-Fi, then Step 2: Open Browser"
                    } else {
                        "Ready • Open URL in Browser or Scan QR Code"
                    }
                }
            }
        }

        btnCopyPwd?.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = android.content.ClipData.newPlainText("Hotspot Password", tvPwd?.text ?: "")
            cm.setPrimaryClip(clip)
            CleanToast.show(this, "Password Copied!")
        }

        btnCopyUrl?.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val clip = android.content.ClipData.newPlainText("WebShare URL", tvUrl?.text ?: "")
            cm.setPrimaryClip(clip)
            CleanToast.show(this, "Copied: ${tvUrl?.text}")
        }

        btnStop?.setOnClickListener {
            WebShareManager.stopWebShare(this)
            dialog.dismiss()
            activeWebShareDialog = null
        }

        dialog.show()
    }

    private fun handleIncomingShareIntent(intent: Intent?) {
        if (intent == null) return
        val action = intent.action
        val type = intent.type ?: ""

        try {
            if (Intent.ACTION_SEND == action) {
                @Suppress("DEPRECATION")
                val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: intent.data
                if (uri != null) {
                    val title = PlayerHolder.resolveMediaTitle(this, uri, null)
                    val isVideo = !type.startsWith("audio/")
                    openPlayer(uri, title, isVideo, null)
                }
            } else if (Intent.ACTION_SEND_MULTIPLE == action) {
                @Suppress("DEPRECATION")
                val uris = intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                if (!uris.isNullOrEmpty()) {
                    val firstUri = uris[0]
                    val title = PlayerHolder.resolveMediaTitle(this, firstUri, null)
                    val isVideo = !type.startsWith("audio/")
                    openPlayer(firstUri, title, isVideo, null)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showShareReceiveDialog() {
        FastShareManager.startReceiverService(this, "192.168.49.1")
        showShareProgressDialog(isSender = false, filePaths = emptyList())
    }

    @Suppress("DEPRECATION")
    private fun showQrScannerDialog() {
        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme).create()
        val view = layoutInflater.inflate(R.layout.dialog_qr_scanner, null)
        dialog.setView(view)
        dialog.setCancelable(true)

        val surfaceView = view.findViewById<SurfaceView>(R.id.svCameraPreview)
        val tvStatus = view.findViewById<TextView>(R.id.tvScannerStatus)
        val pbConnecting = view.findViewById<ProgressBar>(R.id.pbScannerConnecting)
        val btnFlash = view.findViewById<Button>(R.id.btnScannerFlash)
        val btnWifiSettings = view.findViewById<Button>(R.id.btnScannerWifiSettings)
        val btnCancel = view.findViewById<Button>(R.id.btnScannerCancel)

        var camera: android.hardware.Camera? = null
        var isFlashOn = false
        var isScanned = false

        btnCancel.setOnClickListener { dialog.dismiss() }

        btnWifiSettings.setOnClickListener {
            dialog.dismiss()
            try {
                startActivity(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))
                CleanToast.show(this, "Connect to sender's hotspot, then tap Receive")
                showShareProgressDialog(isSender = false, filePaths = emptyList())
                FastShareManager.startReceiverService(this, "192.168.49.1")
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        btnFlash.setOnClickListener {
            try {
                val cam = camera ?: return@setOnClickListener
                val params = cam.parameters
                if (isFlashOn) {
                    params.flashMode = android.hardware.Camera.Parameters.FLASH_MODE_OFF
                    btnFlash.text = "Flash"
                    isFlashOn = false
                } else {
                    params.flashMode = android.hardware.Camera.Parameters.FLASH_MODE_TORCH
                    btnFlash.text = "Flash On"
                    isFlashOn = true
                }
                cam.parameters = params
            } catch (e: Exception) {}
        }

        surfaceView.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                try {
                    camera = android.hardware.Camera.open()
                    camera?.setDisplayOrientation(90)
                    camera?.setPreviewDisplay(holder)

                    val params = camera?.parameters
                    if (params?.supportedFocusModes?.contains(android.hardware.Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE) == true) {
                        params.focusMode = android.hardware.Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
                    }
                    try { camera?.parameters = params } catch (e: Exception) {}

                    val reader = MultiFormatReader()
                    val hints = mapOf(
                        DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
                        DecodeHintType.CHARACTER_SET to "UTF-8"
                    )
                    reader.setHints(hints)

                    var isDecoding = false

                    camera?.setPreviewCallback { data, cam ->
                        if (isScanned || isDecoding) return@setPreviewCallback
                        val size = cam.parameters.previewSize ?: return@setPreviewCallback
                        val w = size.width
                        val h = size.height

                        isDecoding = true
                        Executors.newSingleThreadExecutor().execute {
                            try {
                                val rotated = ByteArray(data.size)
                                for (y in 0 until h) {
                                    for (x in 0 until w) {
                                        rotated[x * h + h - y - 1] = data[x + y * w]
                                    }
                                }
                                val source = PlanarYUVLuminanceSource(
                                    rotated, h, w, 0, 0, h, w, false
                                )
                                val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
                                val result = reader.decodeWithState(binaryBitmap)
                                val text = result.text

                                if (!text.isNullOrBlank() && !isScanned) {
                                    isScanned = true
                                    runOnUiThread {
                                        pbConnecting.visibility = View.VISIBLE
                                        tvStatus.text = "QR Code Detected! Connecting..."
                                        dialog.dismiss()
                                        handleScannedWifiQr(text)
                                    }
                                }
                            } catch (e: Exception) {
                                // Keep scanning next frame
                            } finally {
                                reader.reset()
                                isDecoding = false
                            }
                        }
                    }
                    camera?.startPreview()
                } catch (e: Exception) {
                    e.printStackTrace()
                    tvStatus.text = "Camera preview unavailable"
                }
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                try {
                    camera?.setPreviewCallback(null)
                    camera?.stopPreview()
                    camera?.release()
                } catch (e: Exception) {}
                camera = null
            }
        })

        dialog.show()
    }

    private fun handleScannedWifiQr(qrText: String) {
        var ssid = ""
        var password = ""
        var hostIp = "192.168.43.1"

        try {
            val sMatch = Regex("S:([^;]+);").find(qrText)
            if (sMatch != null) ssid = sMatch.groupValues[1]

            val pMatch = Regex("P:([^;]+);").find(qrText)
            if (pMatch != null) password = pMatch.groupValues[1]

            val hMatch = Regex("H:([^;]+);").find(qrText)
            if (hMatch != null) hostIp = hMatch.groupValues[1]
        } catch (e: Exception) {
            e.printStackTrace()
        }

        CleanToast.show(this, "Connecting to sender: ${ssid.ifEmpty { "Hotspot" }}...")

        connectToSenderWifi(ssid, password) { isConnected, gatewayIp ->
            val targetHost = if (!gatewayIp.isNullOrBlank() && gatewayIp != "0.0.0.0") gatewayIp else hostIp
            FastShareManager.startReceiverService(this@MainActivity, targetHost)
            runOnUiThread {
                showShareProgressDialog(isSender = false, filePaths = emptyList())
            }
        }
    }

    private fun connectToSenderWifi(ssid: String, password: String, onConnected: ((Boolean, String?) -> Unit)? = null) {
        if (ssid.isBlank()) {
            onConnected?.invoke(false, null)
            return
        }

        var hasTriggered = false
        val triggerOnce = { success: Boolean, gateway: String? ->
            if (!hasTriggered) {
                hasTriggered = true
                onConnected?.invoke(success, gateway)
            }
        }

        // 3.5-second safety watchdog so receiver starts even if OS dialog was delayed or user connected manually
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            triggerOnce(true, null)
        }, 3500)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val specifierBuilder = WifiNetworkSpecifier.Builder()
                    .setSsid(ssid)
                if (password.isNotBlank()) {
                    specifierBuilder.setWpa2Passphrase(password)
                }
                val request = NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                    .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .setNetworkSpecifier(specifierBuilder.build())
                    .build()

                connectivityManager.requestNetwork(request, object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        super.onAvailable(network)
                        try {
                            connectivityManager.bindProcessToNetwork(network)
                        } catch (e: Exception) {}

                        var gatewayIp: String? = null
                        try {
                            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                            val dhcp = wm?.dhcpInfo
                            if (dhcp != null && dhcp.gateway != 0) {
                                gatewayIp = String.format("%d.%d.%d.%d", dhcp.gateway and 0xff, (dhcp.gateway shr 8) and 0xff, (dhcp.gateway shr 16) and 0xff, (dhcp.gateway shr 24) and 0xff)
                            } else if (dhcp != null && dhcp.serverAddress != 0) {
                                gatewayIp = String.format("%d.%d.%d.%d", dhcp.serverAddress and 0xff, (dhcp.serverAddress shr 8) and 0xff, (dhcp.serverAddress shr 16) and 0xff, (dhcp.serverAddress shr 24) and 0xff)
                            }
                        } catch (e: Exception) {}

                        triggerOnce(true, gatewayIp)
                    }

                    override fun onUnavailable() {
                        super.onUnavailable()
                        triggerOnce(false, null)
                    }
                })
            } else {
                @Suppress("DEPRECATION")
                val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val wifiConfig = WifiConfiguration().apply {
                    SSID = "\"" + ssid + "\""
                    preSharedKey = "\"" + password + "\""
                }
                @Suppress("DEPRECATION")
                val netId = wifiManager.addNetwork(wifiConfig)
                wifiManager.disconnect()
                wifiManager.enableNetwork(netId, true)
                wifiManager.reconnect()
                triggerOnce(true, null)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            triggerOnce(false, null)
        }
    }

    private fun showShareProgressDialog(isSender: Boolean, filePaths: List<String>) {
        if (activeShareProgressDialog?.isShowing == true) {
            try { activeShareProgressDialog?.dismiss() } catch (e: Exception) {}
        }

        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme).create()
        val view = layoutInflater.inflate(R.layout.dialog_share_progress, null)
        dialog.setView(view)
        dialog.setCancelable(true)

        activeShareProgressDialog = dialog
        dialog.setOnDismissListener {
            activeShareProgressDialog = null
            refreshShareTabUI()
        }

        val tvHeader = view.findViewById<TextView>(R.id.tvTransferHeader)
        val tvSubheader = view.findViewById<TextView>(R.id.tvTransferSubheader)
        val layoutQr = view.findViewById<View>(R.id.layoutQrContainer)
        val ivQr = view.findViewById<ImageView>(R.id.ivShareQrCode)
        val tvSpeed = view.findViewById<TextView>(R.id.tvTransferSpeed)
        val tvPercent = view.findViewById<TextView>(R.id.tvTransferPercent)
        val pbProgress = view.findViewById<ProgressBar>(R.id.pbTransferProgress)
        val tvFileName = view.findViewById<TextView>(R.id.tvTransferFileName)
        val tvBytes = view.findViewById<TextView>(R.id.tvTransferBytes)
        val btnMinimize = view.findViewById<Button>(R.id.btnMinimizeTransfer)
        val btnCancel = view.findViewById<Button>(R.id.btnCancelTransfer)

        val renderQr = { ssid: String, pwd: String, ip: String ->
            val pwdDisplay = if (pwd.isNotBlank()) " • Pass: $pwd" else ""
            tvSubheader.text = "Hotspot: $ssid$pwdDisplay • IP: $ip"
            val qrBitmap = QrCodeHelper.generateWifiQrCodeWithHost(ssid, pwd, ip, 8988, 512, 512)
            if (qrBitmap != null) {
                ivQr?.imageTintList = null
                ivQr?.colorFilter = null
                ivQr?.setImageBitmap(qrBitmap)
            }
        }

        if (isSender) {
            tvHeader.text = "Sending Files (5GHz Turbo)"
            tvSubheader.text = "Hotspot active • Ready to transfer"
            layoutQr.visibility = View.VISIBLE

            if (FastShareService.lastHotspotSsid.isNotBlank()) {
                renderQr(FastShareService.lastHotspotSsid, FastShareService.lastHotspotPassword, FastShareService.lastHotspotIp)
            }

            layoutQr.setOnClickListener {
                val pwdMsg = if (FastShareService.lastHotspotPassword.isNotBlank()) "\nPassword: ${FastShareService.lastHotspotPassword}" else ""
                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                    .setTitle("Wi-Fi Hotspot Connection Details")
                    .setMessage("Network (SSID): ${FastShareService.lastHotspotSsid.ifEmpty { "CleanPlayer Hotspot" }}$pwdMsg\nIP: ${FastShareService.lastHotspotIp}\n\nScan this QR code with any phone camera or Wi-Fi scanner to connect directly without typing password.")
                    .setPositiveButton("OK", null)
                    .show()
            }
        } else {
            tvHeader.text = "Receiving Files (5GHz Turbo)"
            tvSubheader.text = "Searching for 5GHz Hotspot..."
            layoutQr.visibility = View.GONE
        }

        if (FastShareService.isTransferActive.get() && FastShareService.currentFileName.isNotBlank()) {
            tvFileName.text = FastShareService.currentFileName
            tvPercent.text = "${FastShareService.currentProgressPercent}%"
            pbProgress.progress = FastShareService.currentProgressPercent
            tvSpeed.text = "⚡ ${String.format("%.1f", FastShareService.currentSpeedMb)} MB/s"
            val tMb = String.format("%.1f MB", FastShareService.currentTransferredBytes / (1024f * 1024f))
            val totMb = String.format("%.1f MB", FastShareService.currentTotalBytes / (1024f * 1024f))
            tvBytes?.text = "$tMb / $totMb"
        }

        FastShareService.onHotspotStarted = { ssid, pwd, ip, port ->
            runOnUiThread {
                renderQr(ssid, pwd, ip)
            }
        }

        FastShareService.onTransferProgressUpdate = { fileName, percent, speedMb, transferred, total, isCompleted ->
            runOnUiThread {
                tvFileName.text = fileName
                tvPercent.text = "$percent%"
                pbProgress.progress = percent
                tvSpeed.text = "⚡ ${String.format("%.1f", speedMb)} MB/s"
                val tMb = String.format("%.1f MB", transferred / (1024f * 1024f))
                val totMb = String.format("%.1f MB", total / (1024f * 1024f))
                tvBytes?.text = "$tMb / $totMb"

                if (FastShareService.isTransferActive.get()) {
                    cardActiveTransferBanner?.visibility = View.VISIBLE
                    tvActiveBannerTitle?.text = if (FastShareService.isSenderMode) "⚡ Sending in Background..." else "⚡ Receiving in Background..."
                    tvActiveBannerSpeed?.text = "${String.format("%.1f", speedMb)} MB/s"
                    pbActiveBannerProgress?.progress = percent
                    tvActiveBannerFileName?.text = "$fileName ($percent%) • $tMb / $totMb"
                }

                if (isCompleted) {
                    tvSubheader.text = "Transfer Complete!"
                    btnCancel.text = "Done"
                    btnMinimize?.visibility = View.GONE
                    cardActiveTransferBanner?.visibility = View.GONE
                    refreshShareTabUI()
                }
            }
        }

        FastShareService.onTransferError = { err ->
            runOnUiThread {
                tvSubheader.text = err
            }
        }

        btnMinimize?.setOnClickListener {
            dialog.dismiss()
            
            refreshShareTabUI()
        }

        btnCancel.setOnClickListener {
            if (FastShareService.isTransferActive.get()) {
                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                    .setTitle("Cancel Transfer?")
                    .setMessage("Kya aap transfer cancel karna chahte hain?")
                    .setPositiveButton("Stop Transfer") { _, _ ->
                        FastShareManager.stopTransferService(this)
                        dialog.dismiss()
                        refreshShareTabUI()
                    }
                    .setNegativeButton("Keep Running", null)
                    .show()
            } else {
                dialog.dismiss()
                refreshShareTabUI()
            }
        }

        dialog.show()
    }

    private fun showShareSettingsBottomSheet() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_share_settings, null)
        dialog.setContentView(view)

        view.findViewById<View>(R.id.btnShareSettingsClose)?.setOnClickListener { dialog.dismiss() }

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)

        // 1. Band
        val tvBand = view.findViewById<TextView>(R.id.tvShareBandVal)
        tvBand?.text = ytPrefs.getString("pref_share_band", "5GHz High-Speed Band (Recommended)")
        view.findViewById<View>(R.id.rowShareBand)?.setOnClickListener {
            val bands = arrayOf("5GHz High-Speed Band (Recommended)", "2.4GHz Compatibility Mode")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Hotspot Frequency Band")
                .setItems(bands) { _, which ->
                    val chosen = bands[which]
                    ytPrefs.edit().putString("pref_share_band", chosen).apply()
                    tvBand?.text = chosen
                    refreshShareTabUI()
                }
                .show()
        }

        // 2. Transfer Mode (Parallel vs Sequential)
        val tvMode = view.findViewById<TextView>(R.id.tvShareTransferModeVal)
        val curParallel = ytPrefs.getBoolean("pref_share_is_parallel", true)
        tvMode?.text = if (curParallel) "⚡ Multi Parallel Streams (Fastest for Batch Files)" else "🎯 One-by-One Sequential (Best for Large Movies)"
        view.findViewById<View>(R.id.rowShareTransferMode)?.setOnClickListener {
            val modes = arrayOf(
                "⚡ Multi Parallel Streams (Fastest for Batch Files)",
                "🎯 One-by-One Sequential (Best for Large Movies)"
            )
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Transfer Queue Mode")
                .setSingleChoiceItems(modes, if (curParallel) 0 else 1) { d, which ->
                    val isPar = (which == 0)
                    ytPrefs.edit().putBoolean("pref_share_is_parallel", isPar).apply()
                    tvMode?.text = modes[which]
                    d.dismiss()
                }
                .show()
        }

        // 3. Storage Save Directory
        val tvSaveDir = view.findViewById<TextView>(R.id.tvShareSaveDirVal)
        tvSaveDir?.text = FastShareManager.getSaveDirectoryDisplayName(this)
        view.findViewById<View>(R.id.rowShareSaveDir)?.setOnClickListener {
            val presetFolders = arrayOf(
                "Download/CleanPlayer (Default)",
                "Movies/CleanPlayer",
                "Music/CleanPlayer",
                "DCIM/CleanPlayer",
                "Documents/CleanPlayer",
                "Custom Folder..."
            )
            val currentDir = ytPrefs.getString("pref_share_save_dir", "Download/CleanPlayer") ?: "Download/CleanPlayer"
            var selectedIdx = when (currentDir) {
                "Download/CleanPlayer" -> 0
                "Movies/CleanPlayer" -> 1
                "Music/CleanPlayer" -> 2
                "DCIM/CleanPlayer" -> 3
                "Documents/CleanPlayer" -> 4
                else -> 5
            }

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Storage Save Location")
                .setSingleChoiceItems(presetFolders, selectedIdx) { dialogInterface, which ->
                    if (which == 5) {
                        dialogInterface.dismiss()
                        val customInput = EditText(this).apply {
                            hint = "e.g. Download/Shared"
                            setText(currentDir)
                            setSingleLine()
                            setTextColor(Color.WHITE)
                        }
                        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                            .setTitle("Enter Folder Name")
                            .setView(customInput)
                            .setPositiveButton("Save") { _, _ ->
                                val customPath = customInput.text.toString().trim()
                                if (customPath.isNotBlank()) {
                                    FastShareManager.setSaveDirectory(this, customPath)
                                    tvSaveDir?.text = FastShareManager.getSaveDirectoryDisplayName(this)
                                }
                            }
                            .setNegativeButton("Cancel", null)
                            .show()
                    } else {
                        val chosenFolder = when (which) {
                            0 -> "Download/CleanPlayer"
                            1 -> "Movies/CleanPlayer"
                            2 -> "Music/CleanPlayer"
                            3 -> "DCIM/CleanPlayer"
                            4 -> "Documents/CleanPlayer"
                            else -> "Download/CleanPlayer"
                        }
                        FastShareManager.setSaveDirectory(this, chosenFolder)
                        tvSaveDir?.text = FastShareManager.getSaveDirectoryDisplayName(this)
                        dialogInterface.dismiss()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 4. Device Display Name
        val tvDevice = view.findViewById<TextView>(R.id.tvShareDeviceNameVal)
        val curName = ytPrefs.getString("pref_share_device_name", "CleanPlayer (" + Build.MODEL + ")") ?: "CleanPlayer"
        tvDevice?.text = curName
        view.findViewById<View>(R.id.rowShareDeviceName)?.setOnClickListener {
            val input = EditText(this).apply {
                setText(curName)
                setSingleLine()
                setTextColor(Color.WHITE)
            }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Device Display Name")
                .setView(input)
                .setPositiveButton("Save") { _, _ ->
                    val newName = input.text.toString().trim()
                    if (newName.isNotBlank()) {
                        ytPrefs.edit().putString("pref_share_device_name", newName).apply()
                        tvDevice?.text = newName
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 5. Clear History
        view.findViewById<View>(R.id.rowShareClearHistory)?.setOnClickListener {
            ShareHistoryManager.clearHistory(this)
            refreshShareTabUI()
            dialog.dismiss()
        }

        dialog.show()
    }

    companion object {
        init {
            androidx.appcompat.app.AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        }
    }


    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnToolbarSearch: ImageButton
    private lateinit var btnToolbarSort: ImageButton
    private lateinit var btnToolbarOpen: ImageButton
    private lateinit var fabPlay: FloatingActionButton
    private lateinit var etSearch: EditText
    private lateinit var tabVideo: LinearLayout
    private lateinit var tabAudio: LinearLayout
    private lateinit var tabSettings: NestedScrollView
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var tabYouTube: FrameLayout
    private lateinit var layoutYtMainFeed: LinearLayout
        // YouTube Dedicated Settings Controls
    private lateinit var tvYtAdBlockStatus: TextView
    private lateinit var btnToggleYtAdBlock: Button
    private lateinit var tvYtSponsorBlockStatus: TextView
    private lateinit var btnConfigSponsorBlock: Button
    private lateinit var tvYtDefaultQualityStatus: TextView
    private lateinit var btnChangeYtQuality: Button
    private lateinit var tvYtExtractorBridgeStatus: TextView
    private lateinit var btnChangeYtExtractorBridge: Button
    private lateinit var tvYtClientSpoofingStatus: TextView
    private lateinit var btnChangeYtClient: Button
    private lateinit var tvYtBgAudioStatus: TextView
    private lateinit var btnToggleYtBgAudio: Button
    private lateinit var tvYtInterfaceStatus: TextView
    private lateinit var btnConfigYtUI: Button
    private lateinit var tvYtAccountStatus: TextView
    private lateinit var btnManageYtAccount: Button
    private lateinit var tvYtExtractorOtaStatus: TextView
    private lateinit var btnSyncYtExtractorOta: Button
    private lateinit var nsvYtFeed: NestedScrollView
    private lateinit var rvYouTubeFeed: RecyclerView
    private lateinit var rvYouTubeFeedSecondary: RecyclerView
    private lateinit var srlYouTubeFeed: androidx.swiperefreshlayout.widget.SwipeRefreshLayout
    private lateinit var pbYtFeedLoading: ProgressBar
    private lateinit var layoutYtEmpty: LinearLayout
    private lateinit var btnYtRetry: Button
    private lateinit var btnYtSearch: ImageButton
    private lateinit var btnYtAccount: ImageButton
    private lateinit var btnYtCast: ImageButton
    private lateinit var btnYtNotifications: ImageButton
    private lateinit var layoutYtSearchBar: LinearLayout
    private lateinit var etYtSearchQuery: EditText
    private lateinit var btnYtCloseSearch: ImageButton
    private lateinit var chipYtAll: TextView
    private lateinit var chipYtMusic: TextView
    private lateinit var chipYtGaming: TextView
    private lateinit var chipYtPodcasts: TextView
    private lateinit var chipYtLive: TextView
    private lateinit var chipYtTrending: TextView
    private lateinit var chipYtNews: TextView
        // YouTube You Tab & Fullscreen Fields
    private lateinit var rvYtHistory: RecyclerView
    private lateinit var rvYtDownloads: RecyclerView
    private var ytHistoryAdapter: YouTubeHistoryAdapter? = null
    private var ytDownloadsAdapter: YouTubeHistoryAdapter? = null
    private var isYtFullscreen = false
    // YouTube Overlay Controls Views (1:1 with Official YouTube)
    private lateinit var pbYtBottomMiniProgress: ProgressBar
    private lateinit var layoutYtPlayerOverlay: RelativeLayout
    private var btnYtAudioMode: ImageButton? = null
    private lateinit var layoutYtAudioModeVisual: LinearLayout
    private lateinit var ivYtAudioModeThumb: ImageView
    private lateinit var btnYtPlayerCC: ImageButton
    private lateinit var btnYtRewind10: ImageButton
    private lateinit var btnYtForward10: ImageButton
    private lateinit var tvYtPlayerCurrentTime: TextView
    private lateinit var sbYtPlayer: SeekBar
    private var isYtUserSeeking = false
    private var isYtAutoplayEnabled = true
    private val ytOverlayHandler = Handler(Looper.getMainLooper())
    private val ytOverlayHideRunnable = Runnable {
        if (YouTubeExoPlayerManager.isPlaying()) {
            layoutYtPlayerOverlay.animate()
                .alpha(0f)
                .setDuration(250)
                .withEndAction {
                    layoutYtPlayerOverlay.visibility = View.GONE
                    layoutYtPlayerOverlay.alpha = 1f
                }
                .start()
        }
    }

    private lateinit var youTubeFeedAdapter: YouTubeFeedAdapter
    private lateinit var youTubeFeedSecondaryAdapter: YouTubeFeedAdapter
    private var currentYtCategory: String = "All"
    private var isYtFeedLoaded = false
    private var lastActiveTabId = R.id.nav_video

    // YouTube Dedicated Bottom Nav
    private lateinit var btnYtNavHome: LinearLayout
    private lateinit var btnYtNavSubs: LinearLayout
    private lateinit var btnYtNavLibrary: LinearLayout

    // YouTube Portrait Detail Player (Matching Screenshot 5681.jpg)
    private lateinit var layoutYtPlayerDetail: LinearLayout
    private lateinit var playerViewYt: androidx.media3.ui.PlayerView
    private lateinit var pbYtBuffering: ProgressBar
    private lateinit var btnYtCenterPlayPause: ImageButton
    private lateinit var btnYtCollapsePlayer: ImageButton
    private lateinit var btnYtFullscreen: ImageButton
    private lateinit var tvYtDetailTitle: TextView
    private lateinit var tvYtDetailSubtitle: TextView
    private lateinit var ivYtDetailAvatar: ImageView
    private lateinit var tvYtDetailChannel: TextView
    private lateinit var btnYtSubscribe: TextView
    private lateinit var layoutYtLikePill: LinearLayout
    private lateinit var tvYtDetailLikes: TextView
    private lateinit var layoutYtSharePill: LinearLayout
    private lateinit var layoutYtDownloadPill: LinearLayout
    private lateinit var tvYtDownloadPill: TextView
    private lateinit var ivYtDownloadPill: ImageView
    private lateinit var tvYtAudioQualityStatus: TextView
    private lateinit var btnChangeYtAudioQuality: Button
    private lateinit var tvYtBufferLimitStatus: TextView
    private lateinit var btnChangeYtBufferLimit: Button



    // Audio Mode Visualizer View
    private lateinit var ytAudioVisualizerView: AudioVisualizerView
    private var ytMiniAudioVisualizerView: AudioVisualizerView? = null
    private var btnYtPrevVideo: ImageButton? = null
    private var btnYtNextVideo: ImageButton? = null
    private var btnYtVideoBoost: TextView? = null
    private var layoutYtGestureOverlay: View? = null
    private var ivYtGestureIcon: ImageView? = null
    private var tvYtGestureText: TextView? = null
    private val ytGestureHideHandler = Handler(Looper.getMainLooper())
    private val ytGestureHideRunnable = Runnable {
        layoutYtGestureOverlay?.visibility = View.GONE
    }

    private fun showYtGestureFeedback(iconRes: Int, text: String) {
        layoutYtGestureOverlay?.bringToFront()
        layoutYtGestureOverlay?.visibility = View.VISIBLE
        ivYtGestureIcon?.setImageResource(iconRes)
        tvYtGestureText?.text = text
        ytGestureHideHandler.removeCallbacks(ytGestureHideRunnable)
        ytGestureHideHandler.postDelayed(ytGestureHideRunnable, 1200)
    }
    private var isYtLoadingMore = false
    private val allYtFeedVideos = mutableListOf<YouTubeVideo>()

    private val ytVisualizerHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val ytVisualizerRunnable = object : Runnable {
        override fun run() {
            val ytPlayer = YouTubeExoPlayerManager.exoPlayer
            if (ytPlayer != null && ytPlayer.isPlaying) {
                val cur = ytPlayer.currentPosition
                val dur = ytPlayer.duration
                if (::layoutYtAudioModeVisual.isInitialized && layoutYtAudioModeVisual.visibility == View.VISIBLE) {
                    ytAudioVisualizerView.onPlaybackProgress(cur, dur)
                }
                if (::cardYtMiniPlayer.isInitialized && cardYtMiniPlayer.visibility == View.VISIBLE && ytMiniAudioVisualizerView?.visibility == View.VISIBLE) {
                    ytMiniAudioVisualizerView?.onPlaybackProgress(cur, dur)
                }
            }
            ytVisualizerHandler.postDelayed(this, 100)
        }
    }

    private val ytMediaReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "com.cleanplayer.app.ACTION_YT_PLAY_NEXT" -> playNextYouTubeVideo()
                "com.cleanplayer.app.ACTION_YT_PLAY_PREV" -> playPreviousYouTubeVideo()
            }
        }
    }
    private lateinit var layoutYtSavePill: LinearLayout
    private lateinit var layoutYtCommentsCard: LinearLayout
    private lateinit var tvYtDetailCommentsCount: TextView
    private lateinit var rvYtRelatedVideos: RecyclerView

    // YouTube Floating Miniplayer (Matching Screenshots 5682.jpg & 5680.jpg)
    private lateinit var cardYtMiniPlayer: MaterialCardView
    private lateinit var ivYtMiniThumb: ImageView
    private lateinit var tvYtMiniTitle: TextView
    private lateinit var tvYtMiniChannel: TextView
    private lateinit var btnYtMiniPlayPause: ImageButton
    private lateinit var btnYtMiniClose: ImageButton
    private lateinit var layoutYtMiniControlsOverlay: View
    private lateinit var btnYtMiniExpand: ImageButton
    private val ytMiniControlsHideHandler = Handler(Looper.getMainLooper())
    private val ytMiniControlsHideRunnable = Runnable {
        if (::layoutYtMiniControlsOverlay.isInitialized) {
            layoutYtMiniControlsOverlay.visibility = View.GONE
        }
    }
    private lateinit var playerViewYtMini: androidx.media3.ui.PlayerView
    private lateinit var ytScaleGestureDetector: ScaleGestureDetector
    private var ytAspectRatioMode = 0 // 0: Fit, 1: Zoom to fill, 2: Stretch
    private var isYtPinchActive = false

    private var currentPlayingYtVideo: YouTubeVideo? = null
    private var isYtVideoPlaying: Boolean = false

    private lateinit var btnViewAllVideos: TextView
    private lateinit var btnViewFolders: TextView
    private lateinit var rvVideos: RecyclerView
    private lateinit var layoutFoldersContainer: LinearLayout
    private lateinit var rvFolders: RecyclerView
    private lateinit var layoutFolderDetailHeader: LinearLayout
    private lateinit var btnFolderBack: ImageButton
    private lateinit var tvFolderHeaderTitle: TextView
    private lateinit var tvFolderHeaderSubtitle: TextView
    private lateinit var rvFolderVideos: RecyclerView
    private lateinit var layoutEmptyVideo: LinearLayout
    private lateinit var btnBrowseVideo: Button

    private var isFolderViewActive: Boolean = false
    private var allFolders: List<MediaFolder> = emptyList()
    private var currentSelectedFolder: MediaFolder? = null
    private var folderAdapter: FolderAdapter? = null
    private var folderVideoAdapter: MediaAdapter? = null

    private lateinit var rvAudio: RecyclerView
    private lateinit var layoutEmptyAudio: LinearLayout
    private lateinit var btnBrowseAudio: Button

    // 0. AI Smart Suite & Performance Views
    private lateinit var tvPerformanceModeStatus: TextView
    private lateinit var tvSettingAiKaraokeStatus: TextView
    private lateinit var btnToggleSettingAiKaraoke: Button
    private lateinit var tvSettingAiAutoEqStatus: TextView
    private lateinit var btnToggleSettingAiAutoEq: Button
    private lateinit var tvSettingAiSilenceStatus: TextView
    private lateinit var btnToggleSettingAiSilence: Button
    private lateinit var tvSettingAiLyricsStatus: TextView
    private lateinit var btnToggleSettingAiLyrics: Button
    private lateinit var tvSettingSpeechToTextStatus: TextView
    private lateinit var btnToggleSettingSpeechToText: Button
    private lateinit var tvSettingAutoEmbedLrcStatus: TextView
    private lateinit var btnToggleSettingAutoEmbedLrc: Button
    private lateinit var tvSettingWordSyncStatus: TextView
    private lateinit var btnToggleSettingWordSync: Button
    private lateinit var tvSettingAiProfilerStatus: TextView
    private lateinit var btnViewSettingAiProfiler: Button
    private lateinit var btnChangePerformanceMode: Button
    private lateinit var tvAiSmartTransitionStatus: TextView
    private lateinit var btnToggleAiSmartTransition: Button
    private lateinit var tvAiTopicPreferencesStatus: TextView
    private lateinit var btnChangeAiTopics: Button
    private lateinit var tvAiDialogueBoostStatus: TextView
    private lateinit var btnToggleAiDialogueBoost: Button
    private lateinit var tvAiSponsorBlockStatus: TextView
    private lateinit var btnConfigAiSponsorBlock: Button
    private lateinit var tvAiModelSyncStatus: TextView
    private lateinit var btnSyncAiModel: Button
    private lateinit var tvAiOnDemandModelStatus: TextView
    private lateinit var btnManageAiNeuralModel: Button

    // 1. Video Settings Views
    private lateinit var tvSettingAiVideoBoostStatus: TextView
    private lateinit var btnToggleSettingAiVideoBoost: Button
    private lateinit var tvSettingAiSmartChaptersStatus: TextView
    private lateinit var btnToggleSettingAiSmartChapters: Button
    private lateinit var tvSettingAiNightVisionStatus: TextView
    private lateinit var btnToggleSettingAiNightVision: Button
    private lateinit var tvHighRefreshRateStatus: TextView
    private lateinit var btnToggleHighRefreshRate: Button
    private lateinit var tvDefaultOrientationStatus: TextView
    private lateinit var btnChangeOrientation: Button

    // Top Notch Mini-Player Views (matches 5203.jpg)
    private lateinit var cardNotchPlayer: MaterialCardView
    private lateinit var ivNotchIcon: ImageView
    private lateinit var tvNotchTitle: TextView
    private lateinit var tvNotchArtist: TextView
    private lateinit var btnNotchClose: ImageButton
    private lateinit var btnNotchRepeat: ImageButton
    private lateinit var btnNotchPrev: ImageButton
    private lateinit var btnNotchPlayPause: ImageButton
    private lateinit var btnNotchNext: ImageButton
    private lateinit var btnNotchOpen: ImageButton
    private lateinit var tvNotchCurrent: TextView
    private lateinit var sbNotch: SeekBar
    private lateinit var tvNotchTotal: TextView
    private lateinit var tvWideColorStatus: TextView
    private lateinit var btnToggleWideColor: Button
    private lateinit var tvDeblockingStatus: TextView
    private lateinit var btnToggleDeblocking: Button
    private lateinit var tvAutoScreenOffStatus: TextView
    private lateinit var btnToggleAutoScreenOff: Button

    // Auto Screen-Off Battery Saver for YouTube & Main
    private var isYtScreenOffDimmed = false
    private var savedYtScreenBrightness = -1f
    private val autoScreenOffYtHandler = Handler(Looper.getMainLooper())
    private val autoScreenOffYtRunnable = Runnable { applyAutoScreenOffYt() }

    private fun scheduleAutoScreenOffYt(delayMs: Long = (PlayerHolder.autoScreenOffTimeoutMinutes * 60 * 1000L).coerceAtLeast(5000L)) {
        if (!PlayerHolder.isAutoScreenOffEnabled) return
        autoScreenOffYtHandler.removeCallbacks(autoScreenOffYtRunnable)
        autoScreenOffYtHandler.postDelayed(autoScreenOffYtRunnable, delayMs)
    }

    private fun cancelAutoScreenOffYt() {
        autoScreenOffYtHandler.removeCallbacks(autoScreenOffYtRunnable)
        if (isYtScreenOffDimmed) {
            isYtScreenOffDimmed = false
            runOnUiThread {
                try {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    if (savedYtScreenBrightness >= 0f) {
                        val lp = window.attributes
                        lp.screenBrightness = savedYtScreenBrightness
                        window.attributes = lp
                    }
                } catch (e: Exception) {}
            }
        }
    }

    private fun applyAutoScreenOffYt() {
        if (!PlayerHolder.isAutoScreenOffEnabled) return
        isYtScreenOffDimmed = true
        runOnUiThread {
            try {
                if (savedYtScreenBrightness < 0f) {
                    val cur = window.attributes.screenBrightness
                    savedYtScreenBrightness = if (cur >= 0f) cur else 0.5f
                }
                updateScreenWakeLock(false)
                val lp = window.attributes
                lp.screenBrightness = 0.01f
                window.attributes = lp
            } catch (e: Exception) {}
        }
    }
    private lateinit var tvHwDecodeStatus: TextView
    private lateinit var btnChangeHw: Button
    private lateinit var tvBgPipStatus: TextView
    private lateinit var btnChangeBgPip: Button
    private lateinit var tvResumeModeStatus: TextView
    private lateinit var btnChangeResumeMode: Button
    private lateinit var tvDoubleTapStatus: TextView
    private lateinit var btnChangeDoubleTap: Button
    private lateinit var tvAspectRatioStatus: TextView
    private lateinit var btnChangeAspectRatio: Button
    private lateinit var tvAudioBoostStatus: TextView
    private lateinit var btnToggleAudioBoost: Button

    // 2. Integrated Dolby, Spatial & Equalizer Audio Suite Views
    private lateinit var tvMasterProfileStatus: TextView
    private lateinit var btnChangeMasterProfile: Button
    private lateinit var tvDolbySurroundStatus: TextView
    private lateinit var btnChangeDolbySurround: Button
    private lateinit var tvEqualizerStatus: TextView
    private lateinit var btnChangeEqualizer: Button
    private lateinit var tvDialogueBoostStatus: TextView
    private lateinit var btnToggleDialogueBoost: Button
    private lateinit var tvDigitalPassthroughStatus: TextView
    private lateinit var btnTogglePassthrough: Button
    private lateinit var tvAudioOutputStatus: TextView
    private lateinit var btnChangeAudioOutput: Button
    private lateinit var tvHeadsetPauseStatus: TextView
    private lateinit var btnToggleHeadsetPause: Button
    private lateinit var tvTimeStretchStatus: TextView
    private lateinit var btnToggleTimeStretch: Button

    // 3. Subtitle Settings Views
    private lateinit var btnToggleSubAutoload: Button
    private lateinit var tvSubSizeStatus: TextView
    private lateinit var btnChangeSubSize: Button
    private lateinit var tvSubColorStatus: TextView
    private lateinit var btnChangeSubColor: Button
    private lateinit var tvSubBackgroundStatus: TextView
    private lateinit var btnChangeSubBackground: Button
    private lateinit var tvSubStyleStatus: TextView
    private lateinit var btnToggleSubStyle: Button
    private lateinit var tvSubEncodingStatus: TextView
    private lateinit var btnChangeSubEncoding: Button

    // 4. Gestures Settings Views
    private lateinit var tvGestureVolumeStatus: TextView
    private lateinit var btnToggleGestureVolume: Button
    private lateinit var tvGestureBrightnessStatus: TextView
    private lateinit var btnToggleGestureBrightness: Button
    private lateinit var tvGestureSeekStatus: TextView
    private lateinit var btnToggleGestureSeek: Button
    private lateinit var tvFastSeekStatus: TextView
    private lateinit var btnToggleFastSeek: Button

    // 5. Interface Settings Views
    private lateinit var tvAppThemeStatus: TextView
    private lateinit var btnChangeAppTheme: Button

    // 6. Advanced Settings Views
    private lateinit var btnClearCache: Button
    private lateinit var btnClearResume: Button
    private lateinit var btnResetSettings: Button
    private lateinit var tvCacheSizeStatus: TextView

    private var allVideos = listOf<MediaItem>()
    private var allAudio = listOf<MediaItem>()
    private var videoAdapter: MediaAdapter? = null
    private var audioAdapter: MediaAdapter? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val title = PlayerHolder.resolveMediaTitle(this, it, null)
            val type = contentResolver.getType(it) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(it, title, isVideo, null)
        }
    }

    private val csvImportLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                val text = contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() } ?: ""
                val count = YouTubeSubscriptionManager.importFromCsv(this, text)
                CleanToast.show(this, "Imported $count channels successfully!")
                loadSubscriptionsFeed()
            } catch (e: Exception) {
                CleanToast.show(this, "Failed to import file: ${e.message}")
            }
        }
    }

    private val subtitlePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            // Silent notification removed
        }
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        loadMediaFiles()
    }

    private var pendingCameraAction: (() -> Unit)? = null
    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            pendingCameraAction?.invoke()
        } else {
            CleanToast.show(this, "Camera permission needed to scan sender's QR code")
            showShareReceiveDialog()
        }
        pendingCameraAction = null
    }

    private fun checkCameraPermissionAndScan(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            onGranted()
        } else {
            pendingCameraAction = onGranted
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private var pendingShareAction: (() -> Unit)? = null
    private val sharePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val nearbyGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions[Manifest.permission.NEARBY_WIFI_DEVICES] ?: (ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED)
        } else true
        val locationGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (nearbyGranted || locationGranted) {
            pendingShareAction?.invoke()
        } else {
            CleanToast.show(this, "Nearby devices permission required for 5GHz P2P Share")
        }
        pendingShareAction = null
    }

    private fun checkSharePermissionsAndRun(action: () -> Unit) {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_IMAGES)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (needed.isNotEmpty()) {
            pendingShareAction = action
            sharePermissionLauncher.launch(needed.toTypedArray())
        } else {
            action()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        PlayerHolder.loadPreferences(this)
        if (PlayerHolder.isMonochrome()) {
            setTheme(R.style.Theme_Multimedia_Monochrome)
        } else {
            setTheme(R.style.Theme_Multimedia)
        }
        super.onCreate(savedInstanceState)
        ChannelAvatarManager.init(this)
        applyHighRefreshRate()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        setContentView(R.layout.activity_main)

        // Initialize Downloader instance
        try {
            DynamicExtractorOtaEngine.initialize(this)
        } catch (e: Throwable) {}

        // Auto-detect hardware profile (Moto Edge 60 Fusion, 12GB RAM, Adreno GPU, etc.)
        try {
            HardwareProfilerEngine.applyAutoSetup(this, false)
        } catch (e: Throwable) {}

        onBackPressedDispatcher.addCallback(this) {
            handleBackPress()
        }

        initViews()
        setupBottomNav()
        setupSearch()
        applyThemeUI()
        applyAppWideImmersiveMode()

        // Ultra-Fast Cold Start Optimization:
        // Defer non-critical tabs (Share, Settings 6-screen suite) until immediately after the first frame renders.
        window.decorView.post {
            if (isFinishing || isDestroyed) return@post
            ensureShareInitialized()
            ensureSettingsInitialized()
            if (::tabShare.isInitialized) {
                refreshShareTabUI()
            }
            if (intent?.getStringExtra("OPEN_TAB") == "SHARE") {
                intent?.removeExtra("OPEN_TAB")
                showTab(video = false, audio = false, youtube = false, share = true, settings = false)
                bottomNav.selectedItemId = R.id.nav_share
                if (FastShareService.isTransferActive.get() && (activeShareProgressDialog == null || activeShareProgressDialog?.isShowing == false)) {
                    showShareProgressDialog(isSender = FastShareService.isSenderMode, filePaths = emptyList())
                }
            }
        }

        ViewCompat.setOnApplyWindowInsetsListener(window.decorView.findViewById(android.R.id.content)) { _, insets ->
            val navInsets = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            val bottomInset = if (isYtFullscreen) 0 else navInsets.bottom

            findViewById<View>(R.id.bottomNav)?.setPadding(0, 0, 0, bottomInset)
            findViewById<View>(R.id.layoutYtBottomBar)?.setPadding(0, 0, 0, bottomInset)

            if (::cardYtMiniPlayer.isInitialized) {
                val miniLp = cardYtMiniPlayer.layoutParams as? FrameLayout.LayoutParams
                if (miniLp != null) {
                    val baseMargin = (68 * resources.displayMetrics.density).toInt()
                    miniLp.bottomMargin = baseMargin + bottomInset
                    cardYtMiniPlayer.layoutParams = miniLp
                }
            }
            insets
        }

        val filter = android.content.IntentFilter().apply {
            addAction("com.cleanplayer.app.ACTION_YT_PLAY_NEXT")
            addAction("com.cleanplayer.app.ACTION_YT_PLAY_PREV")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(ytMediaReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(ytMediaReceiver, filter)
        }

        val ytPrefsInit = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        isYtAutoplayEnabled = ytPrefsInit.getBoolean("pref_yt_autoplay", true)
        YouTubeExoPlayerManager.onVideoEnded = {
            if (PlayerHolder.isSleepAtEndOfMedia) {
                PlayerHolder.isSleepAtEndOfMedia = false
                YouTubeExoPlayerManager.pause()
                runOnUiThread {
                    CleanToast.show(this, "Sleep timer: Paused at end of video")
                }
                scheduleAutoScreenOffYt(5000L)
            } else if (isYtAutoplayEnabled) {
                playNextYouTubeVideo()
            } else {
                scheduleAutoScreenOffYt(5000L)
            }
        }

        checkAndRequestPermissions()

        val openFullPlayer = {
            val uri = PlayerHolder.currentUri
            if (uri != null) {
                openPlayer(uri, PlayerHolder.currentTitle, isVideo = !PlayerHolder.isAudioOnly, path = PlayerHolder.currentPath)
            }
        }
        cardNotchPlayer.setOnClickListener {
            if (isLocalMediaActive()) {
                openFullPlayer()
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                showTab(video = false, audio = false, youtube = true, settings = false)
                layoutYtPlayerDetail.visibility = View.VISIBLE
                if (::playerViewYtMini.isInitialized) {
                    YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
                }
                YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
                applyYouTubeAspectRatio(ytAspectRatioMode)
                if (YouTubeExoPlayerManager.isAudioOnlyMode) {
                    YouTubeExoPlayerManager.switchToVideo(this)
                }
            }
        }
        btnNotchOpen.setOnClickListener {
            if (isLocalMediaActive()) {
                openFullPlayer()
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                showTab(video = false, audio = false, youtube = true, settings = false)
                layoutYtPlayerDetail.visibility = View.VISIBLE
                YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
            }
        }

        btnNotchPlayPause.setOnClickListener {
            if (isLocalMediaActive()) {
                val audioPlayer = PlayerHolder.audioExoPlayer
                if (audioPlayer != null) {
                    if (audioPlayer.isPlaying) audioPlayer.pause() else audioPlayer.play()
                    btnNotchPlayPause.setImageResource(
                        if (audioPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                    MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = audioPlayer.isPlaying)
                } else {
                    PlayerHolder.mediaPlayer?.let { player ->
                        if (player.isPlaying) {
                            player.pause()
                            btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_play)
                            MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = false)
                        } else {
                            player.play()
                            btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_pause)
                            MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = true)
                        }
                    }
                }
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                YouTubeExoPlayerManager.togglePlayPause()
                val isPlaying = YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
                btnNotchPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            }
        }

        btnNotchPrev.setOnClickListener {
            if (isLocalMediaActive()) {
                PlayerHolder.playPrevious(this)
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                val current = YouTubeExoPlayerManager.getCurrentPosition()
                YouTubeExoPlayerManager.seekTo((current - 10000).coerceAtLeast(0))
            }
        }

        btnNotchNext.setOnClickListener {
            if (isLocalMediaActive()) {
                PlayerHolder.playNext(this)
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            } else if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                val current = YouTubeExoPlayerManager.getCurrentPosition()
                val duration = YouTubeExoPlayerManager.getDuration()
                YouTubeExoPlayerManager.seekTo((current + 10000).coerceAtMost(duration))
            }
        }

        btnNotchRepeat.setOnClickListener {
            if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                val p = YouTubeExoPlayerManager.exoPlayer ?: return@setOnClickListener
                val nextMode = when (p.repeatMode) {
                    androidx.media3.common.Player.REPEAT_MODE_OFF -> androidx.media3.common.Player.REPEAT_MODE_ONE
                    androidx.media3.common.Player.REPEAT_MODE_ONE -> androidx.media3.common.Player.REPEAT_MODE_ALL
                    else -> androidx.media3.common.Player.REPEAT_MODE_OFF
                }
                p.repeatMode = nextMode
                val displayMode = when (nextMode) {
                    androidx.media3.common.Player.REPEAT_MODE_ONE -> 2
                    androidx.media3.common.Player.REPEAT_MODE_ALL -> 1
                    else -> 0
                }
                updateNotchRepeatUI(displayMode)
            } else {
                val mode = PlayerHolder.toggleRepeatMode()
                updateNotchRepeatUI(mode)
            }
        }

        btnNotchClose.setOnClickListener {
            if (isLocalMediaActive()) {
                PlayerHolder.release()
                MediaPlaybackService.stop(this)
                audioAdapter?.setPlayingUri(null)
            } else {
                YouTubeExoPlayerManager.pause()
                YouTubeExoPlayerManager.stop()
                YouTubeExoPlayerManager.currentPlayingVideo = null
                currentPlayingYtVideo = null
                isYtVideoPlaying = false
            }
            cardNotchPlayer.visibility = View.GONE
        }

        sbNotch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    tvNotchCurrent.text = formatTime(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                sb?.let {
                    val target = it.progress.toLong()
                    if (YouTubeExoPlayerManager.exoPlayer != null && YouTubeExoPlayerManager.currentPlayingVideo != null) {
                        YouTubeExoPlayerManager.seekTo(target)
                    } else if (PlayerHolder.audioExoPlayer != null) {
                        PlayerHolder.audioExoPlayer?.seekTo(target)
                    } else {
                        PlayerHolder.mediaPlayer?.time = target
                    }
                }
            }
        })

        intent?.data?.let { uri ->
            val title = PlayerHolder.resolveMediaTitle(this, uri, null)
            val type = intent?.type ?: contentResolver.getType(uri) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(uri, title, isVideo, null)
        }
    }

    private val notchProgressHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val notchProgressRunnable = object : Runnable {
        override fun run() {
            // 1. YouTube Player Real-Time Progress & Time Tracking (independent of cardNotchPlayer)
            val ytPlayer = YouTubeExoPlayerManager.exoPlayer
            val ytVideo = YouTubeExoPlayerManager.currentPlayingVideo
            if (ytPlayer != null && ytVideo != null) {
                val current = ytPlayer.currentPosition.coerceAtLeast(0L)
                val duration = ytPlayer.duration.let { if (it > 0) it else 0L }

                if (::tvYtPlayerCurrentTime.isInitialized && !isYtUserSeeking) {
                    if (duration > 0) {
                        tvYtPlayerCurrentTime.text = "${formatTime(current)} / ${formatTime(duration)}"
                        sbYtPlayer.max = duration.toInt()
                        sbYtPlayer.progress = current.toInt()
                        if (::pbYtBottomMiniProgress.isInitialized && !YouTubeExoPlayerManager.isAudioOnlyMode) {
                            pbYtBottomMiniProgress.max = duration.toInt()
                            pbYtBottomMiniProgress.progress = current.toInt()
                        }
                    } else if (current > 0) {
                        tvYtPlayerCurrentTime.text = "${formatTime(current)} / --:--"
                    }
                }

                if (cardNotchPlayer.visibility == View.VISIBLE && duration > 0) {
                    sbNotch.max = duration.toInt()
                    sbNotch.progress = current.toInt()
                    tvNotchCurrent.text = formatTime(current)
                    tvNotchTotal.text = formatTime(duration)
                    btnNotchPlayPause.setImageResource(
                        if (ytPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                }
            }

            // 2. Local Media Player Progress (Audio / Video)
            if (cardNotchPlayer.visibility == View.VISIBLE && isLocalMediaActive()) {
                val audioPlayer = PlayerHolder.audioExoPlayer
                val vlcPlayer = PlayerHolder.mediaPlayer

                if (audioPlayer != null && PlayerHolder.currentUri != null) {
                    val current = audioPlayer.currentPosition
                    val duration = audioPlayer.duration
                    if (duration > 0) {
                        sbNotch.max = duration.toInt()
                        sbNotch.progress = current.toInt()
                        tvNotchCurrent.text = formatTime(current)
                        tvNotchTotal.text = formatTime(duration)
                    }
                    btnNotchPlayPause.setImageResource(
                        if (audioPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                } else if (vlcPlayer != null && PlayerHolder.currentUri != null) {
                    val current = vlcPlayer.time
                    val duration = vlcPlayer.length
                    if (duration > 0) {
                        sbNotch.max = duration.toInt()
                        sbNotch.progress = current.toInt()
                        tvNotchCurrent.text = formatTime(current)
                        tvNotchTotal.text = formatTime(duration)
                    }
                    btnNotchPlayPause.setImageResource(
                        if (vlcPlayer.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                }
            }
            notchProgressHandler.postDelayed(this, 1000)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(ytMediaReceiver) } catch (e: Exception) {}
        ytVisualizerHandler.removeCallbacks(ytVisualizerRunnable)
        autoScreenOffYtHandler.removeCallbacksAndMessages(null)
        try {
            if (::playerViewYt.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            }
            if (::playerViewYtMini.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
            }
        } catch (e: Exception) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applyAppWideImmersiveMode()
        }
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applyAppWideImmersiveMode()
        if (::layoutYtPlayerDetail.isInitialized && layoutYtPlayerDetail.visibility == View.VISIBLE) {
            val surfaceContainer = findViewById<View>(R.id.layoutYtPlayerSurfaceContainer)
            val detailsScroll = (layoutYtPlayerDetail as? android.view.ViewGroup)?.getChildAt(1)

            if (newConfig.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
                isYtFullscreen = true
                detailsScroll?.visibility = View.GONE
                findViewById<View>(R.id.bottomNav)?.visibility = View.GONE
                if (::fabPlay.isInitialized) fabPlay.visibility = View.GONE
                val lp = surfaceContainer?.layoutParams
                if (lp != null) {
                    lp.height = LinearLayout.LayoutParams.MATCH_PARENT
                    lp.width = LinearLayout.LayoutParams.MATCH_PARENT
                    surfaceContainer.layoutParams = lp
                }
                btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen_exit)
                enableImmersiveNotchMode()
                applyYouTubeAspectRatio(ytAspectRatioMode)
                showYouTubeOverlay()
            } else if (newConfig.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT) {
                isYtFullscreen = false
                detailsScroll?.visibility = View.VISIBLE
                findViewById<View>(R.id.bottomNav)?.visibility = View.VISIBLE
                updateFabPlayVisibility()
                val lp = surfaceContainer?.layoutParams
                if (lp != null) {
                    lp.height = (230 * resources.displayMetrics.density).toInt()
                    lp.width = LinearLayout.LayoutParams.MATCH_PARENT
                    surfaceContainer.layoutParams = lp
                }
                btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen)
                window.statusBarColor = Color.parseColor("#0F0F0F")
                applyYouTubeAspectRatio(ytAspectRatioMode)
                showYouTubeOverlay()
            }
        }
    }

    private fun applyAppWideImmersiveMode() {
        try {
            window.navigationBarColor = Color.TRANSPARENT
            window.statusBarColor = Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.isNavigationBarContrastEnforced = false
                window.isStatusBarContrastEnforced = false
            }
            val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            val shouldHideNav = isYtFullscreen || (isLandscape && tabYouTube.visibility == View.VISIBLE && layoutYtPlayerDetail.visibility == View.VISIBLE)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.let { controller ->
                    if (shouldHideNav) {
                        controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                    } else {
                        controller.hide(WindowInsets.Type.statusBars())
                        controller.show(WindowInsets.Type.navigationBars())
                    }
                    controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            } else {
                @Suppress("DEPRECATION")
                if (shouldHideNav) {
                    window.decorView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    )
                } else {
                    window.decorView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    )
                }
            }
        } catch (e: Exception) {}
    }


    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingShareIntent(intent)
        if (intent?.getStringExtra("OPEN_TAB") == "SHARE") {
            showTab(video = false, audio = false, youtube = false, share = true, settings = false)
            bottomNav.selectedItemId = R.id.nav_share
            if (FastShareService.isTransferActive.get() && (activeShareProgressDialog == null || activeShareProgressDialog?.isShowing == false)) {
                showShareProgressDialog(isSender = FastShareService.isSenderMode, filePaths = emptyList())
            }
        }
    }

    override fun onResume() {
        super.onResume()
        applyAppWideImmersiveMode()

        YouTubeExoPlayerManager.onAudioModeChanged = { isAudioOnly ->
            runOnUiThread {
                updateAudioModeUI(isAudioOnly)
            }
        }

        notchProgressHandler.removeCallbacks(notchProgressRunnable)
        notchProgressHandler.post(notchProgressRunnable)

        YouTubeExoPlayerManager.onAppForegrounded(this)

        if (::playerViewYt.isInitialized) {
            if (!YouTubeExoPlayerManager.isAudioOnlyMode && currentPlayingYtVideo != null) {
                playerViewYt.visibility = View.VISIBLE
                YouTubeExoPlayerManager.reattachPlayerView(playerViewYt)
                updateAudioModeUI(false)
            } else {
                updateAudioModeUI(YouTubeExoPlayerManager.isAudioOnlyMode)
            }
        }
        YouTubeDownloaderHelper.onDownloadProgressChanged = { downloadId, percent, downStr, totalStr, status ->
            runOnUiThread {
                tvYtDownloadPill.text = "" + percent + "%"
                ivYtDownloadPill.setColorFilter(Color.parseColor("#3EA6FF"))
            }
        }

        YouTubeDownloaderHelper.onDownloadFinished = { downloadId, fileName, success ->
            runOnUiThread {
                if (success) {
                    tvYtDownloadPill.text = "Downloaded"
                    ivYtDownloadPill.setImageResource(R.drawable.ic_check_player)
                    ivYtDownloadPill.setColorFilter(Color.parseColor("#00E676"))
                } else {
                    tvYtDownloadPill.text = "Download"
                    ivYtDownloadPill.setImageResource(R.drawable.ic_download)
                    ivYtDownloadPill.setColorFilter(Color.WHITE)
                }
            }
        }

        YouTubeExoPlayerManager.onPlaybackStateChanged = { isPlaying ->
            runOnUiThread {
                isYtVideoPlaying = isPlaying
                if (isPlaying) {
                    cancelAutoScreenOffYt()
                    updateScreenWakeLock(!YouTubeExoPlayerManager.isAudioOnlyMode)
                    AiVideoEnhancer.applyEnhancement(this@MainActivity, false)
                } else {
                    if (PlayerHolder.isAutoScreenOffEnabled && !YouTubeExoPlayerManager.isAudioOnlyMode) {
                        scheduleAutoScreenOffYt(PlayerHolder.autoScreenOffTimeoutMinutes * 60 * 1000L)
                    } else {
                        updateScreenWakeLock(false)
                    }
                }
                btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                btnYtCenterPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                updateNotchPlayerUI()

                if (::ytAudioVisualizerView.isInitialized) {
                    ytAudioVisualizerView.setPlaying(isPlaying)
                    val sId = YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0
                    if (sId > 0) ytAudioVisualizerView.linkToAudio(sId)
                }
                ytMiniAudioVisualizerView?.let { mini ->
                    mini.setPlaying(isPlaying)
                    val sId = YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0
                    if (sId > 0) mini.linkToAudio(sId)
                }
                if (isPlaying) {
                    ytVisualizerHandler.removeCallbacks(ytVisualizerRunnable)
                    ytVisualizerHandler.post(ytVisualizerRunnable)
                }
            }
        }
        YouTubeExoPlayerManager.onBufferingStateChanged = { isBuffering ->
            runOnUiThread {
                pbYtBuffering.visibility = if (isBuffering) View.VISIBLE else View.GONE
                if (!isBuffering) {
                    if (layoutYtPlayerOverlay.visibility == View.VISIBLE) {
                        btnYtCenterPlayPause.visibility = View.VISIBLE
                    }
                } else {
                    btnYtCenterPlayPause.visibility = View.GONE
                }
            }
        }
        YouTubeExoPlayerManager.onSponsorSkipped = { label ->
            showYtGestureFeedback(R.drawable.ic_forward_10, "Skipped $label [SponsorBlock]")
        }
        YouTubeExoPlayerManager.onPlayerError = { error ->
            DynamicExtractorOtaEngine.syncRules(this, force = true)
            runOnUiThread {
                pbYtBuffering.visibility = View.GONE
                btnYtCenterPlayPause.visibility = View.VISIBLE
                btnYtCenterPlayPause.setImageResource(R.drawable.ic_play_player)
                val v = currentPlayingYtVideo
                if (v != null) {
                    // Unwanted popup removed
                    YouTubeStreamResolver.resolveStreams(v.id, 480) { resStream ->
                        if (resStream != null) {
                            val fastOpt = resStream.availableQualities.firstOrNull { it.audioUrl == null }
                            val url = fastOpt?.videoUrl ?: resStream.videoUrl
                            YouTubeExoPlayerManager.playVideo(
                                context = this,
                                video = v,
                                videoStreamUrl = url,
                                audioStreamUrl = null,
                                pureAudioUrl = resStream.pureAudioUrl,
                                allAudioUrls = resStream.allAudioUrls
                            )
                        } else {
                            // Unwanted popup removed
                        }
                    }
                }
            }
        }
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        }
        updateSettingsUI()
        updateNotchPlayerUI()
        audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
        notchProgressHandler.post(notchProgressRunnable)

        PlayerHolder.onTrackChangedListener = { item ->
            runOnUiThread {
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(item.uri)
            }
        }
        PlayerHolder.onPlaybackStateChangedListener = { isPlaying ->
            runOnUiThread {
                btnNotchPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
                audioAdapter?.notifyDataSetChanged()
                updateNotchPlayerUI()
            }
        }

    }

    private fun updateYtVideoBoostBadge() {
        btnYtVideoBoost?.let { btn ->
            if (PlayerHolder.isAiVideoSharpnessEnabled || PlayerHolder.isAiNeuralSuperResEnabled) {
                btn.text = "✨ HDR"
                btn.setTextColor(Color.parseColor("#FF9800"))
            } else {
                btn.text = "HDR: OFF"
                btn.setTextColor(Color.parseColor("#8E8E93"))
            }
        }
    }

    private fun updateAudioModeUI(isAudioOnly: Boolean) {
        if (isAudioOnly) {
            layoutYtAudioModeVisual.visibility = View.VISIBLE
            btnYtAudioMode?.setImageResource(R.drawable.ic_video)
            btnYtAudioMode?.setColorFilter(Color.parseColor("#FF8800"))
            ivYtAudioModeThumb.visibility = View.VISIBLE
            currentPlayingYtVideo?.let { v ->
                ImageLoaderHelper.loadImage(v.thumbnailUrl, ivYtAudioModeThumb, R.drawable.ic_audio)
            }
            ytAudioVisualizerView.visibility = View.GONE
            ytAudioVisualizerView.setPlaying(false)
            ivYtMiniThumb.visibility = View.VISIBLE
            ytMiniAudioVisualizerView?.visibility = View.GONE
            playerViewYt.visibility = View.INVISIBLE
            if (::pbYtBottomMiniProgress.isInitialized) {
                pbYtBottomMiniProgress.visibility = View.GONE
            }
        } else {
            layoutYtAudioModeVisual.visibility = View.GONE
            ytAudioVisualizerView.visibility = View.GONE
            ytAudioVisualizerView.setPlaying(false)
            ivYtMiniThumb.visibility = View.VISIBLE
            ytMiniAudioVisualizerView?.visibility = View.GONE
            btnYtAudioMode?.setImageResource(R.drawable.ic_audio)
            btnYtAudioMode?.setColorFilter(Color.WHITE)
            playerViewYt.visibility = View.VISIBLE
            YouTubeExoPlayerManager.reattachPlayerView(playerViewYt)
        }
        showYouTubeOverlay()
    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if (ev?.action == MotionEvent.ACTION_DOWN) {
            if (isYtScreenOffDimmed) {
                cancelAutoScreenOffYt()
                if (isYtVideoPlaying) {
                    updateScreenWakeLock(!YouTubeExoPlayerManager.isAudioOnlyMode)
                } else if (currentPlayingYtVideo != null) {
                    scheduleAutoScreenOffYt(PlayerHolder.autoScreenOffTimeoutMinutes * 60 * 1000L)
                }
            } else if (!isYtVideoPlaying && currentPlayingYtVideo != null) {
                scheduleAutoScreenOffYt(PlayerHolder.autoScreenOffTimeoutMinutes * 60 * 1000L)
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onStop() {
        super.onStop()
        val isPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        val isBackgroundAllowed = PlayerHolder.isBackgroundPlayEnabled || PlayerHolder.backgroundPipMode > 0
        if (!isPip && isBackgroundAllowed && YouTubeExoPlayerManager.isPlaying()) {
            YouTubeExoPlayerManager.onAppBackgrounded(this)
            currentPlayingYtVideo?.let { v ->
                MediaPlaybackService.start(
                    context = this,
                    title = v.title,
                    artist = v.channelTitle,
                    isPlaying = true,
                    isYouTube = true,
                    thumbUrl = v.thumbnailUrl
                )
            }
        } else if (!isPip && YouTubeExoPlayerManager.isPlaying()) {
            // Background playback is not enabled: Pause immediately to save data & battery!
            YouTubeExoPlayerManager.pause()
            MediaPlaybackService.stop(this)
        }

        // Release file transfer background resources if no transfer is currently running
        if (!FastShareService.isTransferActive.get()) {
            FastShareManager.stopTransferService(this)
        }
    }

    override fun onPause() {
        super.onPause()
        updateScreenWakeLock(false)
        notchProgressHandler.removeCallbacks(notchProgressRunnable)
        PlayerHolder.onTrackChangedListener = null
        PlayerHolder.onPlaybackStateChangedListener = null
        // Media3 ExoPlayer handles background audio playback and PiP
    }

    private fun updateNotchRepeatUI(mode: Int) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        when (mode) {
            1 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat_one)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            2 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            else -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(secondaryColor)
            }
        }
    }

    private fun isLocalMediaActive(): Boolean {
        val audioPlayer = PlayerHolder.audioExoPlayer
        val vlcPlayer = PlayerHolder.mediaPlayer
        val isAudioPlaying = audioPlayer != null && audioPlayer.isPlaying
        val isVlcPlaying = vlcPlayer != null && vlcPlayer.isPlaying
        if (isAudioPlaying || isVlcPlaying) return true
        if (PlayerHolder.currentUri != null && (audioPlayer != null || vlcPlayer != null)) {
            val ytPlayer = YouTubeExoPlayerManager.exoPlayer
            val isYtPlaying = ytPlayer != null && ytPlayer.isPlaying
            return !isYtPlaying
        }
        return false
    }

    private fun updateNotchPlayerUI() {
        if (::layoutYtPlayerDetail.isInitialized && layoutYtPlayerDetail.visibility == View.VISIBLE) {
            cardNotchPlayer.visibility = View.GONE
            return
        }
        val ytVideo = YouTubeExoPlayerManager.currentPlayingVideo
        val ytPlayer = YouTubeExoPlayerManager.exoPlayer
        val audioPlayer = PlayerHolder.audioExoPlayer
        val vlcPlayer = PlayerHolder.mediaPlayer

        if (ytPlayer != null && ytVideo != null && ytPlayer.playbackState != androidx.media3.common.Player.STATE_IDLE) {
            // 1. YouTube Online Streaming Active in Notch (Only while playing!)
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = ytVideo.title
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = ytVideo.channelTitle
            val isPlaying = ytPlayer.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = ytPlayer.duration
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                val current = ytPlayer.currentPosition
                sbNotch.progress = current.toInt()
                tvNotchCurrent.text = formatTime(current)
                tvNotchTotal.text = formatTime(duration)
            }
            if (!ytVideo.thumbnailUrl.isNullOrBlank()) {
                ImageLoaderHelper.load(this, ytVideo.thumbnailUrl, ivNotchIcon)
            } else {
                ivNotchIcon.setImageResource(R.drawable.ic_youtube)
            }
        } else if (audioPlayer != null && PlayerHolder.currentUri != null && audioPlayer.isPlaying) {
            // 2. Local Audio Media3 Active in Notch (Only while playing!)
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = PlayerHolder.currentTitle
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = PlayerHolder.currentArtist
            val isPlaying = audioPlayer.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = audioPlayer.duration
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                val current = audioPlayer.currentPosition
                sbNotch.progress = current.toInt()
                tvNotchCurrent.text = formatTime(current)
                tvNotchTotal.text = formatTime(duration)
            }
            ivNotchIcon.setImageResource(R.drawable.ic_audio)
        } else if (vlcPlayer != null && PlayerHolder.currentUri != null && vlcPlayer.isPlaying) {
            // 3. Local Video VLC Active in Notch (Only while playing!)
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = PlayerHolder.currentTitle
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = PlayerHolder.currentArtist
            val isPlaying = vlcPlayer.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = vlcPlayer.length
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                sbNotch.progress = vlcPlayer.time.toInt()
                tvNotchCurrent.text = formatTime(vlcPlayer.time)
                tvNotchTotal.text = formatTime(duration)
            }
            ivNotchIcon.setImageResource(R.drawable.ic_video)
        } else {
            cardNotchPlayer.visibility = View.GONE
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (hours > 0) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    private fun showSortDialog() {
        val sortOptions = arrayOf(
            getString(R.string.sort_name_asc),
            getString(R.string.sort_name_desc),
            getString(R.string.sort_date_newest),
            getString(R.string.sort_duration),
            getString(R.string.sort_size)
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle(R.string.sort_title)
            .setItems(sortOptions) { _, which ->
                when (which) {
                    0 -> {
                        allVideos = allVideos.sortedBy { it.title.lowercase() }
                        allAudio = allAudio.sortedBy { it.title.lowercase() }
                    }
                    1 -> {
                        allVideos = allVideos.sortedByDescending { it.title.lowercase() }
                        allAudio = allAudio.sortedByDescending { it.title.lowercase() }
                    }
                    2 -> {
                        allVideos = allVideos.sortedByDescending { it.id }
                        allAudio = allAudio.sortedByDescending { it.id }
                    }
                    3 -> {
                        allVideos = allVideos.sortedByDescending { it.durationMs }
                        allAudio = allAudio.sortedByDescending { it.durationMs }
                    }
                    4 -> {
                        allVideos = allVideos.sortedByDescending { it.sizeBytes }
                        allAudio = allAudio.sortedByDescending { it.sizeBytes }
                    }
                }
                videoAdapter?.updateList(allVideos)
                audioAdapter?.updateList(allAudio)
                updateFoldersData()
                // Silent notification removed
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        btnToolbarSearch = findViewById(R.id.btnToolbarSearch)
        btnToolbarSearch.setOnClickListener {
            val searchLayout = findViewById<View>(R.id.layoutSearch)
            searchLayout.visibility = if (searchLayout.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (searchLayout.visibility == View.VISIBLE) {
                etSearch.requestFocus()
            }
        }
        btnToolbarSort = findViewById(R.id.btnToolbarSort)
        btnToolbarSort.setOnClickListener { showSortDialog() }
        btnToolbarOpen = findViewById(R.id.btnToolbarOpen)
        fabPlay = findViewById(R.id.fabPlay)
        fabPlay.setOnClickListener {
            if (allVideos.isNotEmpty()) {
                val item = allVideos.first()
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } else if (allAudio.isNotEmpty()) {
                YouTubeExoPlayerManager.pause()
                YouTubeExoPlayerManager.stop()
                YouTubeExoPlayerManager.currentPlayingVideo = null
                currentPlayingYtVideo = null
                isYtVideoPlaying = false
                if (::cardYtMiniPlayer.isInitialized) cardYtMiniPlayer.visibility = View.GONE
                if (::layoutYtAudioModeVisual.isInitialized) layoutYtAudioModeVisual.visibility = View.GONE
                PlayerHolder.setPlaylistAndPlay(this, allAudio, 0)
                openPlayer(allAudio[0].uri, allAudio[0].title, isVideo = false, path = allAudio[0].filePath, artist = allAudio[0].artist)
            } else {
                CleanToast.show(this, "No media files found")
            }
        }
        etSearch = findViewById(R.id.etSearch)
        tabVideo = findViewById(R.id.tabVideo)
        tabAudio = findViewById(R.id.tabAudio)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)
        tabYouTube = findViewById(R.id.tabYouTube)
        layoutYtMainFeed = findViewById(R.id.layoutYtMainFeed)
        // btnYtExitToLocal removed for clean official header
        nsvYtFeed = findViewById(R.id.nsvYtFeed)
        rvYouTubeFeed = findViewById(R.id.rvYouTubeFeed)
        rvYouTubeFeedSecondary = findViewById(R.id.rvYouTubeFeedSecondary)
        srlYouTubeFeed = findViewById(R.id.srlYouTubeFeed)
        pbYtFeedLoading = findViewById(R.id.pbYtFeedLoading)
        layoutYtEmpty = findViewById(R.id.layoutYtEmpty)
        btnYtRetry = findViewById(R.id.btnYtRetry)
        btnYtSearch = findViewById(R.id.btnYtSearch)
        btnYtAccount = findViewById(R.id.btnYtAccount)
        btnYtCast = findViewById(R.id.btnYtCast)
        btnYtNotifications = findViewById(R.id.btnYtNotifications)
        layoutYtSearchBar = findViewById(R.id.layoutYtSearchBar)
        etYtSearchQuery = findViewById(R.id.etYtSearchQuery)
        btnYtCloseSearch = findViewById(R.id.btnYtCloseSearch)
        chipYtAll = findViewById(R.id.chipYtAll)
        chipYtMusic = findViewById(R.id.chipYtMusic)
        chipYtGaming = findViewById(R.id.chipYtGaming)
        chipYtPodcasts = findViewById(R.id.chipYtPodcasts)
        chipYtLive = findViewById(R.id.chipYtLive)
        chipYtTrending = findViewById(R.id.chipYtTrending)
        chipYtNews = findViewById(R.id.chipYtNews)

        btnYtNavHome = findViewById(R.id.btnYtNavHome)
        btnYtNavSubs = findViewById(R.id.btnYtNavSubs)
        btnYtNavLibrary = findViewById(R.id.btnYtNavLibrary)

        layoutYtPlayerDetail = findViewById(R.id.layoutYtPlayerDetail)
        playerViewYt = findViewById(R.id.playerViewYt)
        pbYtBuffering = findViewById(R.id.pbYtBuffering)
        btnYtCenterPlayPause = findViewById(R.id.btnYtCenterPlayPause)
        YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        YouTubeExoPlayerManager.onPlaybackStateChanged = { isPlaying ->
            runOnUiThread {
                isYtVideoPlaying = isPlaying
                if (isPlaying) {
                    cancelAutoScreenOffYt()
                    updateScreenWakeLock(!YouTubeExoPlayerManager.isAudioOnlyMode)
                } else {
                    if (PlayerHolder.isAutoScreenOffEnabled && !YouTubeExoPlayerManager.isAudioOnlyMode) {
                        scheduleAutoScreenOffYt(PlayerHolder.autoScreenOffTimeoutMinutes * 60 * 1000L)
                    } else {
                        updateScreenWakeLock(false)
                    }
                }
                btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                btnYtCenterPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
                updateNotchPlayerUI()

                if (::ytAudioVisualizerView.isInitialized) {
                    ytAudioVisualizerView.setPlaying(isPlaying)
                    val sId = YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0
                    if (sId > 0) ytAudioVisualizerView.linkToAudio(sId)
                }
                ytMiniAudioVisualizerView?.let { mini ->
                    mini.setPlaying(isPlaying)
                    val sId = YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0
                    if (sId > 0) mini.linkToAudio(sId)
                }
                if (isPlaying) {
                    ytVisualizerHandler.removeCallbacks(ytVisualizerRunnable)
                    ytVisualizerHandler.post(ytVisualizerRunnable)
                }
            }
        }
        YouTubeExoPlayerManager.onBufferingStateChanged = { isBuffering ->
            runOnUiThread {
                pbYtBuffering.visibility = if (isBuffering) View.VISIBLE else View.GONE
                if (!isBuffering) {
                    if (layoutYtPlayerOverlay.visibility == View.VISIBLE) {
                        btnYtCenterPlayPause.visibility = View.VISIBLE
                    }
                } else {
                    btnYtCenterPlayPause.visibility = View.GONE
                }
            }
        }
        YouTubeExoPlayerManager.onSponsorSkipped = { label ->
            showYtGestureFeedback(R.drawable.ic_forward_10, "Skipped $label [SponsorBlock]")
        }
        YouTubeExoPlayerManager.onPlayerError = { error ->
            DynamicExtractorOtaEngine.syncRules(this, force = true)
            runOnUiThread {
                pbYtBuffering.visibility = View.GONE
                btnYtCenterPlayPause.visibility = View.VISIBLE
                btnYtCenterPlayPause.setImageResource(R.drawable.ic_play_player)
                val v = currentPlayingYtVideo
                if (v != null) {
                    // Unwanted popup removed
                    YouTubeStreamResolver.resolveStreams(v.id, 480) { resStream ->
                        if (resStream != null) {
                            val fastOpt = resStream.availableQualities.firstOrNull { it.audioUrl == null }
                            val url = fastOpt?.videoUrl ?: resStream.videoUrl
                            YouTubeExoPlayerManager.playVideo(
                                context = this,
                                video = v,
                                videoStreamUrl = url,
                                audioStreamUrl = null,
                                pureAudioUrl = resStream.pureAudioUrl,
                                allAudioUrls = resStream.allAudioUrls
                            )
                        } else {
                            // Unwanted popup removed
                        }
                    }
                }
            }
        }
        btnYtCenterPlayPause.setOnClickListener {
            val player = YouTubeExoPlayerManager.exoPlayer
            if (player != null && (player.playbackState == androidx.media3.common.Player.STATE_IDLE || player.playerError != null)) {
                currentPlayingYtVideo?.let { playYouTubeVideoInApp(it) }
            } else {
                YouTubeExoPlayerManager.togglePlayPause()
            }
        }
        // Rogue play/pause hide click listener removed to prevent disappearing button
        btnYtCollapsePlayer = findViewById(R.id.btnYtCollapsePlayer)
        btnYtFullscreen = findViewById(R.id.btnYtFullscreen)
        tvYtDetailTitle = findViewById(R.id.tvYtDetailTitle)
        tvYtDetailSubtitle = findViewById(R.id.tvYtDetailSubtitle)
        ivYtDetailAvatar = findViewById(R.id.ivYtDetailAvatar)
        tvYtDetailChannel = findViewById(R.id.tvYtDetailChannel)
        btnYtSubscribe = findViewById(R.id.btnYtSubscribe)
        layoutYtLikePill = findViewById(R.id.layoutYtLikePill)
        tvYtDetailLikes = findViewById(R.id.tvYtDetailLikes)
        layoutYtSharePill = findViewById(R.id.layoutYtSharePill)
        layoutYtDownloadPill = findViewById(R.id.layoutYtDownloadPill)
        tvYtDownloadPill = findViewById(R.id.tvYtDownloadPill)
        ivYtDownloadPill = findViewById(R.id.ivYtDownloadPill)
        tvYtAudioQualityStatus = findViewById(R.id.tvYtAudioQualityStatus)
        btnChangeYtAudioQuality = findViewById(R.id.btnChangeYtAudioQuality)
        tvYtBufferLimitStatus = findViewById(R.id.tvYtBufferLimitStatus)
        btnChangeYtBufferLimit = findViewById(R.id.btnChangeYtBufferLimit)

        ytAudioVisualizerView = findViewById(R.id.ytAudioVisualizerView)
        ytAudioVisualizerView.onModelChangedListener = { model, name ->
            PlayerHolder.visualizerModel = model
            PlayerHolder.savePreferences(this)
            ytMiniAudioVisualizerView?.setModel(model)
            showYtGestureFeedback(R.drawable.ic_soundwave, name)
        }


        layoutYtSavePill = findViewById(R.id.layoutYtSavePill)
        layoutYtCommentsCard = findViewById(R.id.layoutYtCommentsCard)
        tvYtDetailCommentsCount = findViewById(R.id.tvYtDetailCommentsCount)
        rvYtRelatedVideos = findViewById(R.id.rvYtRelatedVideos)

        cardYtMiniPlayer = findViewById(R.id.cardYtMiniPlayer)
        ivYtMiniThumb = findViewById(R.id.ivYtMiniThumb)
        tvYtMiniTitle = findViewById(R.id.tvYtMiniTitle)
        tvYtMiniChannel = findViewById(R.id.tvYtMiniChannel)
        btnYtMiniPlayPause = findViewById(R.id.btnYtMiniPlayPause)
        btnYtMiniClose = findViewById(R.id.btnYtMiniClose)
        layoutYtMiniControlsOverlay = findViewById(R.id.layoutYtMiniControlsOverlay)
        btnYtMiniExpand = findViewById(R.id.btnYtMiniExpand)
        playerViewYtMini = findViewById(R.id.playerViewYtMini)


        ytScaleGestureDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private var lastScaleTime = 0L

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val scaleFactor = detector.scaleFactor
                val now = System.currentTimeMillis()
                if (now - lastScaleTime < 300) return true

                if (scaleFactor > 1.05f) {
                    if (ytAspectRatioMode != 1) {
                        applyYouTubeAspectRatio(1)
                        lastScaleTime = now
                    }
                } else if (scaleFactor < 0.95f) {
                    if (ytAspectRatioMode != 0) {
                        applyYouTubeAspectRatio(0)
                        lastScaleTime = now
                    }
                }
                return true
            }

            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                isYtPinchActive = true
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                isYtPinchActive = false
            }
        })

        val initTtlHours = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE).getInt("pref_yt_stream_ttl_hours", 4)
        YouTubeStreamResolver.setCacheTtlHours(initTtlHours)
        initNativeYouTubeEngine()

        btnViewAllVideos = findViewById(R.id.btnViewAllVideos)
        btnViewFolders = findViewById(R.id.btnViewFolders)
        rvVideos = findViewById(R.id.rvVideos)
        layoutFoldersContainer = findViewById(R.id.layoutFoldersContainer)
        rvFolders = findViewById(R.id.rvFolders)
        layoutFolderDetailHeader = findViewById(R.id.layoutFolderDetailHeader)
        btnFolderBack = findViewById(R.id.btnFolderBack)
        tvFolderHeaderTitle = findViewById(R.id.tvFolderHeaderTitle)
        tvFolderHeaderSubtitle = findViewById(R.id.tvFolderHeaderSubtitle)
        rvFolderVideos = findViewById(R.id.rvFolderVideos)
        layoutEmptyVideo = findViewById(R.id.layoutEmptyVideo)
        btnBrowseVideo = findViewById(R.id.btnBrowseVideo)

        rvFolders.layoutManager = LinearLayoutManager(this)
        rvFolderVideos.layoutManager = LinearLayoutManager(this)

        btnViewAllVideos.setOnClickListener {
            switchVideoViewMode(folders = false)
        }

        btnViewFolders.setOnClickListener {
            switchVideoViewMode(folders = true)
        }

        btnFolderBack.setOnClickListener {
            closeFolderDetail()
        }

        rvAudio = findViewById(R.id.rvAudio)
        layoutEmptyAudio = findViewById(R.id.layoutEmptyAudio)
        btnBrowseAudio = findViewById(R.id.btnBrowseAudio)

        // YouTube Settings Views
        tvYtAdBlockStatus = findViewById(R.id.tvYtAdBlockStatus)
        btnToggleYtAdBlock = findViewById(R.id.btnToggleYtAdBlock)
        tvYtSponsorBlockStatus = findViewById(R.id.tvYtSponsorBlockStatus)
        btnConfigSponsorBlock = findViewById(R.id.btnConfigSponsorBlock)
        tvYtDefaultQualityStatus = findViewById(R.id.tvYtDefaultQualityStatus)
        btnChangeYtQuality = findViewById(R.id.btnChangeYtQuality)
        tvYtExtractorBridgeStatus = findViewById(R.id.tvYtExtractorBridgeStatus)
        btnChangeYtExtractorBridge = findViewById(R.id.btnChangeYtExtractorBridge)
        findViewById<View>(R.id.rowYtExtractorBridge)?.setOnClickListener {
            showExtractorBridgeDialog()
        }
        btnChangeYtExtractorBridge.setOnClickListener {
            showExtractorBridgeDialog()
        }

        findViewById<View>(R.id.rowYtClientSpoofing)?.setOnClickListener {
            showClientSpoofingDialog()
        }
        tvYtClientSpoofingStatus = findViewById(R.id.tvYtClientSpoofingStatus)
        btnChangeYtClient = findViewById(R.id.btnChangeYtClient)
        tvYtBgAudioStatus = findViewById(R.id.tvYtBgAudioStatus)
        btnToggleYtBgAudio = findViewById(R.id.btnToggleYtBgAudio)
        tvYtInterfaceStatus = findViewById(R.id.tvYtInterfaceStatus)
        btnConfigYtUI = findViewById(R.id.btnConfigYtUI)
        tvYtAccountStatus = findViewById(R.id.tvYtAccountStatus)
        btnManageYtAccount = findViewById(R.id.btnManageYtAccount)

        btnToggleYtAdBlock.setOnClickListener {
            val prefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
            val cur = prefs.getBoolean("pref_yt_adblock", true)
            prefs.edit().putBoolean("pref_yt_adblock", !cur).apply()
            updateSettingsUI()
        }

        btnConfigSponsorBlock.setOnClickListener {
            showSponsorBlockSettingsDialog()
        }

        btnChangeYtQuality.setOnClickListener {
            showYouTubeQualityDialog()
        }

        btnChangeYtClient.setOnClickListener {
            showClientSpoofingDialog()
        }

        btnToggleYtBgAudio.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            updateSettingsUI()
        }

        btnConfigYtUI.setOnClickListener {
            showYouTubeUiConfigDialog()
        }

        btnManageYtAccount.setOnClickListener {
            showEditProfileDialog()
        }

        tvYtExtractorOtaStatus = findViewById(R.id.tvYtExtractorOtaStatus)
        btnSyncYtExtractorOta = findViewById(R.id.btnSyncYtExtractorOta)
        val triggerExtractorSync = {
            CleanToast.show(this, "🔄 Checking for live NewPipe Extractor & Cipher updates...")
            DynamicExtractorOtaEngine.syncRules(this, force = true) { _, msg ->
                updateSettingsUI()
                CleanToast.show(this, msg)
            }
        }
        btnSyncYtExtractorOta.setOnClickListener { triggerExtractorSync() }
        findViewById<View>(R.id.rowYtExtractorOta)?.setOnClickListener { triggerExtractorSync() }

        findViewById<View>(R.id.rowYtAdBlock)?.setOnClickListener {
            btnToggleYtAdBlock.performClick()
        }
        findViewById<View>(R.id.rowYtSponsorBlock)?.setOnClickListener {
            btnConfigSponsorBlock.performClick()
        }
        findViewById<View>(R.id.rowYtDefaultQuality)?.setOnClickListener {
            btnChangeYtQuality.performClick()
        }
        findViewById<View>(R.id.rowYtBgAudio)?.setOnClickListener {
            btnToggleYtBgAudio.performClick()
        }
        findViewById<View>(R.id.rowYtInterfaceCustomization)?.setOnClickListener {
            btnConfigYtUI.performClick()
        }
        findViewById<View>(R.id.rowYtAccountManagement)?.setOnClickListener {
            btnManageYtAccount.performClick()
        }

        // Video Settings
        tvSettingAiVideoBoostStatus = findViewById(R.id.tvSettingAiVideoBoostStatus)
        btnToggleSettingAiVideoBoost = findViewById(R.id.btnToggleSettingAiVideoBoost)
        tvSettingAiSmartChaptersStatus = findViewById(R.id.tvSettingAiSmartChaptersStatus)
        btnToggleSettingAiSmartChapters = findViewById(R.id.btnToggleSettingAiSmartChapters)
        tvSettingAiNightVisionStatus = findViewById(R.id.tvSettingAiNightVisionStatus)
        btnToggleSettingAiNightVision = findViewById(R.id.btnToggleSettingAiNightVision)
        tvHighRefreshRateStatus = findViewById(R.id.tvHighRefreshRateStatus)
        btnToggleHighRefreshRate = findViewById(R.id.btnToggleHighRefreshRate)
        tvDefaultOrientationStatus = findViewById(R.id.tvDefaultOrientationStatus)
        btnChangeOrientation = findViewById(R.id.btnChangeOrientation)

        // Notch Mini Player
        cardNotchPlayer = findViewById(R.id.cardNotchPlayer)
        ivNotchIcon = findViewById(R.id.ivNotchIcon)
        tvNotchTitle = findViewById(R.id.tvNotchTitle)
        tvNotchArtist = findViewById(R.id.tvNotchArtist)
        btnNotchClose = findViewById(R.id.btnNotchClose)
        btnNotchRepeat = findViewById(R.id.btnNotchRepeat)
        btnNotchPrev = findViewById(R.id.btnNotchPrev)
        btnNotchPlayPause = findViewById(R.id.btnNotchPlayPause)
        btnNotchNext = findViewById(R.id.btnNotchNext)
        btnNotchOpen = findViewById(R.id.btnNotchOpen)
        tvNotchCurrent = findViewById(R.id.tvNotchCurrent)
        sbNotch = findViewById(R.id.sbNotch)
        tvNotchTotal = findViewById(R.id.tvNotchTotal)
        tvWideColorStatus = findViewById(R.id.tvWideColorStatus)
        btnToggleWideColor = findViewById(R.id.btnToggleWideColor)
        tvDeblockingStatus = findViewById(R.id.tvDeblockingStatus)
        btnToggleDeblocking = findViewById(R.id.btnToggleDeblocking)
        tvAutoScreenOffStatus = findViewById(R.id.tvAutoScreenOffStatus)
        btnToggleAutoScreenOff = findViewById(R.id.btnToggleAutoScreenOff)
        tvHwDecodeStatus = findViewById(R.id.tvHwDecodeStatus)
        btnChangeHw = findViewById(R.id.btnChangeHw)
        tvBgPipStatus = findViewById(R.id.tvBgPipStatus)
        btnChangeBgPip = findViewById(R.id.btnChangeBgPip)
        tvResumeModeStatus = findViewById(R.id.tvResumeModeStatus)
        btnChangeResumeMode = findViewById(R.id.btnChangeResumeMode)
        tvDoubleTapStatus = findViewById(R.id.tvDoubleTapStatus)
        btnChangeDoubleTap = findViewById(R.id.btnChangeDoubleTap)
        tvAspectRatioStatus = findViewById(R.id.tvAspectRatioStatus)
        btnChangeAspectRatio = findViewById(R.id.btnChangeAspectRatio)
        tvAudioBoostStatus = findViewById(R.id.tvAudioBoostStatus)
        btnToggleAudioBoost = findViewById(R.id.btnToggleAudioBoost)

        // Audio Suite Settings
        tvMasterProfileStatus = findViewById(R.id.tvMasterProfileStatus)
        btnChangeMasterProfile = findViewById(R.id.btnChangeMasterProfile)
        tvDolbySurroundStatus = findViewById(R.id.tvDolbySurroundStatus)
        btnChangeDolbySurround = findViewById(R.id.btnChangeDolbySurround)
        tvEqualizerStatus = findViewById(R.id.tvEqualizerStatus)
        btnChangeEqualizer = findViewById(R.id.btnChangeEqualizer)
        tvDialogueBoostStatus = findViewById(R.id.tvDialogueBoostStatus)
        btnToggleDialogueBoost = findViewById(R.id.btnToggleDialogueBoost)
        tvDigitalPassthroughStatus = findViewById(R.id.tvDigitalPassthroughStatus)
        btnTogglePassthrough = findViewById(R.id.btnTogglePassthrough)
        tvAudioOutputStatus = findViewById(R.id.tvAudioOutputStatus)
        btnChangeAudioOutput = findViewById(R.id.btnChangeAudioOutput)
        tvHeadsetPauseStatus = findViewById(R.id.tvHeadsetPauseStatus)
        btnToggleHeadsetPause = findViewById(R.id.btnToggleHeadsetPause)
        tvTimeStretchStatus = findViewById(R.id.tvTimeStretchStatus)
        btnToggleTimeStretch = findViewById(R.id.btnToggleTimeStretch)

        // Subtitle Settings
        btnToggleSubAutoload = findViewById(R.id.btnToggleSubAutoload)
        tvSubSizeStatus = findViewById(R.id.tvSubSizeStatus)
        btnChangeSubSize = findViewById(R.id.btnChangeSubSize)
        tvSubColorStatus = findViewById(R.id.tvSubColorStatus)
        btnChangeSubColor = findViewById(R.id.btnChangeSubColor)
        tvSubBackgroundStatus = findViewById(R.id.tvSubBackgroundStatus)
        btnChangeSubBackground = findViewById(R.id.btnChangeSubBackground)
        tvSubStyleStatus = findViewById(R.id.tvSubStyleStatus)
        btnToggleSubStyle = findViewById(R.id.btnToggleSubStyle)
        tvSubEncodingStatus = findViewById(R.id.tvSubEncodingStatus)
        btnChangeSubEncoding = findViewById(R.id.btnChangeSubEncoding)

        // Gesture Settings
        tvGestureVolumeStatus = findViewById(R.id.tvGestureVolumeStatus)
        btnToggleGestureVolume = findViewById(R.id.btnToggleGestureVolume)
        tvGestureBrightnessStatus = findViewById(R.id.tvGestureBrightnessStatus)
        btnToggleGestureBrightness = findViewById(R.id.btnToggleGestureBrightness)
        tvGestureSeekStatus = findViewById(R.id.tvGestureSeekStatus)
        btnToggleGestureSeek = findViewById(R.id.btnToggleGestureSeek)
        tvFastSeekStatus = findViewById(R.id.tvFastSeekStatus)
        btnToggleFastSeek = findViewById(R.id.btnToggleFastSeek)

        // Interface Settings
        tvAppThemeStatus = findViewById(R.id.tvAppThemeStatus)
        btnChangeAppTheme = findViewById(R.id.btnChangeAppTheme)

        // Advanced Settings
        btnClearCache = findViewById(R.id.btnClearCache)
        btnClearResume = findViewById(R.id.btnClearResume)
        btnResetSettings = findViewById(R.id.btnResetSettings)
        tvCacheSizeStatus = findViewById(R.id.tvCacheSizeStatus)

        rvVideos.layoutManager = LinearLayoutManager(this)
        rvAudio.layoutManager = LinearLayoutManager(this)

        val openFileAction = {
            filePickerLauncher.launch(arrayOf("video/*", "audio/*"))
        }

        btnToolbarOpen.setOnClickListener { openFileAction() }
        btnBrowseVideo.setOnClickListener { openFileAction() }
        btnBrowseAudio.setOnClickListener { openFileAction() }

        // Dynamic App Version binding
        val vName = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "3.5" } catch (e: Exception) { "3.5" }
        findViewById<TextView>(R.id.badgeAppVersion)?.text = "v$vName"
        findViewById<TextView>(R.id.tvDeveloperName)?.text = "👨‍💻 Developer: Rajesh Shah"
        findViewById<TextView>(R.id.tvAppVersionCode)?.text = "Version $vName (Master Edition) • CleanPlayer"
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterMedia(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterMedia(query: String) {
        val q = query.trim().lowercase()
        val filteredVideos = if (q.isEmpty()) allVideos else allVideos.filter { it.title.lowercase().contains(q) }
        val filteredAudio = if (q.isEmpty()) allAudio else allAudio.filter {
            it.title.lowercase().contains(q) || (it.artist?.lowercase()?.contains(q) == true)
        }

        videoAdapter?.updateList(filteredVideos)
        audioAdapter?.updateList(filteredAudio)

        if (isFolderViewActive) {
            val filteredFolders = if (q.isEmpty()) allFolders else allFolders.filter { folder ->
                folder.folderName.lowercase().contains(q) || folder.videos.any { it.title.lowercase().contains(q) }
            }
            folderAdapter?.updateFolders(filteredFolders)
        }

        if (!isFolderViewActive) {
            rvVideos.visibility = if (filteredVideos.isNotEmpty()) View.VISIBLE else View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = if (filteredVideos.isEmpty()) View.VISIBLE else View.GONE
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            layoutEmptyVideo.visibility = if (allFolders.isEmpty()) View.VISIBLE else View.GONE
        }

        rvAudio.visibility = if (filteredAudio.isNotEmpty()) View.VISIBLE else View.GONE
        layoutEmptyAudio.visibility = if (filteredAudio.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_video -> {
                    showTab(video = true, audio = false, youtube = false, settings = false)
                    switchVideoViewMode(folders = false)
                    true
                }
                R.id.nav_audio -> {
                    showTab(video = false, audio = true, youtube = false, settings = false)
                    true
                }
                R.id.nav_youtube -> {
                    showTab(video = false, audio = false, youtube = true, share = false, settings = false)
                    true
                }
                R.id.nav_share -> {
                    showTab(video = false, audio = false, youtube = false, share = true, settings = false)
                    true
                }
                R.id.nav_more -> {
                    showTab(video = false, audio = false, youtube = false, settings = true)
                    true
                }
                else -> false
            }
        }
    }

    private var areSettingsInitialized = false
    private fun ensureSettingsInitialized() {
        if (!areSettingsInitialized) {
            areSettingsInitialized = true
            setupAiSettings()
            setupVideoSettings()
            setupAudioSuiteSettings()
            setupSubtitleSettings()
            setupGestureSettings()
            setupInterfaceAndAdvancedSettings()
        }
    }

    private var isShareInitialized = false
    private fun ensureShareInitialized() {
        if (!isShareInitialized) {
            isShareInitialized = true
            setupShareTab()
        }
    }

    private fun showTab(video: Boolean, audio: Boolean, youtube: Boolean, share: Boolean = false, settings: Boolean = false) {
        val isExitingYouTube = ::tabYouTube.isInitialized && tabYouTube.visibility == View.VISIBLE && !youtube
        if (isExitingYouTube) {
            handleYouTubeToLocalTransition()
        }
        if (settings) {
            ensureSettingsInitialized()
        }
        if (share) {
            ensureShareInitialized()
        }
        tabVideo.visibility = if (video) View.VISIBLE else View.GONE
        tabAudio.visibility = if (audio) View.VISIBLE else View.GONE
        tabYouTube.visibility = if (youtube) View.VISIBLE else View.GONE
        if (::tabShare.isInitialized) tabShare.visibility = if (share) View.VISIBLE else View.GONE
        tabSettings.visibility = if (settings) View.VISIBLE else View.GONE

        if (youtube) {
            toolbar.visibility = View.GONE
            findViewById<View>(R.id.topBarContainer)?.visibility = View.GONE
            bottomNav.visibility = View.GONE
            fabPlay.visibility = View.GONE
            window.statusBarColor = Color.parseColor("#0F0F0F")

            if (!isYtFeedLoaded) {
                loadYouTubeFeed(currentYtCategory)
            }
        } else {
            if (!share && !FastShareService.isTransferActive.get()) {
                FastShareManager.stopTransferService(this)
            }
            lastActiveTabId = when {
                audio -> R.id.nav_audio
                share -> R.id.nav_share
                settings -> R.id.nav_more
                else -> R.id.nav_video
            }

            toolbar.visibility = View.VISIBLE
            findViewById<View>(R.id.topBarContainer)?.visibility = if (share || settings) View.GONE else View.VISIBLE
            bottomNav.visibility = View.VISIBLE
            updateFabPlayVisibility()
            window.statusBarColor = Color.parseColor("#000000")

            if (share) {
                refreshShareTabUI()
            }

            applyThemeUI()
        }
        updateNotchPlayerUI()
    }

    private fun initNativeYouTubeEngine() {
        rvYouTubeFeed.layoutManager = LinearLayoutManager(this)
        rvYouTubeFeedSecondary.layoutManager = LinearLayoutManager(this)

        youTubeFeedAdapter = YouTubeFeedAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        youTubeFeedAdapter.onChannelClick = { chTitle, avatar ->
            openYouTubeChannelPage(chTitle, avatar)
        }
        rvYouTubeFeed.adapter = youTubeFeedAdapter

        nsvYtFeed?.setOnScrollChangeListener(androidx.core.widget.NestedScrollView.OnScrollChangeListener { v, _, scrollY, _, _ ->
            val child = v.getChildAt(0) ?: return@OnScrollChangeListener
            val diff = (child.bottom - (v.height + scrollY))
            if (diff <= 1400 && !isYtFeedLoadingMore && isYtFeedLoaded) {
                loadMoreYouTubeHomeFeed()
            }
        })

        rvYouTubeFeed.addOnScrollListener(object : androidx.recyclerview.widget.RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: androidx.recyclerview.widget.RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (dy <= 0) return
                val lm = recyclerView.layoutManager as? androidx.recyclerview.widget.LinearLayoutManager ?: return
                if (!isYtFeedLoadingMore && isYtFeedLoaded && (lm.childCount + lm.findFirstVisibleItemPosition()) >= lm.itemCount - 4 && lm.itemCount > 0) {
                    loadMoreYouTubeHomeFeed()
                }
            }
        })

        youTubeFeedSecondaryAdapter = YouTubeFeedAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        youTubeFeedSecondaryAdapter.onChannelClick = { chTitle, avatar ->
            openYouTubeChannelPage(chTitle, avatar)
        }
        rvYouTubeFeedSecondary.adapter = youTubeFeedSecondaryAdapter


        btnYtPrevVideo = findViewById(R.id.btnYtPrevVideo)
        btnYtNextVideo = findViewById(R.id.btnYtNextVideo)
        ytMiniAudioVisualizerView = findViewById(R.id.ytMiniAudioVisualizerView)
        ytMiniAudioVisualizerView?.onModelChangedListener = { model, _ ->
            ytAudioVisualizerView.setModel(model)
        }
        layoutYtGestureOverlay = findViewById(R.id.layoutYtGestureOverlay)
        ivYtGestureIcon = findViewById(R.id.ivYtGestureIcon)
        tvYtGestureText = findViewById(R.id.tvYtGestureText)

        btnYtPrevVideo?.setOnClickListener {
            playPreviousYouTubeVideo()
            showYouTubeOverlay()
        }
        btnYtNextVideo?.setOnClickListener {
            playNextYouTubeVideo()
            showYouTubeOverlay()
        }

        findViewById<View>(R.id.ivYtLogo)?.setOnClickListener {
            exitYouTubeToLocal()
        }
        findViewById<View>(R.id.btnYtViewAllHistory)?.setOnClickListener {
            showYouTubeFullHistoryDialog()
        }
        findViewById<View>(R.id.btnYtViewAllDownloads)?.setOnClickListener {
            showYouTubeFullDownloadsDialog()
        }

        nsvYtFeed.setOnScrollChangeListener(androidx.core.widget.NestedScrollView.OnScrollChangeListener { v, _, scrollY, _, _ ->
            val child = v.getChildAt(0)
            if (child != null && scrollY >= (child.measuredHeight - v.measuredHeight - 400)) {
                if (!isYtLoadingMore && isYtFeedLoaded) {
                    loadMoreYouTubeFeed()
                }
            }
        })

        srlYouTubeFeed.setColorSchemeColors(Color.parseColor("#FF0000"))
        srlYouTubeFeed.setProgressBackgroundColorSchemeColor(Color.parseColor("#1A1A1A"))
        srlYouTubeFeed.setOnRefreshListener {
            loadYouTubeFeed(currentYtCategory)
        }

        btnYtRetry.setOnClickListener {
            loadYouTubeFeed(currentYtCategory)
        }

// btnYtExitToLocal click removed

        btnYtNavHome.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            // 1. Hide Subscriptions & You containers
            findViewById<View>(R.id.hsvSubscribedChannels)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtSubsDiscovery)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
            layoutYtEmpty.visibility = View.GONE

            // 2. Reset category chip to All
            currentYtCategory = "All"
            chipYtAll.setBackgroundResource(R.drawable.bg_youtube_chip_active)
            chipYtAll.setTextColor(Color.BLACK)
            for (c in listOf(chipYtMusic, chipYtGaming, chipYtNews, chipYtPodcasts, chipYtLive)) {
                c.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                c.setTextColor(Color.WHITE)
            }

            // 3. Restore Home feed immediately from cache without wipe
            if (allYtFeedVideos.isNotEmpty()) {
                youTubeFeedAdapter.updateItems(allYtFeedVideos)
                youTubeFeedSecondaryAdapter.updateItems(emptyList())
            } else {
                loadYouTubeFeed("All")
            }
            nsvYtFeed.smoothScrollTo(0, 0)
        }


        btnYtNavSubs.setOnClickListener {
            loadSubscriptionsFeed()
        }

        btnYtNavLibrary.setOnClickListener {
            exitYouTubeToLocal()
        }

        btnYtCast.setOnClickListener {
            showCastDevicesDialog()
        }

        btnYtNotifications.setOnClickListener {
            showNotificationsDialog()
        }

        btnYtAccount.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        btnYtSearch.setOnClickListener {
            if (layoutYtSearchBar.visibility == View.VISIBLE) {
                layoutYtSearchBar.visibility = View.GONE
            } else {
                layoutYtSearchBar.visibility = View.VISIBLE
                etYtSearchQuery.requestFocus()
            }
        }

        btnYtCloseSearch.setOnClickListener {
            val q = etYtSearchQuery.text?.toString() ?: ""
            if (q.isNotEmpty()) {
                // 1-tap clear typed text
                etYtSearchQuery.text?.clear()
            } else {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
                imm?.hideSoftInputFromWindow(etYtSearchQuery.windowToken, 0)
                etYtSearchQuery.clearFocus()
                layoutYtSearchBar.visibility = View.GONE
                loadYouTubeFeed(currentYtCategory)
            }
        }

        etYtSearchQuery.setOnEditorActionListener { _, _, _ ->
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
            imm?.hideSoftInputFromWindow(etYtSearchQuery.windowToken, 0)
            etYtSearchQuery.clearFocus()
            val query = etYtSearchQuery.text.toString().trim()
            if (query.isNotEmpty()) {
                performYouTubeSearch(query)
            }
            true
        }

        val chips = listOf(
            chipYtAll to "All",
            chipYtMusic to "Music",
            chipYtGaming to "Gaming",
            chipYtPodcasts to "Podcasts",
            chipYtLive to "Live",
            chipYtTrending to "Trending",
            chipYtNews to "News"
        )

        for ((chipView, cat) in chips) {
            chipView.setOnClickListener {
                for ((c, _) in chips) {
                    c.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                    c.setTextColor(Color.parseColor("#FFFFFF"))
                    c.setTypeface(null, android.graphics.Typeface.NORMAL)
                }
                chipView.setBackgroundResource(R.drawable.bg_youtube_chip_active)
                chipView.setTextColor(Color.parseColor("#000000"))
                chipView.setTypeface(null, android.graphics.Typeface.BOLD)

                currentYtCategory = cat
                loadYouTubeFeed(cat)
            }
        }

        setupYouTubeDetailPlayer()
        setupYouTubeMiniPlayer()

        findViewById<View>(R.id.btnYtPlayerSettings)?.setOnClickListener {
            showYouTubePlayerQuickControlsDialog()
        }
        findViewById<View>(R.id.btnYtPlayerQuality)?.setOnClickListener {
            showYouTubeQualityDialog()
        }
        findViewById<View>(R.id.btnYtPlayerAudioTrack)?.setOnClickListener {
            showAudioTrackSelectionDialog()
        }

        findViewById<View>(R.id.btnYtYouSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.rowYtReturnToLocal)?.setOnClickListener {
            exitYouTubeToLocal()
        }

        findViewById<View>(R.id.btnYtYouNavHome)?.setOnClickListener {
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
            findViewById<View>(R.id.hsvSubscribedChannels)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtSubsDiscovery)?.visibility = View.GONE
            layoutYtEmpty.visibility = View.GONE
            currentYtCategory = "All"
            chipYtAll.setBackgroundResource(R.drawable.bg_youtube_chip_active)
            chipYtAll.setTextColor(Color.BLACK)
            for (c in listOf(chipYtMusic, chipYtGaming, chipYtNews, chipYtPodcasts, chipYtLive)) {
                c.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                c.setTextColor(Color.WHITE)
            }
            if (allYtFeedVideos.isNotEmpty()) {
                youTubeFeedAdapter.updateItems(allYtFeedVideos)
                youTubeFeedSecondaryAdapter.updateItems(emptyList())
            } else {
                loadYouTubeFeed("All")
            }
            nsvYtFeed.smoothScrollTo(0, 0)
        }
        findViewById<View>(R.id.btnYtYouNavSubs)?.setOnClickListener { loadSubscriptionsFeed() }
        findViewById<View>(R.id.btnYtYouNavYou)?.setOnClickListener { updateYouTabUI() }
        findViewById<View>(R.id.btnYtYouCast)?.setOnClickListener { showCastDevicesDialog() }

        btnYtNavLibrary.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.VISIBLE
            updateYouTabUI()
        }

        rvYtHistory = findViewById(R.id.rvYtHistory)
        rvYtHistory.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        ytHistoryAdapter = YouTubeHistoryAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        ytHistoryAdapter?.onMoreClick = { video, _ ->
            showHistoryVideoOptionsMenu(video) {
                updateYouTabUI()
            }
        }
        rvYtHistory.adapter = ytHistoryAdapter

        rvYtDownloads = findViewById(R.id.rvYtDownloads)
        rvYtDownloads.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        ytDownloadsAdapter = YouTubeHistoryAdapter(this, emptyList()) { video ->
            playYouTubeVideoInApp(video)
        }
        ytDownloadsAdapter?.onMoreClick = { video, _ ->
            showDownloadedVideoOptionsMenu(video) {
                updateYouTabUI()
            }
        }
        rvYtDownloads.adapter = ytDownloadsAdapter

        findViewById<View>(R.id.cardYtPremiumBenefits)?.visibility = View.GONE
        findViewById<View>(R.id.cardYtYouAccount)?.setOnClickListener {
            val subCount = YouTubeSubscriptionManager.getSubscriptions(this).size
            val options = arrayOf(
                "📑 Subscribed Channels ($subCount channels)",
                "🎯 Preferred Topics & Feed Personalization",
                "✏️ Edit Profile Display Name",
                "⚙️ YouTube Settings & Preferences",
                "⚙️ YouTube Stream & Quality Settings",
                "🗑️ Clear Watch History"
            )
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Account & Profile")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> {
                            val subs = YouTubeSubscriptionManager.getSubscriptions(this)
                            if (subs.isEmpty()) {
                                loadSubscriptionsFeed()
                            } else {
                                val names = subs.map { "• " + it.title }.toTypedArray()
                                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                                    .setTitle("Subscribed Channels (${subs.size})")
                                    .setItems(names) { _, idx ->
                                        val ch = subs[idx]
                                        openYouTubeChannelPage(ch.title, ch.avatarUrl)
                                    }
                                    .setPositiveButton("Close", null)
                                    .show()
                            }
                        }
                        1 -> showPersonalizedTopicsDialog()
                        2 -> showEditProfileDialog()
                        3 -> showYouTubePremiumBenefitsDialog()
                        4 -> showYouTubeDedicatedSettingsDialog()
                        5 -> {
                            YouTubeHistoryManager.clearHistory(this)
                            updateYouTabUI()
                            CleanToast.show(this, "Watch history cleared")
                        }
                    }
                }
                .setNegativeButton("Close", null)
                .show()
        }
        findViewById<View>(R.id.rowYtReturnToLocal)?.setOnClickListener {
            exitYouTubeToLocal()
        }
        updateYouTabUI()
    }


    private fun updateScreenWakeLock(keepOn: Boolean) {
        runOnUiThread {
            if (keepOn) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (::playerViewYt.isInitialized) {
                    playerViewYt.keepScreenOn = true
                }
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.keepScreenOn = true
                }
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (::playerViewYt.isInitialized) {
                    playerViewYt.keepScreenOn = false
                }
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.keepScreenOn = false
                }
            }
        }
    }

    private fun setupYouTubeDetailPlayer() {
        rvYtRelatedVideos.layoutManager = LinearLayoutManager(this)
        rvYtRelatedVideos.adapter = youTubeFeedSecondaryAdapter

        val nsvYtDetail = findViewById<androidx.core.widget.NestedScrollView>(R.id.nsvYtDetail)
        nsvYtDetail?.setOnScrollChangeListener(androidx.core.widget.NestedScrollView.OnScrollChangeListener { v, _, scrollY, _, _ ->
            val child = v.getChildAt(0) ?: return@OnScrollChangeListener
            val diff = (child.bottom - (v.height + scrollY))
            if (diff <= 800 && !isRelatedVideosLoading && currentPlayingYtVideo != null) {
                loadMoreRelatedVideos()
            }
        })

        pbYtBottomMiniProgress = findViewById(R.id.pbYtBottomMiniProgress)
        layoutYtPlayerOverlay = findViewById(R.id.layoutYtPlayerOverlay)
        btnYtAudioMode = findViewById(R.id.btnYtAudioMode)
        layoutYtAudioModeVisual = findViewById(R.id.layoutYtAudioModeVisual)
        layoutYtAudioModeVisual.setOnClickListener {
            if (layoutYtPlayerOverlay.visibility == View.VISIBLE) {
                hideYouTubeOverlay()
            } else {
                showYouTubeOverlay()
            }
        }
        ivYtAudioModeThumb = findViewById(R.id.ivYtAudioModeThumb)

        btnYtAudioMode?.setOnClickListener {
            val isNowAudioOnly = YouTubeExoPlayerManager.toggleAudioVideoMode(this)
            updateAudioModeUI(isNowAudioOnly)
            updateScreenWakeLock(isYtVideoPlaying && !isNowAudioOnly)
        }
        btnYtVideoBoost = findViewById(R.id.btnYtVideoBoost)
        updateYtVideoBoostBadge()

        btnYtVideoBoost?.setOnClickListener {
            PlayerHolder.isAiVideoSharpnessEnabled = !PlayerHolder.isAiVideoSharpnessEnabled
            PlayerHolder.savePreferences(this)
            updateYtVideoBoostBadge()
            AiVideoEnhancer.applyEnhancement(this, false)
            CleanToast.show(
                this,
                if (PlayerHolder.isAiVideoSharpnessEnabled) "✨ HDR Boost: ON (Vibrant Colors & Contrast)" else "HDR Boost: OFF"
            )
            showYouTubeOverlay()
        }

        btnYtVideoBoost?.setOnLongClickListener {
            NeuralSuperResTuneDialog.show(this) {
                updateYtVideoBoostBadge()
                AiVideoEnhancer.applyEnhancement(this, false)
            }
            showYouTubeOverlay()
            true
        }

        btnYtPlayerCC = findViewById(R.id.btnYtPlayerCC)
        btnYtRewind10 = findViewById(R.id.btnYtRewind10)
        btnYtForward10 = findViewById(R.id.btnYtForward10)
        tvYtPlayerCurrentTime = findViewById(R.id.tvYtPlayerCurrentTime)
        sbYtPlayer = findViewById(R.id.sbYtPlayer)

        btnYtCollapsePlayer.setOnClickListener {
            handleBackPress()
        }

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        var ytGestureStartX = 0f
        var ytGestureStartY = 0f
        var isYtGestureActive = false
        var ytGestureType = 0 // 0: None, 1: Volume, 2: Brightness, 3: Seek
        var ytInitialVolume = 0
        var ytInitialBrightness = 0.5f
        var ytSeekStartPosition = 0L
        // showYtGestureFeedback moved to class member

        var ytLastTapTime = 0L
        var ytLastTapX = 0f
        var ytLastTapY = 0f
        var ytCumulativeScale = 1.0f

        val ytScaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                ytCumulativeScale = 1.0f
                isYtPinchActive = true
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                ytCumulativeScale *= detector.scaleFactor
                if (ytCumulativeScale > 1.12f) {
                    if (ytAspectRatioMode != 1) {
                        applyYouTubeAspectRatio(1) // Zoomed to fill (no black bars!)
                        ytCumulativeScale = 1.0f
                    }
                } else if (ytCumulativeScale < 0.88f) {
                    if (ytAspectRatioMode != 0) {
                        applyYouTubeAspectRatio(0) // Original Fit
                        ytCumulativeScale = 1.0f
                    }
                }
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                isYtPinchActive = false
                ytCumulativeScale = 1.0f
            }
        })

        fun handleYouTubeTouch(view: View, event: MotionEvent): Boolean {
            ytScaleDetector.onTouchEvent(event)
            if (event.pointerCount >= 2) {
                isYtGestureActive = false
                ytGestureType = 0
                return true
            }
            if (isYtPinchActive) {
                if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                    isYtPinchActive = false
                }
                return true
            }

            val w = view.width.toFloat().coerceAtLeast(1f)
            val h = view.height.toFloat().coerceAtLeast(1f)

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    ytGestureStartX = event.x
                    ytGestureStartY = event.y
                    isYtGestureActive = false
                    ytGestureType = 0
                    ytInitialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    ytInitialBrightness = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                    ytSeekStartPosition = YouTubeExoPlayerManager.getCurrentPosition()
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = event.x - ytGestureStartX
                    val deltaY = ytGestureStartY - event.y // up is positive
                    val absDeltaX = kotlin.math.abs(deltaX.toFloat())
                    val absDeltaY = kotlin.math.abs(deltaY.toFloat())

                    if (!isYtGestureActive && (absDeltaX > 25f || absDeltaY > 25f)) {
                        isYtGestureActive = true
                        ytGestureType = if (absDeltaX > absDeltaY) {
                            3 // Seek (Horizontal swipe)
                        } else if (ytGestureStartX >= w * 0.20f && ytGestureStartX <= w * 0.80f) {
                            4 // Fullscreen / Collapse (Vertical swipe from center 60% of video)
                        } else if (ytGestureStartX < w * 0.20f) {
                            2 // Brightness (Left vertical edge swipe)
                        } else {
                            1 // Volume (Right vertical edge swipe)
                        }
                    }

                    if (isYtGestureActive) {
                        when (ytGestureType) {
                            1 -> { // Volume
                                val change = ((deltaY / (h * 0.75f)) * maxVolume.toFloat()).toInt()
                                val newVol = (ytInitialVolume + change).coerceIn(0, maxVolume)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                                val percent = if (maxVolume > 0) (newVol * 100) / maxVolume else 0
                                showYtGestureFeedback(R.drawable.ic_equalizer, "Volume: $percent%")
                            }
                            2 -> { // Brightness
                                val change = deltaY / (h * 0.75f)
                                val newBrightness = (ytInitialBrightness + change).coerceIn(0.01f, 1.0f)
                                val lp = window.attributes
                                lp.screenBrightness = newBrightness
                                window.attributes = lp
                                val percent = (newBrightness * 100).toInt()
                                showYtGestureFeedback(android.R.drawable.ic_menu_view, "Brightness: $percent%")
                            }
                            3 -> { // Seek
                                val dur = YouTubeExoPlayerManager.getDuration()
                                if (dur > 0) {
                                    val seekOffsetMs = ((deltaX / w) * 90000).toLong()
                                    val targetMs = (ytSeekStartPosition + seekOffsetMs).coerceIn(0, dur)
                                    val sign = if (seekOffsetMs >= 0) "+" else ""
                                    showYtGestureFeedback(R.drawable.ic_speed, "$sign${seekOffsetMs / 1000}s (${formatTime(targetMs)})")
                                }
                            }
                            4 -> { // Center Vertical Swipe (Swipe Up -> Fullscreen, Swipe Down -> Exit/Collapse)
                                val minSwipeDist = 40f * resources.displayMetrics.density
                                if (deltaY > minSwipeDist) {
                                    if (!isYtFullscreen) {
                                        showYtGestureFeedback(R.drawable.ic_fullscreen, "Swipe Up for Fullscreen")
                                    }
                                } else if (deltaY < -minSwipeDist) {
                                    if (isYtFullscreen) {
                                        showYtGestureFeedback(R.drawable.ic_fullscreen_exit, "Swipe Down to Exit Fullscreen")
                                    } else {
                                        showYtGestureFeedback(R.drawable.ic_expand_more, "Swipe Down to Minimize")
                                    }
                                }
                            }
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isYtGestureActive) {
                        if (ytGestureType == 3) {
                            val deltaX = event.x - ytGestureStartX
                            val dur = YouTubeExoPlayerManager.getDuration()
                            if (dur > 0) {
                                val seekOffsetMs = ((deltaX / w) * 90000).toLong()
                                val targetMs = (ytSeekStartPosition + seekOffsetMs).coerceIn(0, dur)
                                YouTubeExoPlayerManager.seekTo(targetMs)
                            }
                        } else if (ytGestureType == 4) {
                            val deltaY = ytGestureStartY - event.y // up is positive
                            val minSwipeDist = 35f * resources.displayMetrics.density
                            if (deltaY > minSwipeDist) {
                                // Swiped UP: Automatically enter fullscreen landscape!
                                if (!isYtFullscreen) {
                                    toggleYouTubeFullscreen()
                                }
                            } else if (deltaY < -minSwipeDist) {
                                // Swiped DOWN: If fullscreen, exit to portrait; if portrait, collapse to miniplayer!
                                if (isYtFullscreen) {
                                    toggleYouTubeFullscreen()
                                } else {
                                    collapseYouTubePlayer()
                                }
                            }
                        }
                        isYtGestureActive = false
                        ytGestureType = 0
                    } else {
                        // Tap handling
                        val now = System.currentTimeMillis()
                        val tapDistX = kotlin.math.abs(event.x - ytLastTapX)
                        val tapDistY = kotlin.math.abs(event.y - ytLastTapY)

                        if (now - ytLastTapTime < 350 && tapDistX < 80f && tapDistY < 80f) {
                            // Double tap
                            ytLastTapTime = 0L
                            if (event.x < w * 0.35f) {
                                val cur = YouTubeExoPlayerManager.getCurrentPosition()
                                YouTubeExoPlayerManager.seekTo((cur - 10000).coerceAtLeast(0))
                                showYtGestureFeedback(R.drawable.ic_replay_10, "-10s")
                                showYouTubeOverlay()
                            } else if (event.x > w * 0.65f) {
                                val cur = YouTubeExoPlayerManager.getCurrentPosition()
                                val dur = YouTubeExoPlayerManager.getDuration()
                                YouTubeExoPlayerManager.seekTo((cur + 10000).coerceAtMost(dur))
                                showYtGestureFeedback(R.drawable.ic_forward_10, "+10s")
                                showYouTubeOverlay()
                            } else {
                                YouTubeExoPlayerManager.togglePlayPause()
                                showYouTubeOverlay()
                            }
                        } else {
                            // Single tap
                            ytLastTapTime = now
                            ytLastTapX = event.x
                            ytLastTapY = event.y
                            if (layoutYtPlayerOverlay.visibility == View.VISIBLE) {
                                hideYouTubeOverlay()
                            } else {
                                showYouTubeOverlay()
                            }
                        }
                    }
                }
            }
            return true
        }

        playerViewYt.setOnTouchListener { v, event -> handleYouTubeTouch(v, event) }
        layoutYtPlayerOverlay.setOnTouchListener { v, event -> handleYouTubeTouch(v, event) }

        btnYtRewind10.setOnClickListener {
            val cur = YouTubeExoPlayerManager.getCurrentPosition()
            YouTubeExoPlayerManager.seekTo((cur - 10000).coerceAtLeast(0))
            showYouTubeOverlay()
        }

        btnYtForward10.setOnClickListener {
            val cur = YouTubeExoPlayerManager.getCurrentPosition()
            val dur = YouTubeExoPlayerManager.getDuration()
            YouTubeExoPlayerManager.seekTo((cur + 10000).coerceAtMost(dur))
            showYouTubeOverlay()
        }



        btnYtPlayerCC.setOnClickListener {
            showYouTubeSubtitleDialog()
            showYouTubeOverlay()
        }

        sbYtPlayer.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    isYtUserSeeking = true
                    val dur = YouTubeExoPlayerManager.getDuration()
                    tvYtPlayerCurrentTime.text = "${formatTime(progress.toLong())} / ${formatTime(dur)}"
                    showYouTubeOverlay()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                isYtUserSeeking = true
                ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                isYtUserSeeking = false
                seekBar?.let {
                    YouTubeExoPlayerManager.seekTo(it.progress.toLong())
                }
                showYouTubeOverlay()
            }
        })

        btnYtFullscreen.setOnClickListener {
            toggleYouTubeFullscreen()
        }

        val openCurrentChannel = {
            currentPlayingYtVideo?.let { v ->
                openYouTubeChannelPage(v.channelTitle, v.channelAvatarUrl)
            }
        }
        tvYtDetailChannel.setOnClickListener { openCurrentChannel() }
        ivYtDetailAvatar.setOnClickListener { openCurrentChannel() }
        findViewById<View>(R.id.cardYtDetailAvatar)?.setOnClickListener { openCurrentChannel() }

        val ivYtDetailBell = findViewById<ImageView>(R.id.ivYtDetailBell)
        val updateSubscribeUI = { isSub: Boolean ->
            btnYtSubscribe.text = if (isSub) "Subscribed ∨" else "Subscribe"
            if (isSub) {
                btnYtSubscribe.setBackgroundColor(Color.parseColor("#272727"))
                btnYtSubscribe.setTextColor(Color.WHITE)
                ivYtDetailBell?.visibility = View.VISIBLE
            } else {
                btnYtSubscribe.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
                btnYtSubscribe.setTextColor(Color.BLACK)
                ivYtDetailBell?.visibility = View.GONE
            }
        }

        btnYtSubscribe.setOnClickListener {
            val v = currentPlayingYtVideo ?: return@setOnClickListener
            if (YouTubeSubscriptionManager.isSubscribed(this, v.channelTitle)) {
                YouTubeSubscriptionManager.unsubscribe(this, v.channelTitle)
                updateSubscribeUI(false)
                CleanToast.show(this, "Unsubscribed from ${v.channelTitle}")
            } else {
                YouTubeSubscriptionManager.subscribe(this, v.channelTitle, null, v.channelAvatarUrl)
                updateSubscribeUI(true)
                CleanToast.show(this, "Subscribed to ${v.channelTitle}!")
            }
        }

        ivYtDetailBell?.setOnClickListener {
            val v = currentPlayingYtVideo ?: return@setOnClickListener
            val bellOptions = arrayOf("🔔 All (Get all notifications)", "🔕 Personalized (Recommended)", "🚫 None (Muted)")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Notifications for ${v.channelTitle}")
                .setItems(bellOptions) { _, bIdx ->
                    val mode = when (bIdx) {
                        0 -> "All"
                        1 -> "Personalized"
                        else -> "Off"
                    }
                    CleanToast.show(this, "Notifications set to $mode for ${v.channelTitle}")
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        findViewById<View>(R.id.layoutYtListeningPill)?.setOnClickListener {
            showListeningControlsBottomSheet()
        }

        layoutYtLikePill.setOnClickListener {
            val video = currentPlayingYtVideo ?: return@setOnClickListener
            val isLiked = YouTubeHistoryManager.toggleBookmark(this, video)
            if (isLiked) {
                SmartRecommendationEngine.recordBookmarkSignal(this, video)
            }
            SmartRecommendationEngine.invalidateCache()
            val ivLike = findViewById<ImageView>(R.id.ivYtLikeIcon)
            val tvLikes = findViewById<TextView>(R.id.tvYtDetailLikes)
            if (isLiked) {
                ivLike?.setColorFilter(Color.parseColor("#FF0000"))
                tvLikes?.setTextColor(Color.parseColor("#FF0000"))
                // Silent notification removed
            } else {
                ivLike?.setColorFilter(Color.WHITE)
                tvLikes?.setTextColor(Color.WHITE)
                // Silent notification removed
            }
            updateYouTabUI()
        }

        layoutYtSharePill.setOnClickListener {
            val v = currentPlayingYtVideo ?: return@setOnClickListener
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, v.title)
                putExtra(Intent.EXTRA_TEXT, "Watch '${v.title}' on YouTube: https://youtu.be/${v.id}")
            }
            startActivity(Intent.createChooser(intent, "Share Video"))
        }

        layoutYtDownloadPill.setOnClickListener {
            currentPlayingYtVideo?.let { v ->
                YouTubeDownloaderHelper.showDownloadDialog(this, v)
            }
        }

        val openAudioQualityDialog = {
            val audioQualities = arrayOf(
                "Auto (Adaptive - Recommended)",
                "High Quality (160 kbps Opus - Studio Audio)",
                "Normal Quality (128 kbps M4A - Clear & Balanced)",
                "Data Saver (64 kbps - Ultra-Low Data)"
            )
            val curAudio = ytPrefs.getString("pref_yt_audio_quality", "Auto (Adaptive - Recommended)") ?: "Auto (Adaptive - Recommended)"
            val curIdx = audioQualities.indexOfFirst { it.startsWith(curAudio.substringBefore(" ")) }.coerceAtLeast(0)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Audio Streaming Quality")
                .setSingleChoiceItems(audioQualities, curIdx) { dialog, which ->
                    val selected = audioQualities[which]
                    ytPrefs.edit().putString("pref_yt_audio_quality", selected).apply()
                    updateSettingsUI()
                    val label = selected.substringBefore(" -")
                    // Silent notification removed
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeYtAudioQuality.setOnClickListener { openAudioQualityDialog() }
        findViewById<View>(R.id.rowYtAudioQuality).setOnClickListener { openAudioQualityDialog() }

        val openBufferLimitDialog = {
            val bufferOptions = arrayOf(
                "15s (Eco Data Saver - Least Data)",
                "30s (Balanced - Standard)",
                "60s (Ultra Fast - Anti-Stutter - Recommended)",
                "120s (Maximum Pre-Buffer - Wi-Fi & Travel)"
            )
            val curBuffer = ytPrefs.getString("pref_yt_buffer_limit", "30s (Balanced - Standard)") ?: "30s"
            val curIdx = bufferOptions.indexOfFirst { it.startsWith(curBuffer.substringBefore(" ")) }.let { if (it >= 0) it else 1 }

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Streaming Buffer Limit")
                .setSingleChoiceItems(bufferOptions, curIdx) { dialog, which ->
                    val selected = bufferOptions[which]
                    ytPrefs.edit().putString("pref_yt_buffer_limit", selected).apply()
                    YouTubeExoPlayerManager.applyBufferLimit(this, selected)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeYtBufferLimit.setOnClickListener { openBufferLimitDialog() }
        findViewById<View>(R.id.rowYtBufferLimit).setOnClickListener { openBufferLimitDialog() }

        val openMediaDiskCacheDialog = {
            val options = arrayOf(
                "512 MB (Compact Data Saver)",
                "1024 MB (1 GB - Recommended)",
                "2048 MB (2 GB - High Performance)",
                "4096 MB (4 GB - Ultra Large)",
                "8192 MB (8 GB - Extreme Heavy Usage)",
                "16384 MB (16 GB - Massive Offline Cache)",
                "32768 MB (32 GB - Maximum Storage)"
            )
            val sizeValues = longArrayOf(512L, 1024L, 2048L, 4096L, 8192L, 16384L, 32768L)
            val curMb = ytPrefs.getLong("pref_yt_disk_cache_mb", 1024L)
            val curIdx = sizeValues.indexOf(curMb).let { if (it >= 0) it else 1 }

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Media Disk Cache Size")
                .setSingleChoiceItems(options, curIdx) { dialog, which ->
                    val chosen = options[which]
                    val sizeMb = sizeValues[which]
                    ytPrefs.edit()
                        .putString("pref_yt_disk_cache_label", chosen)
                        .putLong("pref_yt_disk_cache_mb", sizeMb)
                        .apply()
                    YouTubeExoPlayerManager.updateDiskCacheSize(this, sizeMb)
                    updateSettingsUI()
                    CleanToast.show(this, "💾 Disk Cache: $chosen")
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.btnChangeYtMediaCache)?.setOnClickListener { openMediaDiskCacheDialog() }
        findViewById<View>(R.id.rowYtMediaCache)?.setOnClickListener { openMediaDiskCacheDialog() }

        val openStreamCacheTtlDialog = {
            val options = arrayOf(
                "2 Hours (Fast Refresh)",
                "4 Hours (Recommended)",
                "8 Hours (Extended Cache)",
                "12 Hours (All-Day Cache)",
                "24 Hours (Maximum Retention)",
                "48 Hours (Ultra Long Cache)"
            )
            val hoursValues = intArrayOf(2, 4, 8, 12, 24, 48)
            val curHours = ytPrefs.getInt("pref_yt_stream_ttl_hours", 4)
            val curIdx = hoursValues.indexOf(curHours).let { if (it >= 0) it else 1 }

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Stream URL Cache Duration")
                .setSingleChoiceItems(options, curIdx) { dialog, which ->
                    val chosen = options[which]
                    val hours = hoursValues[which]
                    ytPrefs.edit()
                        .putString("pref_yt_stream_ttl_label", chosen)
                        .putInt("pref_yt_stream_ttl_hours", hours)
                        .apply()
                    YouTubeStreamResolver.setCacheTtlHours(hours)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.btnChangeYtStreamCacheTtl)?.setOnClickListener { openStreamCacheTtlDialog() }
        findViewById<View>(R.id.rowYtStreamCacheTtl)?.setOnClickListener { openStreamCacheTtlDialog() }

        layoutYtSavePill.setOnClickListener {
            currentPlayingYtVideo?.let { v ->
                val saved = YouTubeHistoryManager.toggleBookmark(this, v)
                if (saved) {
                    SmartRecommendationEngine.recordBookmarkSignal(this, v)
                }
            }
        }

        findViewById<View>(R.id.layoutYtBookmarkPill)?.setOnClickListener {
            val video = currentPlayingYtVideo ?: return@setOnClickListener
            showKeyMomentsDialog(video)
        }

        layoutYtCommentsCard.setOnClickListener {
            val video = currentPlayingYtVideo ?: return@setOnClickListener
            showCommentsBottomSheet(video)
        }
    }

    private fun setupYouTubeMiniPlayer() {

        findViewById<View>(R.id.btnYtPlayerSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }
        findViewById<View>(R.id.btnYtPlayerQuality)?.setOnClickListener {
            showYouTubeQualityDialog()
        }
        findViewById<View>(R.id.btnYtPlayerAudioTrack)?.setOnClickListener {
            showAudioTrackSelectionDialog()
        }

        findViewById<View>(R.id.btnYtYouSettings)?.setOnClickListener {
            showYouTubeDedicatedSettingsDialog()
        }

        findViewById<View>(R.id.rowYtReturnToLocal)?.setOnClickListener {
            exitYouTubeToLocal()
        }

        findViewById<View>(R.id.btnYtYouNavHome)?.setOnClickListener {
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
            findViewById<View>(R.id.hsvSubscribedChannels)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtSubsDiscovery)?.visibility = View.GONE
            layoutYtEmpty.visibility = View.GONE
            currentYtCategory = "All"
            chipYtAll.setBackgroundResource(R.drawable.bg_youtube_chip_active)
            chipYtAll.setTextColor(Color.BLACK)
            for (c in listOf(chipYtMusic, chipYtGaming, chipYtNews, chipYtPodcasts, chipYtLive)) {
                c.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                c.setTextColor(Color.WHITE)
            }
            if (allYtFeedVideos.isNotEmpty()) {
                youTubeFeedAdapter.updateItems(allYtFeedVideos)
                youTubeFeedSecondaryAdapter.updateItems(emptyList())
            } else {
                loadYouTubeFeed("All")
            }
            nsvYtFeed.smoothScrollTo(0, 0)
        }
        findViewById<View>(R.id.btnYtYouNavSubs)?.setOnClickListener { loadSubscriptionsFeed() }
        findViewById<View>(R.id.btnYtYouNavYou)?.setOnClickListener { updateYouTabUI() }
        findViewById<View>(R.id.btnYtYouCast)?.setOnClickListener { showCastDevicesDialog() }

        btnYtNavLibrary.setOnClickListener {
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
            }
            findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.GONE
            findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.VISIBLE
        }
        cardYtMiniPlayer.setOnClickListener {
            if (::layoutYtMiniControlsOverlay.isInitialized && layoutYtMiniControlsOverlay.visibility == View.VISIBLE) {
                expandYouTubePlayer()
            } else {
                showMiniPlayerControls()
            }
        }

        btnYtMiniExpand.setOnClickListener {
            expandYouTubePlayer()
        }

        btnYtMiniPlayPause.setOnClickListener {
            YouTubeExoPlayerManager.togglePlayPause()
            val isPlaying = YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
            btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
            showMiniPlayerControls()
        }

        btnYtMiniClose.setOnClickListener {
            ytMiniControlsHideHandler.removeCallbacks(ytMiniControlsHideRunnable)
            YouTubeExoPlayerManager.stop()
            if (::playerViewYtMini.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
            }
            YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            cardYtMiniPlayer.visibility = View.GONE
            if (::layoutYtMiniControlsOverlay.isInitialized) {
                layoutYtMiniControlsOverlay.visibility = View.GONE
            }
            currentPlayingYtVideo = null
            isYtVideoPlaying = false
        }
    }

    private fun updateMiniPlayerUI() {
        val video = currentPlayingYtVideo
        if (video != null) {
            cardYtMiniPlayer.visibility = View.VISIBLE
            tvYtMiniTitle.text = video.title
            tvYtMiniChannel.text = video.channelTitle
            val isAudioMode = YouTubeExoPlayerManager.isAudioOnlyMode
            if (isAudioMode) {
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.visibility = View.GONE
                    YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
                }
                ivYtMiniThumb.visibility = View.VISIBLE
                ImageLoaderHelper.loadImage(video.thumbnailUrl, ivYtMiniThumb, R.drawable.ic_audio)
                ytMiniAudioVisualizerView?.visibility = View.GONE
                ytMiniAudioVisualizerView?.setPlaying(false)
                YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            } else {
                ivYtMiniThumb.visibility = View.GONE
                ytMiniAudioVisualizerView?.visibility = View.GONE
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.visibility = View.VISIBLE
                    YouTubeExoPlayerManager.switchPlayerView(playerViewYt, playerViewYtMini)
                }
            }
            btnYtMiniPlayPause.setImageResource(if (YouTubeExoPlayerManager.exoPlayer?.isPlaying == true) R.drawable.ic_pause_player else R.drawable.ic_play_player)
        } else {
            cardYtMiniPlayer.visibility = View.GONE
        }
    }

    private fun openYouTubeChannelPage(channelTitle: String, avatarUrl: String?) {
        if (channelTitle.isBlank()) return

        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val view = layoutInflater.inflate(R.layout.dialog_youtube_channel, null)
        dialog.setContentView(view)

        dialog.window?.let { win ->
            win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            win.statusBarColor = Color.parseColor("#0F0F0F")
            win.navigationBarColor = Color.parseColor("#0F0F0F")
        }

        view.findViewById<View>(R.id.btnChannelClose)?.setOnClickListener { dialog.dismiss() }

        val tvHeaderTitle = view.findViewById<TextView>(R.id.tvChannelHeaderTitle)
        val tvName = view.findViewById<TextView>(R.id.tvChannelName)
        val tvHandle = view.findViewById<TextView>(R.id.tvChannelHandle)
        val tvStats = view.findViewById<TextView>(R.id.tvChannelStats)
        val tvDesc = view.findViewById<TextView>(R.id.tvChannelDesc)
        val ivAvatar = view.findViewById<ImageView>(R.id.ivChannelAvatar)
        val ivBanner = view.findViewById<ImageView>(R.id.ivChannelBanner)
        val btnSub = view.findViewById<TextView>(R.id.btnChannelSubscribe)
        val btnJoin = view.findViewById<TextView>(R.id.btnChannelJoin)
        val tabHome = view.findViewById<TextView>(R.id.tabChannelHome)
        val tabVideos = view.findViewById<TextView>(R.id.tabChannelVideos)
        val tabLive = view.findViewById<TextView>(R.id.tabChannelLive)
        val tabPlaylists = view.findViewById<TextView>(R.id.tabChannelPlaylists)
        val rvVideos = view.findViewById<RecyclerView>(R.id.rvChannelVideos)
        val pbLoading = view.findViewById<ProgressBar>(R.id.pbChannelLoading)
        val tvEmpty = view.findViewById<TextView>(R.id.tvChannelEmpty)

        tvHeaderTitle?.text = channelTitle
        tvName?.text = channelTitle
        val cleanHandle = "@" + channelTitle.replace(" ", "").lowercase()
        tvHandle?.text = cleanHandle

        if (ivAvatar != null && !avatarUrl.isNullOrBlank()) {
            ImageLoaderHelper.loadImage(avatarUrl, ivAvatar, R.drawable.ic_account_circle)
        }

        val updateSubState = { isSubbed: Boolean ->
            btnSub?.text = if (isSubbed) "Subscribed ∨" else "Subscribe"
            if (isSubbed) {
                btnSub?.setBackgroundResource(R.drawable.bg_chip_black)
                btnSub?.setTextColor(Color.WHITE)
            } else {
                btnSub?.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
                btnSub?.setTextColor(Color.BLACK)
            }
        }

        val isSubbed = YouTubeSubscriptionManager.isSubscribed(this, channelTitle)
        updateSubState(isSubbed)

        btnSub?.setOnClickListener {
            if (YouTubeSubscriptionManager.isSubscribed(this, channelTitle)) {
                YouTubeSubscriptionManager.unsubscribe(this, channelTitle)
                updateSubState(false)
                CleanToast.show(this, "Unsubscribed from $channelTitle")
            } else {
                YouTubeSubscriptionManager.subscribe(this, channelTitle, null, avatarUrl)
                updateSubState(true)
                CleanToast.show(this, "Subscribed to $channelTitle!")
            }
            if (currentPlayingYtVideo?.channelTitle?.equals(channelTitle, ignoreCase = true) == true) {
                val nowSub = YouTubeSubscriptionManager.isSubscribed(this, channelTitle)
                btnYtSubscribe.text = if (nowSub) "Subscribed ∨" else "Subscribe"
                if (nowSub) {
                    btnYtSubscribe.setBackgroundColor(Color.parseColor("#272727"))
                    btnYtSubscribe.setTextColor(Color.WHITE)
                } else {
                    btnYtSubscribe.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
                    btnYtSubscribe.setTextColor(Color.BLACK)
                }
            }
        }

        // Functional ★ Join Membership Feature
        val channelVipKey = "vip_channel_" + channelTitle.trim().lowercase().replace(" ", "_")
        val vipPrefs = getSharedPreferences("cleanplayer_vip_channels", Context.MODE_PRIVATE)

        val updateJoinState = {
            val isVip = vipPrefs.getBoolean(channelVipKey, false)
            if (isVip) {
                btnJoin?.text = "★ Joined"
                btnJoin?.setTextColor(Color.parseColor("#FFD700"))
                btnJoin?.setBackgroundResource(R.drawable.bg_speed_preset_selected)
            } else {
                btnJoin?.text = "★ Join"
                btnJoin?.setTextColor(Color.WHITE)
                btnJoin?.setBackgroundResource(R.drawable.bg_chip_black)
            }
        }
        updateJoinState()

        btnJoin?.setOnClickListener {
            val isCurrentlyVip = vipPrefs.getBoolean(channelVipKey, false)
            if (isCurrentlyVip) {
                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                    .setTitle("★ $channelTitle Membership")
                    .setMessage("You are an active VIP Member of $channelTitle.\n\nBenefits:\n• VIP badge on channel & playback\n• Priority updates for live concerts & streams\n• Free supporter status in CleanPlayer")
                    .setPositiveButton("Keep Membership", null)
                    .setNegativeButton("Leave Membership") { _, _ ->
                        vipPrefs.edit().putBoolean(channelVipKey, false).apply()
                        updateJoinState()
                        CleanToast.show(this, "VIP membership removed")
                    }
                    .show()
            } else {
                AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                    .setTitle("★ Join $channelTitle Membership")
                    .setMessage("Join as a VIP Channel Member:\n\n• ★ Exclusive VIP Member badge on this channel\n• 🎵 Priority access to live concert streams & audio\n• ❤️ Support $channelTitle directly\n\n(CleanPlayer VIP Supporter feature)")
                    .setPositiveButton("★ Join Membership") { _, _ ->
                        vipPrefs.edit().putBoolean(channelVipKey, true).apply()
                        updateJoinState()
                        CleanToast.show(this, "🎉 You are now a VIP Member of $channelTitle!")
                    }
                    .setNegativeButton("Not Now", null)
                    .show()
            }
        }

        view.findViewById<View>(R.id.btnChannelSearch)?.setOnClickListener {
            dialog.dismiss()
            if (::etYtSearchQuery.isInitialized) { etYtSearchQuery.setText(channelTitle) }
            performYouTubeSearch(channelTitle)
        }

        view.findViewById<View>(R.id.btnChannelMenu)?.setOnClickListener {
            val options = arrayOf(
                "📤 Share Channel",
                "🔔 Channel Notifications",
                "🎯 Add Channel to Preferred Topics",
                "ℹ️ Channel Details"
            )
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(channelTitle)
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, channelTitle)
                                putExtra(Intent.EXTRA_TEXT, "Check out $channelTitle on CleanPlayer: https://www.youtube.com/results?search_query=${android.net.Uri.encode(channelTitle)}")
                            }
                            startActivity(Intent.createChooser(shareIntent, "Share Channel"))
                        }
                        1 -> {
                            val bellOptions = arrayOf("🔔 All (Get all notifications)", "🔕 Personalized (Recommended)", "🚫 None (Muted)")
                            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                                .setTitle("Notifications for $channelTitle")
                                .setItems(bellOptions) { _, bIdx ->
                                    val mode = when (bIdx) {
                                        0 -> "All"
                                        1 -> "Personalized"
                                        else -> "Off"
                                    }
                                    CleanToast.show(this, "Notifications set to $mode for $channelTitle")
                                }
                                .setNegativeButton("Cancel", null)
                                .show()
                        }
                        2 -> {
                            SmartRecommendationEngine.saveSelectedTopics(
                                this,
                                SmartRecommendationEngine.getSelectedTopics(this) + channelTitle
                            )
                            CleanToast.show(this, "Added '$channelTitle' to AI Preferred Topics!")
                        }
                        3 -> {
                            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                                .setTitle(channelTitle)
                                .setMessage("Channel: $channelTitle\nVerified: Yes\nPlatform: YouTube Official Creator\nPlayer: CleanPlayer Ad-Free Client")
                                .setPositiveButton("OK", null)
                                .show()
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        rvVideos?.layoutManager = LinearLayoutManager(this)
        val channelAdapter = YouTubeFeedAdapter(this, emptyList()) { selectedVideo ->
            dialog.dismiss()
            playYouTubeVideoInApp(selectedVideo)
        }
        rvVideos?.adapter = channelAdapter

        pbLoading?.visibility = View.VISIBLE
        tvEmpty?.visibility = View.GONE

        val selectTab = { selected: TextView? ->
            listOf(tabHome, tabVideos, tabLive, tabPlaylists).forEach { tab ->
                if (tab == selected) {
                    tab?.setTextColor(Color.WHITE)
                } else {
                    tab?.setTextColor(Color.parseColor("#888888"))
                }
            }
        }

        var allChannelVideos = emptyList<YouTubeVideo>()

        val parseViewsCount: (String) -> Long = { rawViews ->
            val raw = rawViews.lowercase()
            if (raw.contains("m")) {
                val num = raw.substringBefore("m").replace("views", "").trim().toDoubleOrNull() ?: 0.0
                (num * 1_000_000).toLong()
            } else if (raw.contains("k")) {
                val num = raw.substringBefore("k").replace("views", "").trim().toDoubleOrNull() ?: 0.0
                (num * 1_000).toLong()
            } else if (raw.contains("lakh")) {
                val num = raw.substringBefore("lakh").replace("views", "").trim().toDoubleOrNull() ?: 0.0
                (num * 100_000).toLong()
            } else if (raw.contains("cr")) {
                val num = raw.substringBefore("cr").replace("views", "").trim().toDoubleOrNull() ?: 0.0
                (num * 10_000_000).toLong()
            } else {
                raw.replace("views", "").replace(",", "").trim().toLongOrNull() ?: 0L
            }
        }

        // 1. Home Tab: Featured / Top videos + Recent
        tabHome?.setOnClickListener {
            selectTab(tabHome)
            if (allChannelVideos.isEmpty()) {
                tvEmpty?.visibility = View.VISIBLE
                tvEmpty?.text = "No videos available"
                channelAdapter.updateItems(emptyList())
            } else {
                tvEmpty?.visibility = View.GONE
                val sortedPopular = allChannelVideos.sortedByDescending { parseViewsCount(it.views) }
                val featured = sortedPopular.take(2)
                val rest = allChannelVideos.filterNot { it.id in featured.map { f -> f.id } }
                channelAdapter.updateItems(featured + rest)
            }
        }

        // 2. Videos Tab: Complete video catalog
        tabVideos?.setOnClickListener {
            selectTab(tabVideos)
            if (allChannelVideos.isEmpty()) {
                tvEmpty?.visibility = View.VISIBLE
                tvEmpty?.text = "No videos uploaded yet"
                channelAdapter.updateItems(emptyList())
            } else {
                tvEmpty?.visibility = View.GONE
                channelAdapter.updateItems(allChannelVideos)
            }
        }

        // 3. Live Tab: Live streams & Live concert recordings
        tabLive?.setOnClickListener {
            selectTab(tabLive)
            val liveFilter = allChannelVideos.filter { v ->
                val t = v.title.lowercase()
                t.contains("live") || t.contains("concert") || t.contains("stream") ||
                t.contains("performance") || t.contains("session") || t.contains("stage") ||
                t.contains("tour")
            }
            if (liveFilter.isNotEmpty()) {
                tvEmpty?.visibility = View.GONE
                channelAdapter.updateItems(liveFilter)
            } else {
                pbLoading?.visibility = View.VISIBLE
                tvEmpty?.visibility = View.GONE
                YouTubeFeedRepository.searchVideos("$channelTitle live concert") { fetchedLive ->
                    pbLoading?.visibility = View.GONE
                    if (fetchedLive.isNotEmpty()) {
                        tvEmpty?.visibility = View.GONE
                        channelAdapter.updateItems(fetchedLive)
                    } else {
                        tvEmpty?.visibility = View.VISIBLE
                        tvEmpty?.text = "No live streams found for $channelTitle"
                        channelAdapter.updateItems(emptyList())
                    }
                }
            }
        }

        // 4. Playlists Tab: Albums, Mixes & Compilations
        tabPlaylists?.setOnClickListener {
            selectTab(tabPlaylists)
            val playlistFilter = allChannelVideos.filter { v ->
                val t = v.title.lowercase()
                t.contains("playlist") || t.contains("album") || t.contains("mix") ||
                t.contains("jukebox") || t.contains("nonstop") || t.contains("full audio") ||
                t.contains("vol") || t.contains("ep") || t.contains("compilation")
            }
            if (playlistFilter.isNotEmpty()) {
                tvEmpty?.visibility = View.GONE
                channelAdapter.updateItems(playlistFilter)
            } else {
                pbLoading?.visibility = View.VISIBLE
                tvEmpty?.visibility = View.GONE
                YouTubeFeedRepository.searchVideos("$channelTitle full album playlist") { fetchedPlaylists ->
                    pbLoading?.visibility = View.GONE
                    if (fetchedPlaylists.isNotEmpty()) {
                        tvEmpty?.visibility = View.GONE
                        channelAdapter.updateItems(fetchedPlaylists)
                    } else {
                        tvEmpty?.visibility = View.VISIBLE
                        tvEmpty?.text = "No playlists found for $channelTitle"
                        channelAdapter.updateItems(emptyList())
                    }
                }
            }
        }

        YouTubeFeedRepository.getChannelDetails(channelTitle, avatarUrl) { chName, chHandle, chAvatar, chBanner, subCount, vidCount, description, channelVideos ->
            pbLoading?.visibility = View.GONE
            tvHandle?.text = chHandle
            tvStats?.text = "$subCount • $vidCount"
            tvDesc?.text = "$description ...more >"

            if (ivAvatar != null && !chAvatar.isNullOrBlank()) {
                ImageLoaderHelper.loadImage(chAvatar, ivAvatar, R.drawable.ic_account_circle)
            }
            if (ivBanner != null && !chBanner.isNullOrBlank()) {
                ImageLoaderHelper.loadImage(chBanner, ivBanner, R.drawable.bg_youtube_premium_badge)
            }

            allChannelVideos = channelVideos
            if (channelVideos.isEmpty()) {
                tvEmpty?.visibility = View.VISIBLE
            } else {
                tvEmpty?.visibility = View.GONE
                selectTab(tabHome)
                val sortedPopular = allChannelVideos.sortedByDescending { parseViewsCount(it.views) }
                val featured = sortedPopular.take(2)
                val rest = allChannelVideos.filterNot { it.id in featured.map { f -> f.id } }
                channelAdapter.updateItems(featured + rest)
            }
        }

        dialog.show()
    }

    private fun updateFabPlayVisibility() {
        if (!::fabPlay.isInitialized) return
        val isLocalMediaTab = (tabVideo.visibility == View.VISIBLE || tabAudio.visibility == View.VISIBLE)
        val isYtActive = (tabYouTube.visibility == View.VISIBLE || layoutYtPlayerDetail.visibility == View.VISIBLE || cardYtMiniPlayer.visibility == View.VISIBLE)
        fabPlay.visibility = if (isLocalMediaTab && !isYtActive) View.VISIBLE else View.GONE
    }

    private fun collapseYouTubePlayer() {
        try {
            val p = YouTubeExoPlayerManager.exoPlayer
            val curPos = p?.currentPosition ?: 0L
            val totDur = p?.duration ?: 0L
            currentPlayingYtVideo?.let { v ->
                SmartRecommendationEngine.recordWatchProgress(this, v, curPos, totDur)
            }
        } catch (e: Exception) {}
        hideYouTubeOverlay()
        layoutYtPlayerDetail.visibility = View.GONE
        findViewById<View>(R.id.bottomNav)?.visibility = View.VISIBLE
        updateFabPlayVisibility()
        findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
        findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE

        val video = currentPlayingYtVideo
        if (video != null) {
            cardYtMiniPlayer.visibility = View.VISIBLE
            tvYtMiniTitle.text = video.title
            tvYtMiniChannel.text = video.channelTitle
            val isAudioMode = YouTubeExoPlayerManager.isAudioOnlyMode
            if (isAudioMode) {
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.visibility = View.GONE
                    YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
                }
                ivYtMiniThumb.visibility = View.VISIBLE
                ImageLoaderHelper.loadImage(video.thumbnailUrl, ivYtMiniThumb, R.drawable.ic_audio)
                ytMiniAudioVisualizerView?.visibility = View.GONE
                ytMiniAudioVisualizerView?.setPlaying(false)
                YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            } else {
                ivYtMiniThumb.visibility = View.GONE
                ytMiniAudioVisualizerView?.visibility = View.GONE
                if (::playerViewYtMini.isInitialized) {
                    playerViewYtMini.visibility = View.VISIBLE
                    YouTubeExoPlayerManager.switchPlayerView(playerViewYt, playerViewYtMini)
                }
            }
            showMiniPlayerControls()
        } else {
            cardYtMiniPlayer.visibility = View.GONE
        }
    }


    private fun showMiniPlayerControls() {
        if (::layoutYtMiniControlsOverlay.isInitialized) {
            layoutYtMiniControlsOverlay.visibility = View.VISIBLE
            val isPlaying = YouTubeExoPlayerManager.exoPlayer?.isPlaying == true
            btnYtMiniPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player)
            ytMiniControlsHideHandler.removeCallbacks(ytMiniControlsHideRunnable)
            ytMiniControlsHideHandler.postDelayed(ytMiniControlsHideRunnable, 2500)
        }
    }

    private fun expandYouTubePlayer() {
        ytMiniControlsHideHandler.removeCallbacks(ytMiniControlsHideRunnable)
        if (::layoutYtMiniControlsOverlay.isInitialized) {
            layoutYtMiniControlsOverlay.visibility = View.GONE
        }
        cardYtMiniPlayer.visibility = View.GONE
        layoutYtPlayerDetail.visibility = View.VISIBLE
        if (YouTubeExoPlayerManager.isAudioOnlyMode) {
            updateAudioModeUI(true)
        } else {
            playerViewYt.visibility = View.VISIBLE
            YouTubeExoPlayerManager.switchPlayerView(playerViewYtMini, playerViewYt)
        }
        showYouTubeOverlay()
    }

    private fun toggleYouTubeAspectRatio() {
        ytAspectRatioMode = (ytAspectRatioMode + 1) % 3
        applyYouTubeAspectRatio(ytAspectRatioMode)
    }

    private fun applyYouTubeAspectRatio(mode: Int) {
        ytAspectRatioMode = mode
        when (mode) {
            0 -> {
                playerViewYt.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                showYtGestureFeedback(R.drawable.ic_aspect_ratio, "Original (Fit)")
            }
            1 -> {
                playerViewYt.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                showYtGestureFeedback(R.drawable.ic_aspect_ratio, "Zoomed to fill")
            }
            2 -> {
                playerViewYt.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
                showYtGestureFeedback(R.drawable.ic_aspect_ratio, "Stretch")
            }
        }
        showYouTubeOverlay()
    }

    private fun showYouTubeAspectRatioDialog() {
        val options = arrayOf(
            "Original (Fit to screen)",
            "Zoomed to fill (No black bars)",
            "Stretch to screen"
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Video Aspect Ratio & Zoom")
            .setSingleChoiceItems(options, ytAspectRatioMode.coerceIn(0, 2)) { dialog, which ->
                applyYouTubeAspectRatio(which)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exitYouTubeToLocal() {
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            layoutYtPlayerDetail.visibility = View.GONE
        }
        showTab(video = true, audio = false, youtube = false, settings = false)
        bottomNav.selectedItemId = R.id.nav_video
        updateNotchPlayerUI()
    }

    /**
     * AI-Powered Smart Intent Flow for YouTube to Local Navigation:
     * - If actively playing: Automatically converts into Background Audio-Only stream (90% data saved, 0 interruption).
     * - If paused: Detects intent. Preserves session in Top Notch player ready to resume instantly with 0 data drain.
     */
    private fun handleYouTubeToLocalTransition() {
        val ytVideo = currentPlayingYtVideo ?: YouTubeExoPlayerManager.currentPlayingVideo
        val isYtPlaying = YouTubeExoPlayerManager.isPlaying()

        if (!PlayerHolder.isAiSmartTransitionEnabled) {
            if (isYtPlaying) {
                YouTubeExoPlayerManager.pause()
                MediaPlaybackService.stop(this)
            }
            return
        }

        if (isYtPlaying && ytVideo != null) {
            // Case 1: Video was actively playing -> Seamlessly convert to Background Audio-Only!
            YouTubeExoPlayerManager.switchToPureAudio(this)
            YouTubeExoPlayerManager.isAudioOnlyMode = true

            if (::playerViewYt.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
            }
            if (::playerViewYtMini.isInitialized) {
                YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
                playerViewYtMini.visibility = View.GONE
            }
            if (::cardYtMiniPlayer.isInitialized) {
                cardYtMiniPlayer.visibility = View.GONE
            }

            MediaPlaybackService.start(
                context = this,
                title = ytVideo.title,
                artist = ytVideo.channelTitle,
                isPlaying = true,
                isYouTube = true,
                thumbUrl = ytVideo.thumbnailUrl
            )
            updateNotchPlayerUI()
            CleanToast.show(this, "🤖 Continuing as Audio-Only (Data Saved)")

        } else if (ytVideo != null) {
            // Case 2: Video was PAUSED by user before coming to Local!
            val duration = YouTubeExoPlayerManager.exoPlayer?.duration ?: 0L
            val currentPos = YouTubeExoPlayerManager.exoPlayer?.currentPosition ?: 0L
            val isNearEnd = duration > 0 && currentPos >= (duration - 5000L)

            if (isNearEnd) {
                // Video already completed: gracefully release session
                YouTubeExoPlayerManager.stop()
                MediaPlaybackService.stop(this)
                if (::cardYtMiniPlayer.isInitialized) cardYtMiniPlayer.visibility = View.GONE
            } else {
                // Video paused midway: Preserve state on Top Notch player ready to resume instantly!
                // Zero background data drain because player is paused.
                YouTubeExoPlayerManager.pause()
                MediaPlaybackService.stop(this)
                if (::playerViewYt.isInitialized) {
                    YouTubeExoPlayerManager.detachPlayerView(playerViewYt)
                }
                if (::playerViewYtMini.isInitialized) {
                    YouTubeExoPlayerManager.detachPlayerView(playerViewYtMini)
                    playerViewYtMini.visibility = View.GONE
                }
                if (::cardYtMiniPlayer.isInitialized) {
                    cardYtMiniPlayer.visibility = View.GONE
                }
                updateNotchPlayerUI()
                CleanToast.show(this, "Playback saved to Top Notch")
            }
        }
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            true
        }
    }

    private var isRelatedVideosLoading = false
    private var relatedVideosPage = 1

    private fun loadMoreRelatedVideos() {
        val currentVideo = currentPlayingYtVideo ?: return
        if (isRelatedVideosLoading) return
        isRelatedVideosLoading = true

        val query = when (relatedVideosPage) {
            1 -> currentVideo.channelTitle
            2 -> {
                val words = currentVideo.title.split(" ")
                    .filter { it.length > 3 && !it.startsWith("http") && !it.contains("?") }
                    .take(3).joinToString(" ")
                if (words.isNotBlank()) words else currentVideo.channelTitle
            }
            3 -> "trending ${currentVideo.category}"
            else -> {
                val topics = listOf("trending news", "top viral", "latest music", "popular hindi")
                topics[relatedVideosPage % topics.size]
            }
        }
        relatedVideosPage++

        YouTubeFeedRepository.searchVideos(query) { newVideos ->
            runOnUiThread {
                isRelatedVideosLoading = false
                if (newVideos.isNotEmpty() && currentPlayingYtVideo?.id == currentVideo.id) {
                    val historyIds = if (getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE).getBoolean("pref_yt_hide_watched", true)) {
                        YouTubeHistoryManager.getWatchHistory(this@MainActivity).map { it.id }.toSet()
                    } else emptySet()
                    val filtered = newVideos.filter { it.id != currentVideo.id && !historyIds.contains(it.id) }
                    youTubeFeedSecondaryAdapter.appendItems(if (filtered.isNotEmpty()) filtered else newVideos.filter { it.id != currentVideo.id })
                }
            }
        }
    }

    private fun playYouTubeVideoInApp(video: YouTubeVideo) {
        SmartRecommendationEngine.recordVideoClick(this, video.id)
        if (video.id.startsWith("/") || video.id.startsWith("file://") || video.id.startsWith("content://")) {
            val uri = if (video.id.startsWith("content://") || video.id.startsWith("file://")) Uri.parse(video.id) else Uri.fromFile(java.io.File(video.id))
            openPlayer(uri, video.title, isVideo = !video.id.endsWith(".m4a") && !video.id.endsWith(".mp3"), path = video.id)
            return
        }

        val downloadedOfflineFile = YouTubeDownloaderHelper.findDownloadedFile(video.title, video.id)
        if (downloadedOfflineFile != null && downloadedOfflineFile.exists()) {
            CleanToast.show(this, "Playing from Offline Downloads...")
            openPlayer(Uri.fromFile(downloadedOfflineFile), video.title, isVideo = !downloadedOfflineFile.name.endsWith(".m4a"), path = downloadedOfflineFile.absolutePath)
            return
        }

        if (!isNetworkAvailable()) {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("⚠️ Offline Mode")
                .setMessage("Aapka internet band hai aur '${video.title}' offline download nahi hai.\n\n• Watch History vs Downloads: History me sirf dekhe gaye videos ki list rehti hai. Offline bina internet chalane ke liye video ko pehle 'Download' karna hota hai.\n• Offline dekhne ke liye: Video ke niche 'Download' button dabayein.")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        PlayerHolder.stopPlayback(this)
        PlayerHolder.currentUri = null
        audioAdapter?.setPlayingUri(null)
        currentPlayingYtVideo = video
        isYtVideoPlaying = true
        updateScreenWakeLock(true)
        YouTubeHistoryManager.addWatchHistory(this, video)
        SmartRecommendationEngine.invalidateCache()

        // Populate video details using verified declared properties
        tvYtDetailTitle.text = video.title
        tvYtDetailSubtitle.text = "${video.views} • ${video.uploadDate}"
        tvYtDetailChannel.text = video.channelTitle
        ImageLoaderHelper.loadImage(video.channelAvatarUrl, ivYtDetailAvatar, R.drawable.ic_account_circle)
        tvYtDetailLikes.text = video.likes
        tvYtDetailCommentsCount.text = video.commentsCount

        val isSubState = YouTubeSubscriptionManager.isSubscribed(this, video.channelTitle)
        val ivBell = findViewById<ImageView>(R.id.ivYtDetailBell)
        btnYtSubscribe.text = if (isSubState) "Subscribed ∨" else "Subscribe"
        if (isSubState) {
            btnYtSubscribe.setBackgroundColor(Color.parseColor("#272727"))
            btnYtSubscribe.setTextColor(Color.WHITE)
            ivBell?.visibility = View.VISIBLE
        } else {
            btnYtSubscribe.setBackgroundResource(R.drawable.bg_youtube_subscribe_black)
            btnYtSubscribe.setTextColor(Color.BLACK)
            ivBell?.visibility = View.GONE
        }

        // Populate initial related recommendations in portrait feed below player (Excluding watched videos)
        val historyIds = if (getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE).getBoolean("pref_yt_hide_watched", true)) {
            YouTubeHistoryManager.getWatchHistory(this).map { it.id }.toSet()
        } else emptySet()

        val feedItems = youTubeFeedAdapter.getItems()
        val initialRelated = if (feedItems.isNotEmpty()) {
            val f = feedItems.filter { it.id != video.id && !historyIds.contains(it.id) }
            if (f.isNotEmpty()) f else feedItems.filter { it.id != video.id }
        } else {
            val f = YouTubeFeedRepository.defaultFeed.filter { it.id != video.id && !historyIds.contains(it.id) }
            if (f.isNotEmpty()) f else YouTubeFeedRepository.defaultFeed.filter { it.id != video.id }
        }
        youTubeFeedSecondaryAdapter.updateItems(initialRelated)

        // Asynchronously Pre-warm next video in background for 0ms instant start
        val nextCandidate = initialRelated.firstOrNull() ?: feedItems.firstOrNull { it.id != video.id }
        YouTubePreWarmEngine.prewarmVideo(nextCandidate?.id)

        // Reset pagination & fetch real targeted related videos for this video
        relatedVideosPage = 1
        isRelatedVideosLoading = true
        YouTubeFeedRepository.searchVideos(video.channelTitle) { channelVideos ->
            val titleWords = video.title.split(" ")
                .filter { it.length > 3 && !it.startsWith("http") }
                .take(3).joinToString(" ")
            val topicQuery = if (titleWords.isNotBlank()) titleWords else video.channelTitle
            YouTubeFeedRepository.searchVideos(topicQuery) { topicVideos ->
                runOnUiThread {
                    isRelatedVideosLoading = false
                    if (currentPlayingYtVideo?.id == video.id) {
                        val combined = (channelVideos + topicVideos + initialRelated)
                            .filter { it.id != video.id }
                            .distinctBy { it.id }
                        youTubeFeedSecondaryAdapter.updateItems(combined)
                    }
                }
            }
        }

        cardYtMiniPlayer.visibility = View.GONE
        layoutYtPlayerDetail.visibility = View.VISIBLE
        pbYtBuffering.visibility = View.VISIBLE
        btnYtCenterPlayPause.visibility = View.GONE
        tvYtDownloadPill.text = "Download"
        ivYtDownloadPill.setImageResource(R.drawable.ic_download)
        ivYtDownloadPill.setColorFilter(Color.WHITE)
        YouTubeExoPlayerManager.attachPlayerView(playerViewYt)
        updateYtVideoBoostBadge()
        AiVideoEnhancer.applyEnhancement(this, false)

        // Resolve pure, untracked streams via official TeamNewPipe NewPipeExtractor
        val targetRes = when (PlayerHolder.currentVideoQuality) {
            "4K Ultra HD (2160p)", "4K (2160p)", "2160p" -> 2160
            "2K Quad HD (1440p)", "2K (1440p)", "1440p" -> 1440
            "1080p", "1080p Full HD" -> 1080
            "720p", "720p HD" -> 720
            "480p", "480p SD" -> 480
            "360p", "360p Data Saver" -> 360
            "240p", "240p Low" -> 240
            "144p", "144p Ultra Data Saver", "144p Data Saver" -> 144
            else -> 720 // Default Auto to 720p (Adaptive Data Saver)
        }
        YouTubeStreamResolver.resolveStreams(video.id, targetRes) { resolvedStream ->
            pbYtBuffering.visibility = View.GONE
            if (resolvedStream != null && resolvedStream.videoUrl.isNotBlank()) {
                YouTubeFeedRepository.currentAvailableFormats = resolvedStream.availableQualities.map { opt ->
                    VideoStreamFormat(opt.qualityLabel, opt.resolution, opt.videoUrl, opt.audioUrl)
                }
                YouTubeExoPlayerManager.playVideo(
                    context = this,
                    video = video,
                    videoStreamUrl = resolvedStream.videoUrl,
                    audioStreamUrl = resolvedStream.audioUrl,
                    pureAudioUrl = resolvedStream.pureAudioUrl,
                    allAudioUrls = resolvedStream.allAudioUrls,
                    startInAudioOnly = YouTubeExoPlayerManager.isAudioOnlyMode,
                    availableAudioTracks = resolvedStream.availableAudioTracks
                )
                updateAudioModeUI(YouTubeExoPlayerManager.isAudioOnlyMode)
                // Video color filter removed
                btnYtCenterPlayPause.visibility = View.VISIBLE
                updateNotchPlayerUI()
            } else {
                btnYtCenterPlayPause.visibility = View.VISIBLE
                CleanToast.show(this, "Unable to load video. Please check connection.")
            }
        }
    }

    private fun updateMicroGAccountState() {
        btnYtAccount.clearColorFilter()
    }

    private var isYtFeedLoadingMore = false

    private fun loadMoreYouTubeHomeFeed() {
        if (isYtFeedLoadingMore || !isYtFeedLoaded) return
        isYtFeedLoadingMore = true
        if (currentYtCategory == "Subscriptions_Internal") {
            YouTubeSubscriptionManager.fetchSubscriptionsFeed(this) { moreVideos ->
                runOnUiThread {
                    isYtFeedLoadingMore = false
                    if (moreVideos.isNotEmpty()) {
                        val newOnly = moreVideos.filter { v -> allYtFeedVideos.none { it.id == v.id } }
                        if (newOnly.isNotEmpty()) {
                            allYtFeedVideos.addAll(newOnly)
                            youTubeFeedAdapter.appendItems(newOnly)
                        }
                    }
                }
            }
        } else {
            YouTubeFeedRepository.loadMoreFeed(currentYtCategory) { moreVideos ->
                runOnUiThread {
                    isYtFeedLoadingMore = false
                    if (moreVideos.isNotEmpty()) {
                        val newOnly = moreVideos.filter { v -> allYtFeedVideos.none { it.id == v.id } }
                        if (newOnly.isNotEmpty()) {
                            allYtFeedVideos.addAll(newOnly)
                            youTubeFeedAdapter.appendItems(newOnly)
                        }
                    }
                }
            }
        }
    }

    private fun loadYouTubeFeed(category: String) {
        pbYtFeedLoading.visibility = View.VISIBLE
        layoutYtEmpty.visibility = View.GONE

        findViewById<View>(R.id.hsvSubscribedChannels)?.visibility = View.GONE
        findViewById<View>(R.id.layoutYtSubsDiscovery)?.visibility = View.GONE

        if (category.equals("All", ignoreCase = true)) {
            val forceRefresh = srlYouTubeFeed.isRefreshing
            SmartRecommendationEngine.getSmartFeed(this, forceRefresh = forceRefresh) { smartVideos ->
                runOnUiThread {
                    pbYtFeedLoading.visibility = View.GONE
                    srlYouTubeFeed.isRefreshing = false
                    isYtFeedLoaded = true

                    if (smartVideos.isEmpty()) {
                        layoutYtEmpty.visibility = View.VISIBLE
                    } else {
                        layoutYtEmpty.visibility = View.GONE
                        allYtFeedVideos.clear()
                        allYtFeedVideos.addAll(smartVideos)
                        youTubeFeedAdapter.updateItems(smartVideos)
                        youTubeFeedSecondaryAdapter.updateItems(emptyList())
                    }
                }
            }
            return
        }

        YouTubeFeedRepository.getFeed(category) { videos ->
            runOnUiThread {
                pbYtFeedLoading.visibility = View.GONE
                srlYouTubeFeed.isRefreshing = false
                isYtFeedLoaded = true

                if (videos.isEmpty()) {
                    layoutYtEmpty.visibility = View.VISIBLE
                } else {
                    layoutYtEmpty.visibility = View.GONE
                    val historyIds = if (getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE).getBoolean("pref_yt_hide_watched", true)) {
                        YouTubeHistoryManager.getWatchHistory(this@MainActivity).map { it.id }.toSet()
                    } else emptySet()
                    val unreadVideos = videos.filter { !historyIds.contains(it.id) }.let { if (it.isNotEmpty()) it else videos }
                    allYtFeedVideos.clear()
                    allYtFeedVideos.addAll(unreadVideos)
                    youTubeFeedAdapter.updateItems(unreadVideos)
                    youTubeFeedSecondaryAdapter.updateItems(emptyList())
                }
            }
        }
    }

    private fun performYouTubeSearch(query: String) {
        SmartRecommendationEngine.recordSearchQuery(this, query)
        pbYtFeedLoading.visibility = View.VISIBLE
        layoutYtEmpty.visibility = View.GONE
        YouTubeFeedRepository.searchVideos(query) { videos ->
            pbYtFeedLoading.visibility = View.GONE
            if (videos.isEmpty()) {
                layoutYtEmpty.visibility = View.VISIBLE
            } else {
                layoutYtEmpty.visibility = View.GONE
                youTubeFeedAdapter.updateItems(videos)
                youTubeFeedSecondaryAdapter.updateItems(emptyList())
            }
        }
    }


    private fun enableImmersiveNotchMode() {
        try {
            window.navigationBarColor = Color.TRANSPARENT
            window.statusBarColor = Color.TRANSPARENT
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.isNavigationBarContrastEnforced = false
                window.isStatusBarContrastEnforced = false
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.let { controller ->
                    controller.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            }
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun toggleYouTubeFullscreen() {
        isYtFullscreen = !isYtFullscreen
        val surfaceContainer = findViewById<View>(R.id.layoutYtPlayerSurfaceContainer)
        val detailsScroll = layoutYtPlayerDetail.let { detail ->
            (detail as? android.view.ViewGroup)?.getChildAt(1)
        }

        if (isYtFullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            detailsScroll?.visibility = View.GONE
            findViewById<View>(R.id.bottomNav)?.visibility = View.GONE
            if (::fabPlay.isInitialized) fabPlay.visibility = View.GONE
            val lp = surfaceContainer?.layoutParams
            if (lp != null) {
                lp.height = LinearLayout.LayoutParams.MATCH_PARENT
                lp.width = LinearLayout.LayoutParams.MATCH_PARENT
                surfaceContainer.layoutParams = lp
            }
            btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen_exit)
            enableImmersiveNotchMode()
            applyYouTubeAspectRatio(ytAspectRatioMode)
            showYouTubeOverlay()
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            detailsScroll?.visibility = View.VISIBLE
            findViewById<View>(R.id.bottomNav)?.visibility = View.VISIBLE
            updateFabPlayVisibility()
            val lp = surfaceContainer?.layoutParams
            if (lp != null) {
                lp.height = (230 * resources.displayMetrics.density).toInt()
                lp.width = LinearLayout.LayoutParams.MATCH_PARENT
                surfaceContainer.layoutParams = lp
            }
            btnYtFullscreen.setImageResource(R.drawable.ic_fullscreen)
            window.statusBarColor = Color.parseColor("#0F0F0F")
            applyYouTubeAspectRatio(ytAspectRatioMode)
            showYouTubeOverlay()
        }
    }

    private fun updateYouTabUI() {
        val historyList = YouTubeHistoryManager.getWatchHistory(this)
        ytHistoryAdapter?.updateItems(historyList)
        findViewById<View>(R.id.rvYtHistory)?.visibility = if (historyList.isNotEmpty()) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnYtViewAllHistory)?.visibility = if (historyList.isNotEmpty()) View.VISIBLE else View.GONE

        val actualDownloads = YouTubeDownloaderHelper.getDownloadedVideos(this)
        val bookmarks = YouTubeHistoryManager.getBookmarks(this)
        val combinedDownloads = (actualDownloads + bookmarks).distinctBy { it.id }
        ytDownloadsAdapter?.updateItems(combinedDownloads)
        findViewById<View>(R.id.rvYtDownloads)?.visibility = if (combinedDownloads.isNotEmpty()) View.VISIBLE else View.GONE

        // Profile matching screenshot 6217.jpg & YouTube Premium (Customizable per device)
        val tvName = findViewById<TextView>(R.id.tvYtYouName)
        val tvStatus = findViewById<TextView>(R.id.tvYtYouStatus)
        val profPrefs = getSharedPreferences("yt_profile_prefs", Context.MODE_PRIVATE)
        val defaultName = profPrefs.getString("profile_name", "Rajesh Shah") ?: "Rajesh Shah"
        val defaultHandle = profPrefs.getString("profile_handle", "@Rps11") ?: "@Rps11"

        tvName?.text = defaultName
        tvStatus?.text = "$defaultHandle • CleanPlayer Premium (Ad-Free)"
        tvStatus?.setTextColor(Color.parseColor("#AAAAAA"))
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        try {
            activeSettingsBottomSheet?.dismiss()
            activeSettingsBottomSheet = null
        } catch (e: Exception) {}

        if (tabYouTube.visibility == View.VISIBLE &&
            (layoutYtPlayerDetail.visibility == View.VISIBLE || cardYtMiniPlayer.visibility == View.VISIBLE) &&
            YouTubeExoPlayerManager.isPlaying()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    if (cardYtMiniPlayer.visibility == View.VISIBLE) {
                        expandYouTubePlayer()
                    }
                    val aspectRatio = Rational(16, 9)
                    val params = PictureInPictureParams.Builder()
                        .setAspectRatio(aspectRatio)
                        .build()
                    enterPictureInPictureMode(params)
                } catch (e: Exception) {}
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        val surface = findViewById<View>(R.id.layoutYtPlayerSurfaceContainer)
        if (isInPictureInPictureMode) {
            hideYouTubeOverlay()
            if (::layoutYtPlayerOverlay.isInitialized) {
                layoutYtPlayerOverlay.visibility = View.GONE
            }
            layoutYtGestureOverlay?.visibility = View.GONE
            btnYtCenterPlayPause.visibility = View.GONE
            btnYtCollapsePlayer.visibility = View.GONE
            btnYtFullscreen.visibility = View.GONE
            pbYtBuffering.visibility = View.GONE
            layoutYtPlayerDetail.let { detail ->
                (detail as? android.view.ViewGroup)?.getChildAt(1)?.visibility = View.GONE
            }
            findViewById<View>(R.id.layoutYtHeader)?.visibility = View.GONE
            findViewById<View>(R.id.bottomNav)?.visibility = View.GONE
            if (::fabPlay.isInitialized) fabPlay.visibility = View.GONE
            val lp = surface?.layoutParams
            if (lp != null) {
                lp.height = LinearLayout.LayoutParams.MATCH_PARENT
                surface.layoutParams = lp
            }
        } else {
            if (tabYouTube.visibility == View.VISIBLE) {
                layoutYtPlayerDetail.let { detail ->
                    (detail as? android.view.ViewGroup)?.getChildAt(1)?.visibility = View.VISIBLE
                }
                findViewById<View>(R.id.layoutYtHeader)?.visibility = View.VISIBLE
                if (!isYtFullscreen) {
                    findViewById<View>(R.id.bottomNav)?.visibility = View.VISIBLE
                    updateFabPlayVisibility()
                }
                val lp = surface?.layoutParams
                if (lp != null && !isYtFullscreen) {
                    lp.height = (230 * resources.displayMetrics.density).toInt()
                    surface.layoutParams = lp
                }
                showYouTubeOverlay()
            }
        }
    }

    
    private fun showEditProfileDialog() {
        val profPrefs = getSharedPreferences("yt_profile_prefs", Context.MODE_PRIVATE)
        val currentName = profPrefs.getString("profile_name", "Rajesh Shah") ?: "Rajesh Shah"
        val currentHandle = profPrefs.getString("profile_handle", "@Rps11") ?: "@Rps11"

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(60, 40, 60, 20)
        }

        val etName = EditText(this).apply {
            hint = "Display Name (e.g. Rajesh Shah)"
            setText(currentName)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }

        val etHandle = EditText(this).apply {
            hint = "Channel Handle (e.g. @Rps11)"
            setText(currentHandle)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 30 }
        }

        container.addView(etName)
        container.addView(etHandle)

        AlertDialog.Builder(this)
            .setTitle("Edit YouTube Profile")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                val newName = etName.text.toString().trim().ifBlank { "Rajesh Shah" }
                val newHandle = etHandle.text.toString().trim().ifBlank { "@Rps11" }
                profPrefs.edit()
                    .putString("profile_name", newName)
                    .putString("profile_handle", if (newHandle.startsWith("@")) newHandle else "@$newHandle")
                    .apply()
                updateYouTabUI()
                CleanToast.show(this, "Profile updated: $newName")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    
    private fun showYouTubeOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode) {
            hideYouTubeOverlay()
            return
        }
        updateYtVideoBoostBadge()
        ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
        if (::pbYtBottomMiniProgress.isInitialized) {
            pbYtBottomMiniProgress.visibility = View.GONE
        }
        if (::btnYtCenterPlayPause.isInitialized) {
            btnYtCenterPlayPause.visibility = View.VISIBLE
            btnYtCenterPlayPause.setImageResource(
                if (YouTubeExoPlayerManager.isPlaying()) R.drawable.ic_pause_player else R.drawable.ic_play_player
            )
        }
        if (layoutYtPlayerOverlay.visibility != View.VISIBLE) {
            layoutYtPlayerOverlay.alpha = 0f
            layoutYtPlayerOverlay.visibility = View.VISIBLE
            layoutYtPlayerOverlay.animate()
                .alpha(1f)
                .setDuration(180)
                .start()
        }
        if (YouTubeExoPlayerManager.isPlaying()) {
            ytOverlayHandler.postDelayed(ytOverlayHideRunnable, 3000)
        }
    }

    private fun hideYouTubeOverlay() {
        ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
        if (::layoutYtPlayerOverlay.isInitialized) {
            layoutYtPlayerOverlay.animate().cancel()
            layoutYtPlayerOverlay.visibility = View.GONE
        }
        if (::pbYtBottomMiniProgress.isInitialized && !YouTubeExoPlayerManager.isAudioOnlyMode) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isInPictureInPictureMode) {
                pbYtBottomMiniProgress.visibility = View.GONE
            } else {
                pbYtBottomMiniProgress.visibility = View.VISIBLE
            }
        }
    }


    // =========================================================================
    private fun handleBackPress(): Boolean {
        // 1. YouTube Active Screen handling
        if (tabYouTube.visibility == View.VISIBLE) {
            if (isYtFullscreen) {
                toggleYouTubeFullscreen()
                return true
            }
            if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
                collapseYouTubePlayer()
                return true
            }
            if (findViewById<View>(R.id.layoutYtYouContainer)?.visibility == View.VISIBLE) {
                findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
                findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
                return true
            }
            if (layoutYtSearchBar.visibility == View.VISIBLE) {
                layoutYtSearchBar.visibility = View.GONE
                loadYouTubeFeed(currentYtCategory)
                return true
            }

            // When user presses Back from YouTube feed:
            // Smoothly navigate back to main screen (Video tab with toolbar & 3-dot menu)
            exitYouTubeToLocal()
            return true
        } else if (isFolderViewActive && currentSelectedFolder != null) {
            closeFolderDetail()
            return true
        }

        // 2. Active WebShare Dialog: Dismiss dialog without stopping background WebShare server!
        if (activeWebShareDialog?.isShowing == true) {
            try {
                activeWebShareDialog?.dismiss()
            } catch (e: Exception) {}
            activeWebShareDialog = null
            refreshShareTabUI()
            return true
        }

        // 3. Active FastShare Progress Dialog
        if (activeShareProgressDialog?.isShowing == true) {
            try {
                activeShareProgressDialog?.dismiss()
            } catch (e: Exception) {}
            activeShareProgressDialog = null
            refreshShareTabUI()
            return true
        }

        if (FastShareService.isTransferActive.get()) {
            moveTaskToBack(true)
            return true
        }

        // 4. Tab Navigation: If user is on Audio, Share, or Settings/More, pressing Back returns to Video Tab!
        if (tabVideo.visibility != View.VISIBLE) {
            showTab(video = true, audio = false, youtube = false, share = false, settings = false)
            bottomNav.selectedItemId = R.id.nav_video
            return true
        }

        // 5. If audio or video is playing in background, moveTaskToBack instead of destroying playback
        if (YouTubeExoPlayerManager.isPlaying() || PlayerHolder.audioExoPlayer?.isPlaying == true || PlayerHolder.mediaPlayer?.isPlaying == true) {
            moveTaskToBack(true)
            return true
        }

        // 6. Home (Video) Tab Double-Tap Back to Exit Prevention
        if (backPressedOnce) {
            finish()
            return true
        }
        backPressedOnce = true
        CleanToast.show(this, "Press back again to exit CleanPlayer")
        Handler(Looper.getMainLooper()).postDelayed({ backPressedOnce = false }, 2000)
        return true
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
            if (handleBackPress()) return true
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (handleBackPress()) return
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    private fun showYouTubePremiumBenefitsDialog() {
        showYouTubeDedicatedSettingsDialog()
    }

    private fun showYouTubeListeningControlsDialog() {
        val speeds = arrayOf("0.75x", "1.0x (Normal)", "1.25x", "1.5x", "2.0x")
        val speedValues = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val currentSpeed = YouTubeExoPlayerManager.exoPlayer?.playbackParameters?.speed ?: 1.0f

        val options = arrayOf(
            "⏪ Rewind 10 seconds",
            "⏩ Forward 10 seconds",
            "⚡ Speed: ${currentSpeed}x",
            "🎧 Background Play: Always Enabled (Premium)",
            "📱 Enter Picture-in-Picture Mode"
        )

        AlertDialog.Builder(this)
            .setTitle("🎧 YouTube Premium Listening Controls")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val p = (YouTubeExoPlayerManager.getCurrentPosition() - 10000).coerceAtLeast(0)
                        YouTubeExoPlayerManager.seekTo(p)
                        // Toast removed per user request (unnecessary)
                    }
                    1 -> {
                        val d = YouTubeExoPlayerManager.getDuration()
                        val p = (YouTubeExoPlayerManager.getCurrentPosition() + 10000).coerceAtMost(d)
                        YouTubeExoPlayerManager.seekTo(p)
                        // Toast removed per user request (unnecessary)
                    }
                    2 -> {
                        AlertDialog.Builder(this)
                            .setTitle("Select Playback Speed")
                            .setItems(speeds) { _, sIdx ->
                                YouTubeExoPlayerManager.exoPlayer?.setPlaybackSpeed(speedValues[sIdx])
                                // Toast removed per user request (unnecessary)
                            }
                            .show()
                    }
                    3 -> {
                        // Unwanted popup removed
                    }
                    4 -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            try {
                                enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build())
                            } catch (e: Exception) {}
                        }
                    }
                }
            }
            .setPositiveButton("Done", null)
            .show()
    }

    // --- 0. AI Smart Suite & Performance Handlers ---
    private fun showHardwareProfilerDialog() {
        HardwareProfilerEngine.showProfilerDialog(this)
    }

    private fun setupAiSettings() {
        tvPerformanceModeStatus = findViewById(R.id.tvPerformanceModeStatus)
        tvSettingAiKaraokeStatus = findViewById(R.id.tvSettingAiKaraokeStatus)
        btnToggleSettingAiKaraoke = findViewById(R.id.btnToggleSettingAiKaraoke)
        tvSettingAiAutoEqStatus = findViewById(R.id.tvSettingAiAutoEqStatus)
        btnToggleSettingAiAutoEq = findViewById(R.id.btnToggleSettingAiAutoEq)
        tvSettingAiSilenceStatus = findViewById(R.id.tvSettingAiSilenceStatus)
        btnToggleSettingAiSilence = findViewById(R.id.btnToggleSettingAiSilence)
        tvSettingAiLyricsStatus = findViewById(R.id.tvSettingAiLyricsStatus)
        btnToggleSettingAiLyrics = findViewById(R.id.btnToggleSettingAiLyrics)
        tvSettingSpeechToTextStatus = findViewById(R.id.tvSettingSpeechToTextStatus)
        btnToggleSettingSpeechToText = findViewById(R.id.btnToggleSettingSpeechToText)
        tvSettingAutoEmbedLrcStatus = findViewById(R.id.tvSettingAutoEmbedLrcStatus)
        btnToggleSettingAutoEmbedLrc = findViewById(R.id.btnToggleSettingAutoEmbedLrc)
        tvSettingWordSyncStatus = findViewById(R.id.tvSettingWordSyncStatus)
        btnToggleSettingWordSync = findViewById(R.id.btnToggleSettingWordSync)
        tvSettingAiProfilerStatus = findViewById(R.id.tvSettingAiProfilerStatus)
        btnViewSettingAiProfiler = findViewById(R.id.btnViewSettingAiProfiler)

        btnToggleSettingAiKaraoke.setOnClickListener {
            val s = !PlayerHolder.isAiKaraokeEnabled
            AiAudioDspEngine.applyKaraokeMode(this, false, s)
            updateSettingsUI()
            CleanToast.show(this, if (s) "🎤 AI Karaoke: ON (Vocals Cut)" else "🎤 AI Karaoke: OFF")
        }
        findViewById<View>(R.id.rowSettingAiKaraoke)?.setOnClickListener { btnToggleSettingAiKaraoke.performClick() }

        btnToggleSettingAiAutoEq.setOnClickListener {
            PlayerHolder.isAiAutoEqEnabled = !PlayerHolder.isAiAutoEqEnabled
            updateSettingsUI()
            CleanToast.show(this, if (PlayerHolder.isAiAutoEqEnabled) "🎛️ Auto-EQ: ON (${PlayerHolder.currentAiDetectedGenre})" else "🎛️ Auto-EQ: OFF")
        }
        findViewById<View>(R.id.rowSettingAiAutoEq)?.setOnClickListener { btnToggleSettingAiAutoEq.performClick() }

        btnToggleSettingAiSilence.setOnClickListener {
            PlayerHolder.isAiSilenceTrimmerEnabled = !PlayerHolder.isAiSilenceTrimmerEnabled
            updateSettingsUI()
            CleanToast.show(this, if (PlayerHolder.isAiSilenceTrimmerEnabled) "🔇 Silence Trimmer: ON" else "🔇 Silence Trimmer: OFF")
        }
        findViewById<View>(R.id.rowSettingAiSilence)?.setOnClickListener { btnToggleSettingAiSilence.performClick() }

        btnToggleSettingAiLyrics.setOnClickListener {
            PlayerHolder.isDualLanguageLyricsEnabled = !PlayerHolder.isDualLanguageLyricsEnabled
            updateSettingsUI()
            CleanToast.show(this, if (PlayerHolder.isDualLanguageLyricsEnabled) "📜 Synced Lyrics + Translation: ON" else "📜 Synced Lyrics: Standard")
        }
        findViewById<View>(R.id.rowSettingAiLyrics)?.setOnClickListener { btnToggleSettingAiLyrics.performClick() }

        btnToggleSettingSpeechToText.setOnClickListener {
            PlayerHolder.isSpeechToTextAutoEnabled = !PlayerHolder.isSpeechToTextAutoEnabled
            updateSettingsUI()
            CleanToast.show(this, if (PlayerHolder.isSpeechToTextAutoEnabled) "🎙️ Speech-to-Text Engine: ON" else "🎙️ Speech-to-Text Engine: OFF")
        }
        findViewById<View>(R.id.rowSettingSpeechToText)?.setOnClickListener { btnToggleSettingSpeechToText.performClick() }

        btnToggleSettingAutoEmbedLrc.setOnClickListener {
            PlayerHolder.isAutoEmbedLrcEnabled = !PlayerHolder.isAutoEmbedLrcEnabled
            updateSettingsUI()
            CleanToast.show(this, if (PlayerHolder.isAutoEmbedLrcEnabled) "💾 Permanent .LRC Attachment: ON" else "💾 Permanent .LRC Attachment: OFF")
        }
        findViewById<View>(R.id.rowSettingAutoEmbedLrc)?.setOnClickListener { btnToggleSettingAutoEmbedLrc.performClick() }

        btnToggleSettingWordSync.setOnClickListener {
            PlayerHolder.isWordByWordLyricsEnabled = !PlayerHolder.isWordByWordLyricsEnabled
            updateSettingsUI()
            CleanToast.show(this, if (PlayerHolder.isWordByWordLyricsEnabled) "🎤 Word-by-Word Karaoke Sync: ON" else "🎤 Standard Line Sync: ON")
        }
        findViewById<View>(R.id.rowSettingWordSync)?.setOnClickListener { btnToggleSettingWordSync.performClick() }

        btnViewSettingAiProfiler.setOnClickListener {
            showHardwareProfilerDialog()
        }
        findViewById<View>(R.id.rowSettingAiProfiler)?.setOnClickListener { showHardwareProfilerDialog() }

        val openSmartAiHub = {
            SmartAiHubDialog.show(this) {
                updateSettingsUI()
            }
        }
        findViewById<View>(R.id.btnOpenSmartAiHub)?.setOnClickListener { openSmartAiHub() }
        findViewById<View>(R.id.rowOpenSmartAiHub)?.setOnClickListener { openSmartAiHub() }

        btnChangePerformanceMode = findViewById(R.id.btnChangePerformanceMode)
        tvAiSmartTransitionStatus = findViewById(R.id.tvAiSmartTransitionStatus)
        btnToggleAiSmartTransition = findViewById(R.id.btnToggleAiSmartTransition)
        tvAiTopicPreferencesStatus = findViewById(R.id.tvAiTopicPreferencesStatus)
        btnChangeAiTopics = findViewById(R.id.btnChangeAiTopics)
        tvAiDialogueBoostStatus = findViewById(R.id.tvAiDialogueBoostStatus)
        btnToggleAiDialogueBoost = findViewById(R.id.btnToggleAiDialogueBoost)
        tvAiSponsorBlockStatus = findViewById(R.id.tvAiSponsorBlockStatus)
        btnConfigAiSponsorBlock = findViewById(R.id.btnConfigAiSponsorBlock)

        val openPerfDialog = {
            val options = arrayOf(
                "🏎️ Ultra Fast / Turbo (High Performance)\n• Instant video & audio pre-warming\n• 60s Anti-stutter Playback Buffer\n• High-speed RAM & 120Hz thumbnail cache",
                "⚖️ Balanced (Recommended)\n• 30s Standard Playback Buffer\n• Standard RAM & battery balanced",
                "🔋 Eco Data Saver\n• 15s Minimal Buffer\n• Low RAM footprint & Battery Saver"
            )
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("⚡ Speed & RAM Performance Mode")
                .setSingleChoiceItems(options, PlayerHolder.performanceMode.coerceIn(0, 2)) { dialog, which ->
                    PlayerHolder.performanceMode = which
                    PlayerHolder.savePreferences(this)
                    YouTubeExoPlayerManager.applyPerformanceModeSettings(this)
                    val bufStr = when (which) {
                        0 -> "60s (Ultra Fast - Anti-Stutter - Recommended)"
                        1 -> "30s (Balanced - Standard)"
                        else -> "15s (Eco Data Saver - Least Data)"
                    }
                    ytPrefs.edit().putString("pref_yt_buffer_limit", bufStr).apply()
                    YouTubeExoPlayerManager.applyBufferLimit(this, bufStr)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangePerformanceMode.setOnClickListener { openPerfDialog() }
        findViewById<View>(R.id.rowPerformanceMode)?.setOnClickListener { openPerfDialog() }

        btnToggleAiSmartTransition.setOnClickListener {
            PlayerHolder.isAiSmartTransitionEnabled = !PlayerHolder.isAiSmartTransitionEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
            val state = if (PlayerHolder.isAiSmartTransitionEnabled) "Enabled" else "Disabled"
            // Toast removed per user request (unnecessary)
        }
        findViewById<View>(R.id.rowAiSmartTransition)?.setOnClickListener {
            btnToggleAiSmartTransition.performClick()
        }

        val openTopics = {
            showPersonalizedTopicsDialog {
                updateSettingsUI()
            }
        }
        btnChangeAiTopics.setOnClickListener { openTopics() }
        findViewById<View>(R.id.rowAiTopicPreferences)?.setOnClickListener { openTopics() }

        btnToggleAiDialogueBoost.setOnClickListener {
            PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
            PlayerHolder.savePreferences(this)
            val currentAudioSession = YouTubeExoPlayerManager.exoPlayer?.audioSessionId
                ?: PlayerHolder.audioExoPlayer?.audioSessionId
                ?: 0
            PlayerHolder.applyAudioEffects(currentAudioSession)
            updateSettingsUI()
            val state = if (PlayerHolder.isDialogueBoostEnabled) "Enabled (+8dB Voice Boost)" else "Disabled"
            // Toast removed per user request (unnecessary)
        }
        findViewById<View>(R.id.rowAiDialogueBoost)?.setOnClickListener {
            btnToggleAiDialogueBoost.performClick()
        }

        btnConfigAiSponsorBlock.setOnClickListener {
            showSponsorBlockSettingsDialog()
        }
        findViewById<View>(R.id.rowAiSponsorBlock)?.setOnClickListener {
            btnConfigAiSponsorBlock.performClick()
        }

        tvAiModelSyncStatus = findViewById(R.id.tvAiModelSyncStatus)
        btnSyncAiModel = findViewById(R.id.btnSyncAiModel)
        val triggerSync = {
            CleanToast.show(this, "🔄 Refreshing local recommendations...")
            SmartRecommendationEngine.syncOnlineModelUpdates(this, force = true) { _, msg ->
                updateSettingsUI()
                CleanToast.show(this, "✅ $msg")
            }
        }
        btnSyncAiModel.setOnClickListener { triggerSync() }
        findViewById<View>(R.id.rowAiModelSync)?.setOnClickListener { triggerSync() }

        tvAiOnDemandModelStatus = findViewById(R.id.tvAiOnDemandModelStatus)
        btnManageAiNeuralModel = findViewById(R.id.btnManageAiNeuralModel)
        val openNeuralModelManager = {
            NeuralSuperResTuneDialog.show(this) {
                updateSettingsUI()
            }
        }
        btnManageAiNeuralModel.setOnClickListener { openNeuralModelManager() }
        findViewById<View>(R.id.rowAiOnDemandNeuralModel)?.setOnClickListener { openNeuralModelManager() }
    }

    // --- 1. Video Settings Handlers ---
    private fun setupVideoSettings() {
        btnToggleSettingAiVideoBoost.setOnClickListener {
            PlayerHolder.isAiVideoSharpnessEnabled = !PlayerHolder.isAiVideoSharpnessEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
            CleanToast.show(this, if (PlayerHolder.isAiVideoSharpnessEnabled) "✨ AI Video Boost: ON (Sharpness & HDR)" else "✨ AI Video Boost: OFF")
        }
        findViewById<View>(R.id.rowSettingAiVideoBoost)?.setOnClickListener { btnToggleSettingAiVideoBoost.performClick() }

        btnToggleSettingAiSmartChapters.setOnClickListener {
            PlayerHolder.isAiSmartChaptersEnabled = !PlayerHolder.isAiSmartChaptersEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
            CleanToast.show(this, if (PlayerHolder.isAiSmartChaptersEnabled) "🎬 AI Smart Chapters: ON" else "🎬 AI Smart Chapters: OFF")
        }
        findViewById<View>(R.id.rowSettingAiSmartChapters)?.setOnClickListener { btnToggleSettingAiSmartChapters.performClick() }

        btnToggleSettingAiNightVision.setOnClickListener {
            PlayerHolder.isAiNightVisionEnabled = !PlayerHolder.isAiNightVisionEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
            CleanToast.show(this, if (PlayerHolder.isAiNightVisionEnabled) "🌙 AI Night Vision: ON (Shadows Lifted)" else "🌙 AI Night Vision: OFF")
        }
        findViewById<View>(R.id.rowSettingAiNightVision)?.setOnClickListener { btnToggleSettingAiNightVision.performClick() }
        btnToggleHighRefreshRate.setOnClickListener {
            PlayerHolder.isHighRefreshRateEnabled = !PlayerHolder.isHighRefreshRateEnabled
            PlayerHolder.savePreferences(this)
            applyHighRefreshRate()
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHighRefreshRate).setOnClickListener {
            btnToggleHighRefreshRate.performClick()
        }

        val orientationOptions = arrayOf("Auto Sensor (Free Rotation)", "Direct Landscape (Recommended)", "Portrait (Vertical)")
        val openOrientationDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Default Video Orientation")
                .setSingleChoiceItems(orientationOptions, PlayerHolder.defaultOrientation) { dialog, which ->
                    PlayerHolder.defaultOrientation = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeOrientation.setOnClickListener { openOrientationDialog() }
        findViewById<View>(R.id.rowDefaultOrientation).setOnClickListener { openOrientationDialog() }

        btnToggleWideColor.setOnClickListener {
            PlayerHolder.isWideColorGamutEnabled = !PlayerHolder.isWideColorGamutEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowWideColor).setOnClickListener {
            btnToggleWideColor.performClick()
        }

        btnToggleDeblocking.setOnClickListener {
            PlayerHolder.isDeblockingFilterEnabled = !PlayerHolder.isDeblockingFilterEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDeblocking).setOnClickListener {
            btnToggleDeblocking.performClick()
        }

        btnToggleAutoScreenOff.setOnClickListener {
            PlayerHolder.isAutoScreenOffEnabled = !PlayerHolder.isAutoScreenOffEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
            CleanToast.show(
                this,
                if (PlayerHolder.isAutoScreenOffEnabled) "🔋 Auto Screen-Off: ON (Sleeps on finish or > 3 min pause)" else "🔋 Auto Screen-Off: OFF"
            )
        }
        findViewById<View>(R.id.rowAutoScreenOff)?.setOnClickListener {
            btnToggleAutoScreenOff.performClick()
        }
        val hwOptions = arrayOf("Disabled (Software)", "Automatic (Recommended)", "Decoding Only", "Full Acceleration")
        val openHwDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_hw_decoding)
                .setSingleChoiceItems(hwOptions, PlayerHolder.hwAccelerationMode) { dialog, which ->
                    PlayerHolder.hwAccelerationMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeHw.setOnClickListener { openHwDialog() }
        findViewById<View>(R.id.rowHwDecode).setOnClickListener { openHwDialog() }

        val bgPipOptions = arrayOf("Stop Playback", "Play in Background", "Picture-in-Picture (PiP)")
        val openBgPipDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_bg_pip)
                .setSingleChoiceItems(bgPipOptions, PlayerHolder.backgroundPipMode) { dialog, which ->
                    PlayerHolder.backgroundPipMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeBgPip.setOnClickListener { openBgPipDialog() }
        findViewById<View>(R.id.rowBgPip).setOnClickListener { openBgPipDialog() }

        val resumeOptions = arrayOf("Never (Always start from beginning)", "Ask confirmation on open", "Always resume automatically")
        val openResumeDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_resume)
                .setSingleChoiceItems(resumeOptions, PlayerHolder.resumeMode) { dialog, which ->
                    PlayerHolder.resumeMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeResumeMode.setOnClickListener { openResumeDialog() }
        findViewById<View>(R.id.rowResumeMode).setOnClickListener { openResumeDialog() }

        val seekOptions = arrayOf("5 seconds", "10 seconds", "20 seconds", "30 seconds")
        val seekValues = arrayOf(5, 10, 20, 30)
        val openSeekDialog = {
            val currentIdx = seekValues.indexOf(PlayerHolder.doubleTapSeekSeconds).let { if (it >= 0) it else 1 }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_double_tap)
                .setSingleChoiceItems(seekOptions, currentIdx) { dialog, which ->
                    PlayerHolder.doubleTapSeekSeconds = seekValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDoubleTap.setOnClickListener { openSeekDialog() }
        findViewById<View>(R.id.rowDoubleTap).setOnClickListener { openSeekDialog() }

        val aspectOptions = arrayOf("Best Fit (Default)", "Fit Screen", "Fill Screen", "16:9 Aspect Ratio", "4:3 Aspect Ratio")
        val openAspectDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_aspect_ratio)
                .setSingleChoiceItems(aspectOptions, PlayerHolder.defaultAspectRatio) { dialog, which ->
                    PlayerHolder.defaultAspectRatio = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAspectRatio.setOnClickListener { openAspectDialog() }
        findViewById<View>(R.id.rowAspectRatio).setOnClickListener { openAspectDialog() }

        btnToggleAudioBoost.setOnClickListener {
            PlayerHolder.isAudioBoostEnabled = !PlayerHolder.isAudioBoostEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowAudioBoost).setOnClickListener {
            btnToggleAudioBoost.performClick()
        }
    }

    // --- 2. Integrated Dolby, Spatial & Equalizer Audio Suite Handlers ---
    private fun setupAudioSuiteSettings() {
        // Master Profile Dialog
        val openMasterProfileDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Select Audio Profile")
                .setSingleChoiceItems(PlayerHolder.masterProfileNames, PlayerHolder.masterAudioProfile) { dialog, which ->
                    PlayerHolder.applyMasterProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeMasterProfile.setOnClickListener { openMasterProfileDialog() }
        findViewById<View>(R.id.rowMasterProfile).setOnClickListener { openMasterProfileDialog() }

        // Dolby & Spatial Virtualizer Mode
        val modes = arrayOf("Standard Stereo (Downmix)", "Dolby 3D Headphone (Binaural HRTF)", "Dolby ProLogic Surround (Matrix)", "Cinema 3D Soundstage (Wide Room)")
        val openDolbyDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_dolby_surround)
                .setSingleChoiceItems(modes, PlayerHolder.dolbySpatialMode) { dialog, which ->
                    PlayerHolder.dolbySpatialMode = which
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDolbySurround.setOnClickListener { openDolbyDialog() }
        findViewById<View>(R.id.rowDolbySurround).setOnClickListener { openDolbyDialog() }

        // 10-Band Equalizer Presets
        val openEqDialog = {
            val presets = PlayerHolder.equalizerPresets
            val currentIdx = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_equalizer)
                .setSingleChoiceItems(presets, currentIdx) { dialog, which ->
                    PlayerHolder.currentEqualizerPreset = which - 1
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeEqualizer.setOnClickListener { openEqDialog() }
        findViewById<View>(R.id.rowEqualizer).setOnClickListener { openEqDialog() }

        // Dialogue Boost (Night Mode) Toggle
        btnToggleDialogueBoost.setOnClickListener {
            PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
            PlayerHolder.masterAudioProfile = 4 // Custom
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDialogueBoost).setOnClickListener {
            btnToggleDialogueBoost.performClick()
        }

        // Digital Passthrough Toggle
        btnTogglePassthrough.setOnClickListener {
            PlayerHolder.isDolbyPassthroughEnabled = !PlayerHolder.isDolbyPassthroughEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDigitalPassthrough).setOnClickListener {
            btnTogglePassthrough.performClick()
        }

        // Audio Output Engine Dialog
        val engines = arrayOf("AudioTrack (Standard)", "OpenSL ES (Low Latency)", "AAudio (Modern NDK)")
        val openEngineDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_audio_output)
                .setSingleChoiceItems(engines, PlayerHolder.audioOutputEngine) { dialog, which ->
                    PlayerHolder.audioOutputEngine = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAudioOutput.setOnClickListener { openEngineDialog() }
        findViewById<View>(R.id.rowAudioOutput).setOnClickListener { openEngineDialog() }

        btnToggleHeadsetPause.setOnClickListener {
            PlayerHolder.isHeadsetPauseEnabled = !PlayerHolder.isHeadsetPauseEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHeadsetPause).setOnClickListener {
            btnToggleHeadsetPause.performClick()
        }

        btnToggleTimeStretch.setOnClickListener {
            PlayerHolder.isTimeStretchingEnabled = !PlayerHolder.isTimeStretchingEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowTimeStretching).setOnClickListener {
            btnToggleTimeStretch.performClick()
        }
    }

    // --- 3. Subtitle Settings Handlers ---
    
    private fun showSubtitleSettings() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        activeSettingsBottomSheet = dialog
        dialog.setOnDismissListener { activeSettingsBottomSheet = null }
        val view = layoutInflater.inflate(R.layout.dialog_subtitle_settings, null)
        dialog.setContentView(view)

        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.let { sheet ->
                val behavior = com.google.android.material.bottomsheet.BottomSheetBehavior.from(sheet)
                behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
            }
        }

        val isMono = PlayerHolder.isMonochrome()
        val accentColor = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        val accentTintList = ColorStateList.valueOf(accentColor)

        view.findViewById<TextView>(R.id.tvSubHeaderTitle)?.setTextColor(accentColor)
        view.findViewById<View>(R.id.btnSubBack).setOnClickListener { dialog.dismiss() }
        view.findViewById<View>(R.id.btnSubSearch)?.setOnClickListener { subtitlePickerLauncher.launch(arrayOf("*/*")); dialog.dismiss() }

        val subHeaders = listOf(
            R.id.tvHeaderFontStyle,
            R.id.tvHeaderBg,
            R.id.tvHeaderShadow,
            R.id.tvHeaderOutline,
            R.id.tvHeaderPos
        )
        for (hId in subHeaders) {
            view.findViewById<TextView>(hId)?.setTextColor(accentColor)
        }

        val checkBoxes = listOf(
            R.id.cbSubAutoLoad,
            R.id.cbSubBold,
            R.id.cbSubBgToggle,
            R.id.cbSubShadowToggle,
            R.id.cbSubOutlineToggle
        )
        for (cbId in checkBoxes) {
            view.findViewById<CheckBox>(cbId)?.buttonTintList = accentTintList
        }

        val seekBars = listOf(
            R.id.sbSubFontOpacity,
            R.id.sbSubBgOpacity,
            R.id.sbSubShadowOpacity,
            R.id.sbSubOutlineOpacity
        )
        for (sbId in seekBars) {
            view.findViewById<SeekBar>(sbId)?.apply {
                progressTintList = accentTintList
                thumbTintList = accentTintList
            }
        }

        // Presets
        view.findViewById<View>(R.id.rowSubPresets).setOnClickListener {
            val presets = arrayOf("Default (White + Shadow)", "Cinema (Yellow + Outline)", "High Contrast (Black Box)", "Clean Minimal")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles presets")
                .setItems(presets) { _, which ->
                    when (which) {
                        0 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBold = false
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = true
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        1 -> {
                            PlayerHolder.subFontColor = "16772155"
                            PlayerHolder.isSubBold = true
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        2 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = true
                            PlayerHolder.subBackgroundOpacity = 75
                        }
                        3 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = false
                            PlayerHolder.isSubOutlineEnabled = false
                        }
                    }
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                    showSubtitleSettings()
                }
                .show()
        }

        // Auto load subtitles
        val cbAutoLoad = view.findViewById<CheckBox>(R.id.cbSubAutoLoad)
        cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
        view.findViewById<View>(R.id.rowSubAutoLoad).setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }

        // Subtitle text encoding
        val tvEncoding = view.findViewById<TextView>(R.id.tvSubEncodingSub)
        tvEncoding.text = "Default (" + PlayerHolder.subEncoding + ")"
        view.findViewById<View>(R.id.rowSubEncoding).setOnClickListener {
            val encodings = arrayOf("UTF-8", "Windows-1252", "ISO-8859-1", "GBK", "Big5")
            val cur = encodings.indexOf(PlayerHolder.subEncoding).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitle text encoding")
                .setSingleChoiceItems(encodings, cur) { d, w ->
                    PlayerHolder.subEncoding = encodings[w]
                    tvEncoding.text = "Default (" + encodings[w] + ")"
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Preferred subtitle language
        val tvLang = view.findViewById<TextView>(R.id.tvSubLanguageSub)
        tvLang.text = PlayerHolder.subPreferredLanguage
        view.findViewById<View>(R.id.rowSubLanguage).setOnClickListener {
            val langs = arrayOf("No language preference", "English", "Hindi", "Spanish", "French", "German")
            val cur = langs.indexOf(PlayerHolder.subPreferredLanguage).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Preferred subtitle language")
                .setSingleChoiceItems(langs, cur) { d, w ->
                    PlayerHolder.subPreferredLanguage = langs[w]
                    tvLang.text = langs[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        // Subtitle Size
        val tvSize = view.findViewById<TextView>(R.id.tvSubSizeSub)
        val sizeLabel = when (PlayerHolder.subFontSize) {
            "14" -> "Small"
            "22" -> "Large"
            "26" -> "Extra large"
            else -> "Normal"
        }
        tvSize.text = sizeLabel
        view.findViewById<View>(R.id.rowSubSize).setOnClickListener {
            val sizes = arrayOf("Small", "Normal", "Large", "Extra large")
            val sizeVals = arrayOf("14", "18", "22", "26")
            val cur = sizeVals.indexOf(PlayerHolder.subFontSize).let { if (it < 0) 1 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles Size")
                .setSingleChoiceItems(sizes, cur) { d, w ->
                    PlayerHolder.subFontSize = sizeVals[w]
                    tvSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Bold subtitles
        val cbBold = view.findViewById<CheckBox>(R.id.cbSubBold)
        cbBold.isChecked = PlayerHolder.isSubBold
        view.findViewById<View>(R.id.rowSubBold).setOnClickListener {
            PlayerHolder.isSubBold = !PlayerHolder.isSubBold
            cbBold.isChecked = PlayerHolder.isSubBold
            PlayerHolder.savePreferences(this)
        }

        // Font Colour Badge
        val cardFontBadge = view.findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardSubFontColorBadge)
        val fontBadgeColor = try {
            val cL = PlayerHolder.subFontColor.toLongOrNull() ?: 16777215L
            if (cL <= 16777215L) (0xFF000000 or cL).toInt() else cL.toInt()
        } catch (e: Exception) { Color.WHITE }
        cardFontBadge.setCardBackgroundColor(fontBadgeColor)

        view.findViewById<View>(R.id.rowSubFontColor).setOnClickListener {
            val colors = arrayOf("White", "Yellow", "Cyan", "Green", "Amber")
            val colorVals = arrayOf("16777215", "16772155", "58879", "6942894", "16766720")
            val colorInts = arrayOf(Color.WHITE, Color.parseColor("#FFEB3B"), Color.parseColor("#00E5FF"), Color.parseColor("#69F0AE"), Color.parseColor("#FFD700"))
            val cur = colorVals.indexOf(PlayerHolder.subFontColor).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Colour")
                .setSingleChoiceItems(colors, cur) { d, w ->
                    PlayerHolder.subFontColor = colorVals[w]
                    cardFontBadge.setCardBackgroundColor(colorInts[w])
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    d.dismiss()
                }
                .show()
        }

        // Font Opacity
        val sbFontOpacity = view.findViewById<SeekBar>(R.id.sbSubFontOpacity)
        sbFontOpacity.progress = PlayerHolder.subFontOpacity
        sbFontOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subFontOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Background Checkbox & Slider
        val cbBg = view.findViewById<CheckBox>(R.id.cbSubBgToggle)
        cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
        view.findViewById<View>(R.id.rowSubBgToggle).setOnClickListener {
            PlayerHolder.isSubBackgroundEnabled = !PlayerHolder.isSubBackgroundEnabled
            cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
            PlayerHolder.savePreferences(this)
        }
        val sbBgOpacity = view.findViewById<SeekBar>(R.id.sbSubBgOpacity)
        sbBgOpacity.progress = PlayerHolder.subBackgroundOpacity
        sbBgOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subBackgroundOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Shadow Checkbox & Slider
        val cbShadow = view.findViewById<CheckBox>(R.id.cbSubShadowToggle)
        cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
        view.findViewById<View>(R.id.rowSubShadowToggle).setOnClickListener {
            PlayerHolder.isSubShadowEnabled = !PlayerHolder.isSubShadowEnabled
            cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
            PlayerHolder.savePreferences(this)
        }
        val sbShadowOpacity = view.findViewById<SeekBar>(R.id.sbSubShadowOpacity)
        sbShadowOpacity.progress = PlayerHolder.subShadowOpacity
        sbShadowOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subShadowOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Outline Checkbox & Slider
        val cbOutline = view.findViewById<CheckBox>(R.id.cbSubOutlineToggle)
        cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
        view.findViewById<View>(R.id.rowSubOutlineToggle).setOnClickListener {
            PlayerHolder.isSubOutlineEnabled = !PlayerHolder.isSubOutlineEnabled
            cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
            PlayerHolder.savePreferences(this)
        }
        val tvOutlineSize = view.findViewById<TextView>(R.id.tvSubOutlineSizeSub)
        tvOutlineSize.text = when (PlayerHolder.subOutlineSize) { 0 -> "Thin"; 2 -> "Thick"; else -> "Normal" }
        view.findViewById<View>(R.id.rowSubOutlineSize).setOnClickListener {
            val sizes = arrayOf("Thin", "Normal", "Thick")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Outline Size")
                .setSingleChoiceItems(sizes, PlayerHolder.subOutlineSize.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subOutlineSize = w
                    tvOutlineSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }
        val sbOutlineOpacity = view.findViewById<SeekBar>(R.id.sbSubOutlineOpacity)
        sbOutlineOpacity.progress = PlayerHolder.subOutlineOpacity
        sbOutlineOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subOutlineOpacity = p
                    PlayerHolder.savePreferences(this@MainActivity)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitle Screen Position & Elevation
        val tvPos = view.findViewById<TextView>(R.id.tvSubPositionSub)
        tvPos.text = when (PlayerHolder.subPosition) { 1 -> "Elevated (Above controls)"; 2 -> "Center Screen"; else -> "Standard Bottom (Default)" }
        view.findViewById<View>(R.id.rowSubPosition).setOnClickListener {
            val posNames = arrayOf("Standard Bottom (Default)", "Elevated (Above controls)", "Center Screen")
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Subtitles position & elevation")
                .setSingleChoiceItems(posNames, PlayerHolder.subPosition.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subPosition = w
                    tvPos.text = posNames[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        dialog.show()
    }

    private fun setupSubtitleSettings() {
        findViewById<View>(R.id.rowSubtitles)?.setOnClickListener {
            showSubtitleSettings()
        }
        btnToggleSubAutoload.setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubAutoload).setOnClickListener {
            btnToggleSubAutoload.performClick()
        }

        val sizeLabels = arrayOf("Very Small (12sp)", "Small (14sp)", "Normal (18sp)", "Large (24sp)", "Huge (32sp)")
        val sizeValues = arrayOf("12", "14", "18", "24", "32")
        val openSizeDialog = {
            val currentIdx = sizeValues.indexOf(PlayerHolder.subFontSize).let { if (it >= 0) it else 2 }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_size)
                .setSingleChoiceItems(sizeLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontSize = sizeValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubSize.setOnClickListener { openSizeDialog() }
        findViewById<View>(R.id.rowSubSize).setOnClickListener { openSizeDialog() }

        val colorLabels = arrayOf("White", "Yellow", "Cyan", "Green")
        val colorValues = arrayOf("16777215", "16776960", "65535", "65280")
        val openColorDialog = {
            val currentIdx = colorValues.indexOf(PlayerHolder.subFontColor).coerceAtLeast(0)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_color)
                .setSingleChoiceItems(colorLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontColor = colorValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubColor.setOnClickListener { openColorDialog() }
        findViewById<View>(R.id.rowSubColor).setOnClickListener { openColorDialog() }

        val bgLabels = arrayOf("Transparent / None", "Translucent Box", "Solid Black Box")
        val openBgDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_background)
                .setSingleChoiceItems(bgLabels, PlayerHolder.subBackgroundStyle) { dialog, which ->
                    PlayerHolder.subBackgroundStyle = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubBackground.setOnClickListener { openBgDialog() }
        findViewById<View>(R.id.rowSubBackground).setOnClickListener { openBgDialog() }

        btnToggleSubStyle.setOnClickListener {
            PlayerHolder.subFontStyle = if (PlayerHolder.subFontStyle == 1) 0 else 1
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubStyle).setOnClickListener {
            btnToggleSubStyle.performClick()
        }

        val encodings = arrayOf("UTF-8 (Default)", "Windows-1252 (Western)", "ISO-8859-1 (Latin)", "GBK (Chinese)", "Shift-JIS (Japanese)")
        val encValues = arrayOf("UTF-8", "WINDOWS-1252", "ISO-8859-1", "GBK", "SHIFT-JIS")
        val openEncDialog = {
            val currentIdx = encValues.indexOf(PlayerHolder.subEncoding).coerceAtLeast(0)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_sub_encoding)
                .setSingleChoiceItems(encodings, currentIdx) { dialog, which ->
                    PlayerHolder.subEncoding = encValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubEncoding.setOnClickListener { openEncDialog() }
        findViewById<View>(R.id.rowSubEncoding).setOnClickListener { openEncDialog() }
    }

    // --- 4. Controls & Gestures Handlers ---
    private fun setupGestureSettings() {
        btnToggleGestureVolume.setOnClickListener {
            PlayerHolder.isVolumeGestureEnabled = !PlayerHolder.isVolumeGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureVolume).setOnClickListener { btnToggleGestureVolume.performClick() }

        btnToggleGestureBrightness.setOnClickListener {
            PlayerHolder.isBrightnessGestureEnabled = !PlayerHolder.isBrightnessGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureBrightness).setOnClickListener { btnToggleGestureBrightness.performClick() }

        btnToggleGestureSeek.setOnClickListener {
            PlayerHolder.isSeekGestureEnabled = !PlayerHolder.isSeekGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureSeek).setOnClickListener { btnToggleGestureSeek.performClick() }

        btnToggleFastSeek.setOnClickListener {
            PlayerHolder.isFastSeekEnabled = !PlayerHolder.isFastSeekEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowFastSeek).setOnClickListener { btnToggleFastSeek.performClick() }
    }

    // --- 5. Interface & Advanced Handlers ---
    private fun setupInterfaceAndAdvancedSettings() {
        val themes = arrayOf("Pure Black OLED (Default)", "Dark Charcoal", getString(R.string.theme_monochrome))
        val openThemeDialog = {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_app_theme)
                .setSingleChoiceItems(themes, PlayerHolder.appThemeMode) { dialog, which ->
                    if (PlayerHolder.appThemeMode != which) {
                        PlayerHolder.appThemeMode = which
                        PlayerHolder.savePreferences(this)
                        dialog.dismiss()
                        applyThemeUI()
                        recreate()
                    } else {
                        dialog.dismiss()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAppTheme.setOnClickListener { openThemeDialog() }
        findViewById<View>(R.id.rowAppTheme).setOnClickListener { openThemeDialog() }

        updateCacheSizeDisplay()
        btnClearCache.setOnClickListener {
            clearAppCache()
            updateCacheSizeDisplay()
            CleanToast.show(this, "Cache cleared successfully")
        }
        findViewById<View>(R.id.rowClearCache).setOnClickListener { btnClearCache.performClick() }

        findViewById<View>(R.id.rowAppVersion)?.setOnClickListener {
            showAppVersionDialog()
        }

        btnClearResume.setOnClickListener {
            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            prefs.edit().clear().apply()
            CleanToast.show(this, "Playback history cleared")
        }
        findViewById<View>(R.id.rowClearResume).setOnClickListener { btnClearResume.performClick() }

        btnResetSettings.setOnClickListener {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle(R.string.pref_reset_settings)
                .setMessage("Restore all player settings to default values?")
                .setPositiveButton("Reset") { _, _ ->
                    PlayerHolder.resetPreferences(this)
                    updateSettingsUI()
                    CleanToast.show(this, "Settings restored to defaults")
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.rowResetSettings).setOnClickListener { btnResetSettings.performClick() }
    }

    private fun applyHighRefreshRate() {
        if (!PlayerHolder.isHighRefreshRateEnabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val modes = display?.supportedModes ?: emptyArray()
                val currentMode = display?.mode
                val targetMode = modes.filter {
                    currentMode == null || (it.physicalWidth == currentMode.physicalWidth && it.physicalHeight == currentMode.physicalHeight)
                }.maxByOrNull { it.refreshRate } ?: modes.maxByOrNull { it.refreshRate }

                targetMode?.let { mode ->
                    val params = window.attributes
                    params.preferredDisplayModeId = mode.modeId
                    window.attributes = params
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun updateToggleButton(btn: Button, isEnabled: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isEnabled) "ON" else "OFF"
        btn.setTextColor(if (isEnabled) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isEnabled) primaryColor else offStrokeColor)
    }

    private fun updateSubStyleButton(btn: Button, isBold: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isBold) "BOLD" else "REG"
        btn.setTextColor(if (isBold) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isBold) primaryColor else offStrokeColor)
    }

    private fun styleActionButton(btn: Button) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        btn.setTextColor(primaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(primaryColor)
    }

    private fun applyThemeUI() {
        val bgMain = when (PlayerHolder.appThemeMode) {
            PlayerHolder.THEME_CHARCOAL -> Color.parseColor("#181818")
            else -> Color.parseColor("#000000") // Pure Black for OLED and Monochrome
        }
        window.decorView.setBackgroundColor(bgMain)
        toolbar.setBackgroundColor(bgMain)
        bottomNav.setBackgroundColor(bgMain)
        tabVideo.setBackgroundColor(bgMain)
        tabAudio.setBackgroundColor(bgMain)
        tabSettings.setBackgroundColor(bgMain)
        if (::tabShare.isInitialized) {
            tabShare.setBackgroundColor(bgMain)
            val heroCard = findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardShareHero)
            val cardBg = if (PlayerHolder.appThemeMode == PlayerHolder.THEME_CHARCOAL) Color.parseColor("#1C1D24") else Color.parseColor("#16171D")
            heroCard?.setCardBackgroundColor(cardBg)
        }
        findViewById<View>(R.id.topBarContainer)?.setBackgroundColor(bgMain)

        val isMono = PlayerHolder.isMonochrome()
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()

        // 1. Bottom Navigation
        val navTint = if (isMono) {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint_mono)
        } else {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint)
        }
        bottomNav.itemIconTintList = navTint
        bottomNav.itemTextColor = navTint

        // 2. Floating Action Button (FAB)
        fabPlay.backgroundTintList = ColorStateList.valueOf(PlayerHolder.getFabBgColorInt())
        fabPlay.setColorFilter(PlayerHolder.getFabIconColorInt())

        // 3. Top Tabs (VIDEOS / FOLDERS)
        if (isFolderViewActive) {
            btnViewFolders.setTextColor(primaryColor)
            btnViewAllVideos.setTextColor(secondaryColor)
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)
        }

        // 4. Search Bar
        val layoutSearch = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.layoutSearch)
        layoutSearch?.boxStrokeColor = primaryColor
        layoutSearch?.hintTextColor = ColorStateList.valueOf(primaryColor)

        // 5. Notch Dynamic Island Player
        btnNotchPlayPause.setColorFilter(primaryColor)
        btnNotchOpen.setColorFilter(primaryColor)
        findViewById<ImageView>(R.id.ivNotchIcon)?.setColorFilter(primaryColor)
        sbNotch.progressTintList = ColorStateList.valueOf(primaryColor)
        sbNotch.thumbTintList = ColorStateList.valueOf(primaryColor)
        val notchStroke = if (isMono) Color.parseColor("#2E2E2E") else Color.parseColor("#2E3440")
        cardNotchPlayer.strokeColor = notchStroke

        // 6. Section Headers & App Name
        findViewById<TextView>(R.id.tvCatVideo)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatAudio)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatSubtitles)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatGestures)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatInterface)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvAppVersionTitle)?.setTextColor(primaryColor)
        val badgeAppVersion = findViewById<TextView>(R.id.badgeAppVersion)
        val cardAppVersion = findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardAppVersion)
        if (isMono) {
            badgeAppVersion?.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#333333"))
            badgeAppVersion?.setTextColor(Color.WHITE)
            cardAppVersion?.strokeColor = Color.parseColor("#2E2E2E")
        } else {
            badgeAppVersion?.backgroundTintList = ColorStateList.valueOf(primaryColor)
            badgeAppVersion?.setTextColor(Color.WHITE)
            cardAppVersion?.strokeColor = Color.parseColor("#2E3440")
        }
        findViewById<TextView>(R.id.tvMasterAudioTitle)?.setTextColor(primaryColor)

        // 7. Browse Buttons
        btnBrowseVideo.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseVideo.setTextColor(if (isMono) Color.BLACK else Color.WHITE)
        btnBrowseAudio.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseAudio.setTextColor(if (isMono) Color.BLACK else Color.WHITE)

        // 8. Action Buttons ("Change", "Clear", "Reset")
        val actionButtons = listOf(
            btnChangeHw,
            btnChangeOrientation,
            btnChangeMasterProfile,
            btnChangeDolbySurround,
            btnChangeEqualizer,
            btnChangeAudioOutput,
            btnChangeBgPip,
            btnChangeResumeMode,
            btnChangeDoubleTap,
            btnChangeAspectRatio,
            btnChangeSubSize,
            btnChangeSubColor,
            btnChangeSubBackground,
            btnChangeSubEncoding,
            btnChangeAppTheme,
            btnClearCache,
            btnClearResume,
            btnResetSettings
        )
        for (btn in actionButtons) {
            styleActionButton(btn)
        }

        // 9. Update Settings Toggle Buttons
        updateSettingsUI()

        // 10. Notify media adapters so list items update their colors
        videoAdapter?.notifyDataSetChanged()
        audioAdapter?.notifyDataSetChanged()
        folderVideoAdapter?.notifyDataSetChanged()
        folderAdapter?.notifyDataSetChanged()
    }

    private fun updateSettingsUI() {
        // Video UI
        if (::btnToggleSettingAiVideoBoost.isInitialized) {
            updateToggleButton(btnToggleSettingAiVideoBoost, PlayerHolder.isAiVideoSharpnessEnabled)
            tvSettingAiVideoBoostStatus.text = if (PlayerHolder.isAiVideoSharpnessEnabled) "Active • Hardware edge sharpening & dynamic micro-contrast" else "Disabled • Raw video playback"
        }
        if (::btnToggleSettingAiSmartChapters.isInitialized) {
            updateToggleButton(btnToggleSettingAiSmartChapters, PlayerHolder.isAiSmartChaptersEnabled)
            tvSettingAiSmartChaptersStatus.text = if (PlayerHolder.isAiSmartChaptersEnabled) "Active • Auto-detects key scenes & timeline markers" else "Disabled"
        }
        if (::btnToggleSettingAiNightVision.isInitialized) {
            updateToggleButton(btnToggleSettingAiNightVision, PlayerHolder.isAiNightVisionEnabled)
            tvSettingAiNightVisionStatus.text = if (PlayerHolder.isAiNightVisionEnabled) "Active • Lifts dark shadows without overexposing highlights" else "Disabled • Standard contrast"
        }
        updateToggleButton(btnToggleHighRefreshRate, PlayerHolder.isHighRefreshRateEnabled)
        tvHighRefreshRateStatus.text = if (PlayerHolder.isHighRefreshRateEnabled) "Enabled (Auto 120Hz / High Refresh Rate)" else "Disabled (Standard 60Hz)"

        tvDefaultOrientationStatus.text = when (PlayerHolder.defaultOrientation) {
            0 -> "Auto Sensor (Free Rotation)"
            2 -> "Portrait (Vertical)"
            else -> "Direct Landscape (Recommended)"
        }

        updateToggleButton(btnToggleWideColor, PlayerHolder.isWideColorGamutEnabled)
        tvWideColorStatus.text = if (PlayerHolder.isWideColorGamutEnabled) "Enabled (10-bit dynamic colors)" else "Disabled (Standard sRGB)"

        updateToggleButton(btnToggleDeblocking, PlayerHolder.isDeblockingFilterEnabled)
        tvDeblockingStatus.text = if (PlayerHolder.isDeblockingFilterEnabled) "Enabled (Crisp gradients & deblocking)" else "Disabled"

        updateToggleButton(btnToggleAutoScreenOff, PlayerHolder.isAutoScreenOffEnabled)
        tvAutoScreenOffStatus.text = if (PlayerHolder.isAutoScreenOffEnabled) "Enabled (Sleeps on finish or paused > 3 min)" else "Disabled (Screen stays awake indefinitely)"

        tvHwDecodeStatus.text = when (PlayerHolder.hwAccelerationMode) {
            0 -> "Disabled (Software FFmpeg)"
            2 -> "Decoding Only"
            3 -> "Full Acceleration"
            else -> "Automatic (Recommended)"
        }
        tvBgPipStatus.text = when (PlayerHolder.backgroundPipMode) {
            0 -> "Stop Playback"
            2 -> "Picture-in-Picture (PiP)"
            else -> "Play in Background"
        }
        tvResumeModeStatus.text = when (PlayerHolder.resumeMode) {
            0 -> "Never (Always start over)"
            2 -> "Always resume automatically"
            else -> "Ask confirmation"
        }
        tvDoubleTapStatus.text = "${PlayerHolder.doubleTapSeekSeconds} seconds"
        tvAspectRatioStatus.text = when (PlayerHolder.defaultAspectRatio) {
            1 -> "Fit Screen"
            2 -> "Fill Screen"
            3 -> "16:9"
            4 -> "4:3"
            else -> "Best Fit"
        }

        updateToggleButton(btnToggleAudioBoost, PlayerHolder.isAudioBoostEnabled)
        tvAudioBoostStatus.text = if (PlayerHolder.isAudioBoostEnabled) "Enabled (Up to 200%)" else "Disabled (Standard 100%)"

        // Integrated Audio Suite UI
        tvMasterProfileStatus.text = "${PlayerHolder.masterProfileNames[PlayerHolder.masterAudioProfile.coerceIn(0, 4)]} (Master Preset)"
        tvDolbySurroundStatus.text = when (PlayerHolder.dolbySpatialMode) {
            1 -> "Dolby 3D Headphone (Binaural HRTF)"
            2 -> "Dolby ProLogic Surround (Matrix)"
            3 -> "Cinema 3D Soundstage (Wide Room)"
            else -> "Standard Stereo (Downmix)"
        }
        val eqIdx = PlayerHolder.currentEqualizerPreset
        tvEqualizerStatus.text = if (eqIdx >= 0 && eqIdx < PlayerHolder.equalizerPresets.size - 1) {
            PlayerHolder.equalizerPresets[eqIdx + 1]
        } else {
            "Flat (Off)"
        }

        updateToggleButton(btnToggleDialogueBoost, PlayerHolder.isDialogueBoostEnabled)
        tvDialogueBoostStatus.text = if (PlayerHolder.isDialogueBoostEnabled) "Dynamic range compression: Clear speech (Enabled)" else "Disabled"

        updateToggleButton(btnTogglePassthrough, PlayerHolder.isDolbyPassthroughEnabled)
        tvDigitalPassthroughStatus.text = if (PlayerHolder.isDolbyPassthroughEnabled) "HDMI / S/PDIF Passthrough (Active)" else "Disabled"

        tvAudioOutputStatus.text = when (PlayerHolder.audioOutputEngine) {
            1 -> "OpenSL ES (Low Latency)"
            2 -> "AAudio (Modern NDK)"
            else -> "AudioTrack (Standard)"
        }

        updateToggleButton(btnToggleHeadsetPause, PlayerHolder.isHeadsetPauseEnabled)
        tvHeadsetPauseStatus.text = if (PlayerHolder.isHeadsetPauseEnabled) "Auto-pause when unplugged (Enabled)" else "Disabled"

        updateToggleButton(btnToggleTimeStretch, PlayerHolder.isTimeStretchingEnabled)
        tvTimeStretchStatus.text = if (PlayerHolder.isTimeStretchingEnabled) "Pitch lock active (Enabled)" else "Disabled"

        // Subtitle UI
        updateToggleButton(btnToggleSubAutoload, PlayerHolder.isSubAutoloadEnabled)

        tvSubSizeStatus.text = when (PlayerHolder.subFontSize) {
            "12" -> "Very Small (12sp)"
            "14" -> "Small (14sp)"
            "24" -> "Large (24sp)"
            "32" -> "Huge (32sp)"
            else -> "Normal (18sp)"
        }
        tvSubColorStatus.text = when (PlayerHolder.subFontColor) {
            "16776960" -> "Yellow"
            "65535" -> "Cyan"
            "65280" -> "Green"
            else -> "White"
        }
        tvSubBackgroundStatus.text = when (PlayerHolder.subBackgroundStyle) {
            1 -> "Translucent Box"
            2 -> "Solid Black Box"
            else -> "Transparent / None"
        }

        updateSubStyleButton(btnToggleSubStyle, PlayerHolder.subFontStyle == 1)
        tvSubStyleStatus.text = if (PlayerHolder.subFontStyle == 1) "Bold font weight" else "Normal font weight"

        tvSubEncodingStatus.text = PlayerHolder.subEncoding

        // Gestures UI
        updateToggleButton(btnToggleGestureVolume, PlayerHolder.isVolumeGestureEnabled)
        tvGestureVolumeStatus.text = if (PlayerHolder.isVolumeGestureEnabled) "Right side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureBrightness, PlayerHolder.isBrightnessGestureEnabled)
        tvGestureBrightnessStatus.text = if (PlayerHolder.isBrightnessGestureEnabled) "Left side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureSeek, PlayerHolder.isSeekGestureEnabled)
        tvGestureSeekStatus.text = if (PlayerHolder.isSeekGestureEnabled) "Horizontal drag (Enabled)" else "Disabled"

        updateToggleButton(btnToggleFastSeek, PlayerHolder.isFastSeekEnabled)
        tvFastSeekStatus.text = if (PlayerHolder.isFastSeekEnabled) "Seek to nearest keyframe (Enabled)" else "Exact frame seek (Disabled)"

        // 0. AI Smart Suite & Performance UI
        if (::tvPerformanceModeStatus.isInitialized) {
            tvPerformanceModeStatus.text = when (PlayerHolder.performanceMode) {
                PlayerHolder.PERF_MODE_ULTRA_FAST -> "🏎️ Ultra Fast (60s Buffer • Pre-warming Active)"
                PlayerHolder.PERF_MODE_BALANCED -> "⚖️ Balanced (30s Buffer • Standard RAM - Recommended)"
                else -> "🔋 Eco Data Saver (15s Buffer • Minimal RAM)"
            }
        }
        if (::tvYtBufferLimitStatus.isInitialized) {
            val buf = ytPrefs.getString("pref_yt_buffer_limit", "60s (Ultra Fast - Anti-Stutter - Recommended)") ?: "60s"
            tvYtBufferLimitStatus.text = buf
        }
        if (::btnToggleSettingAiKaraoke.isInitialized) {
            updateToggleButton(btnToggleSettingAiKaraoke, PlayerHolder.isAiKaraokeEnabled)
            tvSettingAiKaraokeStatus.text = if (PlayerHolder.isAiKaraokeEnabled) "Active • Vocals cut, backing music isolated" else "Disabled • Normal stereo audio"
        }
        if (::btnToggleSettingAiAutoEq.isInitialized) {
            updateToggleButton(btnToggleSettingAiAutoEq, PlayerHolder.isAiAutoEqEnabled)
            tvSettingAiAutoEqStatus.text = if (PlayerHolder.isAiAutoEqEnabled) "Active • Genre detected: ${PlayerHolder.currentAiDetectedGenre}" else "Disabled • Manual Equalizer active"
        }
        if (::btnToggleSettingAiSilence.isInitialized) {
            updateToggleButton(btnToggleSettingAiSilence, PlayerHolder.isAiSilenceTrimmerEnabled)
            tvSettingAiSilenceStatus.text = if (PlayerHolder.isAiSilenceTrimmerEnabled) "Active • Skips dead silence at track start/end" else "Disabled"
        }
        if (::btnToggleSettingAiLyrics.isInitialized) {
            updateToggleButton(btnToggleSettingAiLyrics, PlayerHolder.isDualLanguageLyricsEnabled)
            tvSettingAiLyricsStatus.text = if (PlayerHolder.isDualLanguageLyricsEnabled) "Enabled • Bilingual subtitle translation active" else "Standard • Single language synced LRC"
        }
        if (::btnToggleSettingSpeechToText.isInitialized) {
            updateToggleButton(btnToggleSettingSpeechToText, PlayerHolder.isSpeechToTextAutoEnabled)
            tvSettingSpeechToTextStatus.text = if (PlayerHolder.isSpeechToTextAutoEnabled) "Active • Real-time live vocal/speech recognition" else "Disabled"
        }
        if (::btnToggleSettingAutoEmbedLrc.isInitialized) {
            updateToggleButton(btnToggleSettingAutoEmbedLrc, PlayerHolder.isAutoEmbedLrcEnabled)
            tvSettingAutoEmbedLrcStatus.text = if (PlayerHolder.isAutoEmbedLrcEnabled) "Active • Permanent sync attached to song" else "Standard app cache only"
        }
        try {
            val pInfo = packageManager.getPackageInfo(packageName, 0)
            findViewById<TextView>(R.id.tvAppVersionCode)?.text = "Version " + pInfo.versionName + " (Build " + pInfo.versionCode + ") • CleanPlayer"
        } catch (e: Exception) {}
        if (::btnToggleSettingWordSync.isInitialized) {
            updateToggleButton(btnToggleSettingWordSync, PlayerHolder.isWordByWordLyricsEnabled)
            tvSettingWordSyncStatus.text = if (PlayerHolder.isWordByWordLyricsEnabled) "Active • Word-synced glowing karaoke lyrics" else "Standard full-line highlight"
        }
        if (::tvSettingAiProfilerStatus.isInitialized) {
            val prof = HardwareProfilerEngine.getProfile(this)
            tvSettingAiProfilerStatus.text = "${prof.displayBadge} • Auto-Tuned Active"
        }

        if (::btnToggleAiSmartTransition.isInitialized) {
            val isSmartOn = PlayerHolder.isAiSmartTransitionEnabled
            updateToggleButton(btnToggleAiSmartTransition, isSmartOn)
            tvAiSmartTransitionStatus.text = if (isSmartOn) {
                "Active (Auto Audio-Only & Notch Intent Preservation)"
            } else {
                "Disabled (Direct playback suspend on tab exit)"
            }
        }

        if (::tvAiTopicPreferencesStatus.isInitialized) {
            val topicsCount = SmartRecommendationEngine.getSelectedTopics(this).size
            tvAiTopicPreferencesStatus.text = "$topicsCount Preferred Topics active (Refining Home Feed)"
        }

        if (::btnToggleAiDialogueBoost.isInitialized) {
            val isDialogueOn = PlayerHolder.isDialogueBoostEnabled
            updateToggleButton(btnToggleAiDialogueBoost, isDialogueOn)
            tvAiDialogueBoostStatus.text = if (isDialogueOn) {
                "Active (+8dB Speech Normalization On)"
            } else {
                "Disabled (Standard audio balance)"
            }
        }

        if (::tvAiSponsorBlockStatus.isInitialized) {
            tvAiSponsorBlockStatus.text = if (PlayerHolder.isSponsorBlockEnabled) {
                "Enabled (Auto-skips sponsors, intros & promo)"
            } else {
                "Disabled"
            }
        }

        if (::tvAiModelSyncStatus.isInitialized) {
            tvAiModelSyncStatus.text = "100% Offline • Personalized to your library"
        }

        if (::tvAiOnDemandModelStatus.isInitialized) {
            val statusStr = if (PlayerHolder.isAiNeuralSuperResEnabled) "Active (60 FPS)" else "Ready"
            tvAiOnDemandModelStatus.text = "🎬 Hardware Video & HDR Boost • $statusStr"
        }

        // Interface UI
        tvAppThemeStatus.text = when (PlayerHolder.appThemeMode) {
            PlayerHolder.THEME_MONOCHROME -> getString(R.string.theme_monochrome)
            PlayerHolder.THEME_CHARCOAL -> "Dark Charcoal"
            else -> "Pure Black OLED (Default)"
        }

        // Dedicated YouTube Premium & Advanced Streaming Settings UI
        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val isAdBlockOn = ytPrefs.getBoolean("pref_yt_adblock", true)
        updateToggleButton(btnToggleYtAdBlock, isAdBlockOn)
        tvYtAdBlockStatus.text = if (isAdBlockOn) "Active (100% Ad-Free Video & Feed)" else "Disabled (Standard YouTube)"

        tvYtSponsorBlockStatus.text = if (PlayerHolder.isSponsorBlockEnabled) "Enabled (Auto-skip sponsors/intros)" else "Disabled"
        tvYtDefaultQualityStatus.text = ytPrefs.getString("pref_yt_default_quality", "Auto (Adaptive High Bitrate)") ?: "Auto"
        tvYtAudioQualityStatus.text = ytPrefs.getString("pref_yt_audio_quality", "Auto (Adaptive - Recommended)") ?: "Auto"
        tvYtBufferLimitStatus.text = ytPrefs.getString("pref_yt_buffer_limit", "30s (Balanced Data Saver - Recommended)") ?: "30s"
        findViewById<TextView>(R.id.tvYtMediaCacheStatus)?.text = ytPrefs.getString("pref_yt_disk_cache_label", "4 GB (Ultra Large - 4096 MB - Recommended)") ?: "4 GB (Ultra Large - 4096 MB - Recommended)"
        findViewById<TextView>(R.id.tvYtStreamCacheTtlStatus)?.text = ytPrefs.getString("pref_yt_stream_ttl_label", "4 Hours (Recommended)") ?: "4 Hours (Recommended)"
        tvYtExtractorBridgeStatus.text = "NewPipe Extractor v0.26.5"
        val currentClient = ytPrefs.getString("pref_yt_client_spoof", "TVHTML5_SIMPLY_EMBEDDED_PLAYER") ?: "TVHTML5_SIMPLY_EMBEDDED_PLAYER"
        tvYtClientSpoofingStatus.text = when (currentClient) {
            "ANDROID_TESTSUITE" -> "Android Testsuite (Internal test - No Botguard)"
            "IOS" -> "iOS Official (Direct formats - Native Apple)"
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER" -> "TV HTML5 Embedded (High-bitrate DASH/HLS)"
            "ANDROID" -> "Android Official (Standard YouTube client)"
            else -> "Android VR (Oculus Quest - Zero PoToken Bypass)"
        }

        updateToggleButton(btnToggleYtBgAudio, PlayerHolder.isBackgroundPlayEnabled)
        tvYtBgAudioStatus.text = if (PlayerHolder.isBackgroundPlayEnabled) "Enabled with Lock Screen controls" else "Disabled"

        val showComments = ytPrefs.getBoolean("pref_yt_show_comments", true)
        val showCast = ytPrefs.getBoolean("pref_yt_show_cast", true)
        val commentsStatus = if (showComments) "ON" else "OFF"
        val castStatus = if (showCast) "ON" else "OFF"
        tvYtInterfaceStatus.text = "Comments: $commentsStatus • Cast: $castStatus"

        // Apply UI toggles to current YouTube views
        layoutYtCommentsCard.visibility = if (showComments) View.VISIBLE else View.GONE
        btnYtCast.visibility = if (showCast) View.VISIBLE else View.GONE

        tvYtAccountStatus.text = "Independent Mode • 100% Private (No Account Needed)"

        if (::tvYtExtractorOtaStatus.isInitialized) {
            tvYtExtractorOtaStatus.text = DynamicExtractorOtaEngine.getExtractorSummary(this)
        }
    }
    private fun showSponsorBlockSettingsDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_sponsorblock_settings, null)
        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        view.findViewById<View>(R.id.btnSponsorClose)?.setOnClickListener { dialog.dismiss() }

        val cbMaster = view.findViewById<CheckBox>(R.id.cbSbMaster)
        val cbSponsor = view.findViewById<CheckBox>(R.id.cbSbSponsor)
        val cbIntro = view.findViewById<CheckBox>(R.id.cbSbIntro)
        val cbOutro = view.findViewById<CheckBox>(R.id.cbSbOutro)
        val cbPromo = view.findViewById<CheckBox>(R.id.cbSbPromo)
        val cbInteraction = view.findViewById<CheckBox>(R.id.cbSbInteraction)

        cbMaster?.isChecked = PlayerHolder.isSponsorBlockEnabled
        cbSponsor?.isChecked = PlayerHolder.sbSkipSponsor
        cbIntro?.isChecked = PlayerHolder.sbSkipIntro
        cbOutro?.isChecked = PlayerHolder.sbSkipOutro
        cbPromo?.isChecked = PlayerHolder.sbSkipPromo
        cbInteraction?.isChecked = PlayerHolder.sbSkipInteraction

        val updateStates = {
            PlayerHolder.isSponsorBlockEnabled = cbMaster?.isChecked == true
            PlayerHolder.sbSkipSponsor = cbSponsor?.isChecked == true
            PlayerHolder.sbSkipIntro = cbIntro?.isChecked == true
            PlayerHolder.sbSkipOutro = cbOutro?.isChecked == true
            PlayerHolder.sbSkipPromo = cbPromo?.isChecked == true
            PlayerHolder.sbSkipInteraction = cbInteraction?.isChecked == true
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }

        cbMaster?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbSponsor?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbIntro?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbOutro?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbPromo?.setOnCheckedChangeListener { _, _ -> updateStates() }
        cbInteraction?.setOnCheckedChangeListener { _, _ -> updateStates() }

        dialog.show()
    }

    private fun showYouTubeQualityDialog() {
        val qualities = arrayOf(
            "Auto (Adaptive High Bitrate)",
            "4K Ultra HD (2160p)",
            "2K Quad HD (1440p)",
            "1080p Full HD",
            "720p HD",
            "480p SD",
            "360p Data Saver",
            "240p Low",
            "144p Ultra Data Saver"
        )
        val qualityHeights = intArrayOf(0, 2160, 1440, 1080, 720, 480, 360, 240, 144)
        val prefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val currentQuality = prefs.getString("pref_yt_default_quality", qualities[0]) ?: qualities[0]
        val curIdx = qualities.indexOfFirst { it.equals(currentQuality, ignoreCase = true) || it.startsWith(currentQuality.substringBefore(" ")) }.let { if (it >= 0) it else 0 }

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Default Streaming Quality")
            .setSingleChoiceItems(qualities, curIdx) { dialog, which ->
                val chosen = qualities[which]
                prefs.edit().putString("pref_yt_default_quality", chosen).apply()
                val maxHeight = qualityHeights[which]
                PlayerHolder.currentVideoQuality = chosen
                PlayerHolder.savePreferences(this)
                YouTubeExoPlayerManager.setVideoQuality(maxHeight)
                updateSettingsUI()
                CleanToast.show(this, "Quality set to $chosen")
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showClientSpoofingDialog() {
        val clients = arrayOf(
            "TVHTML5_SIMPLY_EMBEDDED_PLAYER" to "TV HTML5 Embedded (High-bitrate DASH/HLS - Highly Permissive)",
            "IOS" to "iOS Official (Direct formats - Native Apple client)",
            "ANDROID_TESTSUITE" to "Android Testsuite (Internal test client - No Botguard)",
            "ANDROID_VR" to "Android VR (Oculus Quest 2 - Zero PoToken)",
            "ANDROID" to "Android Official (Standard YouTube client)"
        )

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val currentClient = ytPrefs.getString("pref_yt_client_spoof", "TVHTML5_SIMPLY_EMBEDDED_PLAYER") ?: "TVHTML5_SIMPLY_EMBEDDED_PLAYER"
        val currentIndex = clients.indexOfFirst { it.first.equals(currentClient, ignoreCase = true) }.coerceAtLeast(0)

        val displayOptions = clients.map { it.second }.toTypedArray()

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Client Spoofing Profile")
            .setSingleChoiceItems(displayOptions, currentIndex) { dialog, which ->
                val (clientId, _) = clients[which]
                ytPrefs.edit().putString("pref_yt_client_spoof", clientId).apply()
                updateSettingsUI()
                val clientName = clients[which].second.substringBefore(" (")
                // Silent notification removed
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showExtractorBridgeDialog() {
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Extractor Engine")
            .setMessage("Engine: Official TeamNewPipe Extractor (v0.26.5)\nMode: 100% Native Ad-Free Playback\nStatus: Active")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showYouTubeUiConfigDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_youtube_ui_settings, null)
        val dialog = AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val prefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val cbComments = view.findViewById<CheckBox>(R.id.cbYtUiShowComments)
        val cbCast = view.findViewById<CheckBox>(R.id.cbYtUiShowCast)
        val btnDone = view.findViewById<Button>(R.id.btnYtUiSaveClose)

        cbComments?.isChecked = prefs.getBoolean("pref_yt_show_comments", true)
        cbCast?.isChecked = prefs.getBoolean("pref_yt_show_cast", true)

        btnDone?.setOnClickListener {
            prefs.edit()
                .putBoolean("pref_yt_show_comments", cbComments?.isChecked == true)
                .putBoolean("pref_yt_show_cast", cbCast?.isChecked == true)
                .apply()
            updateSettingsUI()
            dialog.dismiss()
        }

        dialog.show()
    }


    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }

        if (permissionsToRequest.isNotEmpty()) {
            storagePermissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            loadMediaFiles()
        }
    }

    private fun switchVideoViewMode(folders: Boolean) {
        isFolderViewActive = folders
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        if (folders) {
            btnViewAllVideos.setTextColor(secondaryColor)
            btnViewFolders.setTextColor(primaryColor)

            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            updateFoldersData()
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)

            rvVideos.visibility = View.VISIBLE
            layoutFoldersContainer.visibility = View.GONE
            closeFolderDetail()
        }
    }

    private fun closeFolderDetail() {
        currentSelectedFolder = null
        layoutFolderDetailHeader.visibility = View.GONE
        rvFolderVideos.visibility = View.GONE
        rvFolders.visibility = View.VISIBLE
    }

    private fun updateFoldersData() {
        val folderMap = linkedMapOf<String, MediaFolder>()
        for (video in allVideos) {
            val key = if (video.folderPath.isNotEmpty()) video.folderPath else video.folderName
            val folder = folderMap.getOrPut(key) {
                MediaFolder(video.folderName, video.folderPath)
            }
            folder.videos.add(video)
        }
        allFolders = folderMap.values.toList()

        btnViewFolders.text = "FOLDERS"
        btnViewAllVideos.text = "VIDEOS"

        if (folderAdapter == null) {
            folderAdapter = FolderAdapter(allFolders) { folder ->
                openFolderDetail(folder)
            }
            rvFolders.adapter = folderAdapter
        } else {
            folderAdapter?.updateFolders(allFolders)
        }
    }

    private fun openFolderDetail(folder: MediaFolder) {
        currentSelectedFolder = folder
        rvFolders.visibility = View.GONE
        layoutFolderDetailHeader.visibility = View.VISIBLE
        rvFolderVideos.visibility = View.VISIBLE

        tvFolderHeaderTitle.text = folder.folderName
        tvFolderHeaderSubtitle.text = "${folder.count} videos • ${folder.getFormattedSize()}"

        folderVideoAdapter = MediaAdapter(folder.videos) { item, _ ->
            try {
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } catch (e: Exception) {
                e.printStackTrace()
                CleanToast.show(this, "Unable to play: ${e.localizedMessage}")
            }
        }
        rvFolderVideos.adapter = folderVideoAdapter
    }

    private fun applyScannedVideos(videos: List<MediaItem>) {
        allVideos = videos
        if (allVideos.isNotEmpty()) {
            layoutEmptyVideo.visibility = View.GONE
            if (videoAdapter == null) {
                videoAdapter = MediaAdapter(allVideos) { item, _ ->
                    try {
                        openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        CleanToast.show(this, "Unable to play: ${e.localizedMessage}")
                    }
                }
                rvVideos.adapter = videoAdapter
            } else {
                videoAdapter?.updateList(allVideos)
            }
            updateFoldersData()
            if (isFolderViewActive) {
                rvVideos.visibility = View.GONE
                layoutFoldersContainer.visibility = View.VISIBLE
            } else {
                rvVideos.visibility = View.VISIBLE
                layoutFoldersContainer.visibility = View.GONE
            }
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = View.VISIBLE
        }
    }

    private fun applyScannedAudio(audios: List<MediaItem>) {
        allAudio = audios
        if (allAudio.isNotEmpty()) {
            rvAudio.visibility = View.VISIBLE
            layoutEmptyAudio.visibility = View.GONE
            if (audioAdapter == null) {
                audioAdapter = MediaAdapter(allAudio) { item, pos ->
                    try {
                        YouTubeExoPlayerManager.pause()
                        YouTubeExoPlayerManager.stop()
                        YouTubeExoPlayerManager.currentPlayingVideo = null
                        currentPlayingYtVideo = null
                        isYtVideoPlaying = false
                        if (::cardYtMiniPlayer.isInitialized) cardYtMiniPlayer.visibility = View.GONE
                        if (::layoutYtAudioModeVisual.isInitialized) layoutYtAudioModeVisual.visibility = View.GONE

                        PlayerHolder.setPlaylistAndPlay(this, allAudio, pos)
                        audioAdapter?.setPlayingUri(item.uri)
                        updateNotchPlayerUI()
                        openPlayer(item.uri, item.title, isVideo = false, path = item.filePath, artist = item.artist)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        CleanToast.show(this, "Unable to play: ${e.localizedMessage}")
                    }
                }
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
                rvAudio.adapter = audioAdapter
            } else {
                audioAdapter?.updateList(allAudio)
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            }
        } else {
            rvAudio.visibility = View.GONE
            layoutEmptyAudio.visibility = View.VISIBLE
        }
    }

    private fun loadMediaFiles(forceRefresh: Boolean = false) {
        val cachedVids = MediaScanner.cachedVideos
        val cachedAuds = MediaScanner.cachedAudio
        if (!forceRefresh && cachedVids != null && cachedAuds != null) {
            applyScannedVideos(cachedVids)
            applyScannedAudio(cachedAuds)
            return
        } else if (cachedVids != null) {
            applyScannedVideos(cachedVids)
        }

        java.util.concurrent.Executors.newSingleThreadExecutor().execute {
            val scannedVideos = MediaScanner.scanVideos(this, forceRefresh)
            val scannedAudio = MediaScanner.scanAudio(this, forceRefresh)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                applyScannedVideos(scannedVideos)
                applyScannedAudio(scannedAudio)
            }
        }
    }

    private fun openPlayer(uri: Uri, title: String, isVideo: Boolean = true, path: String? = null, artist: String? = null) {
        // User intent is now to play local media:
        // Gracefully pause and save YouTube position to history so there is no audio conflict
        if (YouTubeExoPlayerManager.isPlaying()) {
            YouTubeExoPlayerManager.currentPlayingVideo?.let { v ->
                val pos = YouTubeExoPlayerManager.exoPlayer?.currentPosition ?: 0L
                YouTubeHistoryManager.addHistory(this, v, pos)
            }
            YouTubeExoPlayerManager.pause()
            MediaPlaybackService.stop(this)
        }
        PlayerHolder.isAudioOnly = !isVideo
        PlayerHolder.currentArtist = artist ?: "Unknown artist"
        val intent = Intent(this, PlayerActivity::class.java).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra("media_uri", uri.toString())
            putExtra("media_title", title)
            putExtra("media_artist", PlayerHolder.currentArtist)
            putExtra("is_video", isVideo)
            if (!path.isNullOrEmpty()) {
                putExtra("media_path", path)
            }
        }
        startActivity(intent)
    }

    private fun updateCacheSizeDisplay() {
        try {
            var size = getDirSize(cacheDir)
            size += getDirSize(codeCacheDir)
            externalCacheDir?.let { size += getDirSize(it) }
            val formatted = if (size <= 0) "0 B (Clean)" else android.text.format.Formatter.formatFileSize(this, size)
            tvCacheSizeStatus.text = "$formatted • YouTube stream & thumbnail cache (Files safe)"
        } catch (e: Exception) {
            tvCacheSizeStatus.text = "0 B (Clean) • Free up temporary cache"
        }
    }

    private fun getDirSize(dir: java.io.File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var bytes = 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            bytes += if (f.isDirectory) getDirSize(f) else f.length()
        }
        return bytes
    }

    private fun clearAppCache() {
        try {
            cacheDir.deleteRecursively()
            codeCacheDir.deleteRecursively()
            externalCacheDir?.deleteRecursively()
            // Cache cleared
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAppVersionDialog() {
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle(R.string.app_name)
            .setMessage("Version 3.0 (Master Edition)\nBuild: 300\n\nLead Developer: Rajesh Shah\nEngine: Universal Hardware Core with Dolby Surround\n\nStatus: Up to date")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showKeyMomentsDialog(video: YouTubeVideo) {
        val mediaId = video.id
        val mediaTitle = video.title
        val currentMs = YouTubeExoPlayerManager.getCurrentPosition()

        val allBookmarks = BookmarkTimestampManager.getBookmarksForMedia(this, mediaId).toMutableList()
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val density = resources.displayMetrics.density

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (24 * density).toInt())
            setBackgroundColor(Color.parseColor("#1C1C1E"))
        }

        val tvHead = TextView(this).apply {
            text = "🔖 Key Moments & Bookmarks (${allBookmarks.size})"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, (8 * density).toInt())
        }
        sheet.addView(tvHead)

        val btnAdd = Button(this).apply {
            text = "➕ Bookmark Current Moment (${BookmarkTimestampManager.formatDuration(currentMs)})"
            setBackgroundColor(Color.parseColor("#272727"))
            setTextColor(Color.WHITE)
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setOnClickListener {
                val input = android.widget.EditText(this@MainActivity).apply {
                    hint = "Moment note (e.g. Favorite scene, Key point)"
                    setTextColor(Color.WHITE)
                    setHintTextColor(Color.parseColor("#888888"))
                    setPadding(40, 30, 40, 30)
                }
                AlertDialog.Builder(this@MainActivity, R.style.DarkAlertDialogTheme)
                    .setTitle("Bookmark (${BookmarkTimestampManager.formatDuration(currentMs)})")
                    .setView(input)
                    .setPositiveButton("Save") { _, _ ->
                        val note = input.text.toString().trim()
                        BookmarkTimestampManager.addBookmark(this@MainActivity, mediaId, mediaTitle, currentMs, note)
                        CleanToast.show(this@MainActivity, "Key moment bookmarked!")
                        dialog.dismiss()
                        showKeyMomentsDialog(video)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
        sheet.addView(btnAdd)

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (220 * density).toInt()).apply {
                topMargin = (12 * density).toInt()
            }
        }
        val listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        if (allBookmarks.isEmpty()) {
            val tvEmpty = TextView(this).apply {
                text = "No saved moments for this video yet. Tap the button above to bookmark any timestamp!"
                setTextColor(Color.parseColor("#888888"))
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, (30 * density).toInt(), 0, (30 * density).toInt())
            }
            listContainer.addView(tvEmpty)
        } else {
            for (bm in allBookmarks) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding((8 * density).toInt(), (10 * density).toInt(), (8 * density).toInt(), (10 * density).toInt())
                    background = android.util.TypedValue().let { tv ->
                        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                        androidx.core.content.ContextCompat.getDrawable(this@MainActivity, tv.resourceId)
                    }
                    setOnClickListener {
                        YouTubeExoPlayerManager.seekTo(bm.timestampMs)
                        CleanToast.show(this@MainActivity, "Jumped to ${bm.formattedTime}")
                        dialog.dismiss()
                    }
                }
                val tvTime = TextView(this).apply {
                    text = bm.formattedTime
                    setTextColor(Color.parseColor("#FF8800"))
                    textSize = 14f
                    setTypeface(null, Typeface.BOLD)
                    setPadding((6 * density).toInt(), (2 * density).toInt(), (8 * density).toInt(), (2 * density).toInt())
                }
                val tvNote = TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                        marginStart = (8 * density).toInt()
                    }
                    text = bm.note
                    setTextColor(Color.WHITE)
                    textSize = 13f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                val btnDel = ImageButton(this).apply {
                    val s = (28 * density).toInt()
                    layoutParams = LinearLayout.LayoutParams(s, s)
                    setBackgroundResource(android.R.color.transparent)
                    setImageResource(android.R.drawable.ic_menu_delete)
                    setColorFilter(Color.parseColor("#888888"))
                    setOnClickListener {
                        BookmarkTimestampManager.deleteBookmark(this@MainActivity, bm.id)
                        dialog.dismiss()
                        showKeyMomentsDialog(video)
                    }
                }
                row.addView(tvTime)
                row.addView(tvNote)
                row.addView(btnDel)
                listContainer.addView(row)
            }
        }
        scrollView.addView(listContainer)
        sheet.addView(scrollView)

        dialog.setContentView(sheet)
        dialog.show()
    }

    private fun showPersonalizedTopicsDialog(onUpdated: (() -> Unit)? = null) {
        val allCurated = SmartRecommendationEngine.DEFAULT_CURATED_TOPICS.toMutableList()
        val currentSelected = SmartRecommendationEngine.getSelectedTopics(this).toMutableList()

        for (t in currentSelected) {
            if (!allCurated.contains(t)) {
                allCurated.add(t)
            }
        }

        val itemsArray = allCurated.toTypedArray()
        val checkedArray = BooleanArray(itemsArray.size) { i ->
            currentSelected.contains(itemsArray[i])
        }

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("🎯 Preferred Topics & Interests")
            .setMultiChoiceItems(itemsArray, checkedArray) { _, which, isChecked ->
                val topic = itemsArray[which]
                if (isChecked) {
                    if (!currentSelected.contains(topic)) currentSelected.add(topic)
                } else {
                    currentSelected.remove(topic)
                }
            }
            .setPositiveButton("Save (${currentSelected.size})") { dialog, _ ->
                SmartRecommendationEngine.saveSelectedTopics(this, currentSelected)
                // Toast removed per user request (unnecessary)
                onUpdated?.invoke()
                if (currentYtCategory.equals("All", ignoreCase = true)) {
                    loadYouTubeFeed("All")
                }
                dialog.dismiss()
            }
            .setNeutralButton("➕ Custom Topic") { _, _ ->
                showAddCustomTopicDialog { customTopic ->
                    if (!currentSelected.contains(customTopic)) {
                        currentSelected.add(customTopic)
                    }
                    SmartRecommendationEngine.saveSelectedTopics(this, currentSelected)
                    showPersonalizedTopicsDialog(onUpdated)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddCustomTopicDialog(onAdded: (String) -> Unit) {
        val input = android.widget.EditText(this).apply {
            hint = "e.g. Geopolitics, KTM RC, AI Coding"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#888888"))
            setPadding(40, 30, 40, 30)
        }
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Add Custom Topic or Keyword")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotBlank()) {
                    onAdded(text)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun showYouTubePlayerQuickControlsDialog() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val density = resources.displayMetrics.density

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (20 * density).toInt())
            setBackgroundColor(Color.parseColor("#1C1C1E"))
        }

        val headerRow = RelativeLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = (10 * density).toInt()
            }
        }
        val tvHead = TextView(this).apply {
            text = "⚙️ Video Playback Controls"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
        }
        val btnClose = ImageButton(this).apply {
            val s = (28 * density).toInt()
            layoutParams = RelativeLayout.LayoutParams(s, s).apply {
                addRule(RelativeLayout.ALIGN_PARENT_END)
                addRule(RelativeLayout.CENTER_VERTICAL)
            }
            setBackgroundResource(android.R.color.transparent)
            setImageResource(R.drawable.ic_close)
            setColorFilter(Color.WHITE)
            setOnClickListener { dialog.dismiss() }
        }
        headerRow.addView(tvHead)
        headerRow.addView(btnClose)
        sheet.addView(headerRow)

        val div = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply {
                bottomMargin = (10 * density).toInt()
            }
            setBackgroundColor(Color.parseColor("#333333"))
        }
        sheet.addView(div)

        fun createControlRow(title: String, subtitle: String, iconRes: Int, onClick: () -> Unit): View {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((8 * density).toInt(), (12 * density).toInt(), (8 * density).toInt(), (12 * density).toInt())
                background = android.util.TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                    androidx.core.content.ContextCompat.getDrawable(this@MainActivity, tv.resourceId)
                }
                setOnClickListener { onClick() }
            }
            val iv = ImageView(this).apply {
                val s = (24 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(s, s)
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }
            val textLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = (14 * density).toInt()
                }
            }
            val tvT = TextView(this).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 14f
                setTypeface(null, Typeface.BOLD)
            }
            val tvS = TextView(this).apply {
                text = subtitle
                setTextColor(Color.parseColor("#8E8E93"))
                textSize = 12f
                setPadding(0, (2 * density).toInt(), 0, 0)
            }
            textLayout.addView(tvT)
            textLayout.addView(tvS)
            row.addView(iv)
            row.addView(textLayout)
            return row
        }

        // 1. Video Quality
        sheet.addView(createControlRow("🎬 Video Quality", "Current: " + PlayerHolder.currentVideoQuality, R.drawable.ic_aspect_ratio) {
            dialog.dismiss()
            showYouTubeQualityDialog()
        })

        // 2. Playback Speed
        val currentSpeed = YouTubeExoPlayerManager.exoPlayer?.playbackParameters?.speed ?: 1.0f
        sheet.addView(createControlRow("⚡ Playback Speed (" + currentSpeed + "x)", "Adjust playback rate (0.5x - 2.0x)", R.drawable.ic_speed) {
            dialog.dismiss()
            showPlaybackSpeedDialog()
        })

        // 3. Audio Dub Track
        sheet.addView(createControlRow("🌐 Audio Track (Dubbed)", "Hindi Default, English, Original", R.drawable.ic_audiotrack) {
            dialog.dismiss()
            showAudioTrackSelectionDialog()
        })

        // 4. Captions / Subtitles
        val subsEnabled = YouTubeExoPlayerManager.isCaptionsEnabled()
        val subsText = if (subsEnabled) "Captions: ON" else "Captions: OFF"
        sheet.addView(createControlRow("💬 Captions / Subtitles", subsText, R.drawable.ic_subtitles) {
            dialog.dismiss()
            YouTubeExoPlayerManager.toggleCaptions()
            CleanToast.show(this@MainActivity, if (YouTubeExoPlayerManager.isCaptionsEnabled()) "Captions ON" else "Captions OFF")
        })

        // 5. Sound & Equalizer Presets
        sheet.addView(createControlRow("🎛️ Sound & Equalizer", "Normal, Bass Boost, Vocals, Presets", R.drawable.ic_equalizer) {
            dialog.dismiss()
            val presets = arrayOf("Flat (Default)", "Rock", "Pop", "Jazz", "Classical", "Hip Hop", "Dance", "Vocal Booster", "Bass Dynamic")
            val pIdx = PlayerHolder.currentEqualizerPreset.coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Equalizer Presets")
                .setSingleChoiceItems(presets, pIdx) { d, which ->
                    PlayerHolder.currentEqualizerPreset = which
                    PlayerHolder.applyAudioEffects(YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0)
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })

        // 6. Audio / Video Mode
        val isAudio = YouTubeExoPlayerManager.isAudioOnlyMode
        val audioModeText = if (isAudio) "Audio-Only Mode (Active)" else "Video Mode (Active)"
        sheet.addView(createControlRow("🎧 Audio / Video Mode", audioModeText, R.drawable.ic_audio) {
            val isNowAudioOnly = YouTubeExoPlayerManager.toggleAudioVideoMode(this)
            updateAudioModeUI(isNowAudioOnly)
            dialog.dismiss()
        })

        // 7. Video Boost / HDR Enhancer
        val isBoost = PlayerHolder.isAiVideoSharpnessEnabled || PlayerHolder.isAiNeuralSuperResEnabled
        val boostText = if (isBoost) "✨ HDR Boost: ON (Vibrant Colors & Dynamic Contrast)" else "HDR Boost: OFF (Tap to Enable)"
        sheet.addView(createControlRow("✨ Video Boost (HDR)", boostText, R.drawable.ic_aspect_ratio) {
            PlayerHolder.isAiVideoSharpnessEnabled = !PlayerHolder.isAiVideoSharpnessEnabled
            PlayerHolder.savePreferences(this@MainActivity)
            updateYtVideoBoostBadge()
            AiVideoEnhancer.applyEnhancement(this@MainActivity, false)
            CleanToast.show(this@MainActivity, if (PlayerHolder.isAiVideoSharpnessEnabled) "✨ HDR Boost: ON (Vibrant Colors & Contrast)" else "HDR Boost: OFF")
            dialog.dismiss()
        })

        // 8. Advanced YouTube App Settings
        sheet.addView(createControlRow("⚙️ More App Settings (Advanced)", "Personalization, Feed & Cache Options", R.drawable.ic_settings) {
            dialog.dismiss()
            showYouTubeDedicatedSettingsDialog()
        })

        dialog.setContentView(sheet)
        dialog.show()
    }

    fun showYouTubeDedicatedSettingsDialog() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_youtube_app_settings, null)
        dialog.setContentView(view)
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.let { sheet ->
                val behavior = com.google.android.material.bottomsheet.BottomSheetBehavior.from(sheet)
                behavior.state = com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
            }
        }

        view.findViewById<View>(R.id.btnYtSettingsClose)?.setOnClickListener { dialog.dismiss() }

        val ytPrefs = getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)

        // Feed & AI Personalization Topics
        val tvTopics = view.findViewById<TextView>(R.id.tvYtSettingTopicsVal)
        val updateTopicsText = {
            val count = SmartRecommendationEngine.getSelectedTopics(this).size
            tvTopics?.text = if (count > 0) "$count topics active (High Priority Feed)" else "Tap to choose your favorite topics & keywords"
        }
        updateTopicsText()
        view.findViewById<View>(R.id.rowYtSettingPersonalizationTopics)?.setOnClickListener {
            showPersonalizedTopicsDialog {
                updateTopicsText()
            }
        }

        // AI 1. Recommendation Mode
        val tvAiMode = view.findViewById<TextView>(R.id.tvYtSettingAiModeVal)
        val aiModes = arrayOf(
            "Smart Discovery (Topic-Based Recommendation)",
            "Strict Match (Only Selected Topics)",
            "Trending & Viral Velocity (Fast Trending Content)"
        )
        val updateAiModeText = {
            val curAiMode = ytPrefs.getString("pref_yt_ai_mode", aiModes[0]) ?: aiModes[0]
            tvAiMode?.text = curAiMode
        }
        updateAiModeText()

        view.findViewById<View>(R.id.rowYtSettingAiMode)?.setOnClickListener {
            val curAiMode = ytPrefs.getString("pref_yt_ai_mode", aiModes[0]) ?: aiModes[0]
            val curIdx = aiModes.indexOf(curAiMode).let { if (it >= 0) it else 0 }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Recommendation Mode")
                .setSingleChoiceItems(aiModes, curIdx) { d, which ->
                    val chosen = aiModes[which]
                    ytPrefs.edit().putString("pref_yt_ai_mode", chosen).apply()
                    updateAiModeText()
                    CleanToast.show(this, "Recommendation Mode set to $chosen")
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Hide Watched Videos Toggle
        val tvHideWatched = view.findViewById<TextView>(R.id.tvYtSettingHideWatchedVal)
        val updateHideWatchedText = {
            val isHideWatched = ytPrefs.getBoolean("pref_yt_hide_watched", true)
            tvHideWatched?.text = if (isHideWatched) "Enabled (Ek baar dekha video dobara suggest nahi karega)" else "Disabled (Show repeated videos)"
        }
        updateHideWatchedText()

        view.findViewById<View>(R.id.rowYtSettingHideWatched)?.setOnClickListener {
            val newState = !ytPrefs.getBoolean("pref_yt_hide_watched", true)
            ytPrefs.edit().putBoolean("pref_yt_hide_watched", newState).apply()
            updateHideWatchedText()
            SmartRecommendationEngine.invalidateCache()
            CleanToast.show(this, if (newState) "Watched videos hidden from suggestions" else "Watched videos allowed in suggestions")
        }

        // AI 2. Clean Titles & Clickbait Filter
        val tvCleanTitles = view.findViewById<TextView>(R.id.tvYtSettingCleanTitlesVal)
        val updateCleanTitlesText = {
            val isCleanTitlesEnabled = ytPrefs.getBoolean("pref_yt_ai_clean_titles", true)
            tvCleanTitles?.text = if (isCleanTitlesEnabled) "Enabled (Filters sensational ALL-CAPS & spam)" else "Disabled (Raw YouTube titles)"
        }
        updateCleanTitlesText()

        view.findViewById<View>(R.id.rowYtSettingCleanTitles)?.setOnClickListener {
            val newState = !ytPrefs.getBoolean("pref_yt_ai_clean_titles", true)
            ytPrefs.edit().putBoolean("pref_yt_ai_clean_titles", newState).apply()
            updateCleanTitlesText()
            CleanToast.show(this, if (newState) "Clean Titles Enabled" else "Raw Titles Enabled")
        }

        // AI 3. Next-Video Pre-Warming
        val tvPrewarm = view.findViewById<TextView>(R.id.tvYtSettingPreWarmVal)
        val updatePrewarmText = {
            val isPrewarmEnabled = ytPrefs.getBoolean("pref_yt_ai_prewarm", true)
            tvPrewarm?.text = if (isPrewarmEnabled) "Active (Pre-fetches stream for 0ms instant playback)" else "Disabled (Fetch streams on demand)"
        }
        updatePrewarmText()

        view.findViewById<View>(R.id.rowYtSettingPreWarm)?.setOnClickListener {
            val newState = !ytPrefs.getBoolean("pref_yt_ai_prewarm", true)
            ytPrefs.edit().putBoolean("pref_yt_ai_prewarm", newState).apply()
            updatePrewarmText()
            CleanToast.show(this, if (newState) "Pre-Warming Active" else "Pre-Warming Disabled")
        }

        // AI 3b. Next-Video Prewarm Duration
        val tvPrewarmDur = view.findViewById<TextView>(R.id.tvYtSettingPrewarmDurationVal)
        val prewarmOptions = arrayOf(
            "10 Seconds (Fast Buffer ~3 MB)",
            "15 Seconds (Recommended - Balanced ~4 MB)",
            "30 Seconds (Deep Buffer ~8 MB)",
            "60 Seconds (Full Segment ~18 MB)",
            "Disabled (0 Seconds)"
        )
        val prewarmDurValues = intArrayOf(10, 15, 30, 60, 0)
        val updatePrewarmDurationText = {
            val curSec = ytPrefs.getInt("pref_yt_prewarm_seconds", 15)
            val idx = prewarmDurValues.indexOf(curSec).let { if (it >= 0) it else 1 }
            tvPrewarmDur?.text = prewarmOptions[idx]
        }
        updatePrewarmDurationText()

        view.findViewById<View>(R.id.rowYtSettingPrewarmDuration)?.setOnClickListener {
            val curSec = ytPrefs.getInt("pref_yt_prewarm_seconds", 15)
            val curIdx = prewarmDurValues.indexOf(curSec).let { if (it >= 0) it else 1 }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Next-Video Prewarm Duration")
                .setSingleChoiceItems(prewarmOptions, curIdx) { d, which ->
                    val chosenSec = prewarmDurValues[which]
                    ytPrefs.edit().putInt("pref_yt_prewarm_seconds", chosenSec).apply()
                    updatePrewarmDurationText()
                    CleanToast.show(this, "Prewarm set to ${prewarmOptions[which]}")
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // AI 4. Reset AI Recommendation Profile
        view.findViewById<View>(R.id.rowYtSettingAiReset)?.setOnClickListener {
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Reset Recommendation Profile")
                .setMessage("Kya aap apni feed personalization aur topic interests ko reset karna chahte hain? Isse aapki feed fresh ho jayegi.")
                .setPositiveButton("Reset") { _, _ ->
                    SmartRecommendationEngine.saveSelectedTopics(this, SmartRecommendationEngine.DEFAULT_CURATED_TOPICS)
                    SmartRecommendationEngine.invalidateCache()
                    updateTopicsText()
                    CleanToast.show(this, "Recommendation Profile reset successfully!")
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 0. Autoplay Next Video
        val tvAutoplay = view.findViewById<TextView>(R.id.tvYtSettingAutoplayVal)
        val updateAutoplayText = {
            tvAutoplay?.text = if (isYtAutoplayEnabled) "Enabled (Next video plays automatically)" else "Disabled (Pause when video ends)"
        }
        updateAutoplayText()
        view.findViewById<View>(R.id.rowYtSettingAutoplay)?.setOnClickListener {
            isYtAutoplayEnabled = !isYtAutoplayEnabled
            ytPrefs.edit().putBoolean("pref_yt_autoplay", isYtAutoplayEnabled).apply()
            updateAutoplayText()
        }

        // 1. Video Quality
        val tvQuality = view.findViewById<TextView>(R.id.tvYtSettingQualityVal)
        val qualityOptions = arrayOf(
            "Auto (Adaptive High Bitrate)",
            "4K Ultra HD (2160p)",
            "2K Quad HD (1440p)",
            "1080p Full HD",
            "720p HD",
            "480p SD",
            "360p Data Saver",
            "240p Low",
            "144p Ultra Data Saver"
        )
        val qualityHeights = intArrayOf(0, 2160, 1440, 1080, 720, 480, 360, 240, 144)
        val updateQualityText = {
            tvQuality?.text = ytPrefs.getString("pref_yt_default_quality", qualityOptions[0]) ?: qualityOptions[0]
        }
        updateQualityText()
        view.findViewById<View>(R.id.rowYtSettingQuality)?.setOnClickListener {
            val curQual = ytPrefs.getString("pref_yt_default_quality", qualityOptions[0]) ?: qualityOptions[0]
            val curIdx = qualityOptions.indexOfFirst { it.equals(curQual, ignoreCase = true) || it.startsWith(curQual.substringBefore(" ")) }.let { if (it >= 0) it else 0 }
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Default Streaming Quality")
                .setSingleChoiceItems(qualityOptions, curIdx) { d, which ->
                    val chosen = qualityOptions[which]
                    ytPrefs.edit().putString("pref_yt_default_quality", chosen).apply()
                    val maxHeight = qualityHeights[which]
                    PlayerHolder.currentVideoQuality = chosen
                    PlayerHolder.savePreferences(this)
                    YouTubeExoPlayerManager.setVideoQuality(maxHeight)
                    updateQualityText()
                    updateSettingsUI()
                    CleanToast.show(this, "Quality set to $chosen")
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Cache Size Setting
        val tvCacheSize = view.findViewById<TextView>(R.id.tvYtSettingCacheSizeVal)
        val cacheSizeOptions = arrayOf(
            "512 MB (Compact Data Saver)",
            "1024 MB (1 GB - Recommended)",
            "2048 MB (2 GB - High Performance)",
            "4096 MB (4 GB - Ultra Large)",
            "8192 MB (8 GB - Extreme Heavy Usage)",
            "16384 MB (16 GB - Massive Offline Cache)",
            "32768 MB (32 GB - Maximum Storage)"
        )
        val cacheSizeValues = longArrayOf(512L, 1024L, 2048L, 4096L, 8192L, 16384L, 32768L)
        val updateCacheSizeText = {
            val curMb = ytPrefs.getLong("pref_yt_disk_cache_mb", 1024L)
            val idx = cacheSizeValues.indexOf(curMb).let { if (it >= 0) it else 1 }
            tvCacheSize?.text = cacheSizeOptions[idx]
        }
        updateCacheSizeText()

        view.findViewById<View>(R.id.rowYtSettingCacheSize)?.setOnClickListener {
            val curMb = ytPrefs.getLong("pref_yt_disk_cache_mb", 1024L)
            val curIdx = cacheSizeValues.indexOf(curMb).let { if (it >= 0) it else 1 }

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Media Disk Cache Size")
                .setSingleChoiceItems(cacheSizeOptions, curIdx) { d, which ->
                    val chosen = cacheSizeOptions[which]
                    val sizeMb = cacheSizeValues[which]
                    ytPrefs.edit().putLong("pref_yt_disk_cache_mb", sizeMb).putString("pref_yt_disk_cache_label", chosen).apply()
                    YouTubeExoPlayerManager.updateDiskCacheSize(this, sizeMb)
                    updateCacheSizeText()
                    updateSettingsUI()
                    CleanToast.show(this, "Disk Cache: $chosen")
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Cache TTL Setting
        val tvCacheTtl = view.findViewById<TextView>(R.id.tvYtSettingCacheTtlVal)
        val ttlOptions = arrayOf(
            "2 Hours (Fast Refresh)",
            "4 Hours (Recommended)",
            "8 Hours (Extended Cache)",
            "12 Hours (All-Day Cache)",
            "24 Hours (Maximum Retention)",
            "48 Hours (Ultra Long Cache)"
        )
        val ttlHoursValues = intArrayOf(2, 4, 8, 12, 24, 48)
        val updateCacheTtlText = {
            val curHours = ytPrefs.getInt("pref_yt_stream_ttl_hours", 4)
            val idx = ttlHoursValues.indexOf(curHours).let { if (it >= 0) it else 1 }
            tvCacheTtl?.text = ttlOptions[idx]
        }
        updateCacheTtlText()

        view.findViewById<View>(R.id.rowYtSettingCacheTtl)?.setOnClickListener {
            val curHours = ytPrefs.getInt("pref_yt_stream_ttl_hours", 4)
            val curIdx = ttlHoursValues.indexOf(curHours).let { if (it >= 0) it else 1 }

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Stream URL Memory Cache Duration")
                .setSingleChoiceItems(ttlOptions, curIdx) { d, which ->
                    val chosen = ttlOptions[which]
                    val hours = ttlHoursValues[which]
                    ytPrefs.edit().putString("pref_yt_stream_ttl_label", chosen).putInt("pref_yt_stream_ttl_hours", hours).apply()
                    YouTubeStreamResolver.setCacheTtlHours(hours)
                    updateCacheTtlText()
                    updateSettingsUI()
                    CleanToast.show(this, "Cache TTL: $chosen")
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 1b. Streaming Buffer Limit
        val tvBuffer = view.findViewById<TextView>(R.id.tvYtSettingBufferVal)
        val bufferOptions = arrayOf(
            "15s (Ultra Data Saver - Least Data)",
            "30s (Balanced Data Saver - Recommended)",
            "60s (Medium Buffer - Unstable Network)",
            "120s (Maximum Pre-Buffer - Wi-Fi & Travel)"
        )
        val updateBufferText = {
            val curBuffer = ytPrefs.getString("pref_yt_buffer_limit", bufferOptions[1]) ?: bufferOptions[1]
            val idx = bufferOptions.indexOfFirst { it.startsWith(curBuffer.substringBefore(" ")) }.let { if (it >= 0) it else 1 }
            tvBuffer?.text = bufferOptions[idx]
        }
        updateBufferText()

        view.findViewById<View>(R.id.rowYtSettingBuffer)?.setOnClickListener {
            val curBuffer = ytPrefs.getString("pref_yt_buffer_limit", bufferOptions[1]) ?: bufferOptions[1]
            val curIdx = bufferOptions.indexOfFirst { it.startsWith(curBuffer.substringBefore(" ")) }.let { if (it >= 0) it else 1 }

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Streaming Buffer Limit")
                .setSingleChoiceItems(bufferOptions, curIdx) { d, which ->
                    val selected = bufferOptions[which]
                    ytPrefs.edit().putString("pref_yt_buffer_limit", selected).apply()
                    YouTubeExoPlayerManager.applyBufferLimit(this, selected)
                    updateBufferText()
                    updateSettingsUI()
                    CleanToast.show(this, "Buffer: ${selected.substringBefore(" -")}")
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 1c. Audio Streaming Quality
        val tvAudioQuality = view.findViewById<TextView>(R.id.tvYtSettingAudioQualityVal)
        val audioQualities = arrayOf(
            "Auto (Adaptive - Recommended)",
            "High Quality (160 kbps Opus - Studio Audio)",
            "Normal Quality (128 kbps M4A - Clear & Balanced)",
            "Data Saver (64 kbps - Ultra-Low Data)"
        )
        val updateAudioQualityText = {
            val curAudio = ytPrefs.getString("pref_yt_audio_quality", audioQualities[0]) ?: audioQualities[0]
            val idx = audioQualities.indexOfFirst { it.startsWith(curAudio.substringBefore(" ")) }.let { if (it >= 0) it else 0 }
            tvAudioQuality?.text = audioQualities[idx]
        }
        updateAudioQualityText()

        view.findViewById<View>(R.id.rowYtSettingAudioQuality)?.setOnClickListener {
            val curAudio = ytPrefs.getString("pref_yt_audio_quality", audioQualities[0]) ?: audioQualities[0]
            val curIdx = audioQualities.indexOfFirst { it.startsWith(curAudio.substringBefore(" ")) }.let { if (it >= 0) it else 0 }

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Audio Streaming Quality")
                .setSingleChoiceItems(audioQualities, curIdx) { d, which ->
                    val selected = audioQualities[which]
                    ytPrefs.edit().putString("pref_yt_audio_quality", selected).apply()
                    updateAudioQualityText()
                    updateSettingsUI()
                    CleanToast.show(this, "Audio Quality: ${selected.substringBefore(" -")}")
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 2. Decoder
        val tvDecoder = view.findViewById<TextView>(R.id.tvYtSettingDecoderVal)
        val decoderOptions = arrayOf("Automatic (HW MediaCodec - Recommended)", "Software (SW)")
        val updateDecoderText = {
            tvDecoder?.text = if (PlayerHolder.isHardwareDecoding) "Hardware Decoder (HW MediaCodec)" else "Software Decoder (SW)"
        }
        updateDecoderText()

        view.findViewById<View>(R.id.rowYtSettingDecoder)?.setOnClickListener {
            val curIdx = if (PlayerHolder.isHardwareDecoding) 0 else 1
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Hardware Acceleration")
                .setSingleChoiceItems(decoderOptions, curIdx) { d, which ->
                    PlayerHolder.isHardwareDecoding = (which == 0)
                    PlayerHolder.savePreferences(this)
                    updateDecoderText()
                    updateSettingsUI()
                    CleanToast.show(this, if (which == 0) "Hardware Decoder Enabled" else "Software Decoder Enabled")
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 3. Sound & 10-Band EQ
        val tvEq = view.findViewById<TextView>(R.id.tvYtSettingEqVal)
        val updateEqText = {
            val eqIdx = PlayerHolder.currentEqualizerPreset
            tvEq?.text = if (eqIdx >= 0 && eqIdx < PlayerHolder.equalizerPresets.size - 1) PlayerHolder.equalizerPresets[eqIdx + 1] else "Flat (Off)"
        }
        updateEqText()

        view.findViewById<View>(R.id.rowYtSettingEq)?.setOnClickListener {
            val presets = PlayerHolder.equalizerPresets
            val cur = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("10-Band Equalizer Presets")
                .setSingleChoiceItems(presets, cur) { d, which ->
                    PlayerHolder.currentEqualizerPreset = which - 1
                    PlayerHolder.savePreferences(this)
                    updateEqText()
                    CleanToast.show(this, "EQ Preset: ${presets[which]}")
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // 4. Audio Lipsync & Delay
        val tvAudioDelay = view.findViewById<TextView>(R.id.tvYtSettingAudioDelayVal)
        tvAudioDelay?.setText("${PlayerHolder.currentAudioDelayMs} ms (Synchronized)")
        view.findViewById<View>(R.id.rowYtSettingAudioDelay)?.setOnClickListener {
            val del = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(40, 20, 40, 20)
            }
            val tvD = TextView(this).apply {
                text = "${PlayerHolder.currentAudioDelayMs} ms"
                textSize = 18f
                setTextColor(Color.WHITE)
                gravity = android.view.Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val btnMinus = Button(this).apply {
                text = "-50ms"
                setOnClickListener {
                    PlayerHolder.currentAudioDelayMs -= 50
                    tvD.text = "${PlayerHolder.currentAudioDelayMs} ms"
                }
            }
            val btnPlus = Button(this).apply {
                text = "+50ms"
                setOnClickListener {
                    PlayerHolder.currentAudioDelayMs += 50
                    tvD.text = "${PlayerHolder.currentAudioDelayMs} ms"
                }
            }
            del.addView(btnMinus)
            del.addView(tvD)
            del.addView(btnPlus)

            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Audio Delay / Lipsync")
                .setView(del)
                .setPositiveButton("Done") { _, _ ->
                    tvAudioDelay?.setText("${PlayerHolder.currentAudioDelayMs} ms")
                    PlayerHolder.savePreferences(this)
                }
                .show()
        }

        // 5. Subtitles & Styling
        view.findViewById<View>(R.id.rowYtSettingSubtitles)?.setOnClickListener {
            dialog.dismiss()
            showSubtitleSettings()
        }

        // Audio Track & Multi-Language
        view.findViewById<View>(R.id.rowYtSettingAudioTrack)?.setOnClickListener {
            showAudioTrackSelectionDialog()
            dialog.dismiss()
        }

        // 6. SponsorBlock
        val tvSb = view.findViewById<TextView>(R.id.tvYtSettingSponsorBlockVal)
        tvSb?.setText(if (PlayerHolder.isSponsorBlockEnabled) "Enabled (Auto-skip sponsors/intros)" else "Disabled")
        view.findViewById<View>(R.id.rowYtSettingSponsorBlock)?.setOnClickListener {
            dialog.dismiss()
            showSponsorBlockSettingsDialog()
        }

        // 7. Background Audio Playback
        val tvBg = view.findViewById<TextView>(R.id.tvYtSettingBgPlayVal)
        tvBg?.setText(if (PlayerHolder.isBackgroundPlayEnabled) "Enabled with Lock Screen controls" else "Disabled")
        view.findViewById<View>(R.id.rowYtSettingBgPlay)?.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            PlayerHolder.savePreferences(this)
            tvBg?.setText(if (PlayerHolder.isBackgroundPlayEnabled) "Enabled with Lock Screen controls" else "Disabled")
        }

        // 8. Auto Screen-Off Battery Saver
        val tvAutoScreenOffYt = view.findViewById<TextView>(R.id.tvYtSettingAutoScreenOffVal)
        val updateAutoScreenOffText = {
            tvAutoScreenOffYt?.setText(if (PlayerHolder.isAutoScreenOffEnabled) "Enabled (Sleeps on finish or paused > 3 min)" else "Disabled (Screen stays awake)")
        }
        updateAutoScreenOffText()
        view.findViewById<View>(R.id.rowYtSettingAutoScreenOff)?.setOnClickListener {
            PlayerHolder.isAutoScreenOffEnabled = !PlayerHolder.isAutoScreenOffEnabled
            PlayerHolder.savePreferences(this)
            updateAutoScreenOffText()
            updateSettingsUI()
            CleanToast.show(
                this,
                if (PlayerHolder.isAutoScreenOffEnabled) "🔋 Auto Screen-Off: ON (Sleeps on finish or > 3 min pause)" else "🔋 Auto Screen-Off: OFF"
            )
        }

        dialog.show()
    }


    private fun playNextYouTubeVideo() {
        val currentList = if (allYtFeedVideos.isNotEmpty()) allYtFeedVideos else youTubeFeedAdapter.getItems()
        if (currentList.isEmpty()) return
        val curId = currentPlayingYtVideo?.id
        val curIdx = currentList.indexOfFirst { it.id == curId }
        val nextIdx = if (curIdx >= 0) (curIdx + 1) % currentList.size else 0
        val nextVideo = currentList[nextIdx]
        playYouTubeVideoInApp(nextVideo)
        // Silent notification removed
    }

    private fun playPreviousYouTubeVideo() {
        val currentList = if (allYtFeedVideos.isNotEmpty()) allYtFeedVideos else youTubeFeedAdapter.getItems()
        if (currentList.isEmpty()) return
        val curId = currentPlayingYtVideo?.id
        val curIdx = currentList.indexOfFirst { it.id == curId }
        val prevIdx = if (curIdx > 0) curIdx - 1 else currentList.size - 1
        val prevVideo = currentList[prevIdx]
        playYouTubeVideoInApp(prevVideo)
        // Silent notification removed
    }

    private fun loadMoreYouTubeFeed() {
        if (isYtLoadingMore) return
        isYtLoadingMore = true
        findViewById<ProgressBar?>(R.id.pbYtFeedLoadMore)?.visibility = View.VISIBLE
        YouTubeFeedRepository.loadMoreFeed(currentYtCategory) { moreVideos ->
            findViewById<ProgressBar?>(R.id.pbYtFeedLoadMore)?.visibility = View.GONE
            isYtLoadingMore = false
            if (moreVideos.isNotEmpty()) {
                val current = youTubeFeedSecondaryAdapter.getItems().toMutableList()
                current.addAll(moreVideos)
                youTubeFeedSecondaryAdapter.updateItems(current)
                allYtFeedVideos.addAll(moreVideos)
            }
        }
    }

    private fun showYouTubeFullHistoryDialog() {
        val history = YouTubeHistoryManager.getWatchHistory(this)
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_media_queue, null)
        dialog.setContentView(view)
        view.findViewById<TextView>(R.id.tvQueueHeaderTitle)?.text = "Watch History (${history.size})"
        val btnClear = view.findViewById<View>(R.id.btnQueueClear)
        btnClear?.visibility = View.VISIBLE
        btnClear?.setOnClickListener {
            YouTubeHistoryManager.clearHistory(this)
            updateYouTabUI()
            dialog.dismiss()
            CleanToast.show(this, "Watch history cleared")
        }
        val rv = view.findViewById<RecyclerView>(R.id.rvQueueList)
        rv?.layoutManager = LinearLayoutManager(this)
        val adapter = YouTubeHistoryAdapter(this, history) { video ->
            dialog.dismiss()
            playYouTubeVideoInApp(video)
        }
        adapter.onMoreClick = { video, _ ->
            showHistoryVideoOptionsMenu(video) {
                val updated = YouTubeHistoryManager.getWatchHistory(this)
                adapter.updateItems(updated)
                view.findViewById<TextView>(R.id.tvQueueHeaderTitle)?.text = "Watch History (${updated.size})"
                updateYouTabUI()
            }
        }
        rv?.adapter = adapter
        dialog.show()
    }

    private fun showYouTubeFullDownloadsDialog() {
        val actualDownloads = YouTubeDownloaderHelper.getDownloadedVideos(this)
        val bookmarks = YouTubeHistoryManager.getBookmarks(this)
        val combined = (actualDownloads + bookmarks).distinctBy { it.id }.toMutableList()

        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_media_queue, null)
        dialog.setContentView(view)
        view.findViewById<TextView>(R.id.tvQueueHeaderTitle)?.text = "Downloads & Library (${combined.size})"
        view.findViewById<View>(R.id.btnQueueClear)?.visibility = View.GONE
        val rv = view.findViewById<RecyclerView>(R.id.rvQueueList)
        rv?.layoutManager = LinearLayoutManager(this)
        val adapter = YouTubeHistoryAdapter(this, combined) { video ->
            dialog.dismiss()
            playYouTubeVideoInApp(video)
        }
        adapter.onMoreClick = { video, _ ->
            showDownloadedVideoOptionsMenu(video) {
                val updatedActual = YouTubeDownloaderHelper.getDownloadedVideos(this)
                val updatedBookmarks = YouTubeHistoryManager.getBookmarks(this)
                val updated = (updatedActual + updatedBookmarks).distinctBy { it.id }
                adapter.updateItems(updated)
                view.findViewById<TextView>(R.id.tvQueueHeaderTitle)?.text = "Downloads & Library (${updated.size})"
                updateYouTabUI()
            }
        }
        rv?.adapter = adapter
        dialog.show()
    }

    private fun showDownloadedVideoOptionsMenu(video: YouTubeVideo, onActionCompleted: () -> Unit) {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val density = resources.displayMetrics.density

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (24 * density).toInt())
            setBackgroundColor(Color.parseColor("#1C1C1E"))
        }

        val tvTitle = TextView(this).apply {
            text = video.title
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val tvSub = TextView(this).apply {
            text = "${video.channelTitle} • ${video.views}"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f
            setPadding(0, (4 * density).toInt(), 0, (14 * density).toInt())
        }
        sheet.addView(tvTitle)
        sheet.addView(tvSub)

        val div = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply {
                bottomMargin = (8 * density).toInt()
            }
            setBackgroundColor(Color.parseColor("#333333"))
        }
        sheet.addView(div)

        fun createOptionRow(iconRes: Int, text: String, textColor: Int = Color.WHITE, onClick: () -> Unit): View {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((8 * density).toInt(), (14 * density).toInt(), (8 * density).toInt(), (14 * density).toInt())
                background = android.util.TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                    androidx.core.content.ContextCompat.getDrawable(this@MainActivity, tv.resourceId)
                }
                setOnClickListener {
                    dialog.dismiss()
                    onClick()
                }
            }
            val iv = ImageView(this).apply {
                val s = (24 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(s, s)
                setImageResource(iconRes)
                setColorFilter(textColor)
            }
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    marginStart = (16 * density).toInt()
                }
                this.text = text
                setTextColor(textColor)
                textSize = 14f
                setTypeface(null, Typeface.BOLD)
            }
            row.addView(iv)
            row.addView(tv)
            return row
        }

        sheet.addView(createOptionRow(R.drawable.ic_play_player, "Play in CleanPlayer") {
            playYouTubeVideoInApp(video)
        })

        sheet.addView(createOptionRow(R.drawable.ic_share, "Share (File or Link)") {
            shareDownloadedVideo(video)
        })

        sheet.addView(createOptionRow(R.drawable.ic_share_transfer, "Send via WebShare / FastShare") {
            val downloadedFile = YouTubeDownloaderHelper.findDownloadedFile(video.title, video.id)
                ?: if (video.id.startsWith("/")) java.io.File(video.id).takeIf { it.exists() } else null
            if (downloadedFile != null && downloadedFile.exists()) {
                showWebShareDialog(listOf(downloadedFile.absolutePath))
            } else {
                shareDownloadedVideo(video)
            }
        })

        sheet.addView(createOptionRow(R.drawable.ic_close, "Delete from Downloads", Color.parseColor("#FF5252")) {
            deleteDownloadedVideo(video, onActionCompleted)
        })

        dialog.setContentView(sheet)
        dialog.show()
    }

    private fun shareDownloadedVideo(video: YouTubeVideo) {
        val downloadedFile = YouTubeDownloaderHelper.findDownloadedFile(video.title, video.id)
            ?: if (video.id.startsWith("/")) java.io.File(video.id).takeIf { it.exists() } else null

        if (downloadedFile != null && downloadedFile.exists()) {
            try {
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    this,
                    "${packageName}.provider",
                    downloadedFile
                )
                val isAudio = downloadedFile.extension.lowercase() in listOf("m4a", "mp3")
                val mime = if (isAudio) "audio/*" else "video/*"
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, video.title)
                    putExtra(Intent.EXTRA_TEXT, "Shared from CleanPlayer: ${video.title}")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(shareIntent, "Share Video File"))
                return
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val rawId = video.id.substringAfterLast("/").substringBeforeLast(".")
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, video.title)
            putExtra(Intent.EXTRA_TEXT, "Watch '${video.title}' on CleanPlayer: https://youtu.be/$rawId")
        }
        startActivity(Intent.createChooser(shareIntent, "Share Video"))
    }

    private fun deleteDownloadedVideo(video: YouTubeVideo, onDeleted: () -> Unit) {
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Delete Download")
            .setMessage("Delete '${video.title}' from your device downloads?")
            .setPositiveButton("Delete") { _, _ ->
                YouTubeDownloaderHelper.deleteDownloadedVideo(this, video)
                val bookmarks = YouTubeHistoryManager.getBookmarks(this).toMutableList()
                val foundBookmark = bookmarks.find { it.id == video.id || it.title.equals(video.title, true) }
                if (foundBookmark != null) {
                    YouTubeHistoryManager.toggleBookmark(this, foundBookmark)
                }
                updateYouTabUI()
                onDeleted()
                CleanToast.show(this, "Deleted from Downloads")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showHistoryVideoOptionsMenu(video: YouTubeVideo, onActionCompleted: () -> Unit) {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val density = resources.displayMetrics.density

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * density).toInt(), (16 * density).toInt(), (16 * density).toInt(), (24 * density).toInt())
            setBackgroundColor(Color.parseColor("#1C1C1E"))
        }

        val tvTitle = TextView(this).apply {
            text = video.title
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val tvSub = TextView(this).apply {
            text = "${video.channelTitle} • ${video.duration}"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f
            setPadding(0, (4 * density).toInt(), 0, (14 * density).toInt())
        }
        sheet.addView(tvTitle)
        sheet.addView(tvSub)

        val div = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply {
                bottomMargin = (8 * density).toInt()
            }
            setBackgroundColor(Color.parseColor("#333333"))
        }
        sheet.addView(div)

        fun createOptionRow(iconRes: Int, text: String, textColor: Int = Color.WHITE, onClick: () -> Unit): View {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((8 * density).toInt(), (14 * density).toInt(), (8 * density).toInt(), (14 * density).toInt())
                background = android.util.TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                    androidx.core.content.ContextCompat.getDrawable(this@MainActivity, tv.resourceId)
                }
                setOnClickListener {
                    dialog.dismiss()
                    onClick()
                }
            }
            val iv = ImageView(this).apply {
                val s = (24 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(s, s)
                setImageResource(iconRes)
                setColorFilter(textColor)
            }
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    marginStart = (16 * density).toInt()
                }
                this.text = text
                setTextColor(textColor)
                textSize = 14f
                setTypeface(null, Typeface.BOLD)
            }
            row.addView(iv)
            row.addView(tv)
            return row
        }

        sheet.addView(createOptionRow(R.drawable.ic_play_player, "Play Video") {
            playYouTubeVideoInApp(video)
        })

        sheet.addView(createOptionRow(R.drawable.ic_download, "Download Video") {
            YouTubeDownloaderHelper.downloadVideo(this, video)
        })

        sheet.addView(createOptionRow(R.drawable.ic_share, "Share Link") {
            val rawId = video.id.substringAfterLast("/").substringBeforeLast(".")
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, video.title)
                putExtra(Intent.EXTRA_TEXT, "Watch '${video.title}' on CleanPlayer: https://youtu.be/$rawId")
            }
            startActivity(Intent.createChooser(shareIntent, "Share Video"))
        })

        sheet.addView(createOptionRow(R.drawable.ic_close, "Remove from Watch History", Color.parseColor("#FF5252")) {
            val history = YouTubeHistoryManager.getWatchHistory(this).toMutableList()
            history.removeAll { it.id == video.id }
            val prefs = getSharedPreferences("yt_watch_history_prefs", Context.MODE_PRIVATE)
            val jsonArray = org.json.JSONArray()
            for (item in history) {
                val obj = org.json.JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("channelTitle", item.channelTitle)
                    put("thumbnailUrl", item.thumbnailUrl)
                    put("duration", item.duration)
                    put("views", item.views)
                    put("uploadDate", item.uploadDate)
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString("watch_history_json", jsonArray.toString()).apply()
            updateYouTabUI()
            onActionCompleted()
            CleanToast.show(this, "Removed from Watch History")
        })

        dialog.setContentView(sheet)
        dialog.show()
    }


    private fun scheduleOverlayHide(delayMs: Long = 3000L) {
        ytOverlayHandler.removeCallbacks(ytOverlayHideRunnable)
        if (YouTubeExoPlayerManager.isPlaying()) {
            ytOverlayHandler.postDelayed(ytOverlayHideRunnable, delayMs)
        }
    }

    private fun showAudioTrackSelectionDialog() {
        val tracks = YouTubeExoPlayerManager.getAvailableAudioTracks()
        if (tracks.isEmpty()) {
            // Toast removed per user request (unnecessary)
            return
        }
        val labels = tracks.map { if (it.isSelected) "✓  " + it.label else "    " + it.label }.toTypedArray()
        val selectedIdx = tracks.indexOfFirst { it.isSelected }.coerceAtLeast(0)

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Audio Language / Multi-Tracks")
            .setSingleChoiceItems(labels, selectedIdx) { dialog, which ->
                val chosen = tracks[which]
                YouTubeExoPlayerManager.selectAudioTrackByIndex(this, which, chosen)
                getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
                    .edit()
                    .putString("pref_yt_audio_track_lang", chosen.language ?: "hi")
                    .apply()
                CleanToast.show(this, "Audio Language: " + chosen.label.replace("✓", "").trim())
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showYouTubeSubtitleDialog() {
        val tracks = YouTubeExoPlayerManager.getAvailableSubtitleTracks()
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()

        if (tracks.isEmpty()) {
            options.add("No subtitles available for this video")
            actions.add { }
        } else {
            val hasSelected = tracks.any { it.isSelected }
            options.add(if (!hasSelected) "Turn Off Subtitles ✓" else "Turn Off Subtitles")
            actions.add {
                YouTubeExoPlayerManager.selectSubtitleTrack(null)
                btnYtPlayerCC.setColorFilter(Color.WHITE)
            }

            for (track in tracks) {
                val mark = if (track.isSelected) " ✓" else ""
                options.add("${track.label}$mark")
                actions.add {
                    YouTubeExoPlayerManager.selectSubtitleTrack(track)
                    btnYtPlayerCC.setColorFilter(Color.parseColor("#3EA6FF"))
                }
            }
        }

        options.add("⚙ Subtitle Styling & Customization...")
        actions.add { showSubtitleSettings() }

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Captions & Subtitles")
            .setItems(options.toTypedArray()) { dialog, which ->
                if (which in actions.indices) {
                    actions[which].invoke()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCastDevicesDialog() {
        try {
            val intent = Intent("android.settings.CAST_SETTINGS").apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(intent)
            } catch (e2: Exception) {
                CleanToast.show(this, "Wireless Display & Cast settings not supported on this device.")
            }
        }
    }

    private fun showNotificationsDialog() {
        val notifications = arrayOf(
            "🔔 New video uploaded from Arijit Singh",
            "🔔 Trending: Romantic Bollywood Mashup 2026",
            "🔔 CleanPlayer v3.9.2 Active & Ad-Free",
            "🔔 Offline downloads ready for background play"
        )
        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Notifications")
            .setItems(notifications) { d, which ->
                // Unwanted popup removed
                d.dismiss()
            }
            .setPositiveButton("Clear All", null)
            .setNegativeButton("Close", null)
            .show()
    }

    private fun loadSubscriptionsFeed() {
        if (layoutYtPlayerDetail.visibility == View.VISIBLE) {
            collapseYouTubePlayer()
        }
        findViewById<View>(R.id.layoutYtYouContainer)?.visibility = View.GONE
        findViewById<View>(R.id.layoutYtMainFeed)?.visibility = View.VISIBLE
        val allChips = listOf(chipYtAll, chipYtMusic, chipYtGaming, chipYtPodcasts, chipYtLive, chipYtTrending, chipYtNews)
        for (chip in allChips) {
            chip.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
            chip.setTextColor(Color.WHITE)
            chip.setTypeface(null, android.graphics.Typeface.NORMAL)
        }
        chipYtTrending.setBackgroundResource(R.drawable.bg_youtube_chip_active)
        chipYtTrending.setTextColor(Color.BLACK)
        chipYtTrending.setTypeface(null, android.graphics.Typeface.BOLD)
        currentYtCategory = "Subscriptions_Internal"

        val hsvSubscribedChannels = findViewById<HorizontalScrollView>(R.id.hsvSubscribedChannels)
        val layoutSubscribedChannelsRow = findViewById<LinearLayout>(R.id.layoutSubscribedChannelsRow)
        val layoutYtSubsDiscovery = findViewById<LinearLayout>(R.id.layoutYtSubsDiscovery)
        val density = resources.displayMetrics.density

        val subs = YouTubeSubscriptionManager.getSubscriptions(this)
        if (subs.isEmpty()) {
            layoutYtSubsDiscovery?.visibility = View.VISIBLE
            hsvSubscribedChannels?.visibility = View.GONE
            youTubeFeedAdapter.updateItems(emptyList())
            pbYtFeedLoading.visibility = View.GONE
            layoutYtEmpty.visibility = View.GONE
        } else {
            layoutYtSubsDiscovery?.visibility = View.GONE
            hsvSubscribedChannels?.visibility = View.VISIBLE
            layoutSubscribedChannelsRow?.removeAllViews()

            val allPill = TextView(this).apply {
                text = "All Channels"
                setTextColor(Color.WHITE)
                textSize = 12f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setBackgroundResource(R.drawable.bg_youtube_action_pill)
                setPadding((12 * density).toInt(), (6 * density).toInt(), (12 * density).toInt(), (6 * density).toInt())
                setOnClickListener { loadSubscriptionsFeed() }
            }
            layoutSubscribedChannelsRow?.addView(allPill)

            for (ch in subs) {
                val chView = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = android.view.Gravity.CENTER_HORIZONTAL
                    setPadding((8 * density).toInt(), 0, (8 * density).toInt(), 0)
                    setOnClickListener {
                        openYouTubeChannelPage(ch.title, ch.avatarUrl)
                    }
                }
                val iv = ImageView(this).apply {
                    val s = (44 * density).toInt()
                    layoutParams = LinearLayout.LayoutParams(s, s)
                    setImageResource(R.drawable.ic_account_circle)
                }
                ImageLoaderHelper.loadImage(ch.avatarUrl, iv, R.drawable.ic_account_circle)
                val tv = TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams((56 * density).toInt(), LinearLayout.LayoutParams.WRAP_CONTENT)
                    text = ch.title
                    setTextColor(Color.parseColor("#DDDDDD"))
                    textSize = 10f
                    gravity = android.view.Gravity.CENTER_HORIZONTAL
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
                chView.addView(iv)
                chView.addView(tv)
                layoutSubscribedChannelsRow?.addView(chView)
            }
            pbYtFeedLoading.visibility = View.VISIBLE
            layoutYtEmpty.visibility = View.GONE
            YouTubeSubscriptionManager.fetchSubscriptionsFeed(this) { subsVideos ->
                runOnUiThread {
                    pbYtFeedLoading.visibility = View.GONE
                    if (subsVideos.isNotEmpty()) {
                        allYtFeedVideos.clear()
                        allYtFeedVideos.addAll(subsVideos)
                        youTubeFeedAdapter.updateItems(subsVideos)
                        layoutYtEmpty.visibility = View.GONE
                    } else {
                        layoutYtEmpty.visibility = View.GONE
                    }
                }
            }
        }
    }

    private fun showListeningControlsBottomSheet() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val density = resources.displayMetrics.density

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (20 * density).toInt())
            setBackgroundColor(Color.parseColor("#1C1C1E"))
        }

        val headerRow = RelativeLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = (10 * density).toInt()
            }
        }
        val tvHead = TextView(this).apply {
            text = "🎧 Listening Controls & Audio Suite"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
        }
        val btnClose = ImageButton(this).apply {
            val s = (28 * density).toInt()
            layoutParams = RelativeLayout.LayoutParams(s, s).apply {
                addRule(RelativeLayout.ALIGN_PARENT_END)
                addRule(RelativeLayout.CENTER_VERTICAL)
            }
            setBackgroundResource(android.R.color.transparent)
            setImageResource(R.drawable.ic_close)
            setColorFilter(Color.WHITE)
            setOnClickListener { dialog.dismiss() }
        }
        headerRow.addView(tvHead)
        headerRow.addView(btnClose)
        sheet.addView(headerRow)

        val div = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply {
                bottomMargin = (10 * density).toInt()
            }
            setBackgroundColor(Color.parseColor("#333333"))
        }
        sheet.addView(div)

        fun createControlRow(title: String, subtitle: String, iconRes: Int, onClick: () -> Unit): View {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding((8 * density).toInt(), (12 * density).toInt(), (8 * density).toInt(), (12 * density).toInt())
                background = android.util.TypedValue().let { tv ->
                    theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
                    androidx.core.content.ContextCompat.getDrawable(this@MainActivity, tv.resourceId)
                }
                setOnClickListener { onClick() }
            }
            val iv = ImageView(this).apply {
                val s = (24 * density).toInt()
                layoutParams = LinearLayout.LayoutParams(s, s)
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }
            val textLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = (14 * density).toInt()
                }
            }
            val tvT = TextView(this).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 14f
                setTypeface(null, Typeface.BOLD)
            }
            val tvS = TextView(this).apply {
                text = subtitle
                setTextColor(Color.parseColor("#8E8E93"))
                textSize = 12f
                setPadding(0, (2 * density).toInt(), 0, 0)
            }
            textLayout.addView(tvT)
            textLayout.addView(tvS)
            row.addView(iv)
            row.addView(textLayout)
            return row
        }

        val dialogueSubtitle = if (PlayerHolder.isDialogueBoostEnabled) "Active (+8dB Speech Normalization)" else "Disabled (Standard Audio)"
        sheet.addView(createControlRow("🗣️ Dialogue Booster & Night Mode", dialogueSubtitle, R.drawable.ic_equalizer) {
            PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
            PlayerHolder.applyAudioEffects(YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0)
            val msg = if (PlayerHolder.isDialogueBoostEnabled) "Dialogue Boost Enabled (+8dB Clarity)" else "Dialogue Boost Disabled"
            CleanToast.show(this, msg)
            dialog.dismiss()
        })

        val currentSpeed = YouTubeExoPlayerManager.exoPlayer?.playbackParameters?.speed ?: 1.0f
        sheet.addView(createControlRow("⚡ Playback Speed (${currentSpeed}x)", "Natural Voice Pitch Lock enabled", R.drawable.ic_speed) {
            dialog.dismiss()
            showPlaybackSpeedDialog()
        })

        val isAudio = YouTubeExoPlayerManager.isAudioOnlyMode
        val audioModeText = if (isAudio) "Active (Audio-Only Data Saver)" else "Video Mode (Streaming Video + Audio)"
        sheet.addView(createControlRow("🎧 Audio / Video Mode", audioModeText, R.drawable.ic_audio) {
            val isNowAudioOnly = YouTubeExoPlayerManager.toggleAudioVideoMode(this)
            updateAudioModeUI(isNowAudioOnly)
            dialog.dismiss()
        })

        sheet.addView(createControlRow("🎛️ 10-Band Equalizer Presets", "Dolby, Bass Boost & Spatial Suite", R.drawable.ic_equalizer) {
            dialog.dismiss()
            val presets = arrayOf("Flat", "Rock", "Pop", "Jazz", "Classical", "Hip Hop", "Dance", "Vocal Booster", "Bass Dynamic")
            val pIdx = PlayerHolder.currentEqualizerPreset.coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
                .setTitle("Equalizer Presets")
                .setSingleChoiceItems(presets, pIdx) { d, which ->
                    PlayerHolder.currentEqualizerPreset = which
                    PlayerHolder.applyAudioEffects(YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0)
                    // Toast removed per user request (unnecessary)
                    d.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        })

        dialog.setContentView(sheet)
        dialog.show()
    }

    private fun showCommentsBottomSheet(video: YouTubeVideo) {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val density = resources.displayMetrics.density

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (20 * density).toInt())
            setBackgroundColor(Color.parseColor("#1C1C1E"))
        }

        // Header Row with count and close button
        val headerRow = RelativeLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = (10 * density).toInt()
            }
        }
        val tvHead = TextView(this).apply {
            text = "Comments • ${if (video.commentsCount.isNotBlank()) video.commentsCount else "Live"}"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
        }
        val btnClose = ImageButton(this).apply {
            val s = (28 * density).toInt()
            layoutParams = RelativeLayout.LayoutParams(s, s).apply {
                addRule(RelativeLayout.ALIGN_PARENT_END)
                addRule(RelativeLayout.CENTER_VERTICAL)
            }
            setBackgroundResource(android.R.color.transparent)
            setImageResource(R.drawable.ic_close)
            setColorFilter(Color.WHITE)
            setOnClickListener { dialog.dismiss() }
        }
        headerRow.addView(tvHead)
        headerRow.addView(btnClose)
        sheet.addView(headerRow)

        val div = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1).apply {
                bottomMargin = (10 * density).toInt()
            }
            setBackgroundColor(Color.parseColor("#333333"))
        }
        sheet.addView(div)

        val pbLoading = ProgressBar(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                topMargin = (24 * density).toInt()
                bottomMargin = (24 * density).toInt()
            }
            visibility = View.VISIBLE
        }
        sheet.addView(pbLoading)

        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (340 * density).toInt())
            isVerticalScrollBarEnabled = true
        }
        val commentsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scrollView.addView(commentsContainer)
        sheet.addView(scrollView)

        YouTubeFeedRepository.getComments(video.id) { comments ->
            runOnUiThread {
                pbLoading.visibility = View.GONE
                if (comments.isEmpty()) {
                    val tvEmpty = TextView(this).apply {
                        text = "No comments available or comments are turned off for this video."
                        setTextColor(Color.parseColor("#888888"))
                        textSize = 13f
                        gravity = Gravity.CENTER
                        setPadding(0, (40 * density).toInt(), 0, (40 * density).toInt())
                    }
                    commentsContainer.addView(tvEmpty)
                } else {
                    for (c in comments) {
                        val commentRow = LinearLayout(this).apply {
                            orientation = LinearLayout.HORIZONTAL
                            setPadding(0, (8 * density).toInt(), 0, (12 * density).toInt())
                        }
                        val ivAvatar = ImageView(this).apply {
                            val s = (32 * density).toInt()
                            layoutParams = LinearLayout.LayoutParams(s, s)
                            setImageResource(R.drawable.ic_account_circle)
                        }
                        ImageLoaderHelper.loadImage(c.authorAvatarUrl, ivAvatar, R.drawable.ic_account_circle)

                        val textLayout = LinearLayout(this).apply {
                            orientation = LinearLayout.VERTICAL
                            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                                marginStart = (10 * density).toInt()
                            }
                        }
                        val tvAuthor = TextView(this).apply {
                            text = if (c.uploadDate.isNotBlank()) "${c.author} • ${c.uploadDate}" else c.author
                            setTextColor(Color.parseColor("#AAAAAA"))
                            textSize = 11.5f
                            setTypeface(null, Typeface.BOLD)
                        }
                        val tvContent = TextView(this).apply {
                            text = c.text
                            setTextColor(Color.parseColor("#EAEAEA"))
                            textSize = 13f
                            setPadding(0, (2 * density).toInt(), 0, (4 * density).toInt())
                        }
                        val tvLikes = TextView(this).apply {
                            text = if (c.likeCount.isNotBlank()) "👍 ${c.likeCount}" else "👍"
                            setTextColor(Color.parseColor("#888888"))
                            textSize = 11f
                        }
                        textLayout.addView(tvAuthor)
                        textLayout.addView(tvContent)
                        textLayout.addView(tvLikes)

                        commentRow.addView(ivAvatar)
                        commentRow.addView(textLayout)
                        commentsContainer.addView(commentRow)
                    }
                }
            }
        }

        dialog.setContentView(sheet)
        dialog.show()
    }

    private fun showPlaybackSpeedDialog() {
        val speeds = arrayOf("0.25x", "0.5x", "0.75x", "1.0x (Normal)", "1.25x", "1.5x", "1.75x", "2.0x")
        val speedValues = floatArrayOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)
        val currentSpeed = YouTubeExoPlayerManager.exoPlayer?.playbackParameters?.speed ?: 1.0f
        val currentIdx = speedValues.indexOfFirst { kotlin.math.abs(it.toDouble() - currentSpeed.toDouble()) < 0.05 }.let { if (it >= 0) it else 3 }

        AlertDialog.Builder(this, R.style.DarkAlertDialogTheme)
            .setTitle("Playback Speed")
            .setSingleChoiceItems(speeds, currentIdx) { dialog, which ->
                val speed = speedValues[which]
                YouTubeExoPlayerManager.setPlaybackSpeed(speed)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


}
