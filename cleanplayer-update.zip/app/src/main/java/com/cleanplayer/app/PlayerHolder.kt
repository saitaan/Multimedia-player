package com.cleanplayer.app

import android.app.Activity
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.lang.ref.WeakReference

import android.content.Context
import android.graphics.Color
import androidx.core.content.ContextCompat
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.ParcelFileDescriptor
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer

object PlayerHolder {
    private const val PREFS_NAME = "multimedia_settings_prefs"

    var libVLC: LibVLC? = null
    var mediaPlayer: MediaPlayer? = null
    var audioExoPlayer: androidx.media3.exoplayer.ExoPlayer? = null
    var currentUri: Uri? = null
    var currentPath: String? = null
    var currentTitle: String = "Media Track"
    var currentArtist: String = "Unknown artist"
    var currentPfd: ParcelFileDescriptor? = null

    // Playlist Queue Management
    val currentPlaylist: MutableList<MediaItem> = mutableListOf()
    var currentTrackIndex: Int = -1
    var isCrossfadeEnabled: Boolean = true
    var crossfadeSeconds: Int = 3
    var isShuffleEnabled: Boolean = false
    var repeatMode: Int = 0 // 0=Off, 1=Repeat One, 2=Repeat All
    private var audioPlayerListener: androidx.media3.common.Player.Listener? = null

    // Listeners for UI sync
    var onTrackChangedListener: ((MediaItem) -> Unit)? = null
    var onPlaybackStateChangedListener: ((Boolean) -> Unit)? = null
    var onAudioSessionIdChangedListener: ((Int) -> Unit)? = null

    // Native Hardware-Accelerated Audio Effects Suite
    var equalizer: Equalizer? = null
    var virtualizer: Virtualizer? = null
    var bassBoost: BassBoost? = null
    var loudnessEnhancer: LoudnessEnhancer? = null

    // Playback Session State
    var isAudioOnly: Boolean = false
    var currentPlaybackSpeed: Float = 1.0f
    var currentAudioDelayMs: Long = 0L
    var currentSpuDelayMs: Long = 0L

    // --- ADVANCED AI SUITE & HARDWARE PROFILER ---
    var isAiKaraokeEnabled: Boolean = false
    var isAiAutoEqEnabled: Boolean = true
    var isAiSilenceTrimmerEnabled: Boolean = true
    var isAiVideoSharpnessEnabled: Boolean = true
    const val PRESET_AUTO_AI = 0
    const val PRESET_CINEMA_4K = 1
    const val PRESET_STUDIO_AUDIO = 2
    const val PRESET_ECO_SAVER = 3
    var aiPresetMode: Int = PRESET_AUTO_AI

    var isAiNeuralSuperResEnabled: Boolean = false
    var isNeuralVocalRemoverEnabled: Boolean = false
    var isWhisperOfflineSpeechEnabled: Boolean = false
    var aiSuperResSharpness: Int = 80
    var aiSuperResMicroContrast: Int = 75
    var aiSuperResScaleFactor: Int = 4
    var aiSuperResDeNoise: Int = 70
    var isAiSmartChaptersEnabled: Boolean = true
    var isAiNightVisionEnabled: Boolean = false
    var isDualLanguageLyricsEnabled: Boolean = true
    var isLyricsEnglishAlphabetDefault: Boolean = true
    var isWordByWordLyricsEnabled: Boolean = true
    var isSpeechToTextAutoEnabled: Boolean = true
    var isAutoEmbedLrcEnabled: Boolean = true
    var lyricsOffsetMs: Long = 0L
    var currentAiDetectedGenre: String = "Balanced Auto"
    var currentDeviceProfileName: String = "Auto-Tuned (Mali-G57 & 64-bit Ready)"

    // --- VIDEO QUALITY & COLOR ENHANCER ---
    var videoColorProfile: Int = 1 // 0=Standard, 1=Vivid AMOLED Boost (Recommended), 2=Cinema HDR, 3=Sharp Studio, 4=Custom
    var videoContrast: Float = 1.15f
    var videoBrightness: Float = 1.05f
    var videoSaturation: Float = 1.25f
    var videoGamma: Float = 1.0f
    var isWideColorGamutEnabled: Boolean = true
    var isDeblockingFilterEnabled: Boolean = true
    var isHighRefreshRateEnabled: Boolean = true // Auto 120Hz / Max Display Refresh Rate
    var defaultOrientation: Int = 1 // 0=Auto Sensor, 1=Direct Landscape (Default), 2=Portrait
    var isAutoScreenOffEnabled: Boolean = true // Auto turn off display when video finished or paused > 3 min
    var autoScreenOffTimeoutMinutes: Int = 3 // 3 min pause timeout

    // --- INTEGRATED DOLBY, SPATIAL & EQUALIZER AUDIO SUITE ---
    var masterAudioProfile: Int = 0 // 0=Cinema, 1=Music, 2=Speech, 3=Pure, 4=Custom
    var dolbySpatialMode: Int = 0 // 0=Stereo (Loud & Pure Default), 1=Dolby 3D, 2=Dolby ProLogic, 3=Cinema 3D
    var isSpatialAudioEnabled: Boolean = false
    var isDolbyAtmosSimulated: Boolean = false
    var currentEqualizerPreset: Int = 0 // 0=Flat / Pure Loud Default
    var visualizerModel: Int = AudioVisualizerView.MODEL_STUDIO_BARS
    var isDialogueBoostEnabled: Boolean = false // Default off for pure uncompressed sound
    var isSleepAtEndOfMedia: Boolean = false // Smart Sleep Timer End of Track
    var isDolbyPassthroughEnabled: Boolean = false
    var audioOutputEngine: Int = 0
    var isHeadsetPauseEnabled: Boolean = true
    var isTimeStretchingEnabled: Boolean = true // Pitch lock

    // --- VIDEO SETTINGS ---
    var hwAccelerationMode: Int = 1 // 0=Disabled, 1=Automatic, 2=Decoding Only, 3=Full Acceleration
    var isHardwareDecoding: Boolean
        get() = hwAccelerationMode != 0
        set(value) { hwAccelerationMode = if (value) 1 else 0 }
    var backgroundPipMode: Int = 1 // 0=Stop, 1=Background Play, 2=Picture-in-Picture
    var isBackgroundPlayEnabled: Boolean
        get() = backgroundPipMode == 1
        set(value) { backgroundPipMode = if (value) 1 else 0 }
    var isBackgroundAudio: Boolean
        get() = backgroundPipMode > 0
        set(value) { backgroundPipMode = if (value) 1 else 0 }
    var resumeMode: Int = 1 // 0=Never, 1=Ask, 2=Always
    var doubleTapSeekSeconds: Int = 10 // 5, 10, 20, 30
    var defaultAspectRatio: Int = 0 // 0=Best Fit, 1=Fit Screen, 2=Fill Screen, 3=16:9, 4=4:3
    var isAudioBoostEnabled: Boolean = true // Up to 200% volume

    // --- SUBTITLE SETTINGS ---
    var isSubAutoloadEnabled: Boolean = true
    var subFontSize: String = "18"
    var subFontColor: String = "16777215"
    var subBackgroundStyle: Int = 0
    var subFontStyle: Int = 1
    var subEncoding: String = "UTF-8"
    var subPosition: Int = 0 // 0=Bottom, 1=Elevated, 2=Center

    // --- SUBTITLE ADVANCED SETTINGS (Matching Standard Settings) ---
    var isPlaybackHistoryEnabled: Boolean = true
    var isVideoQueueHistoryEnabled: Boolean = true
    var isAudioQueueHistoryEnabled: Boolean = true
    var subPreferredLanguage: String = "No language preference"
    var isSubBold: Boolean = false
    var subFontOpacity: Int = 100
    var isSubBackgroundEnabled: Boolean = false
    var subBackgroundColor: String = "0"
    var subBackgroundOpacity: Int = 60
    var isSubShadowEnabled: Boolean = true
    var subShadowColor: String = "0"
    var subShadowOpacity: Int = 80
    var isSubOutlineEnabled: Boolean = true
    var subOutlineSize: Int = 1 // 0=Thin, 1=Normal, 2=Thick
    var subOutlineColor: String = "0"
    var subOutlineOpacity: Int = 100


    // --- GESTURES & CONTROLS ---
    var isVolumeGestureEnabled: Boolean = true
    var isBrightnessGestureEnabled: Boolean = true
    var isSeekGestureEnabled: Boolean = true
    var isFastSeekEnabled: Boolean = true

    // --- SPONSORBLOCK SETTINGS ---
    var isSponsorBlockEnabled: Boolean = true
    var isSponsorSkipSponsor: Boolean = true
    var isSponsorSkipIntro: Boolean = true
    var isSponsorSkipOutro: Boolean = true
    var isSponsorSkipSelfPromo: Boolean = true
    var isSponsorSkipInteraction: Boolean = true
    var sbSkipSponsor: Boolean
        get() = isSponsorSkipSponsor
        set(v) { isSponsorSkipSponsor = v }
    var sbSkipIntro: Boolean
        get() = isSponsorSkipIntro
        set(v) { isSponsorSkipIntro = v }
    var sbSkipOutro: Boolean
        get() = isSponsorSkipOutro
        set(v) { isSponsorSkipOutro = v }
    var sbSkipPromo: Boolean
        get() = isSponsorSkipSelfPromo
        set(v) { isSponsorSkipSelfPromo = v }
    var sbSkipInteraction: Boolean
        get() = isSponsorSkipInteraction
        set(v) { isSponsorSkipInteraction = v }
    var currentVideoQuality: String = "Auto"

    const val PERF_MODE_ULTRA_FAST = 0
    const val PERF_MODE_BALANCED = 1
    const val PERF_MODE_ECO = 2

    var performanceMode: Int = PERF_MODE_ULTRA_FAST
    var isAiSmartTransitionEnabled: Boolean = true

    // --- INTERFACE & THEMES ---
    const val THEME_OLED: Int = 0
    const val THEME_CHARCOAL: Int = 1
    const val THEME_MONOCHROME: Int = 2
    var appThemeMode: Int = THEME_OLED

    // --- ADVANCED A-B REPEAT ---
    var abRepeatA: Long = -1L
    var abRepeatB: Long = -1L

    fun isMonochrome(): Boolean = appThemeMode == THEME_MONOCHROME

    fun getPrimaryColor(context: Context): Int {
        return if (isMonochrome()) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)
    }

    fun getPrimaryColorInt(): Int {
        return if (isMonochrome()) Color.WHITE else Color.parseColor("#FF8800")
    }

    fun getSecondaryColorInt(): Int {
        return if (isMonochrome()) Color.parseColor("#8E8E93") else Color.parseColor("#9E9E9E")
    }

    fun getNavCheckedColorInt(): Int {
        return if (isMonochrome()) Color.WHITE else Color.parseColor("#FF8800")
    }

    fun getNavUncheckedColorInt(): Int {
        return if (isMonochrome()) Color.parseColor("#8E8E93") else Color.parseColor("#9E9E9E")
    }

    fun getFabBgColorInt(): Int {
        return if (isMonochrome()) Color.WHITE else Color.parseColor("#FF8800")
    }

    fun getFabIconColorInt(): Int {
        return if (isMonochrome()) Color.BLACK else Color.WHITE
    }

    val equalizerPresets = arrayOf(
        "Flat (Off)", "Classical", "Club", "Dance", "Full Bass",
        "Full Treble", "Live", "Party", "Pop", "Rock", "Soft", "Techno", "Vocal"
    )

    val masterProfileNames = arrayOf(
        "Cinema 3D & Dolby (Immersive Movies)",
        "Music & Bass Boost (Concert Hall)",
        "Speech & Dialogue Clarity (Night Mode)",
        "Pure Studio (Flat & Natural)",
        "Custom Configuration"
    )

    val videoProfileNames = arrayOf(
        "Standard / Natural (Original)",
        "Vivid / AMOLED Boost (Vibrant & Punchy)",
        "Cinema / HDR Effect (Deep Contrast)",
        "Sharp & Crisp (Enhanced Details)",
        "Custom Tuning"
    )

    fun applyVideoColorProfile(profileIndex: Int) {
        videoColorProfile = profileIndex
        when (profileIndex) {
            0 -> {
                videoContrast = 1.0f
                videoBrightness = 1.0f
                videoSaturation = 1.0f
                videoGamma = 1.0f
            }
            1 -> {
                videoContrast = 1.15f
                videoBrightness = 1.05f
                videoSaturation = 1.25f
                videoGamma = 1.0f
            }
            2 -> {
                videoContrast = 1.20f
                videoBrightness = 1.02f
                videoSaturation = 1.18f
                videoGamma = 1.08f
            }
            3 -> {
                videoContrast = 1.10f
                videoBrightness = 1.0f
                videoSaturation = 1.10f
                videoGamma = 1.0f
            }
        }
    }

    fun applyMasterProfile(profileIndex: Int) {
        masterAudioProfile = profileIndex
        when (profileIndex) {
            0 -> {
                dolbySpatialMode = 1
                currentEqualizerPreset = 8
                isDialogueBoostEnabled = true
            }
            1 -> {
                dolbySpatialMode = 3
                currentEqualizerPreset = 3
                isDialogueBoostEnabled = false
            }
            2 -> {
                dolbySpatialMode = 2
                currentEqualizerPreset = 11
                isDialogueBoostEnabled = true
            }
            3 -> {
                dolbySpatialMode = 0
                currentEqualizerPreset = -1
                isDialogueBoostEnabled = false
            }
        }
    }

    fun loadPreferences(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        videoColorProfile = prefs.getInt("video_color_profile", 1)
        videoContrast = prefs.getFloat("video_contrast", 1.15f)
        videoBrightness = prefs.getFloat("video_brightness", 1.05f)
        videoSaturation = prefs.getFloat("video_saturation", 1.25f)
        videoGamma = prefs.getFloat("video_gamma", 1.0f)
        isWideColorGamutEnabled = prefs.getBoolean("wide_color_gamut", true)
        isAiNightVisionEnabled = prefs.getBoolean("ai_night_vision", false)
        aiPresetMode = prefs.getInt("ai_preset_mode", PRESET_AUTO_AI)
        isAiNeuralSuperResEnabled = prefs.getBoolean("ai_neural_super_res", false)
        isNeuralVocalRemoverEnabled = prefs.getBoolean("neural_vocal_remover", false)
        isWhisperOfflineSpeechEnabled = prefs.getBoolean("whisper_offline_speech", false)
        aiSuperResSharpness = prefs.getInt("ai_super_res_sharpness", 80)
        aiSuperResMicroContrast = prefs.getInt("ai_super_res_micro_contrast", 75)
        aiSuperResScaleFactor = prefs.getInt("ai_super_res_scale_factor", 4)
        aiSuperResDeNoise = prefs.getInt("ai_super_res_denoise", 70)
        isDeblockingFilterEnabled = prefs.getBoolean("deblocking_filter", true)
        isHighRefreshRateEnabled = prefs.getBoolean("high_refresh_rate", true)
        defaultOrientation = prefs.getInt("default_orientation", 1)
        isAutoScreenOffEnabled = prefs.getBoolean("auto_screen_off_enabled", true)
        autoScreenOffTimeoutMinutes = prefs.getInt("auto_screen_off_timeout_min", 3)

        masterAudioProfile = prefs.getInt("master_audio_profile", 0)
        dolbySpatialMode = prefs.getInt("dolby_spatial_mode", 0)
        currentEqualizerPreset = prefs.getInt("equalizer_preset", 0)
        visualizerModel = prefs.getInt("pref_visualizer_model", AudioVisualizerView.MODEL_STUDIO_BARS)
        isDialogueBoostEnabled = prefs.getBoolean("dialogue_boost", false)
        isDolbyPassthroughEnabled = prefs.getBoolean("dolby_passthrough", false)
        audioOutputEngine = prefs.getInt("audio_output_engine", 0)
        isHeadsetPauseEnabled = prefs.getBoolean("headset_pause", true)
        isTimeStretchingEnabled = prefs.getBoolean("time_stretching", true)

        hwAccelerationMode = prefs.getInt("hw_acceleration_mode", 1)
        backgroundPipMode = prefs.getInt("background_pip_mode", 1)
        resumeMode = prefs.getInt("resume_mode", 1)
        doubleTapSeekSeconds = prefs.getInt("double_tap_seek", 10)
        defaultAspectRatio = prefs.getInt("default_aspect_ratio", 0)
        isAudioBoostEnabled = prefs.getBoolean("audio_boost", true)

        isSubAutoloadEnabled = prefs.getBoolean("sub_autoload", true)
        subFontSize = prefs.getString("sub_font_size", "18") ?: "18"
        subFontColor = prefs.getString("sub_font_color", "16777215") ?: "16777215"
        subBackgroundStyle = prefs.getInt("sub_background_style", 0)
        subFontStyle = prefs.getInt("sub_font_style", 1)
        subEncoding = prefs.getString("sub_encoding", "UTF-8") ?: "UTF-8"
        subPosition = prefs.getInt("sub_position", 0)

        isPlaybackHistoryEnabled = prefs.getBoolean("playback_history", true)
        isVideoQueueHistoryEnabled = prefs.getBoolean("video_queue_history", true)
        isAudioQueueHistoryEnabled = prefs.getBoolean("audio_queue_history", true)
        subPreferredLanguage = prefs.getString("sub_pref_lang", "No language preference") ?: "No language preference"
        isSubBold = prefs.getBoolean("sub_bold", false)
        subFontOpacity = prefs.getInt("sub_font_opacity", 100)
        isSubBackgroundEnabled = prefs.getBoolean("sub_bg_enabled", false)
        subBackgroundColor = prefs.getString("sub_bg_color", "0") ?: "0"
        subBackgroundOpacity = prefs.getInt("sub_bg_opacity", 60)
        isSubShadowEnabled = prefs.getBoolean("sub_shadow_enabled", true)
        subShadowColor = prefs.getString("sub_shadow_color", "0") ?: "0"
        subShadowOpacity = prefs.getInt("sub_shadow_opacity", 80)
        isSubOutlineEnabled = prefs.getBoolean("sub_outline_enabled", true)
        subOutlineSize = prefs.getInt("sub_outline_size", 1)
        subOutlineColor = prefs.getString("sub_outline_color", "0") ?: "0"
        subOutlineOpacity = prefs.getInt("sub_outline_opacity", 100)


        isVolumeGestureEnabled = prefs.getBoolean("gesture_volume", true)
        isBrightnessGestureEnabled = prefs.getBoolean("gesture_brightness", true)
        isSeekGestureEnabled = prefs.getBoolean("gesture_seek", true)
        isFastSeekEnabled = prefs.getBoolean("fast_seek", true)

        appThemeMode = prefs.getInt("app_theme_mode", 0)
        isSponsorBlockEnabled = prefs.getBoolean("sponsorblock_enabled", true)
        isSponsorSkipSponsor = prefs.getBoolean("sponsor_skip_sponsor", true)
        isSponsorSkipIntro = prefs.getBoolean("sponsor_skip_intro", true)
        isSponsorSkipOutro = prefs.getBoolean("sponsor_skip_outro", true)
        isSponsorSkipSelfPromo = prefs.getBoolean("sponsor_skip_selfpromo", true)
        isSponsorSkipInteraction = prefs.getBoolean("sponsor_skip_interaction", true)
        currentVideoQuality = prefs.getString("video_quality", "Auto") ?: "Auto"
        performanceMode = prefs.getInt("pref_performance_mode", PERF_MODE_ULTRA_FAST)
        isAiSmartTransitionEnabled = prefs.getBoolean("pref_ai_smart_transition", true)
    }

    fun savePreferences(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().apply {
            putInt("video_color_profile", videoColorProfile)
            putFloat("video_contrast", videoContrast)
            putFloat("video_brightness", videoBrightness)
            putFloat("video_saturation", videoSaturation)
            putFloat("video_gamma", videoGamma)
            putBoolean("wide_color_gamut", isWideColorGamutEnabled)
            putBoolean("deblocking_filter", isDeblockingFilterEnabled)
            putBoolean("high_refresh_rate", isHighRefreshRateEnabled)
            putBoolean("ai_video_sharpness", isAiVideoSharpnessEnabled)
            putBoolean("ai_smart_chapters", isAiSmartChaptersEnabled)
            putBoolean("ai_night_vision", isAiNightVisionEnabled)
            putInt("ai_preset_mode", aiPresetMode)
            putBoolean("ai_neural_super_res", isAiNeuralSuperResEnabled)
            putBoolean("neural_vocal_remover", isNeuralVocalRemoverEnabled)
            putBoolean("whisper_offline_speech", isWhisperOfflineSpeechEnabled)
            putInt("ai_super_res_sharpness", aiSuperResSharpness)
            putInt("ai_super_res_micro_contrast", aiSuperResMicroContrast)
            putInt("ai_super_res_scale_factor", aiSuperResScaleFactor)
            putInt("ai_super_res_denoise", aiSuperResDeNoise)
            putInt("default_orientation", defaultOrientation)
            putBoolean("auto_screen_off_enabled", isAutoScreenOffEnabled)
            putInt("auto_screen_off_timeout_min", autoScreenOffTimeoutMinutes)

            putInt("master_audio_profile", masterAudioProfile)
            putInt("dolby_spatial_mode", dolbySpatialMode)
            putInt("equalizer_preset", currentEqualizerPreset)
            putInt("pref_visualizer_model", visualizerModel)
            putBoolean("dialogue_boost", isDialogueBoostEnabled)
            putBoolean("dolby_passthrough", isDolbyPassthroughEnabled)
            putInt("audio_output_engine", audioOutputEngine)
            putBoolean("headset_pause", isHeadsetPauseEnabled)
            putBoolean("time_stretching", isTimeStretchingEnabled)

            putInt("hw_acceleration_mode", hwAccelerationMode)
            putInt("background_pip_mode", backgroundPipMode)
            putInt("resume_mode", resumeMode)
            putInt("double_tap_seek", doubleTapSeekSeconds)
            putInt("default_aspect_ratio", defaultAspectRatio)
            putBoolean("audio_boost", isAudioBoostEnabled)

            putBoolean("sub_autoload", isSubAutoloadEnabled)
            putString("sub_font_size", subFontSize)
            putString("sub_font_color", subFontColor)
            putInt("sub_background_style", subBackgroundStyle)
            putInt("sub_font_style", subFontStyle)
            putString("sub_encoding", subEncoding)
            putInt("sub_position", subPosition)

            putBoolean("playback_history", isPlaybackHistoryEnabled)
            putBoolean("video_queue_history", isVideoQueueHistoryEnabled)
            putBoolean("audio_queue_history", isAudioQueueHistoryEnabled)
            putString("sub_pref_lang", subPreferredLanguage)
            putBoolean("sub_bold", isSubBold)
            putInt("sub_font_opacity", subFontOpacity)
            putBoolean("sub_bg_enabled", isSubBackgroundEnabled)
            putString("sub_bg_color", subBackgroundColor)
            putInt("sub_bg_opacity", subBackgroundOpacity)
            putBoolean("sub_shadow_enabled", isSubShadowEnabled)
            putString("sub_shadow_color", subShadowColor)
            putInt("sub_shadow_opacity", subShadowOpacity)
            putBoolean("sub_outline_enabled", isSubOutlineEnabled)
            putInt("sub_outline_size", subOutlineSize)
            putString("sub_outline_color", subOutlineColor)
            putInt("sub_outline_opacity", subOutlineOpacity)


            putBoolean("gesture_volume", isVolumeGestureEnabled)
            putBoolean("gesture_brightness", isBrightnessGestureEnabled)
            putBoolean("gesture_seek", isSeekGestureEnabled)
            putBoolean("fast_seek", isFastSeekEnabled)

            putInt("app_theme_mode", appThemeMode)
        putBoolean("sponsorblock_enabled", isSponsorBlockEnabled)
        putBoolean("sponsor_skip_sponsor", isSponsorSkipSponsor)
        putBoolean("sponsor_skip_intro", isSponsorSkipIntro)
        putBoolean("sponsor_skip_outro", isSponsorSkipOutro)
        putBoolean("sponsor_skip_selfpromo", isSponsorSkipSelfPromo)
        putBoolean("sponsor_skip_interaction", isSponsorSkipInteraction)
        putString("video_quality", currentVideoQuality)
        putInt("pref_performance_mode", performanceMode)
        putBoolean("pref_ai_smart_transition", isAiSmartTransitionEnabled)
            apply()
        }
    }

    fun resetPreferences(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear()
            .putBoolean("lyrics_english_alphabet_default", isLyricsEnglishAlphabetDefault).apply()
        loadPreferences(context)
    }

    fun setPlaylistAndPlay(context: Context, playlist: List<MediaItem>, startIndex: Int) {
        currentPlaylist.clear()
        currentPlaylist.addAll(playlist)
        playTrackAtIndex(context, startIndex)
    }

    fun playTrackAtIndex(context: Context, index: Int, resumeTimeMs: Long = 0L) {
        if (index !in currentPlaylist.indices) return
        try {
            YouTubeExoPlayerManager.pause()
            YouTubeExoPlayerManager.stop()
            YouTubeExoPlayerManager.currentPlayingVideo = null
        } catch (e: Exception) {}
        val oldPath = currentPath
        val curPos = if (isAudioOnly) audioExoPlayer?.currentPosition ?: 0L else mediaPlayer?.time ?: 0L
        val totDur = if (isAudioOnly) audioExoPlayer?.duration ?: 0L else mediaPlayer?.length ?: 0L
        if (!oldPath.isNullOrBlank() && totDur > 0) {
            LocalSmartPlaybackEngine.recordTrackProgress(context, oldPath, curPos, totDur)
        }

        currentTrackIndex = index
        val item = currentPlaylist[index]
        currentUri = item.uri
        currentPath = item.filePath
        currentTitle = item.title
        currentArtist = item.artist ?: "Unknown artist"
        isAudioOnly = !item.isVideo
        LocalSmartPlaybackEngine.recordTrackStarted(context, item.filePath ?: item.uri.toString())

        if (item.isVideo) {
            val player = initPlayer(context, item.uri, item.filePath, isHardwareDecoding, item.title)
            if (resumeTimeMs > 0) {
                player.time = resumeTimeMs
            }
            player.play()
        } else {
            val player = initAudioPlayer(context, item.uri, item.filePath, item.title)
            if (resumeTimeMs > 0) {
                player.seekTo(resumeTimeMs)
            }
            player.play()
            MediaPlaybackService.start(context, currentTitle, currentArtist, isPlaying = true)
        }
        onTrackChangedListener?.invoke(item)
    }

    fun playNext(context: Context): Boolean {
        if (currentPlaylist.isEmpty()) return false
        val nextIdx = if (isShuffleEnabled) {
            LocalSmartPlaybackEngine.getNextSmartTrackIndex(currentPlaylist, currentTrackIndex)
        } else {
            if (currentTrackIndex + 1 < currentPlaylist.size) {
                currentTrackIndex + 1
            } else {
                if (repeatMode == 2) 0 else -1 // Loop back in Repeat All, or stop at queue end
            }
        }

        if (nextIdx in currentPlaylist.indices) {
            playTrackAtIndex(context, nextIdx)
            return true
        }
        return false
    }

    fun playPrevious(context: Context): Boolean {
        if (currentPlaylist.isEmpty()) return false
        val prevIdx = if (currentTrackIndex - 1 >= 0) {
            currentTrackIndex - 1
        } else {
            currentPlaylist.size - 1 // Seamlessly wrap to last track
        }

        if (prevIdx in currentPlaylist.indices) {
            playTrackAtIndex(context, prevIdx)
            return true
        }
        return false
    }

    fun stopPlayback(context: Context) {
        try {
            audioExoPlayer?.let { p ->
                p.stop()
                p.seekTo(0L)
            }
            mediaPlayer?.let { p ->
                p.stop()
                p.time = 0L
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        MediaPlaybackService.stop(context)
        onPlaybackStateChangedListener?.invoke(false)
    }

    fun toggleRepeatMode(): Int {
        repeatMode = when (repeatMode) {
            0 -> 2 // Repeat All
            2 -> 1 // Repeat One
            else -> 0 // Off
        }

        return repeatMode
    }

    fun toggleShuffle(): Boolean {
        isShuffleEnabled = !isShuffleEnabled
        return isShuffleEnabled
    }

    fun resolveMediaTitle(context: Context, uri: Uri, path: String?): String {
        try {
            context.contentResolver.query(
                uri,
                arrayOf(android.provider.MediaStore.MediaColumns.TITLE, android.provider.MediaStore.MediaColumns.DISPLAY_NAME),
                null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val tIdx = cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.TITLE)
                    val nIdx = cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.DISPLAY_NAME)
                    val tVal = if (tIdx != -1) cursor.getString(tIdx) else null
                    val nVal = if (nIdx != -1) cursor.getString(nIdx) else null
                    val candidate = when {
                        !tVal.isNullOrBlank() && !tVal.all { it.isDigit() } -> MediaScanner.cleanMediaTitle(tVal)
                        !nVal.isNullOrBlank() && !nVal.substringBeforeLast('.').all { it.isDigit() } -> MediaScanner.cleanMediaTitle(nVal)
                        !tVal.isNullOrBlank() -> MediaScanner.cleanMediaTitle(tVal)
                        !nVal.isNullOrBlank() -> MediaScanner.cleanMediaTitle(nVal)
                        else -> null
                    }
                    if (!candidate.isNullOrBlank()) return candidate
                }
            }
        } catch (e: Exception) {}

        if (!path.isNullOrBlank()) {
            val f = java.io.File(path)
            if (f.exists() && f.name.isNotBlank()) {
                val fName = f.name
                if (!fName.substringBeforeLast('.').all { it.isDigit() }) {
                    return MediaScanner.cleanMediaTitle(fName)
                }
            }
        }

        val seg = uri.lastPathSegment?.substringAfterLast('/')
        if (!seg.isNullOrBlank() && !seg.all { it.isDigit() }) {
            return MediaScanner.cleanMediaTitle(seg)
        }

        return "Media Track"
    }

    fun initAudioPlayer(context: Context, uri: Uri, path: String?, title: String? = null): androidx.media3.exoplayer.ExoPlayer {
        release()
        currentUri = uri
        currentPath = path

        val resolved = when {
            !title.isNullOrBlank() && !title.all { it.isDigit() } -> title
            !currentTitle.isNullOrBlank() && !currentTitle.all { it.isDigit() } && currentTitle != "Media Track" -> currentTitle
            else -> resolveMediaTitle(context, uri, path)
        }
        currentTitle = resolved
        isAudioOnly = true

        val appContext = context.applicationContext
        val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setUsage(androidx.media3.common.C.USAGE_MEDIA)
            .setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val loadControl = androidx.media3.exoplayer.DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                androidx.media3.exoplayer.DefaultLoadControl.DEFAULT_MIN_BUFFER_MS,
                androidx.media3.exoplayer.DefaultLoadControl.DEFAULT_MAX_BUFFER_MS,
                1000,
                2000
            ).build()

        val renderersFactory = androidx.media3.exoplayer.DefaultRenderersFactory(appContext)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(androidx.media3.exoplayer.DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)

        val player = androidx.media3.exoplayer.ExoPlayer.Builder(appContext, renderersFactory)
            .setAudioAttributes(audioAttributes, true)
            .setLoadControl(loadControl)
            .setHandleAudioBecomingNoisy(true)
            .build()

        val mediaMetadata = androidx.media3.common.MediaMetadata.Builder()
            .setTitle(currentTitle)
            .setArtist(currentArtist)
            .build()

        val mediaItem = androidx.media3.common.MediaItem.Builder()
            .setUri(uri)
            .setMediaMetadata(mediaMetadata)
            .build()

        player.setMediaItem(mediaItem)
        player.prepare()
        player.playbackParameters = androidx.media3.common.PlaybackParameters(currentPlaybackSpeed)

        // Attach native audio effects suite to genuine AudioSessionId
        applyAudioEffects(player.audioSessionId)

        val listener = object : androidx.media3.common.Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId > 0) {
                    applyAudioEffects(audioSessionId)
                    onAudioSessionIdChangedListener?.invoke(audioSessionId)
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                onPlaybackStateChangedListener?.invoke(isPlaying)
                MediaPlaybackService.start(
                    appContext,
                    currentTitle,
                    currentArtist,
                    isPlaying = isPlaying
                )
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    androidx.media3.common.Player.STATE_ENDED -> {
                        if (isSleepAtEndOfMedia) {
                            isSleepAtEndOfMedia = false
                            stopPlayback(appContext)
                            return
                        }
                        if (repeatMode == 1) {
                            player.seekTo(0L)
                            player.play()
                        } else {
                            val hasNext = playNext(appContext)
                            if (!hasNext) {
                                player.seekTo(0L)
                                player.pause()
                                onPlaybackStateChangedListener?.invoke(false)
                                MediaPlaybackService.start(
                                    appContext,
                                    currentTitle,
                                    currentArtist,
                                    isPlaying = false
                                )
                            }
                        }
                    }
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                error.printStackTrace()
                onPlaybackStateChangedListener?.invoke(false)
            }
        }
        player.addListener(listener)
        audioPlayerListener = listener

        audioExoPlayer = player
        return player
    }

    fun initPlayer(context: Context, uri: Uri, path: String?, hwDecode: Boolean, title: String? = null, startTimeMs: Long = 0L): MediaPlayer {
        release()
        currentUri = uri
        currentPath = path

        val resolved = when {
            !title.isNullOrBlank() && !title.all { it.isDigit() } -> title
            !currentTitle.isNullOrBlank() && !currentTitle.all { it.isDigit() } && currentTitle != "Media Track" -> currentTitle
            else -> resolveMediaTitle(context, uri, path)
        }
        currentTitle = resolved

        val options = ArrayList<String>().apply {
            add("--aout=audiotrack")
            add("--no-drop-late-frames")
            add("--no-skip-frames")
            add("--rtsp-tcp")
            add("--audio-time-stretch")
            add("--video-filter=adjust")
            add("--subsdec-encoding=$subEncoding")
            add("--freetype-fontsize=$subFontSize")
            add("--avcodec-fast")
            if (uri.scheme == "http" || uri.scheme == "https") {
                add("--network-caching=3000")
            }
            if (hwDecode) {
                add("--codec=mediacodec_ndk,mediacodec_jni,all")
            } else {
                add("--codec=all")
            }
            add("-v")
        }

        val vlc = LibVLC(context.applicationContext, options)
        libVLC = vlc
        val player = MediaPlayer(vlc)
        mediaPlayer = player

        val file = if (!path.isNullOrBlank()) java.io.File(path) else null
        val media = if (file != null && file.exists() && file.canRead()) {
            Media(vlc, file.absolutePath)
        } else {
            var pfd: ParcelFileDescriptor? = null
            if (uri.scheme != "http" && uri.scheme != "https") {
                try {
                    pfd = context.contentResolver.openFileDescriptor(uri, "r")
                    currentPfd = pfd
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            if (pfd != null) {
                Media(vlc, pfd.fileDescriptor)
            } else {
                Media(vlc, uri)
            }
        }

        if (startTimeMs > 0L) {
            val startSec = (startTimeMs / 1000L).toInt()
            media.addOption(":start-time=$startSec")
        }
        media.addOption(":video-filter=adjust")
        media.setHWDecoderEnabled(hwDecode, false)
        player.media = media
        media.release()

        if (currentAudioDelayMs != 0L) {
            player.setAudioDelay(currentAudioDelayMs * 1000L)
        }
        if (currentSpuDelayMs != 0L) {
            player.setSpuDelay(currentSpuDelayMs * 1000L)
        }
        if (currentPlaybackSpeed != 1.0f) {
            player.rate = currentPlaybackSpeed
        }

        player.setEventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Playing -> {
                    onPlaybackStateChangedListener?.invoke(true)
                }
                MediaPlayer.Event.Paused -> {
                    onPlaybackStateChangedListener?.invoke(false)
                }
                MediaPlayer.Event.EndReached -> {
                    if (isAudioOnly) {
                        if (repeatMode == 1) {
                            player.time = 0L
                            player.play()
                        } else {
                            val hasNext = playNext(context)
                            if (!hasNext) {
                                player.time = 0L
                                player.pause()
                                MediaPlaybackService.start(context, currentTitle, currentArtist, isPlaying = false)
                                onPlaybackStateChangedListener?.invoke(false)
                            }
                        }
                    }
                }
                else -> {}
            }
        }

        try {
            applyAudioEffects()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return player
    }

    fun applyKaraokeToEqualizer(eq: Equalizer) {
        try {
            eq.enabled = true
            val numBands = eq.numberOfBands.toInt()
            val minLevel = eq.bandLevelRange[0]
            val maxLevel = eq.bandLevelRange[1]
            for (i in 0 until numBands) {
                val freq = eq.getCenterFreq(i.toShort()) / 1000
                if (freq in 200..4000) {
                    eq.setBandLevel(i.toShort(), minLevel)
                } else if (freq < 200) {
                    eq.setBandLevel(i.toShort(), (maxLevel * 0.50f).toInt().toShort())
                } else {
                    eq.setBandLevel(i.toShort(), (maxLevel * 0.35f).toInt().toShort())
                }
            }
            virtualizer?.let { virt ->
                virt.enabled = true
                virt.setStrength(1000.toShort())
            }
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }

    fun resetAudioToDefault(context: Context) {
        isAiKaraokeEnabled = false
        isNeuralVocalRemoverEnabled = false
        isDialogueBoostEnabled = false
        isAiAutoEqEnabled = false
        isAiSilenceTrimmerEnabled = false
        isSpatialAudioEnabled = false
        isDolbyAtmosSimulated = false
        dolbySpatialMode = 0
        masterAudioProfile = 0
        currentEqualizerPreset = 0

        try {
            virtualizer?.enabled = false
            virtualizer?.setStrength(0.toShort())
        } catch (t: Throwable) {}

        try {
            bassBoost?.enabled = false
            bassBoost?.setStrength(0.toShort())
        } catch (t: Throwable) {}

        try {
            loudnessEnhancer?.enabled = false
        } catch (t: Throwable) {}

        try {
            equalizer?.let { eq ->
                eq.enabled = false
                if (eq.numberOfPresets > 0) {
                    eq.usePreset(0.toShort())
                }
            }
        } catch (t: Throwable) {}

        try {
            mediaPlayer?.let { vlc ->
                vlc.setEqualizer(null)
                vlc.volume = 100
            }
        } catch (t: Throwable) {}

        try {
            audioExoPlayer?.let { exo ->
                exo.volume = 1.0f
                exo.playbackParameters = androidx.media3.common.PlaybackParameters(1.0f)
            }
        } catch (t: Throwable) {}

        currentPlaybackSpeed = 1.0f

        savePreferences(context)
        applyAudioEffects()
    }

    fun applyAudioEffects(sessionId: Int = 0) {
        val targetSession = if (sessionId > 0) sessionId else (audioExoPlayer?.audioSessionId ?: (YouTubeExoPlayerManager.exoPlayer?.audioSessionId ?: 0))
        if (targetSession > 0) {
            // Isolated try-catches prevent Motorola Dolby Atmos & Moto Spatial Sound conflicts from halting audio pipeline
            try {
                if (equalizer == null || equalizer?.hasControl() != true) {
                    try { equalizer?.release() } catch (e: Exception) {}
                    equalizer = Equalizer(0, targetSession)
                }
                equalizer?.let { eq ->
                    if (isAiKaraokeEnabled) {
                        applyKaraokeToEqualizer(eq)
                    } else {
                        val shouldEnableEq = (currentEqualizerPreset > 0)
                        eq.enabled = shouldEnableEq
                        if (currentEqualizerPreset in 0 until eq.numberOfPresets) {
                            eq.usePreset(currentEqualizerPreset.toShort())
                        }
                    }
                }
            } catch (t: Throwable) {
                equalizer = null
            }

            try {
                val shouldEnableBass = (dolbySpatialMode in 1..3 || currentEqualizerPreset == 3)
                if (bassBoost == null) {
                    try { bassBoost?.release() } catch (e: Exception) {}
                    bassBoost = BassBoost(0, targetSession)
                }
                bassBoost?.let { bb ->
                    bb.enabled = shouldEnableBass
                    if (shouldEnableBass && bb.strengthSupported) {
                        bb.setStrength(500.toShort())
                    } else if (bb.strengthSupported) {
                        bb.setStrength(0.toShort())
                    }
                }
            } catch (t: Throwable) {
                bassBoost = null
            }

            try {
                val shouldEnableVirtualizer = (isSpatialAudioEnabled || dolbySpatialMode != 0)
                if (virtualizer == null) {
                    try { virtualizer?.release() } catch (e: Exception) {}
                    virtualizer = Virtualizer(0, targetSession)
                }
                virtualizer?.let { virt ->
                    virt.enabled = shouldEnableVirtualizer
                    if (shouldEnableVirtualizer && virt.strengthSupported) {
                        virt.setStrength(if (dolbySpatialMode == 3) 1000.toShort() else 500.toShort())
                    } else if (virt.strengthSupported) {
                        virt.setStrength(0.toShort())
                    }
                }
            } catch (t: Throwable) {
                virtualizer = null
            }

            try {
                if (isDialogueBoostEnabled) {
                    if (loudnessEnhancer == null) {
                        try { loudnessEnhancer?.release() } catch (e: Exception) {}
                        loudnessEnhancer = LoudnessEnhancer(targetSession)
                    }
                    loudnessEnhancer?.let { le ->
                        le.setTargetGain(800)
                        le.enabled = true
                    }
                } else {
                    loudnessEnhancer?.enabled = false
                }
            } catch (t: Throwable) {
                loudnessEnhancer = null
            }
        }
        if (mediaPlayer != null && libVLC != null) {
            try {
                if (isAiKaraokeEnabled) {
                    val eq = MediaPlayer.Equalizer.create()
                    eq.setPreAmp(4.0f)
                    eq.setAmp(0, 5.5f)
                    eq.setAmp(1, 3.5f)
                    eq.setAmp(2, -20.0f)
                    eq.setAmp(3, -20.0f)
                    eq.setAmp(4, -20.0f)
                    eq.setAmp(5, -18.0f)
                    eq.setAmp(6, 4.5f)
                    eq.setAmp(7, 5.5f)
                    eq.setAmp(8, 6.0f)
                    eq.setAmp(9, 6.0f)
                    mediaPlayer?.setEqualizer(eq)
                } else if (currentEqualizerPreset > 0 && currentEqualizerPreset in 0 until MediaPlayer.Equalizer.getPresetCount()) {
                    val eq = MediaPlayer.Equalizer.createFromPreset(currentEqualizerPreset)
                    mediaPlayer?.setEqualizer(eq)
                } else {
                    mediaPlayer?.setEqualizer(null)
                }
            } catch (t: Throwable) {
                t.printStackTrace()
            }
        }
    }

    var currentBoostGainMb: Int = 0

    fun setVolumeBoostGain(gainMb: Int) {
        currentBoostGainMb = gainMb.coerceIn(0, 2000)
    }

    fun release() {
        try {
            audioPlayerListener?.let { l ->
                audioExoPlayer?.removeListener(l)
            }
            audioPlayerListener = null
            audioExoPlayer?.let { p ->
                p.stop()
                p.clearMediaItems()
                p.release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            audioExoPlayer = null
        }
        try {
            equalizer?.release()
        } catch (e: Exception) {}
        equalizer = null

        try {
            virtualizer?.release()
        } catch (e: Exception) {}
        virtualizer = null

        try {
            bassBoost?.release()
        } catch (e: Exception) {}
        bassBoost = null

        try {
            loudnessEnhancer?.release()
        } catch (e: Exception) {}
        loudnessEnhancer = null

        mediaPlayer?.let {
            try {
                it.stop()
            } catch (e: Exception) {}
            try {
                val vout = it.vlcVout
                if (vout != null && vout.areViewsAttached()) {
                    it.detachViews()
                }
            } catch (e: Exception) {}
            try {
                it.release()
            } catch (e: Exception) {}
        }
        mediaPlayer = null

        libVLC?.let {
            try {
                it.release()
            } catch (e: Exception) {}
        }
        libVLC = null

        currentPfd?.let {
            try {
                it.close()
            } catch (e: Exception) {}
        }
        currentPfd = null
    }

    fun applyAiPreset(mode: Int, context: Context) {
        aiPresetMode = mode
        when (mode) {
            PRESET_AUTO_AI -> {
                HardwareProfilerEngine.applyAutoSetup(context, true)
                isAiVideoSharpnessEnabled = true
                isAiKaraokeEnabled = false
                isAiAutoEqEnabled = false
                isDialogueBoostEnabled = false
                dolbySpatialMode = 0
                isLyricsEnglishAlphabetDefault = true
                isAiSmartChaptersEnabled = true
            }
            PRESET_CINEMA_4K -> {
                isAiNeuralSuperResEnabled = true
                isAiVideoSharpnessEnabled = true
                isAiNightVisionEnabled = true
                isDialogueBoostEnabled = true
                videoContrast = 1.25f
                videoSaturation = 1.30f
                videoGamma = 1.08f
                aiSuperResScaleFactor = 4
                aiSuperResSharpness = 90
            }
            PRESET_STUDIO_AUDIO -> {
                isAiKaraokeEnabled = false
                isAiAutoEqEnabled = false
                isDialogueBoostEnabled = false
                dolbySpatialMode = 0
                currentEqualizerPreset = 0
                masterAudioProfile = 0
            }
            PRESET_ECO_SAVER -> {
                isAiNeuralSuperResEnabled = false
                isAiVideoSharpnessEnabled = false
                isAiNightVisionEnabled = false
                performanceMode = PERF_MODE_ECO
                videoContrast = 1.0f
                videoSaturation = 1.0f
            }
        }
        savePreferences(context)
        AiVideoEnhancer.applyEnhancement(context, true)
        AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
        applyAudioEffects()
    }
}

object CleanToast {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentToastViewRef: WeakReference<View>? = null
    private var dismissRunnable: Runnable? = null

    fun show(context: Context?, message: String?, durationMs: Long = 1000L) {
        if (context == null || message.isNullOrBlank()) return

        if (Looper.myLooper() != Looper.getMainLooper()) {
            mainHandler.post { show(context, message, durationMs) }
            return
        }

        val activity = when (context) {
            is Activity -> context
            else -> null
        }

        // If not in an active activity, fallback safely to standard Toast
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            try {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {}
            return
        }

        // Cancel and remove any currently showing custom toast
        dismissCurrent()

        val decorView = activity.window?.decorView as? ViewGroup ?: return
        val density = activity.resources.displayMetrics.density

        // 75% Transparent Background (25% Alpha #12131A with subtle translucent white border)
        val backgroundDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 24f * density
            setColor(Color.argb(64, 18, 19, 26)) // 75% transparent (alpha 64 / 255 = 25% opacity)
            setStroke((1f * density).toInt(), Color.argb(40, 255, 255, 255))
        }

        val textView = TextView(activity).apply {
            text = message
            setTextColor(Color.parseColor("#F5F5F7"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(null, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            val padH = (16 * density).toInt()
            val padV = (8 * density).toInt()
            setPadding(padH, padV, padH, padV)
            background = backgroundDrawable
            elevation = 6f * density
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
        }

        val params = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = (84 * density).toInt() // Positioned neatly above bottom navigation
            val maxMargin = (36 * density).toInt()
            marginStart = maxMargin
            marginEnd = maxMargin
        }

        textView.layoutParams = params

        // Smooth Fade-In Animation (150ms)
        val fadeIn = AlphaAnimation(0f, 1f).apply {
            duration = 150L
            fillAfter = true
        }
        textView.startAnimation(fadeIn)

        decorView.addView(textView)
        currentToastViewRef = WeakReference(textView)

        // Auto-Dismiss after exact 1000ms (1 second) with smooth fade-out (200ms)
        val runnable = Runnable {
            val view = currentToastViewRef?.get()
            if (view != null && decorView.indexOfChild(view) != -1) {
                val fadeOut = AlphaAnimation(1f, 0f).apply {
                    duration = 200L
                    setAnimationListener(object : Animation.AnimationListener {
                        override fun onAnimationStart(a: Animation?) {}
                        override fun onAnimationRepeat(a: Animation?) {}
                        override fun onAnimationEnd(a: Animation?) {
                            decorView.removeView(view)
                        }
                    })
                }
                view.startAnimation(fadeOut)
            }
            currentToastViewRef = null
        }

        dismissRunnable = runnable
        mainHandler.postDelayed(runnable, durationMs)
    }

    fun dismissCurrent() {
        dismissRunnable?.let { mainHandler.removeCallbacks(it) }
        dismissRunnable = null
        val view = currentToastViewRef?.get()
        if (view != null) {
            val parent = view.parent as? ViewGroup
            parent?.removeView(view)
        }
        currentToastViewRef = null
    }
    }

