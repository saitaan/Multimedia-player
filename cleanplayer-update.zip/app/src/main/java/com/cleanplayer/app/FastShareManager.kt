package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.util.concurrent.Executors

object FastShareManager {

    private val queryExecutor = Executors.newSingleThreadExecutor()

    fun loadCategoryItems(
        context: Context,
        category: ShareItemType,
        callback: (List<ShareItem>) -> Unit
    ) {
        queryExecutor.execute {
            val list = mutableListOf<ShareItem>()
            try {
                when (category) {
                    ShareItemType.RECENT -> {
                        list.addAll(queryRecentAggregate(context))
                    }
                    ShareItemType.VIDEO -> {
                        list.addAll(queryVideos(context))
                    }
                    ShareItemType.AUDIO -> {
                        list.addAll(queryAudio(context))
                    }
                    ShareItemType.IMAGE -> {
                        list.addAll(queryImages(context))
                    }
                    ShareItemType.APP -> {
                        val pm = context.packageManager
                        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                        for (app in apps) {
                            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || app.packageName == context.packageName) {
                                val appFile = File(app.sourceDir)
                                if (appFile.exists()) {
                                    val appLabel = pm.getApplicationLabel(app).toString()
                                    list.add(
                                        ShareItem(
                                            id = app.packageName,
                                            name = "$appLabel.apk",
                                            path = app.sourceDir,
                                            size = appFile.length(),
                                            mimeType = "application/vnd.android.package-archive",
                                            type = ShareItemType.APP,
                                            packageName = app.packageName
                                        )
                                    )
                                }
                            }
                        }
                    }
                    ShareItemType.FILE -> {
                        val targetDir = getSaveDirectory(context)
                        if (targetDir.exists()) {
                            targetDir.listFiles()?.forEach { f ->
                                if (f.isFile && !f.name.endsWith(".part")) {
                                    list.add(
                                        ShareItem(
                                            id = f.absolutePath.hashCode().toString(),
                                            name = f.name,
                                            path = f.absolutePath,
                                            size = f.length(),
                                            mimeType = "*/*",
                                            type = ShareItemType.FILE,
                                            dateModified = f.lastModified()
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            android.os.Handler(android.os.Looper.getMainLooper()).post {
                callback(list)
            }
        }
    }

    private fun queryVideos(context: Context, maxCount: Int = 150): List<ShareItem> {
        val result = mutableListOf<ShareItem>()
        try {
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.DATE_MODIFIED
            )
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                "${MediaStore.Video.Media.SIZE} > 0",
                null,
                "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val dataCol = cursor.getColumnIndex(MediaStore.Video.Media.DATA)
                val sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val dateCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_MODIFIED)

                var count = 0
                while (cursor.moveToNext() && count < maxCount) {
                    val path = if (dataCol >= 0) cursor.getString(dataCol) ?: "" else ""
                    val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                    if (path.isEmpty() || size <= 0L) continue

                    val name = if (nameCol >= 0) cursor.getString(nameCol) ?: File(path).name else File(path).name
                    val id = if (idCol >= 0) cursor.getString(idCol) ?: path else path
                    val d = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val durStr = if (d > 0) String.format("%02d:%02d", (d / 1000) / 60, (d / 1000) % 60) else null
                    val dateMod = if (dateCol >= 0) cursor.getLong(dateCol) * 1000L else System.currentTimeMillis()

                    result.add(
                        ShareItem(
                            id = id,
                            name = name,
                            path = path,
                            size = size,
                            mimeType = "video/*",
                            type = ShareItemType.VIDEO,
                            durationStr = durStr,
                            dateModified = dateMod
                        )
                    )
                    count++
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }

    private fun queryAudio(context: Context, maxCount: Int = 150): List<ShareItem> {
        val result = mutableListOf<ShareItem>()
        try {
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATE_MODIFIED
            )
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                "${MediaStore.Audio.Media.SIZE} > 0",
                null,
                "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
                val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                val durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val dateCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_MODIFIED)

                var count = 0
                while (cursor.moveToNext() && count < maxCount) {
                    val path = if (dataCol >= 0) cursor.getString(dataCol) ?: "" else ""
                    val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                    if (path.isEmpty() || size <= 0L) continue

                    val dispName = if (nameCol >= 0) cursor.getString(nameCol) else null
                    val title = if (titleCol >= 0) cursor.getString(titleCol) else null
                    val rawName = dispName?.takeIf { it.isNotBlank() }
                        ?: title?.takeIf { it.isNotBlank() }
                        ?: File(path).name
                    val finalName = if (!rawName.contains(".") && path.contains(".")) {
                        rawName + "." + File(path).extension
                    } else rawName

                    val id = if (idCol >= 0) cursor.getString(idCol) ?: path else path
                    val d = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val durStr = if (d > 0) String.format("%02d:%02d", (d / 1000) / 60, (d / 1000) % 60) else null
                    val dateMod = if (dateCol >= 0) cursor.getLong(dateCol) * 1000L else System.currentTimeMillis()

                    result.add(
                        ShareItem(
                            id = id,
                            name = finalName,
                            path = path,
                            size = size,
                            mimeType = "audio/*",
                            type = ShareItemType.AUDIO,
                            durationStr = durStr,
                            dateModified = dateMod
                        )
                    )
                    count++
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }

    private fun queryImages(context: Context, maxCount: Int = 150): List<ShareItem> {
        val result = mutableListOf<ShareItem>()
        try {
            val projection = arrayOf(
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.DATA,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_MODIFIED
            )
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                "${MediaStore.Images.Media.SIZE} > 0",
                null,
                "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                val dataCol = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
                val sizeCol = cursor.getColumnIndex(MediaStore.Images.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED)

                var count = 0
                while (cursor.moveToNext() && count < maxCount) {
                    val path = if (dataCol >= 0) cursor.getString(dataCol) ?: "" else ""
                    val size = if (sizeCol >= 0) cursor.getLong(sizeCol) else 0L
                    if (path.isEmpty() || size <= 0L) continue

                    val name = if (nameCol >= 0) cursor.getString(nameCol) ?: File(path).name else File(path).name
                    val id = if (idCol >= 0) cursor.getString(idCol) ?: path else path
                    val dateMod = if (dateCol >= 0) cursor.getLong(dateCol) * 1000L else System.currentTimeMillis()

                    result.add(
                        ShareItem(
                            id = id,
                            name = name,
                            path = path,
                            size = size,
                            mimeType = "image/*",
                            type = ShareItemType.IMAGE,
                            dateModified = dateMod
                        )
                    )
                    count++
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }

    private fun queryRecentAggregate(context: Context): List<ShareItem> {
        val merged = mutableListOf<ShareItem>()
        merged.addAll(queryVideos(context, maxCount = 50))
        merged.addAll(queryAudio(context, maxCount = 50))
        merged.addAll(queryImages(context, maxCount = 50))
        merged.sortByDescending { it.dateModified }
        return if (merged.size > 100) merged.subList(0, 100) else merged
    }

    fun startSenderService(context: Context, filePaths: List<String>, isParallel: Boolean) {
        val intent = Intent(context, FastShareService::class.java).apply {
            action = FastShareService.ACTION_START_SENDER
            putStringArrayListExtra("files_to_send", ArrayList(filePaths))
            putExtra("is_parallel", isParallel)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun startReceiverService(context: Context, hostIp: String, port: Int = FastShareService.PORT_DEFAULT) {
        val intent = Intent(context, FastShareService::class.java).apply {
            action = FastShareService.ACTION_START_RECEIVER
            putExtra("host_ip", hostIp)
            putExtra("port", port)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun stopTransferService(context: Context) {
        val intent = Intent(context, FastShareService::class.java).apply {
            action = FastShareService.ACTION_STOP_TRANSFER
        }
        context.startService(intent)
    }

    fun getSaveDirectory(context: Context): File {
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val relPath = prefs.getString("pref_share_save_dir", "Download/CleanPlayer") ?: "Download/CleanPlayer"
        val baseDir = android.os.Environment.getExternalStorageDirectory()
            ?: File(context.applicationContext.getExternalFilesDir(null)?.parentFile?.parentFile?.parentFile?.parentFile ?: File("/storage/emulated/0"), "")
        val dir = File(baseDir, relPath)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun getSaveDirectoryDisplayName(context: Context): String {
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val relPath = prefs.getString("pref_share_save_dir", "Download/CleanPlayer") ?: "Download/CleanPlayer"
        return "Internal Storage/$relPath"
    }

    fun setSaveDirectory(context: Context, relPath: String) {
        val cleanRel = relPath.trim()
            .removePrefix("/")
            .removePrefix("Internal Storage/")
            .removePrefix("storage/emulated/0/")
            .trimStart('/')
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("pref_share_save_dir", cleanRel).apply()
    }
}
