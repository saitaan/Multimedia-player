package com.cleanplayer.app

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.util.concurrent.Executors

object FastShareManager {

    private val queryExecutor = Executors.newSingleThreadExecutor()

    fun loadCategoryItems(
        context: Context,
        category: ShareItemType,
        callback: (List<ShareItem>) -> Unit
    ) {
        queryExecutor.execute {
            val list = mutableListOf<ShareItem>()
            try {
                when (category) {
                    ShareItemType.VIDEO -> {
                        val projection = arrayOf(
                            MediaStore.Video.Media._ID,
                            MediaStore.Video.Media.DISPLAY_NAME,
                            MediaStore.Video.Media.DATA,
                            MediaStore.Video.Media.SIZE,
                            MediaStore.Video.Media.DURATION
                        )
                        context.contentResolver.query(
                            MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                            projection,
                            null,
                            null,
                            "${MediaStore.Video.Media.DATE_MODIFIED} DESC LIMIT 80"
                        )?.use { cursor ->
                            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)

                            while (cursor.moveToNext()) {
                                val d = cursor.getLong(durCol)
                                val durStr = if (d > 0) String.format("%02d:%02d", (d / 1000) / 60, (d / 1000) % 60) else null
                                list.add(
                                    ShareItem(
                                        id = cursor.getString(idCol),
                                        name = cursor.getString(nameCol) ?: "Video",
                                        path = cursor.getString(dataCol) ?: "",
                                        size = cursor.getLong(sizeCol),
                                        mimeType = "video/*",
                                        type = ShareItemType.VIDEO,
                                        durationStr = durStr
                                    )
                                )
                            }
                        }
                    }
                    ShareItemType.AUDIO -> {
                        val projection = arrayOf(
                            MediaStore.Audio.Media._ID,
                            MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.DATA,
                            MediaStore.Audio.Media.SIZE,
                            MediaStore.Audio.Media.DURATION
                        )
                        context.contentResolver.query(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                            projection,
                            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
                            null,
                            "${MediaStore.Audio.Media.DATE_MODIFIED} DESC LIMIT 80"
                        )?.use { cursor ->
                            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                            val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)

                            while (cursor.moveToNext()) {
                                val d = cursor.getLong(durCol)
                                val durStr = if (d > 0) String.format("%02d:%02d", (d / 1000) / 60, (d / 1000) % 60) else null
                                list.add(
                                    ShareItem(
                                        id = cursor.getString(idCol),
                                        name = cursor.getString(nameCol) ?: "Track",
                                        path = cursor.getString(dataCol) ?: "",
                                        size = cursor.getLong(sizeCol),
                                        mimeType = "audio/*",
                                        type = ShareItemType.AUDIO,
                                        durationStr = durStr
                                    )
                                )
                            }
                        }
                    }
                    ShareItemType.IMAGE -> {
                        val projection = arrayOf(
                            MediaStore.Images.Media._ID,
                            MediaStore.Images.Media.DISPLAY_NAME,
                            MediaStore.Images.Media.DATA,
                            MediaStore.Images.Media.SIZE
                        )
                        context.contentResolver.query(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                            projection,
                            null,
                            null,
                            "${MediaStore.Images.Media.DATE_MODIFIED} DESC LIMIT 80"
                        )?.use { cursor ->
                            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                            val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)

                            while (cursor.moveToNext()) {
                                list.add(
                                    ShareItem(
                                        id = cursor.getString(idCol),
                                        name = cursor.getString(nameCol) ?: "Image",
                                        path = cursor.getString(dataCol) ?: "",
                                        size = cursor.getLong(sizeCol),
                                        mimeType = "image/*",
                                        type = ShareItemType.IMAGE
                                    )
                                )
                            }
                        }
                    }
                    ShareItemType.APP -> {
                        val pm = context.packageManager
                        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
                        for (app in apps) {
                            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) == 0 || app.packageName == context.packageName) {
                                val appFile = File(app.sourceDir)
                                if (appFile.exists()) {
                                    val appLabel = pm.getApplicationLabel(app).toString()
                                    list.add(
                                        ShareItem(
                                            id = app.packageName,
                                            name = "$appLabel.apk",
                                            path = app.sourceDir,
                                            size = appFile.length(),
                                            mimeType = "application/vnd.android.package-archive",
                                            type = ShareItemType.APP,
                                            packageName = app.packageName
                                        )
                                    )
                                }
                            }
                        }
                    }
                    ShareItemType.FILE -> {
                        val targetDir = File(context.applicationContext.getExternalFilesDir(null)?.parentFile?.parentFile?.parentFile?.parentFile, "Download/CleanPlayer")
                        if (targetDir.exists()) {
                            targetDir.listFiles()?.forEach { f ->
                                if (f.isFile && !f.name.endsWith(".part")) {
                                    list.add(
                                        ShareItem(
                                            id = f.absolutePath.hashCode().toString(),
                                            name = f.name,
                                            path = f.absolutePath,
                                            size = f.length(),
                                            mimeType = "*/*",
                                            type = ShareItemType.FILE
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            android.os.Handler(android.os.Looper.getMainLooper()).post {
                callback(list)
            }
        }
    }

    fun startSenderService(context: Context, filePaths: List<String>, isParallel: Boolean) {
        val intent = Intent(context, FastShareService::class.java).apply {
            action = FastShareService.ACTION_START_SENDER
            putStringArrayListExtra("files_to_send", ArrayList(filePaths))
            putExtra("is_parallel", isParallel)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun startReceiverService(context: Context, hostIp: String, port: Int = FastShareService.PORT_DEFAULT) {
        val intent = Intent(context, FastShareService::class.java).apply {
            action = FastShareService.ACTION_START_RECEIVER
            putExtra("host_ip", hostIp)
            putExtra("port", port)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    fun stopTransferService(context: Context) {
        val intent = Intent(context, FastShareService::class.java).apply {
            action = FastShareService.ACTION_STOP_TRANSFER
        }
        context.startService(intent)
    }
}
