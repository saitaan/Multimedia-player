package com.cleanplayer.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SubscribedChannel(
    val title: String,
    val handle: String?,
    val avatarUrl: String?,
    val subscribedAt: Long = System.currentTimeMillis()
)

object YouTubeSubscriptionManager {

    private const val PREFS_NAME = "cleanplayer_subscriptions_prefs"
    private const val KEY_SUBSCRIPTIONS = "subscribed_channels_json"

    fun getSubscriptions(context: Context): List<SubscribedChannel> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_SUBSCRIPTIONS, null) ?: return emptyList()
        val list = mutableListOf<SubscribedChannel>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    SubscribedChannel(
                        title = obj.getString("title"),
                        handle = obj.optString("handle", null),
                        avatarUrl = obj.optString("avatarUrl", null),
                        subscribedAt = obj.optLong("subscribedAt", 0L)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun isSubscribed(context: Context, channelTitle: String): Boolean {
        if (channelTitle.isBlank()) return false
        val subs = getSubscriptions(context)
        return subs.any { it.title.trim().equals(channelTitle.trim(), ignoreCase = true) }
    }

    fun subscribe(context: Context, channelTitle: String, channelHandle: String? = null, avatarUrl: String? = null): Boolean {
        if (channelTitle.isBlank()) return false
        val current = getSubscriptions(context).toMutableList()
        val existingIdx = current.indexOfFirst { it.title.trim().equals(channelTitle.trim(), ignoreCase = true) }
        if (existingIdx >= 0) {
            return false // already subscribed
        }
        current.add(0, SubscribedChannel(channelTitle.trim(), channelHandle, avatarUrl))
        saveSubscriptions(context, current)
        return true
    }

    fun unsubscribe(context: Context, channelTitle: String): Boolean {
        if (channelTitle.isBlank()) return false
        val current = getSubscriptions(context).toMutableList()
        val removed = current.removeAll { it.title.trim().equals(channelTitle.trim(), ignoreCase = true) }
        if (removed) {
            saveSubscriptions(context, current)
        }
        return removed
    }

    private fun saveSubscriptions(context: Context, list: List<SubscribedChannel>) {
        val arr = JSONArray()
        for (sub in list) {
            val obj = JSONObject()
            obj.put("title", sub.title)
            obj.put("handle", sub.handle)
            obj.put("avatarUrl", sub.avatarUrl)
            obj.put("subscribedAt", sub.subscribedAt)
            arr.put(obj)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SUBSCRIPTIONS, arr.toString())
            .apply()
    }

    fun importFromCsv(context: Context, csvContent: String): Int {
        var count = 0
        try {
            val lines = csvContent.lines()
            for (line in lines) {
                if (line.isBlank() || line.startsWith("Channel Id", ignoreCase = true) || line.startsWith("channelId", ignoreCase = true)) continue
                val parts = line.split(",")
                val rawTitle = when {
                    parts.size >= 3 -> parts[2].trim()
                    parts.size == 2 -> parts[1].trim()
                    parts.isNotEmpty() -> parts[0].trim()
                    else -> ""
                }
                val title = rawTitle.replace("\"", "")
                val handle = if (parts.size >= 2) parts[1].trim().replace("\"", "") else null
                if (title.isNotBlank()) {
                    if (subscribe(context, title, handle, null)) {
                        count++
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return count
    }

    fun getPopularChannels(): List<SubscribedChannel> {
        return listOf(
            SubscribedChannel("T-Series", "@tseries", "https://i.ytimg.com/vi/jfKfPfyJRdk/mqdefault.jpg"),
            SubscribedChannel("Sony Music India", "@sonymusicindia", "https://i.ytimg.com/vi/kffacxfA7G4/mqdefault.jpg"),
            SubscribedChannel("Zee Music Company", "@zeemusiccompany", "https://i.ytimg.com/vi/kJQP7kiw5Fk/mqdefault.jpg"),
            SubscribedChannel("Aaj Tak", "@aajtak", "https://i.ytimg.com/vi/JGwWNGJdvx8/mqdefault.jpg"),
            SubscribedChannel("CarryMinati", "@carryminati", "https://i.ytimg.com/vi/fJ9rUzIMcZQ/mqdefault.jpg"),
            SubscribedChannel("MrBeast", "@mrbeast", "https://i.ytimg.com/vi/9bZkp7q19f0/mqdefault.jpg"),
            SubscribedChannel("Total Gaming", "@totalgaming", "https://i.ytimg.com/vi/L_LUpnjgPso/mqdefault.jpg"),
            SubscribedChannel("Dhruv Rathee", "@dhruvrathee", "https://i.ytimg.com/vi/RgKAFK5djSk/mqdefault.jpg")
        )
    }

    fun fetchSubscriptionsFeed(context: Context, callback: (List<YouTubeVideo>) -> Unit) {
        val subs = getSubscriptions(context)
        if (subs.isEmpty()) {
            callback(emptyList())
            return
        }

        val allVideos = mutableListOf<YouTubeVideo>()
        val channelsToFetch = subs.take(6)
        var completedCount = 0

        for (ch in channelsToFetch) {
            YouTubeFeedRepository.searchVideos(ch.title) { videos ->
                synchronized(allVideos) {
                    allVideos.addAll(videos.take(5))
                    completedCount++
                    if (completedCount >= channelsToFetch.size) {
                        val distinct = allVideos.distinctBy { it.id }
                        callback(distinct)
                    }
                }
            }
        }
    }
}
