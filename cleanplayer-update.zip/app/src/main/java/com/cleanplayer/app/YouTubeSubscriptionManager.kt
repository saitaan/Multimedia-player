package com.cleanplayer.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SubscribedChannel(
    val title: String,
    val handle: String?,
    val avatarUrl: String?,
    val subscribedAt: Long = System.currentTimeMillis()
)

object YouTubeSubscriptionManager {

    private const val PREFS_NAME = "cleanplayer_subscriptions_prefs"
    private const val KEY_SUBSCRIPTIONS = "subscribed_channels_json"

    fun getSubscriptions(context: Context): List<SubscribedChannel> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_SUBSCRIPTIONS, null) ?: return emptyList()
        val list = mutableListOf<SubscribedChannel>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    SubscribedChannel(
                        title = obj.getString("title"),
                        handle = obj.optString("handle", null),
                        avatarUrl = obj.optString("avatarUrl", null),
                        subscribedAt = obj.optLong("subscribedAt", 0L)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun isSubscribed(context: Context, channelTitle: String): Boolean {
        if (channelTitle.isBlank()) return false
        val subs = getSubscriptions(context)
        return subs.any { it.title.trim().equals(channelTitle.trim(), ignoreCase = true) }
    }

    fun subscribe(context: Context, channelTitle: String, channelHandle: String? = null, avatarUrl: String? = null): Boolean {
        if (channelTitle.isBlank()) return false
        val current = getSubscriptions(context).toMutableList()
        val existingIdx = current.indexOfFirst { it.title.trim().equals(channelTitle.trim(), ignoreCase = true) }
        if (existingIdx >= 0) {
            return false // already subscribed
        }
        current.add(0, SubscribedChannel(channelTitle.trim(), channelHandle, avatarUrl))
        saveSubscriptions(context, current)
        return true
    }

    fun unsubscribe(context: Context, channelTitle: String): Boolean {
        if (channelTitle.isBlank()) return false
        val current = getSubscriptions(context).toMutableList()
        val removed = current.removeAll { it.title.trim().equals(channelTitle.trim(), ignoreCase = true) }
        if (removed) {
            saveSubscriptions(context, current)
        }
        return removed
    }

    private fun saveSubscriptions(context: Context, list: List<SubscribedChannel>) {
        val arr = JSONArray()
        for (sub in list) {
            val obj = JSONObject()
            obj.put("title", sub.title)
            obj.put("handle", sub.handle)
            obj.put("avatarUrl", sub.avatarUrl)
            obj.put("subscribedAt", sub.subscribedAt)
            arr.put(obj)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SUBSCRIPTIONS, arr.toString())
            .apply()
    }

    fun fetchSubscriptionsFeed(context: Context, callback: (List<YouTubeVideo>) -> Unit) {
        val subs = getSubscriptions(context)
        if (subs.isEmpty()) {
            callback(emptyList())
            return
        }

        val allVideos = mutableListOf<YouTubeVideo>()
        val channelsToFetch = subs.take(6)
        var completedCount = 0

        for (ch in channelsToFetch) {
            YouTubeFeedRepository.searchVideos(ch.title) { videos ->
                synchronized(allVideos) {
                    allVideos.addAll(videos.take(5))
                    completedCount++
                    if (completedCount >= channelsToFetch.size) {
                        val distinct = allVideos.distinctBy { it.id }
                        callback(distinct)
                    }
                }
            }
        }
    }
}
