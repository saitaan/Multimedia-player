package com.cleanplayer.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.nio.channels.FileChannel
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class FastShareService : Service() {

    companion object {
        const val CHANNEL_ID = "cleanplayer_fast_share_channel"
        const val NOTIFICATION_ID = 202

        const val ACTION_START_SENDER = "com.cleanplayer.app.ACTION_START_SENDER"
        const val ACTION_START_RECEIVER = "com.cleanplayer.app.ACTION_START_RECEIVER"
        const val ACTION_STOP_TRANSFER = "com.cleanplayer.app.ACTION_STOP_TRANSFER"

        const val PORT_DEFAULT = 8989
        const val BUFFER_SIZE = 256 * 1024 // 256 KB Jumbo Buffer for Maximum Throughput

        var onTransferProgressUpdate: ((fileName: String, progressPercent: Int, speedMbPerSec: Float, transferredBytes: Long, totalBytes: Long, isCompleted: Boolean) -> Unit)? = null
        var onTransferError: ((error: String) -> Unit)? = null
        var onHotspotStarted: ((ssid: String, password: String, ip: String, port: Int) -> Unit)? = null

        val isTransferActive = AtomicBoolean(false)

        var currentFileName: String = ""
        var currentProgressPercent: Int = 0
        var currentSpeedMb: Float = 0f
        var currentTransferredBytes: Long = 0L
        var currentTotalBytes: Long = 0L
        var isSenderMode: Boolean = true
        var lastHotspotSsid: String = ""
        var lastHotspotPassword: String = ""
        var lastHotspotIp: String = "192.168.49.1"
    }

    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var localHotspotReservation: WifiManager.LocalOnlyHotspotReservation? = null

    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private val transferExecutor = Executors.newFixedThreadPool(4)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireHighPowerLocks()
    }

    private fun acquireHighPowerLocks() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CleanPlayer:TransferWakeLock").apply {
                acquire(120 * 60 * 1000L) // 2 hours max safe timeout
            }

            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lockMode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            } else {
                @Suppress("DEPRECATION")
                WifiManager.WIFI_MODE_FULL_HIGH_PERF
            }
            wifiLock = wifiManager.createWifiLock(lockMode, "CleanPlayer:HighPerfWifi").apply {
                acquire()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun releaseHighPowerLocks() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
            wakeLock = null
            if (wifiLock?.isHeld == true) wifiLock?.release()
            wifiLock = null
        } catch (e: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundServiceNotification("5GHz Turbo Share Engine", "Ready for high-speed background transfer...")

        when (intent?.action) {
            ACTION_START_SENDER -> {
                isSenderMode = true
                val filesToSend = intent.getStringArrayListExtra("files_to_send") ?: arrayListOf()
                val isParallel = intent.getBooleanExtra("is_parallel", true)
                startSenderHotspotAndServer(filesToSend, isParallel)
            }
            ACTION_START_RECEIVER -> {
                isSenderMode = false
                val hostIp = intent.getStringExtra("host_ip") ?: "192.168.49.1"
                val port = intent.getIntExtra("port", PORT_DEFAULT)
                startReceiverClient(hostIp, port)
            }
            ACTION_STOP_TRANSFER -> {
                stopTransferInternal()
            }
        }
        return START_NOT_STICKY
    }

    private fun startSenderHotspotAndServer(filePaths: List<String>, isParallel: Boolean) {
        isTransferActive.set(true)
        transferExecutor.execute {
            try {
                // Initialize 5GHz Local-Only Hotspot if supported
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                        override fun onStarted(reservation: WifiManager.LocalOnlyHotspotReservation?) {
                            super.onStarted(reservation)
                            localHotspotReservation = reservation
                            var ssid = "CleanPlayer_5GHz_Turbo"
                            var pwd = ""

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                try {
                                    val softApConfig = reservation?.softApConfiguration
                                    if (softApConfig != null) {
                                        ssid = softApConfig.ssid ?: ssid
                                        pwd = softApConfig.passphrase ?: pwd
                                    }
                                } catch (e: Exception) {}
                            }

                            if (pwd.isEmpty()) {
                                @Suppress("DEPRECATION")
                                val config = reservation?.wifiConfiguration
                                @Suppress("DEPRECATION")
                                ssid = config?.SSID ?: ssid
                                @Suppress("DEPRECATION")
                                pwd = config?.preSharedKey ?: pwd
                            }

                            lastHotspotSsid = ssid
                            lastHotspotPassword = pwd
                            lastHotspotIp = "192.168.49.1"
                            onHotspotStarted?.invoke(ssid, pwd, "192.168.49.1", PORT_DEFAULT)
                        }

                        override fun onFailed(reason: Int) {
                            super.onFailed(reason)
                            isTransferActive.set(false)
                            onTransferError?.invoke("Hotspot failed to start (error code: $reason)")
                            stopTransferInternal()
                        }
                    }, android.os.Handler(android.os.Looper.getMainLooper()))
                } else {
                    onHotspotStarted?.invoke("CleanPlayer_Direct", "", "192.168.49.1", PORT_DEFAULT)
                }

                // Start ServerSocket with 1MB Buffer and TCP_NODELAY
                serverSocket?.close()
                serverSocket = ServerSocket(PORT_DEFAULT).apply {
                    reuseAddress = true
                    receiveBufferSize = 1024 * 1024
                }

                while (isTransferActive.get()) {
                    val client = serverSocket?.accept() ?: break
                    client.tcpNoDelay = true
                    client.sendBufferSize = 1024 * 1024
                    client.receiveBufferSize = 1024 * 1024

                    transferExecutor.execute {
                        handleSenderClient(client, filePaths, isParallel)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                isTransferActive.set(false)
                onTransferError?.invoke("Sender error: ${e.localizedMessage ?: "Unknown error"}")
                stopTransferInternal()
            }
        }
    }

    private fun handleSenderClient(socket: Socket, filePaths: List<String>, isParallel: Boolean) {
        try {
            val dis = DataInputStream(BufferedInputStream(socket.getInputStream()))
            val dos = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))

            // Send total file count
            dos.writeInt(filePaths.size)
            dos.flush()

            val buffer = ByteArray(BUFFER_SIZE)

            for (path in filePaths) {
                if (!isTransferActive.get()) break
                val file = File(path)
                if (!file.exists() || !file.canRead()) continue

                val fileName = file.name
                val fileSize = file.length()

                currentFileName = fileName
                currentTotalBytes = fileSize

                // File metadata header
                dos.writeUTF(fileName)
                dos.writeLong(fileSize)
                dos.flush()

                // Handshake for Breakpoint Resume
                val requestedOffset = dis.readLong().coerceIn(0L, fileSize)

                val fis = FileInputStream(file)
                if (requestedOffset > 0) {
                    fis.channel.position(requestedOffset)
                }

                var sentBytes = requestedOffset
                var lastTime = System.currentTimeMillis()
                var bytesSinceLast = 0L

                while (isTransferActive.get() && sentBytes < fileSize) {
                    val toRead = ((fileSize - sentBytes).coerceAtMost(BUFFER_SIZE.toLong())).toInt()
                    val read = fis.read(buffer, 0, toRead)
                    if (read <= 0) break

                    dos.write(buffer, 0, read)
                    sentBytes += read
                    bytesSinceLast += read

                    val now = System.currentTimeMillis()
                    val delta = now - lastTime
                    if (delta >= 400) {
                        dos.flush()
                        val speedMb = (bytesSinceLast.toFloat() / (1024f * 1024f)) / (delta.toFloat() / 1000f)
                        val percent = if (fileSize > 0) ((sentBytes * 100) / fileSize).toInt() else 0

                        currentProgressPercent = percent
                        currentSpeedMb = speedMb
                        currentTransferredBytes = sentBytes

                        onTransferProgressUpdate?.invoke(fileName, percent, speedMb, sentBytes, fileSize, false)
                        updateNotificationSpeed(fileName, percent, speedMb, sentBytes, fileSize)
                        lastTime = now
                        bytesSinceLast = 0L
                    }
                }
                dos.flush()
                fis.close()

                val isDone = sentBytes >= fileSize
                currentProgressPercent = if (isDone) 100 else currentProgressPercent
                currentSpeedMb = 0f
                onTransferProgressUpdate?.invoke(fileName, 100, 0f, sentBytes, fileSize, isDone)
                if (isDone) {
                    notifyTransferCompleted(fileName)
                }

                val itemType = when {
                    fileName.endsWith(".mp4", true) || fileName.endsWith(".mkv", true) || fileName.endsWith(".webm", true) || fileName.endsWith(".avi", true) || fileName.endsWith(".mov", true) -> ShareItemType.VIDEO
                    fileName.endsWith(".mp3", true) || fileName.endsWith(".m4a", true) || fileName.endsWith(".flac", true) || fileName.endsWith(".wav", true) || fileName.endsWith(".aac", true) -> ShareItemType.AUDIO
                    fileName.endsWith(".apk", true) -> ShareItemType.APP
                    fileName.endsWith(".jpg", true) || fileName.endsWith(".png", true) || fileName.endsWith(".jpeg", true) || fileName.endsWith(".webp", true) || fileName.endsWith(".gif", true) -> ShareItemType.IMAGE
                    else -> ShareItemType.FILE
                }

                ShareHistoryManager.addOrUpdateRecord(
                    applicationContext,
                    TransferRecord(
                        id = file.absolutePath.hashCode().toString(),
                        fileName = fileName,
                        filePath = file.absolutePath,
                        totalSize = fileSize,
                        transferredBytes = sentBytes,
                        isOutgoing = true,
                        isCompleted = isDone,
                        type = itemType
                    )
                )
            }
            socket.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startReceiverClient(hostIp: String, port: Int) {
        isTransferActive.set(true)
        transferExecutor.execute {
            try {
                // Retry connection up to 15 times for handshake
                var connected = false
                var attempts = 0
                while (isTransferActive.get() && !connected && attempts < 15) {
                    try {
                        clientSocket = Socket(hostIp, port).apply {
                            tcpNoDelay = true
                            sendBufferSize = 1024 * 1024
                            receiveBufferSize = 1024 * 1024
                        }
                        connected = true
                    } catch (e: Exception) {
                        attempts++
                        Thread.sleep(800)
                    }
                }

                if (!connected) {
                    isTransferActive.set(false)
                    onTransferError?.invoke("Unable to connect to sender hotspot after multiple attempts.")
                    stopTransferInternal()
                    return@execute
                }

                val socket = clientSocket ?: return@execute
                val dis = DataInputStream(BufferedInputStream(socket.getInputStream()))
                val dos = DataOutputStream(BufferedOutputStream(socket.getOutputStream()))

                val totalFiles = dis.readInt()
                val targetDir = FastShareManager.getSaveDirectory(applicationContext)

                val buffer = ByteArray(BUFFER_SIZE)

                for (i in 0 until totalFiles) {
                    if (!isTransferActive.get()) break
                    val fileName = dis.readUTF()
                    val fileSize = dis.readLong()

                    currentFileName = fileName
                    currentTotalBytes = fileSize

                    val targetFile = File(targetDir, fileName)
                    val partFile = File(targetDir, "$fileName.part")

                    // Breakpoint Resume Offset check
                    val existingLength = if (partFile.exists()) partFile.length() else 0L
                    val resumeOffset = if (existingLength < fileSize) existingLength else 0L

                    // Send requested resume offset to sender
                    dos.writeLong(resumeOffset)
                    dos.flush()

                    val fos = FileOutputStream(partFile, resumeOffset > 0)
                    var receivedBytes = resumeOffset
                    var lastTime = System.currentTimeMillis()
                    var bytesSinceLast = 0L

                    while (isTransferActive.get() && receivedBytes < fileSize) {
                        val toRead = ((fileSize - receivedBytes).coerceAtMost(BUFFER_SIZE.toLong())).toInt()
                        val read = dis.read(buffer, 0, toRead)
                        if (read <= 0) break

                        fos.write(buffer, 0, read)
                        receivedBytes += read
                        bytesSinceLast += read

                        val now = System.currentTimeMillis()
                        val delta = now - lastTime
                        if (delta >= 400) {
                            val speedMb = (bytesSinceLast.toFloat() / (1024f * 1024f)) / (delta.toFloat() / 1000f)
                            val percent = if (fileSize > 0) ((receivedBytes * 100) / fileSize).toInt() else 0

                            currentProgressPercent = percent
                            currentSpeedMb = speedMb
                            currentTransferredBytes = receivedBytes

                            onTransferProgressUpdate?.invoke(fileName, percent, speedMb, receivedBytes, fileSize, false)
                            updateNotificationSpeed(fileName, percent, speedMb, receivedBytes, fileSize)
                            lastTime = now
                            bytesSinceLast = 0L
                        }
                    }
                    fos.flush()
                    fos.close()

                    val isDone = receivedBytes >= fileSize
                    if (isDone) {
                        if (targetFile.exists()) targetFile.delete()
                        partFile.renameTo(targetFile)
                    }

                    currentProgressPercent = if (isDone) 100 else currentProgressPercent
                    currentSpeedMb = 0f
                    onTransferProgressUpdate?.invoke(fileName, 100, 0f, receivedBytes, fileSize, isDone)
                    if (isDone) {
                        notifyTransferCompleted(fileName)
                    }

                    val itemType = when {
                        fileName.endsWith(".mp4", true) || fileName.endsWith(".mkv", true) || fileName.endsWith(".webm", true) || fileName.endsWith(".avi", true) || fileName.endsWith(".mov", true) -> ShareItemType.VIDEO
                        fileName.endsWith(".mp3", true) || fileName.endsWith(".m4a", true) || fileName.endsWith(".flac", true) || fileName.endsWith(".wav", true) || fileName.endsWith(".aac", true) -> ShareItemType.AUDIO
                        fileName.endsWith(".apk", true) -> ShareItemType.APP
                        fileName.endsWith(".jpg", true) || fileName.endsWith(".png", true) || fileName.endsWith(".jpeg", true) || fileName.endsWith(".webp", true) || fileName.endsWith(".gif", true) -> ShareItemType.IMAGE
                        else -> ShareItemType.FILE
                    }

                    ShareHistoryManager.addOrUpdateRecord(
                        applicationContext,
                        TransferRecord(
                            id = fileName.hashCode().toString(),
                            fileName = fileName,
                            filePath = (if (isDone) targetFile else partFile).absolutePath,
                            totalSize = fileSize,
                            transferredBytes = receivedBytes,
                            isOutgoing = false,
                            isCompleted = isDone,
                            type = itemType
                        )
                    )
                }

                socket.close()
            } catch (e: Exception) {
                e.printStackTrace()
                isTransferActive.set(false)
                onTransferError?.invoke("Receiver error: ${e.localizedMessage ?: "Unknown error"}")
                stopTransferInternal()
            }
        }
    }

    private fun stopTransferInternal() {
        isTransferActive.set(false)
        currentSpeedMb = 0f
        currentProgressPercent = 0
        currentFileName = ""
        try { serverSocket?.close() } catch (e: Exception) {}
        try { clientSocket?.close() } catch (e: Exception) {}
        serverSocket = null
        clientSocket = null
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                localHotspotReservation?.close()
                localHotspotReservation = null
            }
        } catch (e: Exception) {}
        releaseHighPowerLocks()
        stopForeground(STOP_FOREGROUND_REMOVE)
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.cancel(NOTIFICATION_ID)
        } catch (e: Exception) {}
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "5GHz Turbo Share Transfer",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "High-speed zero-copy P2P file transfers"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun startForegroundServiceNotification(title: String, content: String) {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("OPEN_TAB", "SHARE")
        }
        val pendingOpen = PendingIntent.getActivity(this, 11, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val stopIntent = Intent(this, FastShareService::class.java).apply { action = ACTION_STOP_TRANSFER }
        val pendingStop = PendingIntent.getService(this, 10, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_share_transfer)
            .setContentTitle(title)
            .setContentText(content)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .addAction(R.drawable.ic_close, "Stop", pendingStop)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotificationSpeed(fileName: String, percent: Int, speedMb: Float, transferred: Long, total: Long) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("OPEN_TAB", "SHARE")
        }
        val pendingOpen = PendingIntent.getActivity(this, 11, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val stopIntent = Intent(this, FastShareService::class.java).apply { action = ACTION_STOP_TRANSFER }
        val pendingStop = PendingIntent.getService(this, 10, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val transferredMb = String.format("%.1f", transferred / (1024f * 1024f))
        val totalMb = String.format("%.1f", total / (1024f * 1024f))

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_share_transfer)
            .setContentTitle("⚡ Sharing: $fileName ($percent%)")
            .setContentText("${String.format("%.1f", speedMb)} MB/s • $transferredMb / $totalMb MB • 5GHz")
            .setProgress(100, percent, false)
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_close, "Cancel", pendingStop)
            .build()

        manager.notify(NOTIFICATION_ID, notification)
    }

    private fun notifyTransferCompleted(fileName: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val openIntent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_MAIN
            addCategory(Intent.CATEGORY_LAUNCHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("OPEN_TAB", "SHARE")
        }
        val pendingOpen = PendingIntent.getActivity(this, 11, openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_share_transfer)
            .setContentTitle("✅ Transfer Complete!")
            .setContentText("$fileName transferred successfully • 5GHz Turbo")
            .setContentIntent(pendingOpen)
            .setAutoCancel(true)
            .setOngoing(false)
            .setDefaults(Notification.DEFAULT_ALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        manager.notify(NOTIFICATION_ID + 1, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopTransferInternal()
    }
}
