package com.cleanplayer.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * Ultra-fast, zero-lag asynchronous thumbnail loader for local videos and audio album art.
 * Features:
 * - 2-tier in-memory LruCache + persistent on-disk thumbnail caching.
 * - Hardware ParcelFileDescriptor extraction to bypass Scoped Storage permission barriers on heavy 1080p MKVs.
 * - Non-intrusive dark cinematic card placeholder (No more bright solid orange blocks).
 * - Background low-priority worker thread pool.
 */
object LocalThumbnailLoader {

    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = (maxMemory / 8).coerceIn(4096, 65536) // Cache in KB

    private val memoryCache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
    }

    private val executor = Executors.newFixedThreadPool(2) { runnable ->
        Thread(runnable, "LocalThumbnailWorker").apply {
            priority = Thread.MIN_PRIORITY
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    fun loadThumbnail(
        context: Context,
        item: MediaItem,
        targetView: ImageView,
        placeholderColor: Int = Color.parseColor("#8E8E93")
    ) {
        val cacheKey = if (!item.filePath.isNullOrBlank()) item.filePath else item.uri.toString()

        // 1. Instant Memory Cache Hit (0ms)
        val cached = memoryCache.get(cacheKey)
        if (cached != null && !cached.isRecycled) {
            targetView.tag = cacheKey
            targetView.scaleType = ImageView.ScaleType.CENTER_CROP
            targetView.clearColorFilter()
            targetView.setImageBitmap(cached)
            return
        }

        // 2. Set Default Cinematic Dark Placeholder & Tag
        targetView.tag = cacheKey
        targetView.scaleType = ImageView.ScaleType.CENTER_INSIDE
        targetView.setImageResource(if (item.isVideo) R.drawable.ic_video else R.drawable.ic_audio)
        targetView.setColorFilter(Color.parseColor("#8E8E93"))

        // 3. Asynchronously Load from Disk Cache or Hardware Extraction
        val appContext = context.applicationContext
        executor.execute {
            var bitmap: Bitmap? = loadFromDiskCache(appContext, cacheKey)

            if (bitmap == null) {
                try {
                    bitmap = if (item.isVideo) {
                        loadVideoThumbnail(appContext, item)
                    } else {
                        loadAudioThumbnail(appContext, item)
                    }
                } catch (e: Throwable) {
                    // Ignore decoding errors
                }

                if (bitmap != null) {
                    saveToDiskCache(appContext, cacheKey, bitmap)
                }
            }

            if (bitmap != null) {
                memoryCache.put(cacheKey, bitmap)
                mainHandler.post {
                    if (targetView.tag == cacheKey) {
                        targetView.scaleType = ImageView.ScaleType.CENTER_CROP
                        targetView.clearColorFilter()
                        targetView.setImageBitmap(bitmap)
                    }
                }
            }
        }
    }

    private fun loadVideoThumbnail(context: Context, item: MediaItem): Bitmap? {
        val cr = context.contentResolver

        // Tier 1: System MediaStore Thumbnails table (Pre-indexed)
        try {
            val bm = MediaStore.Video.Thumbnails.getThumbnail(
                cr,
                item.id,
                MediaStore.Video.Thumbnails.MINI_KIND,
                null
            )
            if (bm != null) return bm
        } catch (e: Throwable) {}

        // Tier 2: Android Q+ ContentResolver loadThumbnail
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val bm = cr.loadThumbnail(item.uri, Size(256, 144), null)
                if (bm != null) return bm
            } catch (e: Throwable) {}
        }

        // Tier 3: MediaMetadataRetriever via ParcelFileDescriptor (Works on Scoped Storage 1080p MKVs)
        var pfd: ParcelFileDescriptor? = null
        var retriever: MediaMetadataRetriever? = null
        try {
            pfd = cr.openFileDescriptor(item.uri, "r")
            if (pfd != null) {
                retriever = MediaMetadataRetriever()
                retriever.setDataSource(pfd.fileDescriptor)
                val bm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    retriever.getScaledFrameAtTime(2_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 256, 144)
                        ?: retriever.frameAtTime
                } else {
                    retriever.getFrameAtTime(2_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: retriever.frameAtTime
                }
                if (bm != null) return bm
            }
        } catch (e: Throwable) {
        } finally {
            try { retriever?.release() } catch (e: Throwable) {}
            try { pfd?.close() } catch (e: Throwable) {}
        }

        // Tier 4: Direct file path fallback
        if (!item.filePath.isNullOrBlank()) {
            try {
                val f = File(item.filePath)
                if (f.exists()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val bm = ThumbnailUtils.createVideoThumbnail(f, Size(256, 144), null)
                        if (bm != null) return bm
                    } else {
                        @Suppress("DEPRECATION")
                        val bm = ThumbnailUtils.createVideoThumbnail(item.filePath, MediaStore.Images.Thumbnails.MINI_KIND)
                        if (bm != null) return bm
                    }
                }
            } catch (e: Throwable) {}
        }

        return null
    }

    private fun loadAudioThumbnail(context: Context, item: MediaItem): Bitmap? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val bm = context.contentResolver.loadThumbnail(item.uri, Size(140, 140), null)
                if (bm != null) return bm
            } catch (e: Throwable) {}
        }

        var pfd: ParcelFileDescriptor? = null
        var retriever: MediaMetadataRetriever? = null
        try {
            retriever = MediaMetadataRetriever()
            if (!item.filePath.isNullOrBlank() && File(item.filePath).exists()) {
                retriever.setDataSource(item.filePath)
            } else {
                pfd = context.contentResolver.openFileDescriptor(item.uri, "r")
                if (pfd != null) {
                    retriever.setDataSource(pfd.fileDescriptor)
                } else {
                    retriever.setDataSource(context, item.uri)
                }
            }
            val artBytes = retriever.embeddedPicture
            if (artBytes != null && artBytes.isNotEmpty()) {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = 2
                }
                return BitmapFactory.decodeByteArray(artBytes, 0, artBytes.size, opts)
            }
        } catch (e: Throwable) {
            return null
        } finally {
            try { retriever?.release() } catch (e: Throwable) {}
            try { pfd?.close() } catch (e: Throwable) {}
        }
        return null
    }

    private fun getDiskCacheFile(context: Context, key: String): File {
        val dir = File(context.cacheDir, "cleanplayer_thumbs")
        if (!dir.exists()) dir.mkdirs()
        val safeName = "thumb_" + key.hashCode().toString() + ".jpg"
        return File(dir, safeName)
    }

    private fun loadFromDiskCache(context: Context, key: String): Bitmap? {
        return try {
            val f = getDiskCacheFile(context, key)
            if (f.exists() && f.length() > 0) {
                BitmapFactory.decodeFile(f.absolutePath)
            } else null
        } catch (e: Throwable) {
            null
        }
    }

    private fun saveToDiskCache(context: Context, key: String, bitmap: Bitmap) {
        try {
            val f = getDiskCacheFile(context, key)
            FileOutputStream(f).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos)
            }
        } catch (e: Throwable) {}
    }

    fun applyPerformanceMode() {
        val targetKb = when (PlayerHolder.performanceMode) {
            PlayerHolder.PERF_MODE_ULTRA_FAST -> (maxMemory / 6).coerceIn(16384, 65536)
            PlayerHolder.PERF_MODE_BALANCED -> (maxMemory / 12).coerceIn(8192, 24576)
            else -> 6144
        }
        try {
            memoryCache.resize(targetKb)
        } catch (e: Exception) {}
    }

    fun clearCache() {
        memoryCache.evictAll()
    }
}
