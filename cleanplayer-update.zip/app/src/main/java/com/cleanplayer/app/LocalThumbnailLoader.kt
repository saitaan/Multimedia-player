package com.cleanplayer.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.widget.ImageView
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * Ultra-fast, zero-lag asynchronous thumbnail loader for local videos and audio album art.
 * Features:
 * - 2-tier in-memory LruCache + persistent on-disk thumbnail caching.
 * - Hardware ParcelFileDescriptor extraction to bypass Scoped Storage permission barriers on heavy 1080p MKVs.
 * - Intelligent non-black frame seek algorithms (skips opening production logos and black fade-ins).
 * - Automatic luminance analysis to reject black/blank frames.
 * - Non-intrusive dark cinematic card placeholder with dynamic tint clearance.
 * - Background low-priority worker thread pool.
 */
object LocalThumbnailLoader {

    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = (maxMemory / 8).coerceIn(4096, 65536) // Cache in KB

    private val memoryCache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
    }

    private val executor = Executors.newFixedThreadPool(2) { runnable ->
        Thread(runnable, "LocalThumbnailWorker").apply {
            priority = Thread.MIN_PRIORITY
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    fun loadThumbnail(
        context: Context,
        item: MediaItem,
        targetView: ImageView,
        placeholderColor: Int = Color.parseColor("#8E8E93")
    ) {
        val cacheKey = if (!item.filePath.isNullOrBlank()) item.filePath else item.uri.toString()

        // 1. Instant Memory Cache Hit (0ms)
        val cached = memoryCache.get(cacheKey)
        if (cached != null && !cached.isRecycled) {
            targetView.tag = cacheKey
            targetView.scaleType = ImageView.ScaleType.CENTER_CROP
            targetView.imageTintList = null
            targetView.clearColorFilter()
            targetView.setImageBitmap(cached)
            return
        }

        // 2. Set Default Cinematic Dark Placeholder & Tag
        targetView.tag = cacheKey
        targetView.scaleType = ImageView.ScaleType.CENTER_INSIDE
        targetView.setImageResource(if (item.isVideo) R.drawable.ic_video else R.drawable.ic_audio)
        targetView.imageTintList = ColorStateList.valueOf(placeholderColor)
        targetView.clearColorFilter()

        // 3. Asynchronously Load from Disk Cache or Hardware Extraction
        val appContext = context.applicationContext
        executor.execute {
            var bitmap: Bitmap? = loadFromDiskCache(appContext, cacheKey)

            if (bitmap == null) {
                try {
                    bitmap = if (item.isVideo) {
                        loadVideoThumbnail(appContext, item)
                    } else {
                        loadAudioThumbnail(appContext, item)
                    }
                } catch (e: Throwable) {
                    // Ignore decoding errors
                }

                if (bitmap != null) {
                    saveToDiskCache(appContext, cacheKey, bitmap)
                }
            }

            if (bitmap != null) {
                memoryCache.put(cacheKey, bitmap)
                mainHandler.post {
                    if (targetView.tag == cacheKey) {
                        targetView.scaleType = ImageView.ScaleType.CENTER_CROP
                        targetView.imageTintList = null
                        targetView.clearColorFilter()
                        targetView.setImageBitmap(bitmap)
                    }
                }
            }
        }
    }

    /**
     * Checks if an extracted frame is pure black or pitch dark (luminance < 12).
     */
    private fun isFrameBlankOrBlack(bitmap: Bitmap): Boolean {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return true
        var totalLuminance = 0L
        var samples = 0
        val stepX = (w / 6).coerceAtLeast(1)
        val stepY = (h / 6).coerceAtLeast(1)
        for (x in stepX until w step stepX) {
            for (y in stepY until h step stepY) {
                val p = bitmap.getPixel(x, y)
                val r = Color.red(p)
                val g = Color.green(p)
                val b = Color.blue(p)
                val lum = (r * 299 + g * 587 + b * 114) / 1000
                totalLuminance += lum
                samples++
            }
        }
        if (samples == 0) return true
        val avgLum = totalLuminance / samples
        return avgLum < 12
    }

    private fun loadVideoThumbnail(context: Context, item: MediaItem): Bitmap? {
        val cr = context.contentResolver
        var pfd: ParcelFileDescriptor? = null
        var retriever: MediaMetadataRetriever? = null

        // Priority 1: Hardware MediaMetadataRetriever seeking past black intro frames
        try {
            retriever = MediaMetadataRetriever()
            if (!item.filePath.isNullOrBlank() && File(item.filePath).exists()) {
                retriever.setDataSource(item.filePath)
            } else {
                pfd = cr.openFileDescriptor(item.uri, "r")
                if (pfd != null) {
                    retriever.setDataSource(pfd.fileDescriptor)
                } else {
                    retriever.setDataSource(context, item.uri)
                }
            }

            val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durMs = durStr?.toLongOrNull() ?: item.durationMs
            val totalUs = durMs * 1000L

            // Calculate intelligent seek candidates to skip intro logos and black frames
            val time1 = if (totalUs > 60_000_000L) (totalUs * 15L / 100L) else 5_000_000L
            val time2 = if (totalUs > 120_000_000L) (totalUs * 25L / 100L) else 15_000_000L
            val time3 = if (totalUs > 30_000_000L) (totalUs * 10L / 100L) else 2_000_000L

            var fallbackBm: Bitmap? = null

            for (targetUs in listOf(time1, time2, time3)) {
                val bm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    retriever.getScaledFrameAtTime(targetUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 320, 180)
                        ?: retriever.getFrameAtTime(targetUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                } else {
                    retriever.getFrameAtTime(targetUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                }

                if (bm != null) {
                    if (!isFrameBlankOrBlack(bm)) {
                        return bm
                    }
                    if (fallbackBm == null) {
                        fallbackBm = bm
                    }
                }
            }

            if (fallbackBm != null) {
                return fallbackBm
            }
        } catch (e: Throwable) {
        } finally {
            try { retriever?.release() } catch (e: Throwable) {}
            try { pfd?.close() } catch (e: Throwable) {}
        }

        // Priority 2: Direct file path ThumbnailUtils fallback
        if (!item.filePath.isNullOrBlank()) {
            try {
                val f = File(item.filePath)
                if (f.exists()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        val bm = ThumbnailUtils.createVideoThumbnail(f, Size(320, 180), null)
                        if (bm != null) return bm
                    } else {
                        @Suppress("DEPRECATION")
                        val bm = ThumbnailUtils.createVideoThumbnail(item.filePath, MediaStore.Images.Thumbnails.MINI_KIND)
                        if (bm != null) return bm
                    }
                }
            } catch (e: Throwable) {}
        }

        // Priority 3: Android Q+ ContentResolver loadThumbnail
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val bm = cr.loadThumbnail(item.uri, Size(320, 180), null)
                if (bm != null) return bm
            } catch (e: Throwable) {}
        }

        // Priority 4: System MediaStore Thumbnails table (Pre-indexed)
        try {
            val bm = MediaStore.Video.Thumbnails.getThumbnail(
                cr,
                item.id,
                MediaStore.Video.Thumbnails.MINI_KIND,
                null
            )
            if (bm != null) return bm
        } catch (e: Throwable) {}

        return null
    }

    private fun loadAudioThumbnail(context: Context, item: MediaItem): Bitmap? {
        var pfd: ParcelFileDescriptor? = null
        var retriever: MediaMetadataRetriever? = null
        try {
            retriever = MediaMetadataRetriever()
            if (!item.filePath.isNullOrBlank() && File(item.filePath).exists()) {
                retriever.setDataSource(item.filePath)
            } else {
                pfd = context.contentResolver.openFileDescriptor(item.uri, "r")
                if (pfd != null) {
                    retriever.setDataSource(pfd.fileDescriptor)
                } else {
                    retriever.setDataSource(context, item.uri)
                }
            }
            val artBytes = retriever.embeddedPicture
            if (artBytes != null && artBytes.isNotEmpty()) {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = 2
                }
                return BitmapFactory.decodeByteArray(artBytes, 0, artBytes.size, opts)
            }
        } catch (e: Throwable) {
        } finally {
            try { retriever?.release() } catch (e: Throwable) {}
            try { pfd?.close() } catch (e: Throwable) {}
        }

        // Fallback: Android Q+ ContentResolver loadThumbnail
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val bm = context.contentResolver.loadThumbnail(item.uri, Size(140, 140), null)
                if (bm != null) return bm
            } catch (e: Throwable) {}
        }

        return null
    }

    private fun getDiskCacheFile(context: Context, key: String): File {
        // Automatically cleanup legacy v1 cache that contained blank/black tinted frames
        val oldDir = File(context.cacheDir, "cleanplayer_thumbs")
        if (oldDir.exists()) {
            try { oldDir.deleteRecursively() } catch (e: Throwable) {}
        }

        val dir = File(context.cacheDir, "cleanplayer_thumbs_v2")
        if (!dir.exists()) dir.mkdirs()
        val safeName = "thumb_" + key.hashCode().toString() + ".jpg"
        return File(dir, safeName)
    }

    private fun loadFromDiskCache(context: Context, key: String): Bitmap? {
        return try {
            val f = getDiskCacheFile(context, key)
            if (f.exists() && f.length() > 0) {
                BitmapFactory.decodeFile(f.absolutePath)
            } else null
        } catch (e: Throwable) {
            null
        }
    }

    private fun saveToDiskCache(context: Context, key: String, bitmap: Bitmap) {
        try {
            val f = getDiskCacheFile(context, key)
            FileOutputStream(f).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos)
            }
        } catch (e: Throwable) {}
    }

    fun applyPerformanceMode() {
        val targetKb = when (PlayerHolder.performanceMode) {
            PlayerHolder.PERF_MODE_ULTRA_FAST -> (maxMemory / 6).coerceIn(16384, 65536)
            PlayerHolder.PERF_MODE_BALANCED -> (maxMemory / 12).coerceIn(8192, 24576)
            else -> 6144
        }
        try {
            memoryCache.resize(targetKb)
        } catch (e: Exception) {}
    }

    fun clearCache() {
        memoryCache.evictAll()
    }
}
