package com.cleanplayer.app

import android.accounts.Account
import android.accounts.AccountManager
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

/**
 * ReVanced-Style GmsCore & Vanced MicroG Integration Manager
 * Manages Google Account authentication, OAuth token persistence, and GmsCore client detection.
 * Explicitly launches MicroG login components to strictly prevent system Play Services interception.
 */
object MicroGAuthManager {

    private const val PREFS_NAME = "microg_auth_prefs"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_ACCOUNT_NAME = "account_name"
    private const val KEY_ACCOUNT_EMAIL = "account_email"
    private const val KEY_AVATAR_URL = "avatar_url"
    private const val KEY_AUTH_TOKEN = "oauth_token"

    // Recognized MicroG and ReVanced GmsCore packages (strictly excluding com.google.android.gms)
    val MICROG_PACKAGES = listOf(
        "app.revanced.android.gms", // ReVanced GmsCore
        "com.mgoogle.android.gms",   // Vanced MicroG
        "org.microg.gms.core",       // Official MicroG GmsCore
        "org.microg.gms"             // MicroG variant
    )

    // AccountManager account types exposed exclusively by MicroG / ReVanced GmsCore
    private val ACCOUNT_TYPES = listOf(
        "app.revanced.android.gms",
        "com.mgoogle",
        "org.microg.gms",
        "org.microg.gms.core"
    )

    fun getDetectedMicroGPackage(context: Context): String? {
        val pm = context.packageManager
        for (pkg in MICROG_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, 0)
                return pkg
            } catch (e: PackageManager.NameNotFoundException) {}
        }
        return null
    }

    fun getDetectedMicroGFlavor(context: Context): String? {
        return when (getDetectedMicroGPackage(context)) {
            "app.revanced.android.gms" -> "ReVanced GmsCore"
            "com.mgoogle.android.gms" -> "Vanced MicroG"
            "org.microg.gms.core" -> "MicroG Services"
            "org.microg.gms" -> "MicroG GmsCore"
            else -> null
        }
    }

    fun isMicroGInstalled(context: Context): Boolean {
        return getDetectedMicroGPackage(context) != null
    }

    /**
     * Auto-detect accounts registered in Android AccountManager by MicroG
     */
    fun syncAccountsFromSystem(context: Context): Boolean {
        try {
            val am = AccountManager.get(context)
            for (type in ACCOUNT_TYPES) {
                val accounts = am.getAccountsByType(type)
                if (accounts.isNotEmpty()) {
                    val primaryAccount = accounts[0]
                    
                    var authToken: String? = null
                    val candidateScopes = listOf(
                        "oauth2:https://www.googleapis.com/auth/youtube",
                        "oauth2:https://www.googleapis.com/auth/youtube.force-ssl",
                        "oauth2:https://www.googleapis.com/auth/youtube.readonly",
                        "oauth2:https://www.googleapis.com/auth/youtube https://www.googleapis.com/auth/youtube.force-ssl",
                        "oauth2:https://www.googleapis.com/auth/identity",
                        "oauth2:https://www.googleapis.com/auth/userinfo.profile",
                        "oauth2:https://www.googleapis.com/auth/userinfo.email",
                        "oauth2:email",
                        "oauth2:profile",
                        "full_access",
                        "Manage your YouTube account",
                        "SID",
                        "LSID",
                        "webupdates",
                        "android"
                    )

                    // 1. Non-blocking peekAuthToken from AccountManager local cache
                    for (scope in candidateScopes) {
                        try {
                            val cached = am.peekAuthToken(primaryAccount, scope)
                            if (!cached.isNullOrBlank()) {
                                authToken = cached
                                break
                            }
                        } catch (e: Throwable) {}
                    }

                    // 2. MicroG / GmsCore UserData field scan
                    if (authToken.isNullOrBlank()) {
                        val userDataKeys = listOf("auth_token", "oauth_token", "token", "BearerToken", "YouTubeAuthToken", "authtoken")
                        for (key in userDataKeys) {
                            try {
                                val token = am.getUserData(primaryAccount, key)
                                if (!token.isNullOrBlank()) {
                                    authToken = token
                                    break
                                }
                            } catch (e: Throwable) {}
                        }
                    }

                    // 3. Fallback: blockingGetAuthToken across priority scopes
                    if (authToken.isNullOrBlank()) {
                        for (scope in candidateScopes) {
                            try {
                                val token = am.blockingGetAuthToken(primaryAccount, scope, false)
                                    ?: am.blockingGetAuthToken(primaryAccount, scope, true)
                                if (!token.isNullOrBlank()) {
                                    authToken = token
                                    break
                                }
                            } catch (e: Throwable) {}
                        }
                    }

                    saveAccount(
                        context = context,
                        name = primaryAccount.name.substringBefore("@"),
                        email = primaryAccount.name,
                        avatarUrl = null,
                        token = authToken
                    )
                    return true
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    fun isLoggedIn(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_IS_LOGGED_IN, false)) return true
        return syncAccountsFromSystem(context)
    }

    fun getAccountName(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCOUNT_NAME, "Guest User") ?: "Guest User"
    }

    fun getAccountEmail(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_ACCOUNT_EMAIL, "guest@cleanplayer.app") ?: "guest@cleanplayer.app"
    }

    fun getAvatarUrl(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_AVATAR_URL, null)
    }

    fun getAuthToken(context: Context): String? {
        return getOAuthToken(context)
    }

    fun getOAuthToken(context: Context): String? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        var token = prefs.getString(KEY_AUTH_TOKEN, null)
        if (token.isNullOrBlank() && prefs.getBoolean(KEY_IS_LOGGED_IN, false)) {
            try {
                syncAccountsFromSystem(context)
                token = prefs.getString(KEY_AUTH_TOKEN, null)
            } catch (e: Exception) {}
        }
        return token
    }

    /**
     * Forces invalidation of the current OAuth token from Android AccountManager
     * and performs a fresh token re-acquisition from MicroG/Google auth servers.
     */
    fun invalidateAndRefreshToken(context: Context): String? {
        try {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val oldToken = prefs.getString(KEY_AUTH_TOKEN, null)
            val am = AccountManager.get(context)

            for (type in ACCOUNT_TYPES) {
                try {
                    if (!oldToken.isNullOrBlank()) {
                        am.invalidateAuthToken(type, oldToken)
                    }
                } catch (e: Throwable) {}
            }

            prefs.edit().remove(KEY_AUTH_TOKEN).apply()
            syncAccountsFromSystem(context)
            return prefs.getString(KEY_AUTH_TOKEN, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun getAuthorizationHeader(context: Context): String? {
        val token = getOAuthToken(context) ?: return null
        return "Bearer $token"
    }

    fun saveAccount(context: Context, name: String, email: String, avatarUrl: String? = null, token: String? = null) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_ACCOUNT_NAME, name)
            .putString(KEY_ACCOUNT_EMAIL, email)
            .putString(KEY_AVATAR_URL, avatarUrl)
            .putString(KEY_AUTH_TOKEN, token)
            .apply()
    }

    fun signOut(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
    }

    /**
     * Directly launches the dedicated MicroG Sign-In Screen.
     * Prioritizes explicit component intents to completely prevent system Play Services from intercepting.
     */
    fun startSignInIntent(context: Context) {
        val pm = context.packageManager
        val detectedPkg = getDetectedMicroGPackage(context)

        val candidatePackages = if (detectedPkg != null) {
            listOf(detectedPkg) + MICROG_PACKAGES.filter { it != detectedPkg }
        } else {
            MICROG_PACKAGES
        }

        for (pkg in candidatePackages) {
            try {
                // 1. Direct explicit LoginActivity component
                val loginActivityIntent = Intent().apply {
                    component = ComponentName(pkg, "org.microg.gms.auth.login.LoginActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (loginActivityIntent.resolveActivity(pm) != null) {
                    context.startActivity(loginActivityIntent)
                    return
                }

                // 2. Direct action LOGIN with explicit package lock
                val loginActionIntent = Intent("org.microg.gms.auth.LOGIN").apply {
                    setPackage(pkg)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (loginActionIntent.resolveActivity(pm) != null) {
                    context.startActivity(loginActionIntent)
                    return
                }

                // 3. Direct explicit AccountIntroActivity component
                val introIntent = Intent().apply {
                    component = ComponentName(pkg, "org.microg.gms.auth.AccountIntroActivity")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (introIntent.resolveActivity(pm) != null) {
                    context.startActivity(introIntent)
                    return
                }

                // 4. MicroG Main Settings / Launch Activity
                val launchIntent = pm.getLaunchIntentForPackage(pkg)?.apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                if (launchIntent != null) {
                    context.startActivity(launchIntent)
                    return
                }
            } catch (e: Exception) {}
        }

        // Fallback: Scoped AccountManager strictly without com.google fallback
        val targetAccountType = when (detectedPkg) {
            "app.revanced.android.gms" -> "app.revanced.android.gms"
            "com.mgoogle.android.gms" -> "com.mgoogle"
            "org.microg.gms.core" -> "org.microg.gms"
            else -> "org.microg.gms"
        }

        try {
            val am = AccountManager.get(context)
            val activity = context as? android.app.Activity
            am.addAccount(targetAccountType, null, null, null, activity, null, null)
            return
        } catch (e: Exception) {}

        Toast.makeText(context, "MicroG Services app open nahi ho paya. Kripya check karein ki MicroG installed hai.", Toast.LENGTH_LONG).show()
    }

    fun showAccountDialog(context: Context, onStateChanged: () -> Unit) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_youtube_account, null, false)
        val dialog = AlertDialog.Builder(context)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tvName = dialogView.findViewById<TextView>(R.id.tvDialogAccountName)
        val tvEmail = dialogView.findViewById<TextView>(R.id.tvDialogAccountEmail)
        val tvStatus = dialogView.findViewById<TextView>(R.id.tvDialogMicroGStatus)
        val btnAction = dialogView.findViewById<Button>(R.id.btnDialogAccountAction)
        val btnSignOut = dialogView.findViewById<Button>(R.id.btnDialogSignOut)

        syncAccountsFromSystem(context)

        val flavor = getDetectedMicroGFlavor(context)
        if (flavor != null) {
            tvStatus.text = "$flavor: Connected"
            tvStatus.setTextColor(Color.parseColor("#4CAF50"))
        } else {
            tvStatus.text = "Standalone Mode (100% Ad-Free Core Active)"
            tvStatus.setTextColor(Color.parseColor("#00E5FF"))
        }

        if (isLoggedIn(context)) {
            tvName.text = getAccountName(context)
            tvEmail.text = getAccountEmail(context)
            btnAction.text = "Switch / Manage Account"
            btnSignOut.visibility = View.VISIBLE
        } else {
            tvName.text = if (flavor != null) "Google Account Sign-In" else "MicroG Required For Sign-In"
            tvEmail.text = if (flavor != null) "Sign in via $flavor for subscriptions, history & playlists" else "To sign into your Google account on non-rooted Android, please install ReVanced GmsCore (MicroG)."
            btnAction.text = if (flavor != null) "Sign In with $flavor" else "Download ReVanced GmsCore"
            btnSignOut.visibility = View.GONE
        }

        btnAction.setOnClickListener {
            dialog.dismiss()
            if (flavor != null) {
                startSignInIntent(context)
                onStateChanged()
            } else {
                try {
                    val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/ReVanced/GmsCore/releases/latest")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(browserIntent)
                } catch (e: Exception) {
                    Toast.makeText(context, "Please download ReVanced GmsCore from GitHub", Toast.LENGTH_LONG).show()
                }
            }
        }

        btnSignOut.setOnClickListener {
            signOut(context)
            dialog.dismiss()
            Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
            onStateChanged()
        }

        dialog.show()
    }
}
