package com.cleanplayer.app

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class QueueAdapter(
    private val context: Context,
    private var items: List<MediaItem>,
    private var currentPlayingUri: String?,
    private val onItemClick: (MediaItem, Int) -> Unit
) : RecyclerView.Adapter<QueueAdapter.QueueViewHolder>() {

    fun updateData(newItems: List<MediaItem>, playingUri: String?) {
        this.items = newItems
        this.currentPlayingUri = playingUri
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QueueViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_queue_track, parent, false)
        return QueueViewHolder(view)
    }

    override fun onBindViewHolder(holder: QueueViewHolder, position: Int) {
        val item = items[position]
        val isPlaying = item.uri.toString() == currentPlayingUri

        val isMono = PlayerHolder.isMonochrome()
        val primaryColor = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)
        val secondaryColor = if (isMono) Color.parseColor("#8E8E93") else ContextCompat.getColor(context, R.color.theme_text_secondary)

        val cleanTitle = cleanDisplayTitle(item.title)
        holder.tvTitle.text = cleanTitle

        val artist = if (!item.artist.isNullOrBlank() && item.artist != "<unknown>") item.artist else "Unknown artist"
        val album = if (!item.folderName.isNullOrBlank() && item.folderName != "Music") item.folderName else "Unknown album"
        holder.tvSubtitle.text = "$artist | $album"

        loadThumbnail(item, holder.ivTrackArt, isMono)

        if (isPlaying) {
            holder.itemView.setBackgroundResource(R.drawable.bg_queue_item_playing)
            holder.tvTitle.setTextColor(primaryColor)
            holder.ivPlayIndicator.visibility = View.VISIBLE
            holder.ivPlayIndicator.setColorFilter(primaryColor)
            holder.ivSubIcon.setColorFilter(primaryColor)
        } else {
            holder.itemView.setBackgroundColor(Color.TRANSPARENT)
            holder.tvTitle.setTextColor(Color.WHITE)
            holder.ivPlayIndicator.visibility = View.GONE
            holder.ivSubIcon.setColorFilter(secondaryColor)
        }

        holder.itemView.setOnClickListener {
            onItemClick(item, position)
        }

        holder.btnMore.setOnClickListener { v ->
            showTrackOptions(v, item)
        }
    }

    private fun loadThumbnail(item: MediaItem, imageView: ImageView, isMono: Boolean) {
        imageView.setImageResource(R.drawable.ic_audio)
        if (isMono) {
            imageView.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        } else {
            imageView.colorFilter = null
        }

        imageView.tag = item.uri.toString()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Thread {
                try {
                    val bmp = context.contentResolver.loadThumbnail(item.uri, android.util.Size(128, 128), null)
                    if (bmp != null) {
                        (context as? android.app.Activity)?.runOnUiThread {
                            if (imageView.tag == item.uri.toString()) {
                                imageView.setImageBitmap(bmp)
                                if (isMono) {
                                    imageView.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
                                }
                            }
                        }
                    }
                } catch (e: Exception) {}
            }.start()
        }
    }

    private fun showTrackOptions(anchor: View, item: MediaItem) {
        val popup = PopupMenu(context, anchor)
        popup.menu.add(0, 1, 0, "Play Next")
        popup.menu.add(0, 2, 1, "Add to Favorites")
        popup.menu.add(0, 3, 2, "Share Track")
        popup.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                1 -> {
                    CleanToast.show(context, "Added to Next Up")
                    true
                }
                2 -> {
                    val prefs = context.getSharedPreferences("audio_favorites_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putBoolean(item.uri.toString(), true).apply()
                    CleanToast.show(context, "Added to Favorites")
                    true
                }
                3 -> {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        putExtra(Intent.EXTRA_STREAM, item.uri)
                        type = "audio/*"
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Share Track"))
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun cleanDisplayTitle(raw: String): String {
        var s = MediaScanner.cleanMediaTitle(raw)
        if (s.contains("_")) {
            s = s.replace("__", " - ").replace("_", " ").trim()
        }
        return s
    }

    override fun getItemCount(): Int = items.size

    class QueueViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivTrackArt: ImageView = itemView.findViewById(R.id.ivQueueTrackArt)
        val ivPlayIndicator: ImageView = itemView.findViewById(R.id.ivQueuePlayIndicator)
        val tvTitle: TextView = itemView.findViewById(R.id.tvQueueItemTitle)
        val ivSubIcon: ImageView = itemView.findViewById(R.id.ivQueueSubIcon)
        val tvSubtitle: TextView = itemView.findViewById(R.id.tvQueueItemSubtitle)
        val btnMore: ImageButton = itemView.findViewById(R.id.btnQueueItemMore)
    }
}
