package com.cleanplayer.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Universal CleanPlayer Smart AI & Performance Hub.
 * Provides a unified, accessible, user-friendly control center for:
 * 1. Quick 1-Tap Smart Presets (Auto-AI, Cinema 4K, Studio Audio, Eco Saver)
 * 2. Video AI (Super-Resolution 4K with manual tuning, Video Boost, Night Vision, Smart Chapters)
 * 3. Audio AI (Demucs Neural Vocal Remover / DSP, Dialogue Speech Booster, Dynamic Auto-EQ, Silence Trimmer)
 * 4. Lyrics AI (English Alphabet Script Default, Live Speech-to-Text, Word Karaoke, Translation)
 * 5. Hardware Profiling & On-Demand Models Manager (POCO C85x, Xiaomi HyperOS 3, Android 16 Baklava, Moto)
 */
object SmartAiHubDialog {

    private const val TAB_VIDEO = 0
    private const val TAB_AUDIO = 1
    private const val TAB_LYRICS = 2
    private const val TAB_HARDWARE = 3

    private var activeTab = TAB_VIDEO

    fun show(context: Context, onUpdated: (() -> Unit)? = null) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_smart_ai_hub, null)
        val dialog = AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val btnClose = view.findViewById<ImageButton>(R.id.btnAiHubClose)
        val tvSubtitle = view.findViewById<TextView>(R.id.tvAiHubSubtitle)

        val prof = HardwareProfilerEngine.getProfile(context)
        tvSubtitle?.text = prof.displayBadge

        // Presets Chips
        val chipAuto = view.findViewById<TextView>(R.id.chipPresetAuto)
        val chipCinema = view.findViewById<TextView>(R.id.chipPresetCinema)
        val chipStudio = view.findViewById<TextView>(R.id.chipPresetStudio)
        val chipEco = view.findViewById<TextView>(R.id.chipPresetEco)

        // Category Tabs
        val tabVideo = view.findViewById<TextView>(R.id.tabHubVideo)
        val tabAudio = view.findViewById<TextView>(R.id.tabHubAudio)
        val tabLyrics = view.findViewById<TextView>(R.id.tabHubLyrics)
        val tabHardware = view.findViewById<TextView>(R.id.tabHubHardware)

        // Category Layouts
        val layoutVideo = view.findViewById<LinearLayout>(R.id.layoutTabVideo)
        val layoutAudio = view.findViewById<LinearLayout>(R.id.layoutTabAudio)
        val layoutLyrics = view.findViewById<LinearLayout>(R.id.layoutTabLyrics)
        val layoutHardware = view.findViewById<LinearLayout>(R.id.layoutTabHardware)

        // Video Tab Views
        val rowSuperRes = view.findViewById<View>(R.id.rowHubSuperRes)
        val tvSuperResStatus = view.findViewById<TextView>(R.id.tvHubSuperResStatus)
        val btnTuneSuperRes = view.findViewById<TextView>(R.id.btnHubTuneSuperRes)
        val cbSuperRes = view.findViewById<CheckBox>(R.id.cbHubSuperRes)

        val rowVideoBoost = view.findViewById<View>(R.id.rowHubVideoBoost)
        val cbVideoBoost = view.findViewById<CheckBox>(R.id.cbHubVideoBoost)

        val rowNightVision = view.findViewById<View>(R.id.rowHubNightVision)
        val cbNightVision = view.findViewById<CheckBox>(R.id.cbHubNightVision)

        val rowSmartChapters = view.findViewById<View>(R.id.rowHubSmartChapters)
        val cbSmartChapters = view.findViewById<CheckBox>(R.id.cbHubSmartChapters)

        // Audio Tab Views
        val rowKaraoke = view.findViewById<View>(R.id.rowHubKaraoke)
        val tvKaraokeStatus = view.findViewById<TextView>(R.id.tvHubKaraokeStatus)
        val cbKaraoke = view.findViewById<CheckBox>(R.id.cbHubKaraoke)

        val rowDialogueBoost = view.findViewById<View>(R.id.rowHubDialogueBoost)
        val cbDialogueBoost = view.findViewById<CheckBox>(R.id.cbHubDialogueBoost)

        val rowAutoEq = view.findViewById<View>(R.id.rowHubAutoEq)
        val tvAutoEqStatus = view.findViewById<TextView>(R.id.tvHubAutoEqStatus)
        val cbAutoEq = view.findViewById<CheckBox>(R.id.cbHubAutoEq)

        val rowSilenceTrimmer = view.findViewById<View>(R.id.rowHubSilenceTrimmer)
        val cbSilenceTrimmer = view.findViewById<CheckBox>(R.id.cbHubSilenceTrimmer)

        // Lyrics Tab Views
        val rowScriptToggle = view.findViewById<View>(R.id.rowHubScriptToggle)
        val tvScriptStatus = view.findViewById<TextView>(R.id.tvHubScriptStatus)
        val btnScriptChip = view.findViewById<TextView>(R.id.btnHubScriptToggleChip)

        val rowSpeechToText = view.findViewById<View>(R.id.rowHubSpeechToText)
        val rowWordSync = view.findViewById<View>(R.id.rowHubWordSync)
        val cbWordSync = view.findViewById<CheckBox>(R.id.cbHubWordSync)

        val rowTranslation = view.findViewById<View>(R.id.rowHubTranslation)
        val cbTranslation = view.findViewById<CheckBox>(R.id.cbHubTranslation)

        // Hardware Tab Views
        val tvHwBadge = view.findViewById<TextView>(R.id.tvHubHwBadge)
        val tvHwDetails = view.findViewById<TextView>(R.id.tvHubHwDetails)
        val btnOpenModelManager = view.findViewById<Button>(R.id.btnHubOpenModelManager)

        val btnPerfUltra = view.findViewById<TextView>(R.id.btnHubPerfUltra)
        val btnPerfBalanced = view.findViewById<TextView>(R.id.btnHubPerfBalanced)
        val btnPerfSaver = view.findViewById<TextView>(R.id.btnHubPerfSaver)

        fun updatePresetChips() {
            val mode = PlayerHolder.aiPresetMode
            chipAuto?.setBackgroundResource(if (mode == PlayerHolder.PRESET_AUTO_AI) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            chipAuto?.setTextColor(if (mode == PlayerHolder.PRESET_AUTO_AI) Color.BLACK else Color.WHITE)

            chipCinema?.setBackgroundResource(if (mode == PlayerHolder.PRESET_CINEMA_4K) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            chipCinema?.setTextColor(if (mode == PlayerHolder.PRESET_CINEMA_4K) Color.BLACK else Color.WHITE)

            chipStudio?.setBackgroundResource(if (mode == PlayerHolder.PRESET_STUDIO_AUDIO) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            chipStudio?.setTextColor(if (mode == PlayerHolder.PRESET_STUDIO_AUDIO) Color.BLACK else Color.WHITE)

            chipEco?.setBackgroundResource(if (mode == PlayerHolder.PRESET_ECO_SAVER) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            chipEco?.setTextColor(if (mode == PlayerHolder.PRESET_ECO_SAVER) Color.BLACK else Color.WHITE)
        }

        fun updateTabsNavigation() {
            tabVideo?.setBackgroundResource(if (activeTab == TAB_VIDEO) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            tabVideo?.setTextColor(if (activeTab == TAB_VIDEO) Color.BLACK else Color.WHITE)

            tabAudio?.setBackgroundResource(if (activeTab == TAB_AUDIO) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            tabAudio?.setTextColor(if (activeTab == TAB_AUDIO) Color.BLACK else Color.WHITE)

            tabLyrics?.setBackgroundResource(if (activeTab == TAB_LYRICS) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            tabLyrics?.setTextColor(if (activeTab == TAB_LYRICS) Color.BLACK else Color.WHITE)

            tabHardware?.setBackgroundResource(if (activeTab == TAB_HARDWARE) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            tabHardware?.setTextColor(if (activeTab == TAB_HARDWARE) Color.BLACK else Color.WHITE)

            layoutVideo?.visibility = if (activeTab == TAB_VIDEO) View.VISIBLE else View.GONE
            layoutAudio?.visibility = if (activeTab == TAB_AUDIO) View.VISIBLE else View.GONE
            layoutLyrics?.visibility = if (activeTab == TAB_LYRICS) View.VISIBLE else View.GONE
            layoutHardware?.visibility = if (activeTab == TAB_HARDWARE) View.VISIBLE else View.GONE
        }

        fun updateAllState() {
            updatePresetChips()
            updateTabsNavigation()

            // 1. Video State
            val isSuperResInstalled = AiModelDownloadManager.isModelInstalled(context, AiModelDownloadManager.SUPER_RES_MODEL)
            if (isSuperResInstalled) {
                cbSuperRes?.isChecked = PlayerHolder.isAiNeuralSuperResEnabled
                btnTuneSuperRes?.visibility = View.VISIBLE
                tvSuperResStatus?.text = if (PlayerHolder.isAiNeuralSuperResEnabled) {
                    "Active (${PlayerHolder.aiSuperResScaleFactor}x • ${PlayerHolder.aiSuperResSharpness}% Sharpness)"
                } else {
                    "Installed • Tap to Enable"
                }
                tvSuperResStatus?.setTextColor(Color.parseColor("#4CAF50"))
            } else {
                cbSuperRes?.isChecked = false
                btnTuneSuperRes?.visibility = View.GONE
                tvSuperResStatus?.text = "Not Installed • Tap to Download AI Model (~38 MB)"
                tvSuperResStatus?.setTextColor(Color.parseColor("#FF8800"))
            }

            cbVideoBoost?.isChecked = PlayerHolder.isAiVideoSharpnessEnabled
            cbNightVision?.isChecked = PlayerHolder.isAiNightVisionEnabled
            cbSmartChapters?.isChecked = PlayerHolder.isAiSmartChaptersEnabled

            // 2. Audio State
            val isDemucsInstalled = AiModelDownloadManager.isModelInstalled(context, AiModelDownloadManager.VOCAL_REMOVER_MODEL)
            cbKaraoke?.isChecked = PlayerHolder.isAiKaraokeEnabled || PlayerHolder.isNeuralVocalRemoverEnabled
            tvKaraokeStatus?.text = if (isDemucsInstalled && PlayerHolder.isNeuralVocalRemoverEnabled) {
                "Demucs Neural AI Model Active (Studio Quality)"
            } else if (PlayerHolder.isAiKaraokeEnabled) {
                "Active • Hardware DSP Center Phase Cut"
            } else if (isDemucsInstalled) {
                "Demucs Model Ready • Tap to Enable"
            } else {
                "Instant DSP Ready • Tap to Download Demucs AI (~34 MB)"
            }

            cbDialogueBoost?.isChecked = PlayerHolder.isDialogueBoostEnabled
            cbAutoEq?.isChecked = PlayerHolder.isAiAutoEqEnabled
            tvAutoEqStatus?.text = if (PlayerHolder.isAiAutoEqEnabled) "Active • Tuning for '${PlayerHolder.currentAiDetectedGenre}'" else "Disabled"
            cbSilenceTrimmer?.isChecked = PlayerHolder.isAiSilenceTrimmerEnabled

            // 3. Lyrics State
            if (PlayerHolder.isLyricsEnglishAlphabetDefault) {
                tvScriptStatus?.text = "Active: English Alphabet (Romanized Default)"
                btnScriptChip?.text = "English"
                btnScriptChip?.setBackgroundResource(R.drawable.bg_youtube_chip_active)
                btnScriptChip?.setTextColor(Color.BLACK)
            } else {
                tvScriptStatus?.text = "Active: Original Native Script"
                btnScriptChip?.text = "Original"
                btnScriptChip?.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                btnScriptChip?.setTextColor(Color.WHITE)
            }

            cbWordSync?.isChecked = PlayerHolder.isWordByWordLyricsEnabled
            cbTranslation?.isChecked = PlayerHolder.isDualLanguageLyricsEnabled

            // 4. Hardware State
            tvHwBadge?.text = prof.displayBadge
            tvHwDetails?.text = "Platform: ${prof.brand} ${prof.model} (API ${prof.androidVersion})\nShader: ${prof.recommendedShader}\nGPU: ${prof.gpuVendor}"

            val perf = PlayerHolder.performanceMode
            btnPerfUltra?.setBackgroundResource(if (perf == 2) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            btnPerfUltra?.setTextColor(if (perf == 2) Color.BLACK else Color.WHITE)

            btnPerfBalanced?.setBackgroundResource(if (perf == 1) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            btnPerfBalanced?.setTextColor(if (perf == 1) Color.BLACK else Color.WHITE)

            btnPerfSaver?.setBackgroundResource(if (perf == 0) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            btnPerfSaver?.setTextColor(if (perf == 0) Color.BLACK else Color.WHITE)
        }

        updateAllState()

        // Preset Clicks
        chipAuto?.setOnClickListener {
            PlayerHolder.applyAiPreset(PlayerHolder.PRESET_AUTO_AI, context)
            updateAllState()
            CleanToast.show(context, "⚡ Auto-AI Adaptive Preset Active")
            onUpdated?.invoke()
        }

        chipCinema?.setOnClickListener {
            PlayerHolder.applyAiPreset(PlayerHolder.PRESET_CINEMA_4K, context)
            updateAllState()
            CleanToast.show(context, "🎬 Cinema 4K Preset Active")
            onUpdated?.invoke()
        }

        chipStudio?.setOnClickListener {
            PlayerHolder.applyAiPreset(PlayerHolder.PRESET_STUDIO_AUDIO, context)
            updateAllState()
            CleanToast.show(context, "🎵 Studio Audio Preset Active")
            onUpdated?.invoke()
        }

        chipEco?.setOnClickListener {
            PlayerHolder.applyAiPreset(PlayerHolder.PRESET_ECO_SAVER, context)
            updateAllState()
            CleanToast.show(context, "🔋 Eco Battery Saver Active")
            onUpdated?.invoke()
        }

        // Tab Navigation Clicks
        tabVideo?.setOnClickListener {
            activeTab = TAB_VIDEO
            updateTabsNavigation()
        }

        tabAudio?.setOnClickListener {
            activeTab = TAB_AUDIO
            updateTabsNavigation()
        }

        tabLyrics?.setOnClickListener {
            activeTab = TAB_LYRICS
            updateTabsNavigation()
        }

        tabHardware?.setOnClickListener {
            activeTab = TAB_HARDWARE
            updateTabsNavigation()
        }

        // Video Actions
        rowSuperRes?.setOnClickListener {
            if (!AiModelDownloadManager.isModelInstalled(context, AiModelDownloadManager.SUPER_RES_MODEL)) {
                AiModelDownloadDialog.show(context, AiModelDownloadManager.SUPER_RES_MODEL) {
                    updateAllState()
                    onUpdated?.invoke()
                }
            } else {
                cbSuperRes?.toggle()
                PlayerHolder.isAiNeuralSuperResEnabled = cbSuperRes?.isChecked == true
                PlayerHolder.savePreferences(context)
                AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
                updateAllState()
                CleanToast.show(context, if (PlayerHolder.isAiNeuralSuperResEnabled) "⚡ Neural Super-Resolution: ON (${PlayerHolder.aiSuperResScaleFactor}x)" else "⚡ Neural Super-Resolution: OFF")
                onUpdated?.invoke()
            }
        }

        btnTuneSuperRes?.setOnClickListener {
            NeuralSuperResTuneDialog.show(context) {
                updateAllState()
                onUpdated?.invoke()
            }
        }

        rowVideoBoost?.setOnClickListener {
            cbVideoBoost?.toggle()
            PlayerHolder.isAiVideoSharpnessEnabled = cbVideoBoost?.isChecked == true
            PlayerHolder.savePreferences(context)
            AiVideoEnhancer.applyEnhancement(context, true)
            updateAllState()
            CleanToast.show(context, if (PlayerHolder.isAiVideoSharpnessEnabled) "✨ AI Video Boost: ON (Sharpness & HDR)" else "AI Video Boost: OFF")
            onUpdated?.invoke()
        }

        rowNightVision?.setOnClickListener {
            cbNightVision?.toggle()
            PlayerHolder.isAiNightVisionEnabled = cbNightVision?.isChecked == true
            PlayerHolder.savePreferences(context)
            AiVideoEnhancer.applyEnhancement(context, true)
            updateAllState()
            CleanToast.show(context, if (PlayerHolder.isAiNightVisionEnabled) "🌙 AI Night Vision: ON (Shadows Lifted)" else "AI Night Vision: OFF")
            onUpdated?.invoke()
        }

        rowSmartChapters?.setOnClickListener {
            cbSmartChapters?.toggle()
            PlayerHolder.isAiSmartChaptersEnabled = cbSmartChapters?.isChecked == true
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, if (PlayerHolder.isAiSmartChaptersEnabled) "🎬 AI Smart Chapters: ON" else "AI Smart Chapters: OFF")
            onUpdated?.invoke()
        }

        // Audio Actions
        rowKaraoke?.setOnClickListener {
            val isDemucs = AiModelDownloadManager.isModelInstalled(context, AiModelDownloadManager.VOCAL_REMOVER_MODEL)
            val currentlyActive = PlayerHolder.isAiKaraokeEnabled || PlayerHolder.isNeuralVocalRemoverEnabled
            val newStatus = !currentlyActive

            if (isDemucs) {
                PlayerHolder.isNeuralVocalRemoverEnabled = newStatus
                PlayerHolder.isAiKaraokeEnabled = newStatus
            } else {
                PlayerHolder.isAiKaraokeEnabled = newStatus
                PlayerHolder.isNeuralVocalRemoverEnabled = false
            }
            AiAudioDspEngine.applyKaraokeMode(context, true, newStatus)
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, if (newStatus) "🎤 Karaoke / Vocal Isolation: ON" else "🎤 Karaoke / Vocal Isolation: OFF")
            onUpdated?.invoke()
        }

        rowDialogueBoost?.setOnClickListener {
            cbDialogueBoost?.toggle()
            PlayerHolder.isDialogueBoostEnabled = cbDialogueBoost?.isChecked == true
            PlayerHolder.applyAudioEffects()
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, if (PlayerHolder.isDialogueBoostEnabled) "🗣️ Dialogue Booster: ON (+8dB Speech Clarity)" else "Dialogue Booster: OFF")
            onUpdated?.invoke()
        }

        rowAutoEq?.setOnClickListener {
            cbAutoEq?.toggle()
            PlayerHolder.isAiAutoEqEnabled = cbAutoEq?.isChecked == true
            if (PlayerHolder.isAiAutoEqEnabled) {
                AiAudioDspEngine.autoDetectAndApplyEq(context, true, PlayerHolder.currentTitle, null)
            }
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, if (PlayerHolder.isAiAutoEqEnabled) "🎛️ Auto-Adaptive EQ: ON" else "Auto-Adaptive EQ: OFF")
            onUpdated?.invoke()
        }

        rowSilenceTrimmer?.setOnClickListener {
            cbSilenceTrimmer?.toggle()
            PlayerHolder.isAiSilenceTrimmerEnabled = cbSilenceTrimmer?.isChecked == true
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, if (PlayerHolder.isAiSilenceTrimmerEnabled) "🔇 Smart Silence Trimmer: ON" else "Smart Silence Trimmer: OFF")
            onUpdated?.invoke()
        }

        // Lyrics Actions
        rowScriptToggle?.setOnClickListener {
            PlayerHolder.isLyricsEnglishAlphabetDefault = !PlayerHolder.isLyricsEnglishAlphabetDefault
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, if (PlayerHolder.isLyricsEnglishAlphabetDefault) "🔤 English Alphabet / Romanized Lyrics Active" else "🔤 Original Native Script Active")
            onUpdated?.invoke()
        }

        rowSpeechToText?.setOnClickListener {
            dialog.dismiss()
            if (context is PlayerActivity) {
                context.showSpeechToTextDialog()
            } else {
                CleanToast.show(context, "Open speech-to-text from player toolbar or song menu")
            }
        }

        rowWordSync?.setOnClickListener {
            cbWordSync?.toggle()
            PlayerHolder.isWordByWordLyricsEnabled = cbWordSync?.isChecked == true
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, if (PlayerHolder.isWordByWordLyricsEnabled) "🎤 Word-by-Word Karaoke Sync: ON" else "🎤 Word Sync: OFF")
            onUpdated?.invoke()
        }

        rowTranslation?.setOnClickListener {
            cbTranslation?.toggle()
            PlayerHolder.isDualLanguageLyricsEnabled = cbTranslation?.isChecked == true
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, if (PlayerHolder.isDualLanguageLyricsEnabled) "🌐 Lyrics Dual-Translation: ON" else "🌐 Translation: OFF")
            onUpdated?.invoke()
        }

        // Hardware Actions
        btnOpenModelManager?.setOnClickListener {
            AiModelDownloadDialog.show(context) {
                updateAllState()
                onUpdated?.invoke()
            }
        }

        btnPerfUltra?.setOnClickListener {
            PlayerHolder.performanceMode = 2
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, "⚡ Ultra Performance Mode Active (120Hz/144Hz)")
            onUpdated?.invoke()
        }

        btnPerfBalanced?.setOnClickListener {
            PlayerHolder.performanceMode = 1
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, "⚖️ Balanced Performance Mode Active")
            onUpdated?.invoke()
        }

        btnPerfSaver?.setOnClickListener {
            PlayerHolder.performanceMode = 0
            PlayerHolder.savePreferences(context)
            updateAllState()
            CleanToast.show(context, "🔋 Battery Saver Mode Active")
            onUpdated?.invoke()
        }

        btnClose?.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }
}
