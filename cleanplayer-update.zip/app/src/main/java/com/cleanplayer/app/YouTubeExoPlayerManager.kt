package com.cleanplayer.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import java.io.File
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView

/**
 * AndroidX Media3 (ExoPlayer) Dedicated Adaptive Engine for YouTube
 * Supports high-definition MergingMediaSource (Video + Audio) and Ultra-Low Data Pure Audio streams.
 * Includes Automatic Background Data Saver (drops video download in background saving 95% data).
 */
object YouTubeExoPlayerManager {
    @Volatile
    private var isHighEndCacheScaled: Boolean = false

    fun scaleCacheForHighEndHardware(totalRamGb: Int) {
        if (!isHighEndCacheScaled && totalRamGb >= 10) {
            isHighEndCacheScaled = true
            // High-end hardware scaling: 12GB RAM beast profile
        }
    }


    var exoPlayer: ExoPlayer? = null
        private set

    var currentPlayingVideo: YouTubeVideo? = null

    var currentStreamUrl: String? = null
        private set

    var currentVideoStreamUrl: String? = null
        private set

    var currentAudioStreamUrl: String? = null
        private set

    var currentPureAudioUrl: String? = null
        private set

    var currentAllAudioUrls: List<String> = emptyList()
    var currentYouTubeAudioTracks: List<YouTubeAudioTrack> = emptyList()
    var currentSelectedAudioTrackId: String? = null
        private set

    var currentQualityLabel: String = "Auto"
        private set

    var isAudioOnlyMode: Boolean = false

    var isBackgroundAutoSwitched: Boolean = false
        private set

    var isBackgroundDataSaverEnabled: Boolean = true

    var currentMinBufferMs: Int = 15000
        private set

    var currentMaxBufferMs: Int = 30000
        private set

    fun applyBufferLimit(context: Context, bufferPref: String) {
        val (minMs, maxMs) = when {
            bufferPref.contains("15s") -> 8000 to 15000
            bufferPref.contains("60s") -> 20000 to 60000
            bufferPref.contains("120s") -> 30000 to 120000
            else -> 15000 to 30000
        }
        currentMinBufferMs = minMs
        currentMaxBufferMs = maxMs
    }

    private var trackSelector: DefaultTrackSelector? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var sponsorCheckRunnable: Runnable? = null
    private val playerLock = Any()
    @Volatile
    private var simpleCache: SimpleCache? = null

    @Synchronized
    private fun buildCachedDataSourceFactory(context: Context): DefaultDataSource.Factory {
        val appContext = context.applicationContext
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val cache = getMediaCache(appContext)
        val cacheDataSourceFactory = CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(httpDataSourceFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        return DefaultDataSource.Factory(appContext, cacheDataSourceFactory)
    }

    fun getMediaCacheInstance(context: Context): SimpleCache = getMediaCache(context)

    private fun getMediaCache(context: Context): SimpleCache {
        var cache = simpleCache
        if (cache == null) {
            val appContext = context.applicationContext
            val cacheDir = File(appContext.cacheDir, "cleanplayer_yt_cache")
            val prefs = appContext.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
            val sizeMb = prefs.getLong("pref_yt_disk_cache_mb", 4096L)
            val evictor = LeastRecentlyUsedCacheEvictor(sizeMb * 1024 * 1024L)
            val databaseProvider = StandaloneDatabaseProvider(appContext)
            cache = SimpleCache(cacheDir, evictor, databaseProvider)
            simpleCache = cache
        }
        return cache
    }

    @Synchronized
    fun updateDiskCacheSize(context: Context, sizeMb: Long) {
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        prefs.edit().putLong("pref_yt_disk_cache_mb", sizeMb).apply()
        try {
            simpleCache?.release()
            simpleCache = null
        } catch (e: Exception) {}
    }

    private var errorRetryCount = 0
    @Volatile
    var hasRetriedExpiredUrlForVideoId: String? = null

    fun isHttpExpiredError(error: PlaybackException): Boolean {
        var cause: Throwable? = error
        while (cause != null) {
            if (cause is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) {
                val code = cause.responseCode
                if (code == 403 || code == 410) return true
            }
            val msg = cause.message ?: ""
            if (msg.contains("response code: 403", ignoreCase = true) ||
                msg.contains("response code: 410", ignoreCase = true) ||
                msg.contains("HTTP 403", ignoreCase = true) ||
                msg.contains("HTTP 410", ignoreCase = true) ||
                msg.contains("403 Forbidden", ignoreCase = true) ||
                msg.contains("410 Gone", ignoreCase = true)) {
                return true
            }
            cause = cause.cause
        }
        return false
    }

    var onSponsorSkipped: ((category: String) -> Unit)? = null
    var onPlaybackStateChanged: ((isPlaying: Boolean) -> Unit)? = null
    var onBufferingStateChanged: ((isBuffering: Boolean) -> Unit)? = null
    var onPlayerError: ((error: PlaybackException) -> Unit)? = null
    var onAudioSessionIdChanged: ((sessionId: Int) -> Unit)? = null
    var onAudioModeChanged: ((isAudioOnly: Boolean) -> Unit)? = null
    var onVideoEnded: (() -> Unit)? = null

    @Synchronized
    fun getOrCreatePlayer(context: Context): ExoPlayer {
        val existing = exoPlayer
        if (existing != null) return existing

        val appContext = context.applicationContext
        val selector = DefaultTrackSelector(appContext)
        trackSelector = selector

        val dataSourceFactory = buildCachedDataSourceFactory(context)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        val (minMs, maxMs) = when (PlayerHolder.performanceMode) {
            PlayerHolder.PERF_MODE_ULTRA_FAST -> 30000 to 60000
            PlayerHolder.PERF_MODE_BALANCED -> 15000 to 30000
            else -> 8000 to 15000
        }
        currentMinBufferMs = minMs
        currentMaxBufferMs = maxMs

        val playbackStartMs = when (PlayerHolder.performanceMode) {
            PlayerHolder.PERF_MODE_ULTRA_FAST -> 350
            PlayerHolder.PERF_MODE_BALANCED -> 800
            else -> 1500
        }

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                minMs,
                maxMs,
                playbackStartMs,
                1200
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .setBackBuffer(if (PlayerHolder.performanceMode == PlayerHolder.PERF_MODE_ULTRA_FAST) 120000 else 60000, true)
            .build()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val renderersFactory = DefaultRenderersFactory(appContext)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)

        val player = ExoPlayer.Builder(appContext, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        try {
            player.skipSilenceEnabled = PlayerHolder.isSilenceTrimmerEnabled
        } catch (t: Throwable) {}

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId > 0) {
                    onAudioSessionIdChanged?.invoke(audioSessionId)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                onPlaybackStateChanged?.invoke(isPlaying)
                if (isPlaying) {
                    errorRetryCount = 0
                    startSponsorCheckLoop()
                } else {
                    stopSponsorCheckLoop()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        onBufferingStateChanged?.invoke(true)
                    }
                    Player.STATE_READY -> {
                        errorRetryCount = 0
                        onBufferingStateChanged?.invoke(false)
                    }
                    Player.STATE_ENDED -> {
                        stopSponsorCheckLoop()
                        onBufferingStateChanged?.invoke(false)
                        onPlaybackStateChanged?.invoke(false)
                        onVideoEnded?.invoke()
                    }
                    Player.STATE_IDLE -> {
                        onBufferingStateChanged?.invoke(false)
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                error.printStackTrace()
                onBufferingStateChanged?.invoke(false)

                val currentVideo = currentPlayingVideo
                if (currentVideo != null) {
                    val isExpired = isHttpExpiredError(error)
                    // If error is 403 / 410 or expired URL, invalidate cache and perform exactly ONE fresh retry
                    if (isExpired && hasRetriedExpiredUrlForVideoId != currentVideo.id) {
                        hasRetriedExpiredUrlForVideoId = currentVideo.id
                        val savedPos = exoPlayer?.currentPosition ?: 0L
                        val wasAudioOnly = isAudioOnlyMode

                        // 1. Invalidate stale cached stream URL
                        YouTubeStreamResolver.invalidateStreamCache(currentVideo.id)

                        // 2. Perform fresh extraction and retry once
                        YouTubeStreamResolver.resolveStreams(
                            videoId = currentVideo.id,
                            preferredResolution = 720,
                            forceFresh = true
                        ) { freshStream ->
                            if (freshStream != null) {
                                playVideo(
                                    context = context,
                                    video = currentVideo,
                                    videoStreamUrl = freshStream.videoUrl,
                                    audioStreamUrl = freshStream.audioUrl,
                                    pureAudioUrl = freshStream.pureAudioUrl,
                                    allAudioUrls = freshStream.allAudioUrls,
                                    startPosMs = savedPos,
                                    startInAudioOnly = wasAudioOnly,
                                    availableAudioTracks = freshStream.availableAudioTracks
                                )
                            } else {
                                onPlaybackStateChanged?.invoke(false)
                                onPlayerError?.invoke(error)
                            }
                        }
                        return
                    }

                    // Resilient Error Handling for general transient playback issues (max 2 retries, no loops)
                    if (!isExpired && errorRetryCount < 2) {
                        errorRetryCount++
                        mainHandler.postDelayed({
                            try {
                                if (exoPlayer != null && currentPlayingVideo?.id == currentVideo.id) {
                                    if (!isAudioOnlyMode && !currentPureAudioUrl.isNullOrBlank()) {
                                        switchToPureAudio(context)
                                    } else {
                                        exoPlayer?.prepare()
                                        exoPlayer?.play()
                                    }
                                }
                            } catch (e: Exception) {}
                        }, 800)
                        return
                    }
                }

                errorRetryCount = 0
                onPlaybackStateChanged?.invoke(false)
                onPlayerError?.invoke(error)
            }
        })

        exoPlayer = player
        return player
    }

    @Synchronized
    fun playVideo(
        context: Context,
        video: YouTubeVideo,
        videoStreamUrl: String,
        audioStreamUrl: String? = null,
        pureAudioUrl: String? = null,
        allAudioUrls: List<String> = emptyList(),
        isDash: Boolean = false,
        isHls: Boolean = false,
        startPosMs: Long = 0L,
        startInAudioOnly: Boolean = false,
        availableAudioTracks: List<YouTubeAudioTrack> = emptyList()
    ) {
        val player = getOrCreatePlayer(context)
        val appContext = context.applicationContext
        try {
            PlayerHolder.stop()
        } catch (t: Throwable) {}
        if (currentPlayingVideo?.id != video.id) {
            hasRetriedExpiredUrlForVideoId = null
        }
        currentPlayingVideo = video
        currentStreamUrl = videoStreamUrl
        currentVideoStreamUrl = videoStreamUrl
        currentAudioStreamUrl = audioStreamUrl
        currentPureAudioUrl = pureAudioUrl ?: audioStreamUrl ?: videoStreamUrl
        currentAllAudioUrls = allAudioUrls
        currentYouTubeAudioTracks = availableAudioTracks
        val defaultHindi = availableAudioTracks.firstOrNull {
            it.language.startsWith("hi", ignoreCase = true) ||
            it.language.equals("hin", ignoreCase = true) ||
            it.name.contains("hindi", ignoreCase = true)
        }
        currentSelectedAudioTrackId = defaultHindi?.id
        isBackgroundAutoSwitched = false
        isAudioOnlyMode = startInAudioOnly

        val metadata = MediaMetadata.Builder()
            .setTitle(video.title)
            .setArtist(video.channelTitle)
            .setArtworkUri(Uri.parse(video.thumbnailUrl))
            .build()

        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val dataSourceFactory = DefaultDataSource.Factory(appContext, httpDataSourceFactory)

        // Fetch SponsorBlock segments
        SponsorBlockManager.fetchSegments(video.id)

        try {
            onBufferingStateChanged?.invoke(true)

            if (isAudioOnlyMode && !currentPureAudioUrl.isNullOrBlank()) {
                // PURE AUDIO PLAYBACK - ZERO VIDEO DATA
                trackSelector?.let { sel -> sel.parameters = sel.buildUponParameters().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build() }

                val audioMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(currentPureAudioUrl))
                    .setMediaMetadata(metadata)
                    .build()
                val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)
                val audioSource = progressiveFactory.createMediaSource(audioMediaItem)
                player.setMediaSource(audioSource)
            } else if (!audioStreamUrl.isNullOrBlank() && audioStreamUrl != videoStreamUrl) {
                // High Definition Merged Source (Video + Audio)
                trackSelector?.let { sel -> sel.parameters = sel.buildUponParameters().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).build() }

                val videoMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(videoStreamUrl))
                    .setMediaMetadata(metadata)
                    .build()

                val audioMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(audioStreamUrl))
                    .build()

                val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)
                val videoSource = progressiveFactory.createMediaSource(videoMediaItem)
                val audioSource = progressiveFactory.createMediaSource(audioMediaItem)
                val mergedSource = MergingMediaSource(videoSource, audioSource)

                player.setMediaSource(mergedSource)
            } else {
                trackSelector?.let { sel -> sel.parameters = sel.buildUponParameters().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).build() }

                val mimeType = when {
                    isDash || videoStreamUrl.contains(".mpd") -> MimeTypes.APPLICATION_MPD
                    isHls || videoStreamUrl.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
                    videoStreamUrl.contains(".webm") -> MimeTypes.VIDEO_WEBM
                    videoStreamUrl.contains(".mp4") -> MimeTypes.VIDEO_MP4
                    else -> null
                }

                val mediaItemBuilder = MediaItem.Builder()
                    .setUri(Uri.parse(videoStreamUrl))
                    .setMediaMetadata(metadata)

                if (mimeType != null) {
                    mediaItemBuilder.setMimeType(mimeType)
                }

                val mediaItem = mediaItemBuilder.build()
                player.setMediaItem(mediaItem)
            }

            player.prepare()
            if (startPosMs > 0L) {
                player.seekTo(startPosMs)
            }
            player.playWhenReady = true
            player.play()

            if (PlayerHolder.backgroundPipMode > 0 || PlayerHolder.isBackgroundPlayEnabled) {
                MediaPlaybackService.start(
                    context = context,
                    title = video.title,
                    artist = video.channelTitle,
                    isPlaying = true,
                    isYouTube = true,
                    thumbUrl = video.thumbnailUrl
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            onBufferingStateChanged?.invoke(false)
        }
    }

    fun playVideo(
        context: Context,
        video: YouTubeVideo,
        streamUrl: String,
        isDash: Boolean = false,
        isHls: Boolean = false,
        startPosMs: Long = 0L
    ) {
        playVideo(context, video, streamUrl, null, null, emptyList(), isDash, isHls, startPosMs, false)
    }

    @Synchronized
    fun switchToPureAudio(context: Context): Boolean {
        val player = exoPlayer ?: return false
        val video = currentPlayingVideo ?: return false

        try {
            val hasActiveSource = player.playbackState != Player.STATE_IDLE && player.currentMediaItem != null

            // 1. Instantly disable video track decoding at track-selector level (0ms delay, ZERO BUFFERING)
            trackSelector?.let { sel -> sel.parameters = sel.buildUponParameters().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true).build() }

            isAudioOnlyMode = true

            // If player was not playing or had no media, initialize standalone audio
            if (!hasActiveSource) {
                val audioUrl = currentPureAudioUrl ?: currentAudioStreamUrl ?: return false
                val dataSourceFactory = buildCachedDataSourceFactory(context)
                val metadata = MediaMetadata.Builder()
                    .setTitle(video.title)
                    .setArtist(video.channelTitle)
                    .setArtworkUri(Uri.parse(video.thumbnailUrl))
                    .build()
                val audioMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(audioUrl))
                    .setMediaMetadata(metadata)
                    .build()
                val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)
                player.setMediaSource(progressiveFactory.createMediaSource(audioMediaItem))
                player.prepare()
                player.play()
            }

            onAudioModeChanged?.invoke(true)
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    @Synchronized
    fun switchToVideo(context: Context): Boolean {
        val player = exoPlayer ?: return false
        val video = currentPlayingVideo ?: return false

        try {
            val hasActiveSource = player.playbackState != Player.STATE_IDLE && player.currentMediaItem != null

            // 1. Instantly re-enable video track (0ms delay, seamlessly resumes video frames)
            trackSelector?.let { sel -> sel.parameters = sel.buildUponParameters().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false).build() }

            isAudioOnlyMode = false

            // If started purely in audio mode (no video stream was attached), attach video stream
            if (!hasActiveSource || currentVideoStreamUrl == null) {
                val videoUrl = currentVideoStreamUrl ?: return false
                val audioUrl = currentAudioStreamUrl
                val pos = player.currentPosition
                val wasPlaying = player.isPlaying || player.playWhenReady

                val dataSourceFactory = buildCachedDataSourceFactory(context)
                val metadata = MediaMetadata.Builder()
                    .setTitle(video.title)
                    .setArtist(video.channelTitle)
                    .setArtworkUri(Uri.parse(video.thumbnailUrl))
                    .build()
                val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)

                if (!audioUrl.isNullOrBlank() && audioUrl != videoUrl) {
                    val videoMediaItem = MediaItem.Builder().setUri(Uri.parse(videoUrl)).setMediaMetadata(metadata).build()
                    val audioMediaItem = MediaItem.Builder().setUri(Uri.parse(audioUrl)).build()
                    val videoSource = progressiveFactory.createMediaSource(videoMediaItem)
                    val aSource = progressiveFactory.createMediaSource(audioMediaItem)
                    player.setMediaSource(MergingMediaSource(videoSource, aSource))
                } else {
                    val mediaItem = MediaItem.Builder().setUri(Uri.parse(videoUrl)).setMediaMetadata(metadata).build()
                    player.setMediaItem(mediaItem)
                }
                player.prepare()
                if (pos > 0) player.seekTo(pos)
                player.playWhenReady = wasPlaying
            }

            onAudioModeChanged?.invoke(false)
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    @Synchronized
    fun toggleAudioVideoMode(context: Context): Boolean {
        return if (isAudioOnlyMode) {
            isAudioOnlyMode = false
            switchToVideo(context)
            false
        } else {
            isAudioOnlyMode = true
            switchToPureAudio(context)
            true
        }
    }

    fun onAppBackgrounded(context: Context) {
        if (!isBackgroundDataSaverEnabled) return
        if (exoPlayer == null || currentPlayingVideo == null) return
        if (isAudioOnlyMode) return // Already explicitly in audio only

        try {
            val switched = switchToPureAudio(context)
            if (switched) {
                isBackgroundAutoSwitched = true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun onAppForegrounded(context: Context) {
        if (isBackgroundAutoSwitched) {
            isBackgroundAutoSwitched = false
            try {
                switchToVideo(context)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun reattachPlayerView(playerView: PlayerView) {
        val player = getOrCreatePlayer(playerView.context)
        try {
            if (playerView.player != player) {
                playerView.player = player
            }
            playerView.onResume()
        } catch (e: Exception) {
            playerView.player = player
        }
    }

    fun switchPlayerView(fromView: PlayerView?, toView: PlayerView?) {
        val player = exoPlayer ?: return
        try {
            PlayerView.switchTargetView(player, fromView, toView)
        } catch (e: Exception) {
            if (toView != null) toView.player = player
            if (fromView != null && fromView != toView) fromView.player = null
        }
    }

    fun applyPerformanceModeSettings(context: Context) {
        val (minMs, maxMs) = when (PlayerHolder.performanceMode) {
            PlayerHolder.PERF_MODE_ULTRA_FAST -> 30000 to 60000
            PlayerHolder.PERF_MODE_BALANCED -> 15000 to 30000
            else -> 8000 to 15000
        }
        currentMinBufferMs = minMs
        currentMaxBufferMs = maxMs
    }

    fun attachPlayerView(playerView: PlayerView) {
        val player = getOrCreatePlayer(playerView.context)
        if (playerView.player != player) {
            playerView.player = player
        }
    }

    fun detachPlayerView(playerView: PlayerView) {
        if (playerView.player == exoPlayer) {
            playerView.player = null
        }
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        try {
            if (player.isPlaying) {
                player.pause()
            } else {
                player.play()
            }
        } catch (e: Exception) {}
    }

    fun pause() {
        try {
            exoPlayer?.pause()
        } catch (e: Exception) {}
    }

    @Synchronized
    fun stop() {
        stopSponsorCheckLoop()
        try {
            exoPlayer?.stop()
        } catch (e: Exception) {}
        currentPlayingVideo = null
        currentStreamUrl = null
        isAudioOnlyMode = false
    }

    fun play() {
        try {
            exoPlayer?.play()
        } catch (e: Exception) {}
    }

    fun seekTo(posMs: Long) {
        try {
            exoPlayer?.seekTo(posMs)
        } catch (e: Exception) {}
    }

    fun setPlaybackSpeed(speed: Float) {
        try {
            exoPlayer?.playbackParameters = PlaybackParameters(speed)
        } catch (e: Exception) {}
    }

    fun setVideoQuality(maxHeight: Int) {
        val selector = trackSelector ?: return
        try {
            if (maxHeight <= 0) {
                selector.parameters = selector.buildUponParameters()
                    .clearVideoSizeConstraints()
                    .build()
                currentQualityLabel = "Auto"
            } else {
                selector.parameters = selector.buildUponParameters()
                    .setMaxVideoSize(3840, maxHeight)
                    .build()
                currentQualityLabel = "${maxHeight}p"
            }
        } catch (e: Exception) {}
    }

    @Synchronized
    private fun startSponsorCheckLoop() {
        stopSponsorCheckLoop()
        val runnable = object : Runnable {
            override fun run() {
                synchronized(playerLock) {
                    val player = exoPlayer
                    if (player != null && player.playbackState != Player.STATE_IDLE && player.playbackState != Player.STATE_ENDED) {
                        try {
                            if (player.isPlaying) {
                                val currentPos = player.currentPosition
                                val skip = SponsorBlockManager.checkSkip(currentPos)
                                if (skip != null) {
                                    player.seekTo(skip.first)
                                    onSponsorSkipped?.invoke(skip.second)
                                }
                            }
                        } catch (e: Exception) {}
                        mainHandler.postDelayed(this, 250)
                    }
                }
            }
        }
        sponsorCheckRunnable = runnable
        mainHandler.postDelayed(runnable, 250)
    }

    @Synchronized
    private fun stopSponsorCheckLoop() {
        sponsorCheckRunnable?.let {
            mainHandler.removeCallbacks(it)
            sponsorCheckRunnable = null
        }
    }

    @Synchronized
    fun isPlaying(): Boolean = exoPlayer?.isPlaying == true

    fun getPlayer(): ExoPlayer? = exoPlayer

    fun getCurrentPosition(): Long = exoPlayer?.currentPosition ?: 0L

    fun getDuration(): Long = (exoPlayer?.duration ?: 0L).coerceAtLeast(0L)

    fun release() {
        stopSponsorCheckLoop()
        synchronized(playerLock) {
            try {
                exoPlayer?.stop()
                exoPlayer?.release()
            } catch (e: Exception) {}
            exoPlayer = null
            trackSelector = null
            currentPlayingVideo = null
            currentStreamUrl = null
            currentVideoStreamUrl = null
            currentAudioStreamUrl = null
            currentPureAudioUrl = null
            currentAllAudioUrls = emptyList()
            isAudioOnlyMode = false
            isBackgroundAutoSwitched = false
            onPlaybackStateChanged = null
            onBufferingStateChanged = null
            onSponsorSkipped = null
            onPlayerError = null
            onAudioModeChanged = null
        }
    }

    data class AudioTrackOption(
        val groupIndex: Int,
        val trackIndex: Int,
        val language: String?,
        val label: String,
        val isSelected: Boolean
    )

    fun getAvailableAudioTracks(): List<AudioTrackOption> {
        if (currentYouTubeAudioTracks.isNotEmpty()) {
            return currentYouTubeAudioTracks.mapIndexed { idx, track ->
                val isSelected = if (currentSelectedAudioTrackId != null) {
                    track.id == currentSelectedAudioTrackId
                } else {
                    track.url == currentAudioStreamUrl || (currentAudioStreamUrl == null && (track.language.equals("hi", true) || track.isOriginal))
                }
                AudioTrackOption(
                    groupIndex = 0,
                    trackIndex = idx,
                    language = track.language,
                    label = track.name,
                    isSelected = isSelected
                )
            }
        }
        val player = exoPlayer ?: return emptyList()
        val tracks = mutableListOf<AudioTrackOption>()
        val trackGroups = player.currentTracks.groups
        for (gIdx in trackGroups.indices) {
            val group = trackGroups[gIdx]
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (tIdx in 0 until group.length) {
                    val format = group.getTrackFormat(tIdx)
                    val lang = format.language
                    val langLabel = when {
                        lang.isNullOrBlank() -> "Default / Original"
                        lang.equals("hi", true) || lang.equals("hin", true) -> "Hindi"
                        lang.equals("en", true) || lang.equals("eng", true) -> "English"
                        lang.equals("es", true) || lang.equals("spa", true) -> "Spanish"
                        lang.equals("fr", true) || lang.equals("fra", true) -> "French"
                        lang.equals("de", true) || lang.equals("deu", true) -> "German"
                        lang.equals("ja", true) || lang.equals("jpn", true) -> "Japanese"
                        lang.equals("ko", true) || lang.equals("kor", true) -> "Korean"
                        lang.equals("ru", true) || lang.equals("rus", true) -> "Russian"
                        lang.equals("pt", true) || lang.equals("por", true) -> "Portuguese"
                        else -> lang.uppercase()
                    }
                    val fullLabel = if (!format.label.isNullOrBlank()) "${format.label} ($langLabel)" else langLabel
                    tracks.add(
                        AudioTrackOption(
                            groupIndex = gIdx,
                            trackIndex = tIdx,
                            language = lang,
                            label = fullLabel,
                            isSelected = group.isTrackSelected(tIdx)
                        )
                    )
                }
            }
        }
        return tracks
    }

    fun selectAudioTrackByIndex(context: Context, index: Int, option: AudioTrackOption) {
        if (currentYouTubeAudioTracks.isNotEmpty() && index in currentYouTubeAudioTracks.indices) {
            val track = currentYouTubeAudioTracks[index]
            currentSelectedAudioTrackId = track.id
            currentAudioStreamUrl = track.url
            currentPureAudioUrl = track.url

            val player = exoPlayer ?: return
            val curPos = player.currentPosition
            val wasPlaying = player.isPlaying || player.playWhenReady
            val appContext = context.applicationContext

            val metadata = MediaMetadata.Builder()
                .setTitle(currentPlayingVideo?.title ?: "Video")
                .setArtist(currentPlayingVideo?.channelTitle ?: "")
                .setArtworkUri(currentPlayingVideo?.thumbnailUrl?.let { Uri.parse(it) })
                .build()

            val dataSourceFactory = buildCachedDataSourceFactory(appContext)
            val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)

            val videoUrl = currentVideoStreamUrl
            if (!videoUrl.isNullOrBlank() && !isAudioOnlyMode) {
                val videoMediaItem = MediaItem.Builder().setUri(Uri.parse(videoUrl)).setMediaMetadata(metadata).build()
                val audioMediaItem = MediaItem.Builder().setUri(Uri.parse(track.url)).build()
                val videoSource = progressiveFactory.createMediaSource(videoMediaItem)
                val audioSource = progressiveFactory.createMediaSource(audioMediaItem)
                player.setMediaSource(MergingMediaSource(videoSource, audioSource))
            } else {
                val audioMediaItem = MediaItem.Builder().setUri(Uri.parse(track.url)).setMediaMetadata(metadata).build()
                player.setMediaSource(progressiveFactory.createMediaSource(audioMediaItem))
            }
            player.prepare()
            if (curPos > 0) player.seekTo(curPos)
            player.playWhenReady = wasPlaying
            return
        }
        selectAudioTrack(option)
    }

    fun selectAudioTrack(track: AudioTrackOption) {
        val player = exoPlayer ?: return
        val trackGroups = player.currentTracks.groups
        if (track.groupIndex in trackGroups.indices) {
            val group = trackGroups[track.groupIndex].mediaTrackGroup
            player.trackSelectionParameters = player.trackSelectionParameters
                .buildUpon()
                .setOverrideForType(
                    androidx.media3.common.TrackSelectionOverride(group, track.trackIndex)
                )
                .build()
        }
    }

    data class SubtitleTrackOption(
        val groupIndex: Int,
        val trackIndex: Int,
        val language: String?,
        val label: String,
        val isSelected: Boolean
    )

    fun getAvailableSubtitleTracks(): List<SubtitleTrackOption> {
        val player = exoPlayer ?: return emptyList()
        val tracks = mutableListOf<SubtitleTrackOption>()
        val trackGroups = player.currentTracks.groups
        for (gIdx in trackGroups.indices) {
            val group = trackGroups[gIdx]
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (tIdx in 0 until group.length) {
                    val format = group.getTrackFormat(tIdx)
                    val lang = format.language
                    val langLabel = when {
                        lang.isNullOrBlank() -> "Default / Auto-Generated"
                        lang.equals("hi", true) || lang.equals("hin", true) -> "Hindi"
                        lang.equals("en", true) || lang.equals("eng", true) -> "English"
                        lang.equals("es", true) || lang.equals("spa", true) -> "Spanish"
                        lang.equals("fr", true) || lang.equals("fra", true) -> "French"
                        lang.equals("de", true) || lang.equals("deu", true) -> "German"
                        lang.equals("ja", true) || lang.equals("jpn", true) -> "Japanese"
                        lang.equals("ko", true) || lang.equals("kor", true) -> "Korean"
                        lang.equals("ru", true) || lang.equals("rus", true) -> "Russian"
                        lang.equals("pt", true) || lang.equals("por", true) -> "Portuguese"
                        else -> lang.uppercase()
                    }
                    val fullLabel = if (!format.label.isNullOrBlank()) "${format.label} ($langLabel)" else langLabel
                    tracks.add(
                        SubtitleTrackOption(
                            groupIndex = gIdx,
                            trackIndex = tIdx,
                            language = lang,
                            label = fullLabel,
                            isSelected = group.isTrackSelected(tIdx)
                        )
                    )
                }
            }
        }
        return tracks
    }

    fun isCaptionsEnabled(): Boolean {
        val player = exoPlayer ?: return false
        val trackGroups = player.currentTracks.groups
        for (g in trackGroups) {
            if (g.type == C.TRACK_TYPE_TEXT && g.isSelected) {
                return true
            }
        }
        return false
    }

    fun toggleCaptions() {
        val tracks = getAvailableSubtitleTracks()
        if (isCaptionsEnabled()) {
            selectSubtitleTrack(null)
        } else {
            val trackToSelect = tracks.firstOrNull { it.language?.startsWith("hi", true) == true } ?: tracks.firstOrNull()
            selectSubtitleTrack(trackToSelect)
        }
    }

    fun selectSubtitleTrack(track: SubtitleTrackOption?) {
        val player = exoPlayer ?: return
        if (track == null) {
            player.trackSelectionParameters = player.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            return
        }
        val trackGroups = player.currentTracks.groups
        if (track.groupIndex in trackGroups.indices) {
            val group = trackGroups[track.groupIndex].mediaTrackGroup
            player.trackSelectionParameters = player.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .setOverrideForType(
                    androidx.media3.common.TrackSelectionOverride(group, track.trackIndex)
                )
                .build()
        }
    }
}

/**
 * Intelligent Asynchronous Video Stream Pre-Warming Engine.
 * Embedded directly inside YouTubeExoPlayerManager host file (Rule 26).
 */
object YouTubePreWarmEngine {

    private val executor = java.util.concurrent.Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "YtPreWarmWorker").apply {
            priority = Thread.MIN_PRIORITY
        }
    }

    @Volatile
    private var lastPrewarmedVideoId: String? = null

    fun predictAndPrewarmNext(currentVideoId: String?, upcomingList: List<String>?) {
        if (upcomingList.isNullOrEmpty()) return
        val nextId = upcomingList.firstOrNull { it != currentVideoId && it.isNotBlank() }
        if (!nextId.isNullOrBlank()) {
            prewarmVideo(nextId, 480)
        }
    }

    fun prewarmVideo(videoId: String?, preferredResolution: Int = 480) {
        if (videoId.isNullOrBlank() || videoId == lastPrewarmedVideoId) return
        val context = CleanPlayerApp.instance
        val prefs = context.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("pref_yt_prewarm", true)) return

        val prewarmSeconds = prefs.getInt("pref_yt_prewarm_seconds", 15)
        if (prewarmSeconds <= 0) return

        lastPrewarmedVideoId = videoId

        executor.execute {
            try {
                YouTubeStreamResolver.resolveStreams(videoId, preferredResolution) { resolvedStream ->
                    if (resolvedStream != null) {
                        val targetUrl = resolvedStream.videoUrl
                        if (targetUrl.isNotBlank() && targetUrl.startsWith("http")) {
                            prefetchStreamBytes(context, targetUrl, prewarmSeconds)
                        }
                        val audioUrl = resolvedStream.audioUrl
                        if (!audioUrl.isNullOrBlank() && audioUrl.startsWith("http")) {
                            prefetchStreamBytes(context, audioUrl, prewarmSeconds)
                        }
                    }
                }
            } catch (e: Throwable) {}
        }
    }

    private fun prefetchStreamBytes(context: Context, streamUrl: String, seconds: Int) {
        try {
            val cache = YouTubeExoPlayerManager.getMediaCacheInstance(context)
            // ~2.5 Mbps stream bitrate = ~320 KB/s
            val bytesToFetch = (seconds * 320 * 1024L).coerceIn(1024 * 1024L, 25 * 1024 * 1024L)

            val uri = android.net.Uri.parse(streamUrl)
            val dataSpec = androidx.media3.datasource.DataSpec.Builder()
                .setUri(uri)
                .setPosition(0)
                .setLength(bytesToFetch)
                .build()

            val upstream = androidx.media3.datasource.DefaultHttpDataSource.Factory()
                .setUserAgent(DownloaderImpl.USER_AGENT)
                .setConnectTimeoutMs(8000)
                .setReadTimeoutMs(8000)
                .createDataSource()

            val cacheDataSource = androidx.media3.datasource.cache.CacheDataSource(
                cache,
                upstream,
                androidx.media3.datasource.cache.CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR
            )

            val cacheWriter = androidx.media3.datasource.cache.CacheWriter(
                cacheDataSource,
                dataSpec,
                null,
                null
            )
            cacheWriter.cache()
        } catch (e: Throwable) {
            // Fallback via OkHttp Range request
            try {
                val bytesToFetch = seconds * 320 * 1024L
                val req = okhttp3.Request.Builder()
                    .url(streamUrl)
                    .header("Range", "bytes=0-$bytesToFetch")
                    .build()
                DownloaderImpl.getInstance().client.newCall(req).execute().use { resp ->
                    resp.body?.byteStream()?.use { stream ->
                        val buf = ByteArray(16384)
                        var read = 0
                        var total = 0L
                        while (stream.read(buf).also { read = it } != -1 && total < bytesToFetch) {
                            total += read
                        }
                    }
                }
            } catch (ex: Throwable) {}
        }
    }
}
