package com.cleanplayer.app

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import java.io.File
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.PlayerView

/**
 * AndroidX Media3 (ExoPlayer) Dedicated Adaptive Engine for YouTube
 * Supports high-definition MergingMediaSource (Video + Audio) and Ultra-Low Data Pure Audio streams.
 * Includes Automatic Background Data Saver (drops video download in background saving 95% data).
 */
object YouTubeExoPlayerManager {

    var exoPlayer: ExoPlayer? = null
        private set

    var currentPlayingVideo: YouTubeVideo? = null

    var currentStreamUrl: String? = null
        private set

    var currentVideoStreamUrl: String? = null
        private set

    var currentAudioStreamUrl: String? = null
        private set

    var currentPureAudioUrl: String? = null
        private set

    var currentAllAudioUrls: List<String> = emptyList()
        private set

    var currentQualityLabel: String = "Auto"
        private set

    var isAudioOnlyMode: Boolean = false
        private set

    var isBackgroundAutoSwitched: Boolean = false
        private set

    var isBackgroundDataSaverEnabled: Boolean = true

    var currentMinBufferMs: Int = 15000
        private set

    var currentMaxBufferMs: Int = 30000
        private set

    fun applyBufferLimit(context: Context, bufferPref: String) {
        val (minMs, maxMs) = when {
            bufferPref.contains("15s") -> 8000 to 15000
            bufferPref.contains("60s") -> 20000 to 60000
            bufferPref.contains("120s") -> 30000 to 120000
            else -> 15000 to 30000
        }
        currentMinBufferMs = minMs
        currentMaxBufferMs = maxMs
    }

    private var trackSelector: DefaultTrackSelector? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var sponsorCheckRunnable: Runnable? = null
    private val playerLock = Any()
    @Volatile
    private var simpleCache: SimpleCache? = null

    @Synchronized
    private fun buildCachedDataSourceFactory(context: Context): DefaultDataSource.Factory {
        val appContext = context.applicationContext
        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val cache = getMediaCache(appContext)
        val cacheDataSourceFactory = CacheDataSource.Factory()
            .setCache(cache)
            .setUpstreamDataSourceFactory(httpDataSourceFactory)
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

        return DefaultDataSource.Factory(appContext, cacheDataSourceFactory)
    }

    private fun getMediaCache(context: Context): SimpleCache {
        var cache = simpleCache
        if (cache == null) {
            val appContext = context.applicationContext
            val cacheDir = File(appContext.cacheDir, "cleanplayer_yt_cache")
            val prefs = appContext.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
            val sizeMb = prefs.getLong("pref_yt_disk_cache_mb", 256L)
            val evictor = LeastRecentlyUsedCacheEvictor(sizeMb * 1024 * 1024L)
            val databaseProvider = StandaloneDatabaseProvider(appContext)
            cache = SimpleCache(cacheDir, evictor, databaseProvider)
            simpleCache = cache
        }
        return cache
    }

    @Synchronized
    fun updateDiskCacheSize(context: Context, sizeMb: Long) {
        val appContext = context.applicationContext
        val prefs = appContext.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        prefs.edit().putLong("pref_yt_disk_cache_mb", sizeMb).apply()
        try {
            simpleCache?.release()
            simpleCache = null
        } catch (e: Exception) {}
    }

    private var errorRetryCount = 0

    var onSponsorSkipped: ((category: String) -> Unit)? = null
    var onPlaybackStateChanged: ((isPlaying: Boolean) -> Unit)? = null
    var onBufferingStateChanged: ((isBuffering: Boolean) -> Unit)? = null
    var onPlayerError: ((error: PlaybackException) -> Unit)? = null
    var onAudioSessionIdChanged: ((sessionId: Int) -> Unit)? = null
    var onAudioModeChanged: ((isAudioOnly: Boolean) -> Unit)? = null
    var onVideoEnded: (() -> Unit)? = null

    @Synchronized
    fun getOrCreatePlayer(context: Context): ExoPlayer {
        val existing = exoPlayer
        if (existing != null) return existing

        val appContext = context.applicationContext
        val selector = DefaultTrackSelector(appContext)
        trackSelector = selector

        val dataSourceFactory = buildCachedDataSourceFactory(context)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)

        val prefs = appContext.getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE)
        val bufferPref = prefs.getString("pref_yt_buffer_limit", "30s") ?: "30s"
        val (minMs, maxMs) = when {
            bufferPref.contains("15s") -> 8000 to 15000
            bufferPref.contains("60s") -> 20000 to 60000
            bufferPref.contains("120s") -> 30000 to 120000
            else -> 15000 to 30000
        }
        currentMinBufferMs = minMs
        currentMaxBufferMs = maxMs

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                minMs,
                maxMs,
                500,   // 500ms playback start
                1200   // 1.2s resume buffer
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .setBackBuffer(5000, false)
            .build()

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val player = ExoPlayer.Builder(appContext)
            .setMediaSourceFactory(mediaSourceFactory)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build()

        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId > 0) {
                    onAudioSessionIdChanged?.invoke(audioSessionId)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                onPlaybackStateChanged?.invoke(isPlaying)
                if (isPlaying) {
                    errorRetryCount = 0
                    startSponsorCheckLoop()
                } else {
                    stopSponsorCheckLoop()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> {
                        onBufferingStateChanged?.invoke(true)
                    }
                    Player.STATE_READY -> {
                        errorRetryCount = 0
                        onBufferingStateChanged?.invoke(false)
                    }
                    Player.STATE_ENDED -> {
                        stopSponsorCheckLoop()
                        onBufferingStateChanged?.invoke(false)
                        onPlaybackStateChanged?.invoke(false)
                        onVideoEnded?.invoke()
                    }
                    Player.STATE_IDLE -> {
                        onBufferingStateChanged?.invoke(false)
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                error.printStackTrace()
                onBufferingStateChanged?.invoke(false)

                // Resilient Error Handling & Fallback Stream Switching
                val currentVideo = currentPlayingVideo
                if (currentVideo != null && errorRetryCount < 2) {
                    errorRetryCount++
                    mainHandler.postDelayed({
                        try {
                            if (exoPlayer != null && currentPlayingVideo?.id == currentVideo.id) {
                                // If video failed, fallback to pure audio or alternative audio stream
                                if (!isAudioOnlyMode && !currentPureAudioUrl.isNullOrBlank()) {
                                    switchToPureAudio(context)
                                } else {
                                    exoPlayer?.prepare()
                                    exoPlayer?.play()
                                }
                            }
                        } catch (e: Exception) {}
                    }, 800)
                    return
                }

                errorRetryCount = 0
                onPlaybackStateChanged?.invoke(false)
                onPlayerError?.invoke(error)
            }
        })

        exoPlayer = player
        return player
    }

    @Synchronized
    fun playVideo(
        context: Context,
        video: YouTubeVideo,
        videoStreamUrl: String,
        audioStreamUrl: String? = null,
        pureAudioUrl: String? = null,
        allAudioUrls: List<String> = emptyList(),
        isDash: Boolean = false,
        isHls: Boolean = false,
        startPosMs: Long = 0L,
        startInAudioOnly: Boolean = false
    ) {
        val player = getOrCreatePlayer(context)
        val appContext = context.applicationContext
        currentPlayingVideo = video
        currentStreamUrl = videoStreamUrl
        currentVideoStreamUrl = videoStreamUrl
        currentAudioStreamUrl = audioStreamUrl
        currentPureAudioUrl = pureAudioUrl ?: audioStreamUrl ?: videoStreamUrl
        currentAllAudioUrls = allAudioUrls
        isBackgroundAutoSwitched = false
        isAudioOnlyMode = startInAudioOnly

        val metadata = MediaMetadata.Builder()
            .setTitle(video.title)
            .setArtist(video.channelTitle)
            .setArtworkUri(Uri.parse(video.thumbnailUrl))
            .build()

        val httpDataSourceFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)

        val dataSourceFactory = DefaultDataSource.Factory(appContext, httpDataSourceFactory)

        // Fetch SponsorBlock segments
        SponsorBlockManager.fetchSegments(video.id)

        try {
            onBufferingStateChanged?.invoke(true)

            if (isAudioOnlyMode && !currentPureAudioUrl.isNullOrBlank()) {
                // PURE AUDIO PLAYBACK - ZERO VIDEO DATA
                trackSelector?.parameters = trackSelector?.buildUponParameters()
                    ?.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
                    ?.build() ?: trackSelector?.parameters!!

                val audioMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(currentPureAudioUrl))
                    .setMediaMetadata(metadata)
                    .build()
                val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)
                val audioSource = progressiveFactory.createMediaSource(audioMediaItem)
                player.setMediaSource(audioSource)
            } else if (!audioStreamUrl.isNullOrBlank() && audioStreamUrl != videoStreamUrl) {
                // High Definition Merged Source (Video + Audio)
                trackSelector?.parameters = trackSelector?.buildUponParameters()
                    ?.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false)
                    ?.build() ?: trackSelector?.parameters!!

                val videoMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(videoStreamUrl))
                    .setMediaMetadata(metadata)
                    .build()

                val audioMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(audioStreamUrl))
                    .build()

                val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)
                val videoSource = progressiveFactory.createMediaSource(videoMediaItem)
                val audioSource = progressiveFactory.createMediaSource(audioMediaItem)
                val mergedSource = MergingMediaSource(videoSource, audioSource)

                player.setMediaSource(mergedSource)
            } else {
                trackSelector?.parameters = trackSelector?.buildUponParameters()
                    ?.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false)
                    ?.build() ?: trackSelector?.parameters!!

                val mimeType = when {
                    isDash || videoStreamUrl.contains(".mpd") -> MimeTypes.APPLICATION_MPD
                    isHls || videoStreamUrl.contains(".m3u8") -> MimeTypes.APPLICATION_M3U8
                    videoStreamUrl.contains(".webm") -> MimeTypes.VIDEO_WEBM
                    videoStreamUrl.contains(".mp4") -> MimeTypes.VIDEO_MP4
                    else -> null
                }

                val mediaItemBuilder = MediaItem.Builder()
                    .setUri(Uri.parse(videoStreamUrl))
                    .setMediaMetadata(metadata)

                if (mimeType != null) {
                    mediaItemBuilder.setMimeType(mimeType)
                }

                val mediaItem = mediaItemBuilder.build()
                player.setMediaItem(mediaItem)
            }

            player.prepare()
            if (startPosMs > 0L) {
                player.seekTo(startPosMs)
            }
            player.playWhenReady = true
            player.play()

            if (PlayerHolder.backgroundPipMode > 0 || PlayerHolder.isBackgroundPlayEnabled) {
                MediaPlaybackService.start(
                    context = context,
                    title = video.title,
                    artist = video.channelTitle,
                    isPlaying = true,
                    isYouTube = true,
                    thumbUrl = video.thumbnailUrl
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            onBufferingStateChanged?.invoke(false)
        }
    }

    fun playVideo(
        context: Context,
        video: YouTubeVideo,
        streamUrl: String,
        isDash: Boolean = false,
        isHls: Boolean = false,
        startPosMs: Long = 0L
    ) {
        playVideo(context, video, streamUrl, null, null, emptyList(), isDash, isHls, startPosMs, false)
    }

    @Synchronized
    fun switchToPureAudio(context: Context): Boolean {
        val player = exoPlayer ?: return false
        val video = currentPlayingVideo ?: return false

        try {
            val hasActiveSource = player.playbackState != Player.STATE_IDLE && player.currentMediaItem != null

            // 1. Instantly disable video track decoding at track-selector level (0ms delay, ZERO BUFFERING)
            trackSelector?.parameters = trackSelector?.buildUponParameters()
                ?.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
                ?.build() ?: trackSelector?.parameters!!

            isAudioOnlyMode = true

            // If player was not playing or had no media, initialize standalone audio
            if (!hasActiveSource) {
                val audioUrl = currentPureAudioUrl ?: currentAudioStreamUrl ?: return false
                val dataSourceFactory = buildCachedDataSourceFactory(context)
                val metadata = MediaMetadata.Builder()
                    .setTitle(video.title)
                    .setArtist(video.channelTitle)
                    .setArtworkUri(Uri.parse(video.thumbnailUrl))
                    .build()
                val audioMediaItem = MediaItem.Builder()
                    .setUri(Uri.parse(audioUrl))
                    .setMediaMetadata(metadata)
                    .build()
                val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)
                player.setMediaSource(progressiveFactory.createMediaSource(audioMediaItem))
                player.prepare()
                player.play()
            }

            onAudioModeChanged?.invoke(true)
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    @Synchronized
    fun switchToVideo(context: Context): Boolean {
        val player = exoPlayer ?: return false
        val video = currentPlayingVideo ?: return false

        try {
            val hasActiveSource = player.playbackState != Player.STATE_IDLE && player.currentMediaItem != null

            // 1. Instantly re-enable video track (0ms delay, seamlessly resumes video frames)
            trackSelector?.parameters = trackSelector?.buildUponParameters()
                ?.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, false)
                ?.build() ?: trackSelector?.parameters!!

            isAudioOnlyMode = false

            // If started purely in audio mode (no video stream was attached), attach video stream
            if (!hasActiveSource || currentVideoStreamUrl == null) {
                val videoUrl = currentVideoStreamUrl ?: return false
                val audioUrl = currentAudioStreamUrl
                val pos = player.currentPosition
                val wasPlaying = player.isPlaying || player.playWhenReady

                val dataSourceFactory = buildCachedDataSourceFactory(context)
                val metadata = MediaMetadata.Builder()
                    .setTitle(video.title)
                    .setArtist(video.channelTitle)
                    .setArtworkUri(Uri.parse(video.thumbnailUrl))
                    .build()
                val progressiveFactory = ProgressiveMediaSource.Factory(dataSourceFactory)

                if (!audioUrl.isNullOrBlank() && audioUrl != videoUrl) {
                    val videoMediaItem = MediaItem.Builder().setUri(Uri.parse(videoUrl)).setMediaMetadata(metadata).build()
                    val audioMediaItem = MediaItem.Builder().setUri(Uri.parse(audioUrl)).build()
                    val videoSource = progressiveFactory.createMediaSource(videoMediaItem)
                    val aSource = progressiveFactory.createMediaSource(audioMediaItem)
                    player.setMediaSource(MergingMediaSource(videoSource, aSource))
                } else {
                    val mediaItem = MediaItem.Builder().setUri(Uri.parse(videoUrl)).setMediaMetadata(metadata).build()
                    player.setMediaItem(mediaItem)
                }
                player.prepare()
                if (pos > 0) player.seekTo(pos)
                player.playWhenReady = wasPlaying
            }

            onAudioModeChanged?.invoke(false)
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    @Synchronized
    fun toggleAudioVideoMode(context: Context): Boolean {
        return if (isAudioOnlyMode) {
            isAudioOnlyMode = false
            switchToVideo(context)
            false
        } else {
            isAudioOnlyMode = true
            switchToPureAudio(context)
            true
        }
    }

    fun onAppBackgrounded(context: Context) {
        if (!isBackgroundDataSaverEnabled) return
        if (exoPlayer == null || currentPlayingVideo == null) return
        if (isAudioOnlyMode) return // Already explicitly in audio only

        try {
            val switched = switchToPureAudio(context)
            if (switched) {
                isBackgroundAutoSwitched = true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun onAppForegrounded(context: Context) {
        if (isBackgroundAutoSwitched) {
            isBackgroundAutoSwitched = false
            try {
                switchToVideo(context)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun reattachPlayerView(playerView: PlayerView) {
        val player = getOrCreatePlayer(playerView.context)
        try {
            if (playerView.player != player) {
                playerView.player = player
            }
            playerView.onResume()
        } catch (e: Exception) {
            playerView.player = player
        }
    }

    fun switchPlayerView(fromView: PlayerView?, toView: PlayerView?) {
        val player = exoPlayer ?: return
        try {
            PlayerView.switchTargetView(player, fromView, toView)
        } catch (e: Exception) {
            if (toView != null) toView.player = player
            if (fromView != null && fromView != toView) fromView.player = null
        }
    }

    fun attachPlayerView(playerView: PlayerView) {
        val player = getOrCreatePlayer(playerView.context)
        if (playerView.player != player) {
            playerView.player = player
        }
    }

    fun detachPlayerView(playerView: PlayerView) {
        if (playerView.player == exoPlayer) {
            playerView.player = null
        }
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        try {
            if (player.isPlaying) {
                player.pause()
            } else {
                player.play()
            }
        } catch (e: Exception) {}
    }

    fun pause() {
        try {
            exoPlayer?.pause()
        } catch (e: Exception) {}
    }

    @Synchronized
    fun stop() {
        stopSponsorCheckLoop()
        try {
            exoPlayer?.stop()
        } catch (e: Exception) {}
        currentPlayingVideo = null
        currentStreamUrl = null
        isAudioOnlyMode = false
    }

    fun play() {
        try {
            exoPlayer?.play()
        } catch (e: Exception) {}
    }

    fun seekTo(posMs: Long) {
        try {
            exoPlayer?.seekTo(posMs)
        } catch (e: Exception) {}
    }

    fun setPlaybackSpeed(speed: Float) {
        try {
            exoPlayer?.playbackParameters = PlaybackParameters(speed)
        } catch (e: Exception) {}
    }

    fun setVideoQuality(maxHeight: Int) {
        val selector = trackSelector ?: return
        try {
            if (maxHeight <= 0) {
                selector.parameters = selector.buildUponParameters()
                    .clearVideoSizeConstraints()
                    .build()
                currentQualityLabel = "Auto"
            } else {
                selector.parameters = selector.buildUponParameters()
                    .setMaxVideoSize(3840, maxHeight)
                    .build()
                currentQualityLabel = "${maxHeight}p"
            }
        } catch (e: Exception) {}
    }

    @Synchronized
    private fun startSponsorCheckLoop() {
        stopSponsorCheckLoop()
        val runnable = object : Runnable {
            override fun run() {
                synchronized(playerLock) {
                    val player = exoPlayer
                    if (player != null && player.playbackState != Player.STATE_IDLE && player.playbackState != Player.STATE_ENDED) {
                        try {
                            if (player.isPlaying) {
                                val currentPos = player.currentPosition
                                val skip = SponsorBlockManager.checkSkip(currentPos)
                                if (skip != null) {
                                    player.seekTo(skip.first)
                                    onSponsorSkipped?.invoke(skip.second)
                                }
                            }
                        } catch (e: Exception) {}
                        mainHandler.postDelayed(this, 250)
                    }
                }
            }
        }
        sponsorCheckRunnable = runnable
        mainHandler.postDelayed(runnable, 250)
    }

    @Synchronized
    private fun stopSponsorCheckLoop() {
        sponsorCheckRunnable?.let {
            mainHandler.removeCallbacks(it)
            sponsorCheckRunnable = null
        }
    }

    @Synchronized
    fun isPlaying(): Boolean = exoPlayer?.isPlaying == true

    fun getCurrentPosition(): Long = exoPlayer?.currentPosition ?: 0L

    fun getDuration(): Long = (exoPlayer?.duration ?: 0L).coerceAtLeast(0L)

    fun release() {
        stopSponsorCheckLoop()
        synchronized(playerLock) {
            try {
                exoPlayer?.stop()
                exoPlayer?.release()
            } catch (e: Exception) {}
            exoPlayer = null
            trackSelector = null
            currentPlayingVideo = null
            currentStreamUrl = null
            currentVideoStreamUrl = null
            currentAudioStreamUrl = null
            currentPureAudioUrl = null
            currentAllAudioUrls = emptyList()
            isAudioOnlyMode = false
            isBackgroundAutoSwitched = false
            onPlaybackStateChanged = null
            onBufferingStateChanged = null
            onSponsorSkipped = null
            onPlayerError = null
            onAudioModeChanged = null
        }
    }

    data class AudioTrackOption(
        val groupIndex: Int,
        val trackIndex: Int,
        val language: String?,
        val label: String,
        val isSelected: Boolean
    )

    fun getAvailableAudioTracks(): List<AudioTrackOption> {
        val player = exoPlayer ?: return emptyList()
        val tracks = mutableListOf<AudioTrackOption>()
        val trackGroups = player.currentTracks.groups
        for (gIdx in trackGroups.indices) {
            val group = trackGroups[gIdx]
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (tIdx in 0 until group.length) {
                    val format = group.getTrackFormat(tIdx)
                    val lang = format.language
                    val langLabel = when {
                        lang.isNullOrBlank() -> "Default / Original"
                        lang.equals("hi", true) || lang.equals("hin", true) -> "Hindi"
                        lang.equals("en", true) || lang.equals("eng", true) -> "English"
                        lang.equals("es", true) || lang.equals("spa", true) -> "Spanish"
                        lang.equals("fr", true) || lang.equals("fra", true) -> "French"
                        lang.equals("de", true) || lang.equals("deu", true) -> "German"
                        lang.equals("ja", true) || lang.equals("jpn", true) -> "Japanese"
                        lang.equals("ko", true) || lang.equals("kor", true) -> "Korean"
                        lang.equals("ru", true) || lang.equals("rus", true) -> "Russian"
                        lang.equals("pt", true) || lang.equals("por", true) -> "Portuguese"
                        else -> lang.uppercase()
                    }
                    val fullLabel = if (!format.label.isNullOrBlank()) "${format.label} ($langLabel)" else langLabel
                    tracks.add(
                        AudioTrackOption(
                            groupIndex = gIdx,
                            trackIndex = tIdx,
                            language = lang,
                            label = fullLabel,
                            isSelected = group.isTrackSelected(tIdx)
                        )
                    )
                }
            }
        }
        return tracks
    }

    fun selectAudioTrack(track: AudioTrackOption) {
        val player = exoPlayer ?: return
        val trackGroups = player.currentTracks.groups
        if (track.groupIndex in trackGroups.indices) {
            val group = trackGroups[track.groupIndex].mediaTrackGroup
            player.trackSelectionParameters = player.trackSelectionParameters
                .buildUpon()
                .setOverrideForType(
                    androidx.media3.common.TrackSelectionOverride(group, track.trackIndex)
                )
                .build()
        }
    }

}
