package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.kiosk.KioskInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.Executors

data class VideoStreamFormat(
    val qualityLabel: String,
    val resolution: Int,
    val url: String,
    val audioUrl: String? = null
)

object YouTubeFeedRepository {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    val defaultFeed = emptyList<YouTubeVideo>()
    val defaultShorts = emptyList<YouTubeVideo>()

    fun getFeed(category: String, callback: (List<YouTubeVideo>) -> Unit) {
        executor.execute {
            val onlineVideos = mutableListOf<YouTubeVideo>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)

                if (category.equals("All", ignoreCase = true)) {
                    // Try official Trending Kiosk
                    try {
                        val kiosk = KioskInfo.getInfo(service, "https://www.youtube.com/feed/trending")
                        val streamItems = kiosk.relatedItems.filterIsInstance<StreamInfoItem>()
                        for (item in streamItems) {
                            val vId = item.url.substringAfter("v=").substringBefore("&")
                            val lengthSec = item.duration.toInt()
                            val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                            val viewCount = item.viewCount
                            val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                            onlineVideos.add(
                                YouTubeVideo(
                                    id = vId,
                                    title = item.name ?: "",
                                    channelTitle = item.uploaderName ?: "",
                                    channelAvatarUrl = null,
                                    thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                    duration = durStr,
                                    views = viewStr,
                                    uploadDate = item.textualUploadDate ?: "Trending",
                                    category = "Trending"
                                )
                            )
                        }
                    } catch (e: Exception) {}

                    // Fallback to Live Trending Search if Kiosk is restricted or empty
                    if (onlineVideos.isEmpty()) {
                        val searchExtractor = service.getSearchExtractor("trending songs india", listOf("videos"), "")
                        searchExtractor.fetchPage()
                        val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                        for (item in streamItems) {
                            val vId = item.url.substringAfter("v=").substringBefore("&")
                            val lengthSec = item.duration.toInt()
                            val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                            val viewCount = item.viewCount
                            val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                            onlineVideos.add(
                                YouTubeVideo(
                                    id = vId,
                                    title = item.name ?: "",
                                    channelTitle = item.uploaderName ?: "",
                                    channelAvatarUrl = null,
                                    thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                    duration = durStr,
                                    views = viewStr,
                                    uploadDate = item.textualUploadDate ?: "Popular",
                                    category = "Trending"
                                )
                            )
                        }
                    }
                } else {
                    val query = when (category.lowercase()) {
                        "music" -> "trending music"
                        "gaming" -> "trending gaming"
                        "news" -> "trending news"
                        "podcasts" -> "popular podcasts"
                        "trending" -> "trending videos"
                        "live" -> "live stream"
                        else -> category
                    }
                    val searchExtractor = service.getSearchExtractor(query, listOf("videos"), "")
                    searchExtractor.fetchPage()
                    val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                    for (item in streamItems) {
                        val vId = item.url.substringAfter("v=").substringBefore("&")
                        val lengthSec = item.duration.toInt()
                        val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                        val viewCount = item.viewCount
                        val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                        onlineVideos.add(
                            YouTubeVideo(
                                id = vId,
                                title = item.name ?: "",
                                channelTitle = item.uploaderName ?: "",
                                channelAvatarUrl = null,
                                thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                duration = durStr,
                                views = viewStr,
                                uploadDate = item.textualUploadDate ?: category,
                                category = category
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            mainHandler.post { callback(onlineVideos) }
        }
    }

    fun getShorts(callback: (List<YouTubeVideo>) -> Unit) {
        executor.execute {
            val shortsList = mutableListOf<YouTubeVideo>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)
                val searchExtractor = service.getSearchExtractor("#shorts viral trending", listOf("videos"), "")
                searchExtractor.fetchPage()
                val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                for (item in streamItems.take(8)) {
                    val vId = item.url.substringAfter("v=").substringBefore("&")
                    val viewCount = item.viewCount
                    val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                    shortsList.add(
                        YouTubeVideo(
                            id = vId,
                            title = item.name ?: "",
                            channelTitle = item.uploaderName ?: "",
                            thumbnailUrl = "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                            duration = "00:30",
                            views = viewStr,
                            category = "Shorts",
                            isShort = true
                        )
                    )
                }
            } catch (e: Exception) {}

            mainHandler.post { callback(shortsList) }
        }
    }

    fun searchVideos(query: String, callback: (List<YouTubeVideo>) -> Unit) {
        executor.execute {
            val onlineVideos = mutableListOf<YouTubeVideo>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)
                val searchExtractor = service.getSearchExtractor(query, listOf("videos"), "")
                searchExtractor.fetchPage()
                val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                for (item in streamItems) {
                    val vId = item.url.substringAfter("v=").substringBefore("&")
                    val lengthSec = item.duration.toInt()
                    val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                    val viewCount = item.viewCount
                    val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                    onlineVideos.add(
                        YouTubeVideo(
                            id = vId,
                            title = item.name ?: "",
                            channelTitle = item.uploaderName ?: "",
                            channelAvatarUrl = null,
                            thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                            duration = durStr,
                            views = viewStr,
                            uploadDate = item.textualUploadDate ?: "Search",
                            category = "Search"
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            mainHandler.post { callback(onlineVideos) }
        }
    }

    var currentAvailableFormats: List<VideoStreamFormat> = emptyList()

    fun resolveStreamFormats(
        context: Context,
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>, dashUrl: String?, hlsUrl: String?) -> Unit
    ) {
        YouTubeStreamResolver.resolveStreams(videoId) { resolved ->
            if (resolved != null) {
                val formats = resolved.availableQualities.map { opt ->
                    VideoStreamFormat(
                        qualityLabel = opt.qualityLabel,
                        resolution = opt.resolution,
                        url = opt.videoUrl,
                        audioUrl = opt.audioUrl
                    )
                }
                currentAvailableFormats = formats
                callback(resolved.videoUrl, formats, null, null)
            } else {
                currentAvailableFormats = emptyList()
                callback("", emptyList(), null, null)
            }
        }
    }

    fun resolveStreamFormats(
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>, dashUrl: String?, hlsUrl: String?) -> Unit
    ) {
        YouTubeStreamResolver.resolveStreams(videoId) { resolved ->
            if (resolved != null) {
                val formats = resolved.availableQualities.map { opt ->
                    VideoStreamFormat(
                        qualityLabel = opt.qualityLabel,
                        resolution = opt.resolution,
                        url = opt.videoUrl,
                        audioUrl = opt.audioUrl
                    )
                }
                currentAvailableFormats = formats
                callback(resolved.videoUrl, formats, null, null)
            } else {
                currentAvailableFormats = emptyList()
                callback("", emptyList(), null, null)
            }
        }
    }

    fun resolveStreamFormats(
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>) -> Unit
    ) {
        resolveStreamFormats(videoId) { bestUrl, allFormats, _, _ ->
            callback(bestUrl, allFormats)
        }
    }

    fun resolveStreamUrl(videoId: String, callback: (streamUrl: String) -> Unit) {
        resolveStreamFormats(videoId) { bestUrl, _ ->
            callback(bestUrl)
        }
    }
}
