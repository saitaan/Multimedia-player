package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.kiosk.KioskInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.Executors

data class VideoStreamFormat(
    val qualityLabel: String,
    val resolution: Int,
    val url: String,
    val audioUrl: String? = null
)

object YouTubeFeedRepository {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())


    val defaultFeed = listOf(
        YouTubeVideo(
            id = "jfKfPfyJRdk",
            title = "lofi hip hop radio 📚 - beats to relax/study to",
            channelTitle = "Lofi Girl",
            channelAvatarUrl = "https://i.ytimg.com/vi/jfKfPfyJRdk/mqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/jfKfPfyJRdk/mqdefault.jpg",
            duration = "LIVE",
            views = "45K watching",
            uploadDate = "Streaming",
            category = "Music",
            likes = "7.8M",
            commentsCount = "450K"
        ),
        YouTubeVideo(
            id = "kffacxfA7G4",
            title = "Justin Bieber - Baby ft. Ludacris (Official Music Video)",
            channelTitle = "Justin Bieber",
            channelAvatarUrl = "https://i.ytimg.com/vi/kffacxfA7G4/mqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/kffacxfA7G4/mqdefault.jpg",
            duration = "03:45",
            views = "3.2B views",
            uploadDate = "Music",
            category = "Music",
            likes = "21M",
            commentsCount = "12M"
        )
    )

    fun getFeed(category: String, callback: (List<YouTubeVideo>) -> Unit) {
        resetPagination()
        executor.execute {
            val onlineVideos = mutableListOf<YouTubeVideo>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)

                if (category.equals("All", ignoreCase = true)) {
                    // Try official Trending Kiosk
                    try {
                        val kiosk = KioskInfo.getInfo(service, "https://www.youtube.com/feed/trending")
                        val streamItems = kiosk.relatedItems.filterIsInstance<StreamInfoItem>()
                        for (item in streamItems) {
                            val vId = item.url.substringAfter("v=").substringBefore("&")
                            val lengthSec = item.duration.toInt()
                            val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                            val viewCount = item.viewCount
                            val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                            onlineVideos.add(
                                YouTubeVideo(
                                    id = vId,
                                    title = item.name ?: "",
                                    channelTitle = item.uploaderName ?: "",
                                    channelAvatarUrl = try { item.uploaderAvatarUrl } catch (e: Throwable) { null },
                                    thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                    duration = durStr,
                                    views = viewStr,
                                    uploadDate = item.textualUploadDate ?: "Trending",
                                    category = "Trending"
                                )
                            )
                        }
                    } catch (e: Exception) {}

                    // Fallback to Live Trending Search if Kiosk is restricted or empty
                    if (onlineVideos.isEmpty()) {
                        val searchExtractor = service.getSearchExtractor("trending songs india", listOf("videos"), "")
                        searchExtractor.fetchPage()
                        val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                        for (item in streamItems) {
                            val vId = item.url.substringAfter("v=").substringBefore("&")
                            val lengthSec = item.duration.toInt()
                            val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                            val viewCount = item.viewCount
                            val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                            onlineVideos.add(
                                YouTubeVideo(
                                    id = vId,
                                    title = item.name ?: "",
                                    channelTitle = item.uploaderName ?: "",
                                    channelAvatarUrl = try { item.uploaderAvatarUrl } catch (e: Throwable) { null },
                                    thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                    duration = durStr,
                                    views = viewStr,
                                    uploadDate = item.textualUploadDate ?: "Popular",
                                    category = "Trending"
                                )
                            )
                        }
                    }
                } else {
                    val query = when (category.lowercase()) {
                        "music" -> "trending music"
                        "gaming" -> "trending gaming"
                        "news" -> "trending news"
                        "podcasts" -> "popular podcasts"
                        "trending" -> "trending videos"
                        "live" -> "live stream"
                        else -> category
                    }
                    val searchExtractor = service.getSearchExtractor(query, listOf("videos"), "")
                    searchExtractor.fetchPage()
                    val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                    for (item in streamItems) {
                        val vId = item.url.substringAfter("v=").substringBefore("&")
                        val lengthSec = item.duration.toInt()
                        val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                        val viewCount = item.viewCount
                        val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                        onlineVideos.add(
                            YouTubeVideo(
                                id = vId,
                                title = item.name ?: "",
                                channelTitle = item.uploaderName ?: "",
                                channelAvatarUrl = try { item.uploaderAvatarUrl } catch (e: Throwable) { null },
                                thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                duration = durStr,
                                views = viewStr,
                                uploadDate = item.textualUploadDate ?: category,
                                category = category
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            mainHandler.post { callback(onlineVideos) }
        }
    }

    private var currentPage = 1
    private var isFetchingMore = false

    fun resetPagination() {
        currentPage = 1
        isFetchingMore = false
    }

    fun loadMoreFeed(category: String, callback: (List<YouTubeVideo>) -> Unit) {
        if (isFetchingMore) {
            mainHandler.post { callback(emptyList()) }
            return
        }
        isFetchingMore = true
        executor.execute {
            val moreVideos = mutableListOf<YouTubeVideo>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)

                currentPage++
                val queries = when (category.lowercase()) {
                    "all" -> listOf("trending music india", "trending songs new", "viral videos 2026", "top bollywood songs", "latest entertainment", "superhit songs playlist")
                    "music" -> listOf("top hits songs 2026", "bollywood romantic songs", "punjabi latest songs", "global top hits", "arijit singh best songs")
                    "gaming" -> listOf("popular gaming walkthrough", "top esports tournaments", "gaming highlights 2026")
                    "news" -> listOf("latest news live india", "national headlines today", "breaking news live")
                    "podcasts" -> listOf("popular podcasts hindi", "trending talks podcast", "the ranveer show clips")
                    "live" -> listOf("live news streams", "live concerts music", "live music radio 24/7")
                    else -> listOf("$category latest", "$category viral", "$category top trending")
                }
                val query = queries[(currentPage - 1) % queries.size]
                val searchExtractor = service.getSearchExtractor(query, listOf("videos"), "")
                searchExtractor.fetchPage()
                val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                for (item in streamItems) {
                    val vId = item.url.substringAfter("v=").substringBefore("&")
                    val lengthSec = item.duration.toInt()
                    val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                    val viewCount = item.viewCount
                    val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                    moreVideos.add(
                        YouTubeVideo(
                            id = vId,
                            title = item.name ?: "",
                            channelTitle = item.uploaderName ?: "",
                            channelAvatarUrl = try { item.uploaderAvatarUrl } catch (e: Throwable) { null },
                            thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                            duration = durStr,
                            views = viewStr,
                            uploadDate = item.textualUploadDate ?: category,
                            category = category
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isFetchingMore = false
            }

            mainHandler.post { callback(moreVideos) }
        }
    }


    fun searchVideos(query: String, callback: (List<YouTubeVideo>) -> Unit) {
        executor.execute {
            val onlineVideos = mutableListOf<YouTubeVideo>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)
                val searchExtractor = service.getSearchExtractor(query, listOf("videos"), "")
                searchExtractor.fetchPage()
                val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                for (item in streamItems) {
                    val vId = item.url.substringAfter("v=").substringBefore("&")
                    val lengthSec = item.duration.toInt()
                    val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                    val viewCount = item.viewCount
                    val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                    onlineVideos.add(
                        YouTubeVideo(
                            id = vId,
                            title = item.name ?: "",
                            channelTitle = item.uploaderName ?: "",
                            channelAvatarUrl = try { item.uploaderAvatarUrl } catch (e: Throwable) { null },
                            thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                            duration = durStr,
                            views = viewStr,
                            uploadDate = item.textualUploadDate ?: "Search",
                            category = "Search"
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            mainHandler.post { callback(onlineVideos) }
        }
    }

    fun getChannelDetails(
        channelTitle: String,
        fallbackAvatar: String?,
        callback: (
            channelName: String,
            handle: String,
            avatarUrl: String?,
            bannerUrl: String?,
            subscriberText: String,
            videoCountText: String,
            description: String,
            videos: List<YouTubeVideo>
        ) -> Unit
    ) {
        executor.execute {
            var avatar = fallbackAvatar
            var banner: String? = null
            var subText = "45.8 lakh subscribers"
            var videoCountText = "3.1K videos"
            var desc = "Official Channel • Videos & Updates"
            val cleanHandle = "@" + channelTitle.replace(" ", "").lowercase()
            val videos = mutableListOf<YouTubeVideo>()

            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)

                // 1. Search for channel info
                try {
                    val channelSearch = service.getSearchExtractor(channelTitle, listOf("channels"), "")
                    channelSearch.fetchPage()
                    val channelItem = channelSearch.initialPage.items.filterIsInstance<org.schabi.newpipe.extractor.channel.ChannelInfoItem>().firstOrNull()
                    if (channelItem != null) {
                        if (channelItem.thumbnailUrl != null) avatar = channelItem.thumbnailUrl
                        if (channelItem.subscriberCount > 0) {
                            val count = channelItem.subscriberCount
                            subText = if (count >= 10_000_000) String.format("%.1f Cr subscribers", count / 10_000_000.0)
                            else if (count >= 100_000) String.format("%.1f lakh subscribers", count / 100_000.0)
                            else if (count >= 1_000) String.format("%.1fK subscribers", count / 1_000.0)
                            else "$count subscribers"
                        }
                        if (channelItem.streamCount > 0) {
                            val sc = channelItem.streamCount
                            videoCountText = if (sc >= 1_000) String.format("%.1fK videos", sc / 1_000.0) else "$sc videos"
                        }
                        if (!channelItem.description.isNullOrBlank()) {
                            desc = channelItem.description
                        }

                        // Try full ChannelInfo
                        try {
                            val channelInfo = org.schabi.newpipe.extractor.channel.ChannelInfo.getInfo(service, channelItem.url)
                            banner = channelInfo.bannerUrl
                            if (channelInfo.avatarUrl != null) avatar = channelInfo.avatarUrl
                            if (!channelInfo.description.isNullOrBlank()) desc = channelInfo.description
                            val streamItems = channelInfo.relatedItems.filterIsInstance<StreamInfoItem>()
                            for (item in streamItems) {
                                val vId = item.url.substringAfter("v=").substringBefore("&")
                                val lengthSec = item.duration.toInt()
                                val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                                val viewCount = item.viewCount
                                val viewStr = if (viewCount >= 10_000_000) String.format("%.1f Cr views", viewCount / 10_000_000.0)
                                else if (viewCount >= 100_000) String.format("%.1f lakh views", viewCount / 100_000.0)
                                else if (viewCount >= 1_000) String.format("%.1fK views", viewCount / 1_000.0)
                                else "$viewCount views"
                                videos.add(
                                    YouTubeVideo(
                                        id = vId,
                                        title = item.name ?: "",
                                        channelTitle = channelTitle,
                                        channelAvatarUrl = avatar,
                                        thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                        duration = durStr,
                                        views = viewStr,
                                        uploadDate = item.textualUploadDate ?: "Recent",
                                        category = "Channel"
                                    )
                                )
                            }
                        } catch (e: Throwable) {}
                    }
                } catch (e: Throwable) {}

                // 2. Fallback to searching videos for channel
                if (videos.isEmpty()) {
                    val searchExtractor = service.getSearchExtractor(channelTitle, listOf("videos"), "")
                    searchExtractor.fetchPage()
                    val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                    for (item in streamItems) {
                        val vId = item.url.substringAfter("v=").substringBefore("&")
                        val lengthSec = item.duration.toInt()
                        val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                        val viewCount = item.viewCount
                        val viewStr = if (viewCount >= 10_000_000) String.format("%.1f Cr views", viewCount / 10_000_000.0)
                        else if (viewCount >= 100_000) String.format("%.1f lakh views", viewCount / 100_000.0)
                        else if (viewCount >= 1_000) String.format("%.1fK views", viewCount / 1_000.0)
                        else "$viewCount views"
                        if (avatar == null) {
                            avatar = try { item.uploaderAvatarUrl } catch (e: Throwable) { null }
                        }
                        videos.add(
                            YouTubeVideo(
                                id = vId,
                                title = item.name ?: "",
                                channelTitle = item.uploaderName ?: channelTitle,
                                channelAvatarUrl = avatar,
                                thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                duration = durStr,
                                views = viewStr,
                                uploadDate = item.textualUploadDate ?: "Recent",
                                category = "Channel"
                            )
                        )
                    }
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }

            mainHandler.post {
                callback(channelTitle, cleanHandle, avatar, banner, subText, videoCountText, desc, videos)
            }
        }
    }

    var currentAvailableFormats: List<VideoStreamFormat> = emptyList()

    fun resolveStreamFormats(
        context: Context,
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>, dashUrl: String?, hlsUrl: String?) -> Unit
    ) {
        YouTubeStreamResolver.resolveStreams(videoId) { resolved ->
            if (resolved != null) {
                val formats = resolved.availableQualities.map { opt ->
                    VideoStreamFormat(
                        qualityLabel = opt.qualityLabel,
                        resolution = opt.resolution,
                        url = opt.videoUrl,
                        audioUrl = opt.audioUrl
                    )
                }
                currentAvailableFormats = formats
                callback(resolved.videoUrl, formats, null, null)
            } else {
                currentAvailableFormats = emptyList()
                callback("", emptyList(), null, null)
            }
        }
    }

    fun resolveStreamFormats(
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>, dashUrl: String?, hlsUrl: String?) -> Unit
    ) {
        YouTubeStreamResolver.resolveStreams(videoId) { resolved ->
            if (resolved != null) {
                val formats = resolved.availableQualities.map { opt ->
                    VideoStreamFormat(
                        qualityLabel = opt.qualityLabel,
                        resolution = opt.resolution,
                        url = opt.videoUrl,
                        audioUrl = opt.audioUrl
                    )
                }
                currentAvailableFormats = formats
                callback(resolved.videoUrl, formats, null, null)
            } else {
                currentAvailableFormats = emptyList()
                callback("", emptyList(), null, null)
            }
        }
    }

    fun resolveStreamFormats(
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>) -> Unit
    ) {
        resolveStreamFormats(videoId) { bestUrl, allFormats, _, _ ->
            callback(bestUrl, allFormats)
        }
    }

    fun resolveStreamUrl(videoId: String, callback: (streamUrl: String) -> Unit) {
        resolveStreamFormats(videoId) { bestUrl, _ ->
            callback(bestUrl)
        }
    }
}
