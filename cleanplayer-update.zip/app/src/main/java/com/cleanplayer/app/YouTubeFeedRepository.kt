data class YouTubeComment(
    val author: String,
    val authorAvatarUrl: String?,
    val text: String,
    val uploadDate: String,
    val likeCount: String
)

package com.cleanplayer.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.kiosk.KioskInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import java.util.concurrent.Executors

data class VideoStreamFormat(
    val qualityLabel: String,
    val resolution: Int,
    val url: String,
    val audioUrl: String? = null
)

object YouTubeFeedRepository {

    private val executor = Executors.newFixedThreadPool(4)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val rotatingTrendingQueries = listOf(
        "trending songs india",
        "latest hindi songs 2026",
        "viral trending videos india",
        "top bollywood songs 2026",
        "popular songs india",
        "new movie trailers hindi",
        "trending comedy videos",
        "top music hits india",
        "punjabi trending songs",
        "latest music video 2026"
    )
    private var trendingQueryIndex = (System.currentTimeMillis() % 10).toInt()


    val defaultFeed = listOf(
        YouTubeVideo(
            id = "jfKfPfyJRdk",
            title = "lofi hip hop radio 📚 - beats to relax/study to",
            channelTitle = "Lofi Girl",
            channelAvatarUrl = "https://i.ytimg.com/vi/jfKfPfyJRdk/mqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/jfKfPfyJRdk/mqdefault.jpg",
            duration = "LIVE",
            views = "45K watching",
            uploadDate = "Streaming",
            category = "Music",
            likes = "7.8M",
            commentsCount = "450K"
        ),
        YouTubeVideo(
            id = "kffacxfA7G4",
            title = "Justin Bieber - Baby ft. Ludacris (Official Music Video)",
            channelTitle = "Justin Bieber",
            channelAvatarUrl = "https://i.ytimg.com/vi/kffacxfA7G4/mqdefault.jpg",
            thumbnailUrl = "https://i.ytimg.com/vi/kffacxfA7G4/mqdefault.jpg",
            duration = "03:45",
            views = "3.2B views",
            uploadDate = "Music",
            category = "Music",
            likes = "21M",
            commentsCount = "12M"
        )
    )

    fun getFeed(category: String, callback: (List<YouTubeVideo>) -> Unit) {
        resetPagination()
        executor.execute {
            val onlineVideos = mutableListOf<YouTubeVideo>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)

                if (category.equals("All", ignoreCase = true)) {
                    // Try official Trending Kiosk
                    try {
                        val kiosk = KioskInfo.getInfo(service, "https://www.youtube.com/feed/trending")
                        val streamItems = kiosk.relatedItems.filterIsInstance<StreamInfoItem>()
                        for (item in streamItems) {
                            val vId = item.url.substringAfter("v=").substringBefore("&")
                            val lengthSec = item.duration.toInt()
                            val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                            val viewCount = item.viewCount
                            val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                            onlineVideos.add(
                                YouTubeVideo(
                                    id = vId,
                                    title = item.name ?: "",
                                    channelTitle = item.uploaderName ?: "",
                                    channelAvatarUrl = null,
                                    thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                    duration = durStr,
                                    views = viewStr,
                                    uploadDate = item.textualUploadDate ?: "Trending",
                                    category = "Trending"
                                )
                            )
                        }
                    } catch (e: Exception) {}

                    // Fallback to Dynamic Rotating Search Queries for endless fresh variety
                    if (onlineVideos.isEmpty()) {
                        val q1 = rotatingTrendingQueries[trendingQueryIndex % rotatingTrendingQueries.size]
                        trendingQueryIndex++
                        val q2 = rotatingTrendingQueries[trendingQueryIndex % rotatingTrendingQueries.size]
                        trendingQueryIndex++

                        for (q in listOf(q1, q2)) {
                            try {
                                val searchExtractor = service.getSearchExtractor(q, listOf("videos"), "")
                                searchExtractor.fetchPage()
                                val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                                for (item in streamItems) {
                                    val vId = item.url.substringAfter("v=").substringBefore("&")
                                    val lengthSec = item.duration.toInt()
                                    val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                                    val viewCount = item.viewCount
                                    val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                                    onlineVideos.add(
                                        YouTubeVideo(
                                            id = vId,
                                            title = item.name ?: "",
                                            channelTitle = item.uploaderName ?: "",
                                            channelAvatarUrl = null,
                                            thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                            duration = durStr,
                                            views = viewStr,
                                            uploadDate = item.textualUploadDate ?: "Trending",
                                            category = "Trending"
                                        )
                                    )
                                }
                            } catch (e: Exception) {}
                        }
                    }
                } else {
                    val query = when (category.lowercase()) {
                        "music" -> "trending music"
                        "gaming" -> "trending gaming"
                        "news" -> "trending news"
                        "podcasts" -> "popular podcasts"
                        "trending" -> "trending videos"
                        "live" -> "live stream"
                        "subscriptions", "subscriptions_internal" -> "trending videos"
                        else -> category
                    }
                    val searchExtractor = service.getSearchExtractor(query, listOf("videos"), "")
                    searchExtractor.fetchPage()
                    val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                    for (item in streamItems) {
                        val vId = item.url.substringAfter("v=").substringBefore("&")
                        val lengthSec = item.duration.toInt()
                        val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                        val viewCount = item.viewCount
                        val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                        onlineVideos.add(
                            YouTubeVideo(
                                id = vId,
                                title = item.name ?: "",
                                channelTitle = item.uploaderName ?: "",
                                channelAvatarUrl = null,
                                thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                                duration = durStr,
                                views = viewStr,
                                uploadDate = item.textualUploadDate ?: category,
                                category = category
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            mainHandler.post { callback(onlineVideos) }
        }
    }

    private var currentPage = 1
    private var isFetchingMore = false

    fun resetPagination() {
        currentPage = 1
        isFetchingMore = false
    }

    fun loadMoreFeed(category: String, callback: (List<YouTubeVideo>) -> Unit) {
        if (isFetchingMore) {
            mainHandler.post { callback(emptyList()) }
            return
        }
        isFetchingMore = true
        executor.execute {
            val moreVideos = mutableListOf<YouTubeVideo>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)

                currentPage++
                val queries = when (category.lowercase()) {
                    "all" -> listOf("trending music india", "trending songs new", "viral videos 2026", "top bollywood songs", "latest entertainment", "superhit songs playlist")
                    "music" -> listOf("top hits songs 2026", "bollywood romantic songs", "punjabi latest songs", "global top hits", "arijit singh best songs")
                    "gaming" -> listOf("popular gaming walkthrough", "top esports tournaments", "gaming highlights 2026")
                    "news" -> listOf("latest news live india", "national headlines today", "breaking news live")
                    "podcasts" -> listOf("popular podcasts hindi", "trending talks podcast", "the ranveer show clips")
                    "live" -> listOf("live news streams", "live concerts music", "live music radio 24/7")
                    else -> listOf("$category latest", "$category viral", "$category top trending")
                }
                val query = queries[(currentPage - 1) % queries.size]
                val searchExtractor = service.getSearchExtractor(query, listOf("videos"), "")
                searchExtractor.fetchPage()
                val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                for (item in streamItems) {
                    val vId = item.url.substringAfter("v=").substringBefore("&")
                    val lengthSec = item.duration.toInt()
                    val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                    val viewCount = item.viewCount
                    val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                    moreVideos.add(
                        YouTubeVideo(
                            id = vId,
                            title = item.name ?: "",
                            channelTitle = item.uploaderName ?: "",
                            channelAvatarUrl = null,
                            thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                            duration = durStr,
                            views = viewStr,
                            uploadDate = item.textualUploadDate ?: category,
                            category = category
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isFetchingMore = false
            }

            mainHandler.post { callback(moreVideos) }
        }
    }


    fun searchVideos(query: String, callback: (List<YouTubeVideo>) -> Unit) {
        executor.execute {
            val onlineVideos = mutableListOf<YouTubeVideo>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)
                val searchExtractor = service.getSearchExtractor(query, listOf("videos"), "")
                searchExtractor.fetchPage()
                val streamItems = searchExtractor.initialPage.items.filterIsInstance<StreamInfoItem>()
                for (item in streamItems) {
                    val vId = item.url.substringAfter("v=").substringBefore("&")
                    val lengthSec = item.duration.toInt()
                    val durStr = if (lengthSec > 0) String.format("%02d:%02d", lengthSec / 60, lengthSec % 60) else "00:00"
                    val viewCount = item.viewCount
                    val viewStr = if (viewCount > 1_000_000) String.format("%.1fM views", viewCount / 1_000_000.0) else "$viewCount views"
                    onlineVideos.add(
                        YouTubeVideo(
                            id = vId,
                            title = item.name ?: "",
                            channelTitle = item.uploaderName ?: "",
                            channelAvatarUrl = null,
                            thumbnailUrl = try { item.thumbnails?.firstOrNull()?.url } catch (e: Throwable) { null } ?: "https://i.ytimg.com/vi/$vId/mqdefault.jpg",
                            duration = durStr,
                            views = viewStr,
                            uploadDate = item.textualUploadDate ?: "Search",
                            category = "Search"
                        )
                    )
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            mainHandler.post { callback(onlineVideos) }
        }
    }

    fun getChannelDetails(
        channelTitle: String,
        fallbackAvatar: String?,
        callback: (
            channelName: String,
            handle: String,
            avatarUrl: String?,
            bannerUrl: String?,
            subscriberText: String,
            videoCountText: String,
            description: String,
            videos: List<YouTubeVideo>
        ) -> Unit
    ) {
        searchVideos(channelTitle) { channelVideos ->
            val cleanHandle = "@" + channelTitle.replace(" ", "").lowercase()
            val firstVideo = channelVideos.firstOrNull()
            val avatar = fallbackAvatar ?: firstVideo?.thumbnailUrl
            val subText = "Official Channel • Verified"
            val vidCountText = if (channelVideos.isNotEmpty()) "${channelVideos.size}+ videos" else "Videos"
            val desc = "Welcome to $channelTitle official YouTube channel. Watch all latest videos, music, and official uploads."

            callback(channelTitle, cleanHandle, avatar, null, subText, vidCountText, desc, channelVideos)
        }
    }

    var currentAvailableFormats: List<VideoStreamFormat> = emptyList()

    fun resolveStreamFormats(
        context: Context,
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>, dashUrl: String?, hlsUrl: String?) -> Unit
    ) {
        YouTubeStreamResolver.resolveStreams(videoId) { resolved ->
            if (resolved != null) {
                val formats = resolved.availableQualities.map { opt ->
                    VideoStreamFormat(
                        qualityLabel = opt.qualityLabel,
                        resolution = opt.resolution,
                        url = opt.videoUrl,
                        audioUrl = opt.audioUrl
                    )
                }
                currentAvailableFormats = formats
                callback(resolved.videoUrl, formats, null, null)
            } else {
                currentAvailableFormats = emptyList()
                callback("", emptyList(), null, null)
            }
        }
    }

    fun resolveStreamFormats(
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>, dashUrl: String?, hlsUrl: String?) -> Unit
    ) {
        YouTubeStreamResolver.resolveStreams(videoId) { resolved ->
            if (resolved != null) {
                val formats = resolved.availableQualities.map { opt ->
                    VideoStreamFormat(
                        qualityLabel = opt.qualityLabel,
                        resolution = opt.resolution,
                        url = opt.videoUrl,
                        audioUrl = opt.audioUrl
                    )
                }
                currentAvailableFormats = formats
                callback(resolved.videoUrl, formats, null, null)
            } else {
                currentAvailableFormats = emptyList()
                callback("", emptyList(), null, null)
            }
        }
    }

    fun resolveStreamFormats(
        videoId: String,
        callback: (bestUrl: String, allFormats: List<VideoStreamFormat>) -> Unit
    ) {
        resolveStreamFormats(videoId) { bestUrl, allFormats, _, _ ->
            callback(bestUrl, allFormats)
        }
    }

    fun getComments(videoId: String, callback: (List<YouTubeComment>) -> Unit) {
        executor.execute {
            val list = mutableListOf<YouTubeComment>()
            try {
                YouTubeStreamResolver.initNewPipe()
                val service = NewPipe.getService(ServiceList.YouTube.serviceId)
                val commentsInfo = org.schabi.newpipe.extractor.comments.CommentsInfo.getInfo(
                    service,
                    "https://www.youtube.com/watch?v=$videoId"
                )
                val items = commentsInfo.relatedItems.filterIsInstance<org.schabi.newpipe.extractor.comments.CommentsInfoItem>()
                for (item in items) {
                    val rawText = try {
                        item.commentText?.content ?: item.commentText?.toString() ?: ""
                    } catch (e: Throwable) {
                        ""
                    }
                    if (rawText.isNotBlank()) {
                        val likes = if (item.likeCount > 0) "${item.likeCount} likes" else ""
                        list.add(
                            YouTubeComment(
                                author = item.uploaderName ?: "User",
                                authorAvatarUrl = item.uploaderAvatarUrl,
                                text = rawText,
                                uploadDate = item.textualUploadDate ?: "",
                                likeCount = likes
                            )
                        )
                    }
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
            callback(list)
        }
    }

    fun resolveStreamUrl(videoId: String, callback: (streamUrl: String) -> Unit) {
        resolveStreamFormats(videoId) { bestUrl, _ ->
            callback(bestUrl)
        }
    }
}
