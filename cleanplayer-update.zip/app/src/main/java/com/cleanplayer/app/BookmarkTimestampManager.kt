package com.cleanplayer.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class VideoTimestampBookmark(
    val id: String,
    val mediaId: String,
    val mediaTitle: String,
    val timestampMs: Long,
    val formattedTime: String,
    val note: String,
    val createdAt: Long = System.currentTimeMillis()
)

object BookmarkTimestampManager {

    private const val PREFS_NAME = "cleanplayer_timestamp_bookmarks_prefs"
    private const val KEY_BOOKMARKS = "video_timestamp_bookmarks_json"

    fun formatDuration(ms: Long): String {
        val totalSec = (ms / 1000).toInt()
        val s = totalSec % 60
        val m = (totalSec / 60) % 60
        val h = totalSec / 3600
        return if (h > 0) String.format("%02d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
    }

    fun addBookmark(context: Context, mediaId: String, mediaTitle: String, timestampMs: Long, note: String): VideoTimestampBookmark {
        val list = getAllBookmarks(context).toMutableList()
        val cleanNote = if (note.isBlank()) "Moment at ${formatDuration(timestampMs)}" else note.trim()
        val newBm = VideoTimestampBookmark(
            id = "${mediaId}_$timestampMs",
            mediaId = mediaId,
            mediaTitle = mediaTitle,
            timestampMs = timestampMs,
            formattedTime = formatDuration(timestampMs),
            note = cleanNote
        )
        list.removeAll { it.mediaId == mediaId && Math.abs(it.timestampMs - timestampMs) < 2000L }
        list.add(0, newBm)
        saveBookmarks(context, list)
        return newBm
    }

    fun getBookmarksForMedia(context: Context, mediaId: String): List<VideoTimestampBookmark> {
        return getAllBookmarks(context).filter { it.mediaId == mediaId }.sortedBy { it.timestampMs }
    }

    fun getAllBookmarks(context: Context): List<VideoTimestampBookmark> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_BOOKMARKS, "[]") ?: "[]"
        val list = mutableListOf<VideoTimestampBookmark>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    VideoTimestampBookmark(
                        id = obj.optString("id"),
                        mediaId = obj.optString("mediaId"),
                        mediaTitle = obj.optString("mediaTitle"),
                        timestampMs = obj.optLong("timestampMs"),
                        formattedTime = obj.optString("formattedTime"),
                        note = obj.optString("note"),
                        createdAt = obj.optLong("createdAt")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    fun deleteBookmark(context: Context, bookmarkId: String) {
        val list = getAllBookmarks(context).toMutableList()
        list.removeAll { it.id == bookmarkId }
        saveBookmarks(context, list)
    }

    private fun saveBookmarks(context: Context, list: List<VideoTimestampBookmark>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val arr = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("mediaId", item.mediaId)
                put("mediaTitle", item.mediaTitle)
                put("timestampMs", item.timestampMs)
                put("formattedTime", item.formattedTime)
                put("note", item.note)
                put("createdAt", item.createdAt)
            }
            arr.put(obj)
        }
        prefs.edit().putString(KEY_BOOKMARKS, arr.toString()).apply()
    }
}
