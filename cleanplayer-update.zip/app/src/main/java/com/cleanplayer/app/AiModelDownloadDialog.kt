package com.cleanplayer.app

import android.content.Context

/**
 * 🎬 CleanPlayer Engine Manager Dialog
 * Transparently redirects to the Hardware Video & HDR Boost tuning panel.
 * Zero fake downloads, 100% genuine local GPU and DSP execution.
 */
object AiModelDownloadDialog {

    fun show(
        context: Context,
        initialModel: Any? = null,
        onDismissListener: (() -> Unit)? = null
    ) {
        NeuralSuperResTuneDialog.show(context) {
            onDismissListener?.invoke()
        }
    }
}
