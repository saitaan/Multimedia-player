package com.cleanplayer.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView

/**
 * Universal On-Demand AI Neural Model Manager Dialog.
 * Supports downloading, toggling, tuning, and deleting:
 * 1. ⚡ FastSR Mobile Neural Super-Resolution (~38.4 MB)
 * 2. 🎤 Demucs Neural Vocal Isolator & Stem Splitter (~34.2 MB)
 * 3. 🎙️ Whisper Mobile Offline Speech-to-Text Model (~39.1 MB)
 *
 * Full hardware support for POCO C85x, Xiaomi HyperOS 3, and Android 16 (Baklava).
 */
object AiModelDownloadDialog {

    private var currentModel: AiModelDownloadManager.AiModelInfo = AiModelDownloadManager.SUPER_RES_MODEL

    fun show(context: Context, initialModel: AiModelDownloadManager.AiModelInfo = AiModelDownloadManager.SUPER_RES_MODEL, onDismissListener: (() -> Unit)? = null) {
        currentModel = initialModel
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_ai_model_manager, null)
        val dialog = AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
            .setView(view)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val btnClose = view.findViewById<ImageButton>(R.id.btnAiModelClose)

        val tabSuperRes = view.findViewById<TextView>(R.id.tabModelSuperRes)
        val tabVocal = view.findViewById<TextView>(R.id.tabModelVocalRemover)
        val tabWhisper = view.findViewById<TextView>(R.id.tabModelWhisper)

        val tvTitle = view.findViewById<TextView>(R.id.tvAiModelTitle)
        val tvDesc = view.findViewById<TextView>(R.id.tvAiModelDescription)
        val tvSize = view.findViewById<TextView>(R.id.tvAiModelSize)
        val tvInstallStatus = view.findViewById<TextView>(R.id.tvAiModelInstallStatus)

        val layoutProgress = view.findViewById<LinearLayout>(R.id.layoutAiDownloadProgress)
        val pbDownload = view.findViewById<ProgressBar>(R.id.pbAiModelDownload)
        val tvProgressText = view.findViewById<TextView>(R.id.tvAiDownloadProgressText)
        val btnCancel = view.findViewById<TextView>(R.id.btnCancelAiDownload)

        val btnDownload = view.findViewById<Button>(R.id.btnDownloadAiModel)
        val btnToggle = view.findViewById<Button>(R.id.btnToggleNeuralSuperRes)
        val btnTune = view.findViewById<Button>(R.id.btnTuneSuperResFromManager)
        val btnDelete = view.findViewById<Button>(R.id.btnDeleteAiModel)

        fun updateTabsUi() {
            tabSuperRes?.setBackgroundResource(if (currentModel.id == AiModelDownloadManager.SUPER_RES_MODEL.id) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            tabSuperRes?.setTextColor(if (currentModel.id == AiModelDownloadManager.SUPER_RES_MODEL.id) Color.BLACK else Color.WHITE)

            tabVocal?.setBackgroundResource(if (currentModel.id == AiModelDownloadManager.VOCAL_REMOVER_MODEL.id) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            tabVocal?.setTextColor(if (currentModel.id == AiModelDownloadManager.VOCAL_REMOVER_MODEL.id) Color.BLACK else Color.WHITE)

            tabWhisper?.setBackgroundResource(if (currentModel.id == AiModelDownloadManager.WHISPER_SPEECH_MODEL.id) R.drawable.bg_youtube_chip_active else R.drawable.bg_youtube_chip_inactive)
            tabWhisper?.setTextColor(if (currentModel.id == AiModelDownloadManager.WHISPER_SPEECH_MODEL.id) Color.BLACK else Color.WHITE)
        }

        fun updateUiState() {
            updateTabsUi()
            val model = currentModel
            tvTitle?.text = model.title
            tvDesc?.text = model.description

            val isInstalled = AiModelDownloadManager.isModelInstalled(context, model)
            val isDownloadingThis = AiModelDownloadManager.isDownloading && AiModelDownloadManager.currentDownloadingModelId == model.id

            if (isDownloadingThis) {
                layoutProgress?.visibility = View.VISIBLE
                btnDownload?.visibility = View.GONE
                btnToggle?.visibility = View.GONE
                btnTune?.visibility = View.GONE
                btnDelete?.visibility = View.GONE
                tvInstallStatus?.text = "Downloading..."
                tvInstallStatus?.setTextColor(Color.parseColor("#FFA500"))
            } else if (isInstalled) {
                layoutProgress?.visibility = View.GONE
                btnDownload?.visibility = View.GONE
                btnToggle?.visibility = View.VISIBLE
                btnDelete?.visibility = View.VISIBLE

                val sizeStr = AiModelDownloadManager.getModelSizeFormatted(context, model)
                tvSize?.text = "📦 Installed on Device: $sizeStr"
                tvInstallStatus?.text = "Active & Ready"
                tvInstallStatus?.setTextColor(Color.parseColor("#4CAF50"))

                when (model.id) {
                    AiModelDownloadManager.SUPER_RES_MODEL.id -> {
                        btnTune?.visibility = View.VISIBLE
                        if (PlayerHolder.isAiNeuralSuperResEnabled) {
                            btnToggle?.text = "⚡ Neural Super-Resolution: ON"
                            btnToggle?.setBackgroundResource(R.drawable.bg_youtube_chip_active)
                            btnToggle?.setTextColor(Color.BLACK)
                        } else {
                            btnToggle?.text = "⚡ Neural Super-Resolution: OFF"
                            btnToggle?.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                            btnToggle?.setTextColor(Color.WHITE)
                        }
                    }
                    AiModelDownloadManager.VOCAL_REMOVER_MODEL.id -> {
                        btnTune?.visibility = View.GONE
                        if (PlayerHolder.isNeuralVocalRemoverEnabled) {
                            btnToggle?.text = "🎤 Demucs Vocal Remover: ON"
                            btnToggle?.setBackgroundResource(R.drawable.bg_youtube_chip_active)
                            btnToggle?.setTextColor(Color.BLACK)
                        } else {
                            btnToggle?.text = "🎤 Demucs Vocal Remover: OFF"
                            btnToggle?.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                            btnToggle?.setTextColor(Color.WHITE)
                        }
                    }
                    AiModelDownloadManager.WHISPER_SPEECH_MODEL.id -> {
                        btnTune?.visibility = View.GONE
                        if (PlayerHolder.isWhisperOfflineSpeechEnabled) {
                            btnToggle?.text = "🎙️ Whisper Offline Speech: ON"
                            btnToggle?.setBackgroundResource(R.drawable.bg_youtube_chip_active)
                            btnToggle?.setTextColor(Color.BLACK)
                        } else {
                            btnToggle?.text = "🎙️ Whisper Offline Speech: OFF"
                            btnToggle?.setBackgroundResource(R.drawable.bg_youtube_chip_inactive)
                            btnToggle?.setTextColor(Color.WHITE)
                        }
                    }
                }
            } else {
                layoutProgress?.visibility = View.GONE
                btnDownload?.visibility = View.VISIBLE
                btnToggle?.visibility = View.GONE
                btnTune?.visibility = View.GONE
                btnDelete?.visibility = View.GONE

                val mb = model.expectedSizeBytes.toDouble() / (1024.0 * 1024.0)
                tvSize?.text = String.format(java.util.Locale.US, "📦 Model Size: ~%.1f MB", mb)
                tvInstallStatus?.text = "Not Installed"
                tvInstallStatus?.setTextColor(Color.parseColor("#FF5252"))

                btnDownload?.text = String.format(java.util.Locale.US, "📥 Download %s (~%.1f MB)", model.title.split(" ").firstOrNull() ?: "Model", mb)
            }
        }

        updateUiState()

        tabSuperRes?.setOnClickListener {
            currentModel = AiModelDownloadManager.SUPER_RES_MODEL
            updateUiState()
        }

        tabVocal?.setOnClickListener {
            currentModel = AiModelDownloadManager.VOCAL_REMOVER_MODEL
            updateUiState()
        }

        tabWhisper?.setOnClickListener {
            currentModel = AiModelDownloadManager.WHISPER_SPEECH_MODEL
            updateUiState()
        }

        btnClose?.setOnClickListener {
            dialog.dismiss()
        }

        btnCancel?.setOnClickListener {
            AiModelDownloadManager.cancelDownload()
            updateUiState()
            CleanToast.show(context, "AI Model download cancelled")
        }

        btnDownload?.setOnClickListener {
            val targetModel = currentModel
            CleanToast.show(context, "📥 Downloading ${targetModel.title}...")
            updateUiState()

            AiModelDownloadManager.startDownload(
                context,
                targetModel,
                onProgress = { percent, bytesRead, totalBytes ->
                    if (currentModel.id == targetModel.id) {
                        pbDownload?.progress = percent
                        val mbRead = bytesRead.toDouble() / (1024.0 * 1024.0)
                        val mbTotal = totalBytes.toDouble() / (1024.0 * 1024.0)
                        tvProgressText?.text = String.format(
                            java.util.Locale.US,
                            "Downloading %s... %d%% (%.1f MB / %.1f MB)",
                            targetModel.title.split(" ").firstOrNull() ?: "AI Weights",
                            percent, mbRead, mbTotal
                        )
                    }
                },
                onComplete = { success, errorMsg ->
                    updateUiState()
                    if (success) {
                        CleanToast.show(context, "✅ ${targetModel.title} Activated & Ready!")
                    } else {
                        CleanToast.show(context, "⚠️ Download failed: ${errorMsg ?: "Unknown error"}")
                    }
                }
            )
            updateUiState()
        }

        btnToggle?.setOnClickListener {
            when (currentModel.id) {
                AiModelDownloadManager.SUPER_RES_MODEL.id -> {
                    PlayerHolder.isAiNeuralSuperResEnabled = !PlayerHolder.isAiNeuralSuperResEnabled
                    AiSuperResolutionEngine.applyNeuralEnhancement(context, true)
                    CleanToast.show(context, if (PlayerHolder.isAiNeuralSuperResEnabled) "⚡ Neural Super-Resolution: ON" else "⚡ Neural Super-Resolution: OFF")
                }
                AiModelDownloadManager.VOCAL_REMOVER_MODEL.id -> {
                    PlayerHolder.isNeuralVocalRemoverEnabled = !PlayerHolder.isNeuralVocalRemoverEnabled
                    CleanToast.show(context, if (PlayerHolder.isNeuralVocalRemoverEnabled) "🎤 Demucs Neural Vocal Remover: ON" else "🎤 Demucs Neural Vocal Remover: OFF")
                }
                AiModelDownloadManager.WHISPER_SPEECH_MODEL.id -> {
                    PlayerHolder.isWhisperOfflineSpeechEnabled = !PlayerHolder.isWhisperOfflineSpeechEnabled
                    CleanToast.show(context, if (PlayerHolder.isWhisperOfflineSpeechEnabled) "🎙️ Whisper Offline Speech AI: ON" else "🎙️ Whisper Offline Speech AI: OFF")
                }
            }
            PlayerHolder.savePreferences(context)
            updateUiState()
        }

        btnTune?.setOnClickListener {
            NeuralSuperResTuneDialog.show(context) {
                updateUiState()
            }
        }

        btnDelete?.setOnClickListener {
            val targetModel = currentModel
            AlertDialog.Builder(context, R.style.DarkAlertDialogTheme)
                .setTitle("Delete ${targetModel.title}?")
                .setMessage("This will delete the neural model file from your device internal storage to free up space.")
                .setPositiveButton("Delete") { _, _ ->
                    val deleted = AiModelDownloadManager.deleteModel(context, targetModel)
                    updateUiState()
                    if (deleted) {
                        CleanToast.show(context, "🗑️ ${targetModel.title} deleted. Storage freed.")
                    } else {
                        CleanToast.show(context, "Unable to delete model file")
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        dialog.setOnDismissListener {
            onDismissListener?.invoke()
        }

        dialog.show()
    }
}
