package com.cleanplayer.app

import org.junit.Assert.*
import org.junit.Test
import java.net.URLEncoder

/**
 * Unit Tests for WebShare Engine & QR Code Separation.
 *
 * Verifies:
 * 1. WebShare URL construction with dynamic runtime ports (no hardcoded 8988 or 8080).
 * 2. Pure Wi-Fi QR payload strictly conforms to standard format without HTTP metadata.
 * 3. FastShare P2P QR maintains host/port metadata without regression.
 * 4. Path traversal attacks (../, %2e%2e, backslash) are strictly blocked.
 * 5. Unicode filename Content-Disposition RFC 5987 / RFC 6266 encoding.
 */
class WebShareAndQrTest {

    @Test
    fun testWebShareUrlConstructionWithDynamicPort() {
        val testIp = "192.168.43.1"
        val dynamicPort = 8452 // Arbitrary dynamic free port
        val session = WebShareManager.WebShareSession(
            ssid = "CleanPlayer_WebShare_5GHz",
            password = "testpassword123",
            hotspotIp = testIp,
            serverHost = testIp,
            serverPort = dynamicPort,
            serverUrl = "http://$testIp:$dynamicPort",
            isRunning = true,
            isReady = true
        )

        assertEquals("http://192.168.43.1:8452", session.serverUrl)
        assertFalse("WebShare URL must NOT contain hardcoded 8988", session.serverUrl.contains(":8988"))
        assertTrue("Session must be marked ready", session.isReady)
    }

    @Test
    fun testStandardWifiQrPayloadFormat() {
        val ssid = "CleanPlayer_WebShare_5GHz"
        val password = "securepassword"

        // Generate standard Wi-Fi payload
        val authType = if (password.isNotBlank()) "WPA" else "nopass"
        val payload = "WIFI:T:$authType;S:$ssid;P:$password;;"

        assertEquals("WIFI:T:WPA;S:CleanPlayer_WebShare_5GHz;P:securepassword;;", payload)
        assertFalse("Standard Wi-Fi QR must NEVER contain host IP metadata", payload.contains("H:"))
        assertFalse("Standard Wi-Fi QR must NEVER contain port metadata", payload.contains("PORT:"))
        assertTrue("Standard Wi-Fi QR must end with double semicolon", payload.endsWith(";;"))
    }

    @Test
    fun testStandardWifiQrPayloadNoPassword() {
        val ssid = "Open_Hotspot"
        val payload = "WIFI:T:nopass;S:$ssid;;"
        assertEquals("WIFI:T:nopass;S:Open_Hotspot;;", payload)
        assertFalse(payload.contains("P:"))
    }

    @Test
    fun testFastShareQrPayloadContainsHostMetadata() {
        val ssid = "CleanPlayer_FastShare"
        val password = "p2ppassword"
        val hostIp = "192.168.49.1"
        val port = 8988

        val ipPart = "H:$hostIp;PORT:$port;"
        val payload = "WIFI:T:WPA;S:$ssid;P:$password;$ipPart;"

        assertTrue("FastShare P2P QR must retain host IP", payload.contains("H:192.168.49.1;"))
        assertTrue("FastShare P2P QR must retain port", payload.contains("PORT:8988;"))
    }

    @Test
    fun testPathTraversalDetection() {
        val maliciousPaths = listOf(
            "/../etc/passwd",
            "/download/..%2f..%2fprivate.txt",
            "/stream/..\\windows\\system32",
            "/download/0/../../secret",
            "/download/0\u0000.mp4"
        )

        for (path in maliciousPaths) {
            val isSuspicious = path.contains("..") ||
                    path.contains("%2e%2e", ignoreCase = true) ||
                    path.contains("\\") ||
                    path.contains("\u0000")
            assertTrue("Path traversal should be blocked for: $path", isSuspicious)
        }

        val legitimatePaths = listOf(
            "/",
            "/index.html",
            "/download/0",
            "/stream/1?download=true"
        )

        for (path in legitimatePaths) {
            val isSuspicious = path.contains("..") ||
                    path.contains("%2e%2e", ignoreCase = true) ||
                    path.contains("\\") ||
                    path.contains("\u0000")
            assertFalse("Legitimate path should not be blocked: $path", isSuspicious)
        }
    }

    @Test
    fun testContentDispositionUnicodeEncoding() {
        val rawFilename = "Hindi Movie हिंदी 2026.mp4"
        val safeAsciiName = rawFilename.replace("\"", "\\\"").replace("\r", "").replace("\n", "")
        val utf8Encoded = URLEncoder.encode(rawFilename, "UTF-8").replace("+", "%20")

        val header = "attachment; filename=\"$safeAsciiName\"; filename*=UTF-8''$utf8Encoded"
        assertTrue(header.contains("filename*=UTF-8''"))
        assertTrue(header.contains("%E0%A4%B9%E0%A4%BF%E0%A4%82%E0%A4%A6%E0%A4%80"))
    }
}
