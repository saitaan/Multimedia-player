package com.cleanplayer.app

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Automated Tests for Hardware Trigger & Pulse Processing Reliability.
 *
 * Verifies:
 * 1. Single pulse capture.
 * 2. Rapid pulses & burst boundary processing.
 * 3. Simultaneous multi-sensor independent qualification (zero cross-talk).
 * 4. Noisy input rejection without blocking delays.
 * 5. Pulse conservation: input pulses == accepted + rejected noise.
 * 6. Counter stability across high-volume throughput.
 */
class TriggerPulseReliabilityTest {

    @Before
    fun setup() {
        TriggerPulseManager.resetCounters()
    }

    @Test
    fun testSinglePulseCapture() {
        val success = TriggerPulseManager.onTriggerPulse(channelId = 1, timestampUs = 1000L)
        assertTrue("Single pulse should be accepted", success)
        assertEquals("Total input pulses", 1L, TriggerPulseManager.getTotalInputPulses())
        assertEquals("Total processed pulses", 1L, TriggerPulseManager.getTotalProcessedPulses())
        assertEquals("Channel 1 accepted", 1L, TriggerPulseManager.getChannelAcceptedCount(1))
    }

    @Test
    fun testRapidPulsesConservation() {
        val minWidthUs = TriggerPulseManager.minPulseWidthUs
        val pulseCount = 100
        var currentTs = 1000L

        for (i in 1..pulseCount) {
            currentTs += (minWidthUs + 10L) // Valid interval above debounce threshold
            val accepted = TriggerPulseManager.onTriggerPulse(channelId = 1, timestampUs = currentTs)
            assertTrue("Pulse $i must be accepted", accepted)
        }

        assertEquals("Input count equals processed count", 100L, TriggerPulseManager.getTotalInputPulses())
        assertEquals("Processed count matches input count", 100L, TriggerPulseManager.getTotalProcessedPulses())
        assertEquals("Zero noise rejected for valid spacing", 0L, TriggerPulseManager.getTotalRejectedNoise())
    }

    @Test
    fun testBurstAndNoisyInputRejection() {
        // First pulse
        TriggerPulseManager.onTriggerPulse(channelId = 1, timestampUs = 1000L)

        // Rapid noise burst below 50us threshold
        TriggerPulseManager.onTriggerPulse(channelId = 1, timestampUs = 1010L) // +10us (noise)
        TriggerPulseManager.onTriggerPulse(channelId = 1, timestampUs = 1025L) // +15us (noise)
        TriggerPulseManager.onTriggerPulse(channelId = 1, timestampUs = 1040L) // +15us (noise)

        // Valid pulse after burst settles
        TriggerPulseManager.onTriggerPulse(channelId = 1, timestampUs = 1200L) // +160us (valid)

        assertEquals("Total inputs", 5L, TriggerPulseManager.getTotalInputPulses())
        assertEquals("Processed valid pulses", 2L, TriggerPulseManager.getTotalProcessedPulses())
        assertEquals("Rejected noise pulses", 3L, TriggerPulseManager.getTotalRejectedNoise())
        assertEquals("Pulse Conservation: Input == Processed + Rejected",
            TriggerPulseManager.getTotalInputPulses(),
            TriggerPulseManager.getTotalProcessedPulses() + TriggerPulseManager.getTotalRejectedNoise())
    }

    @Test
    fun testSimultaneousSensorsIndependentQualification() {
        val executor = Executors.newFixedThreadPool(4)
        val latch = CountDownLatch(4)
        val pulsesPerSensor = 250

        // 4 concurrent sensors firing pulses simultaneously
        for (sensorId in 1..4) {
            executor.execute {
                var ts = 10000L * sensorId
                for (p in 1..pulsesPerSensor) {
                    ts += 100L // 100us intervals
                    TriggerPulseManager.onTriggerPulse(channelId = sensorId, timestampUs = ts)
                }
                latch.countDown()
            }
        }

        latch.await(5, TimeUnit.SECONDS)
        executor.shutdown()

        val expectedTotal = 4L * pulsesPerSensor
        assertEquals("Total input across all 4 sensors", expectedTotal, TriggerPulseManager.getTotalInputPulses())
        assertEquals("Total processed pulses across sensors", expectedTotal, TriggerPulseManager.getTotalProcessedPulses())

        for (sensorId in 1..4) {
            assertEquals("Sensor $sensorId count", pulsesPerSensor.toLong(), TriggerPulseManager.getChannelAcceptedCount(sensorId))
        }
    }
}
