package com.cleanplayer.app

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.util.regex.Pattern

/**
 * Unit Tests for Playback End Lifecycle, Screen-Awake state, Performance Model Manager, and OTA Safety.
 */
class PlaybackAndPerformanceTest {

    @Test
    fun testPlaybackEndWithRepeatOffReleasesScreenAwake() {
        val repeatMode = 0 // Repeat OFF
        var isScreenAwake = true
        var isPlaying = true
        var playbackEnded = false

        // Simulate video reaching END
        val isVideoMedia = true
        if (repeatMode == 1) {
            // Replay
            isPlaying = true
            isScreenAwake = true
        } else {
            // Final state reached
            isPlaying = false
            playbackEnded = true
            isScreenAwake = false
        }

        assertFalse("Screen awake must be released when playback ends with repeat OFF", isScreenAwake)
        assertFalse("Player must not be playing after end with repeat OFF", isPlaying)
        assertTrue("Playback must be marked ended", playbackEnded)
    }

    @Test
    fun testPlaybackEndWithRepeatOnMaintainsScreenAwake() {
        val repeatMode = 1 // Repeat ONE / ON
        var isScreenAwake = true
        var isPlaying = true

        if (repeatMode == 1) {
            // Replay starts immediately
            isPlaying = true
            isScreenAwake = true
        } else {
            isPlaying = false
            isScreenAwake = false
        }

        assertTrue("Screen awake must remain active when repeat is ON", isScreenAwake)
        assertTrue("Player must continue playing when repeat is ON", isPlaying)
    }

    @Test
    fun testResumePositionDebounce() {
        var lastSaveTime = 1000L
        var lastSavedPos = 10000L
        var writeCount = 0

        fun onProgressTick(currentPos: Long, currentTime: Long) {
            if (currentTime - lastSaveTime >= 5000L || kotlin.math.abs((currentPos - lastSavedPos).toFloat()) >= 5000f) {
                lastSaveTime = currentTime
                lastSavedPos = currentPos
                writeCount++
            }
        }

        // Simulate 20 high-frequency ticks every 300ms (spanning 6 seconds)
        for (i in 1..20) {
            val t = 1000L + (i * 300L)
            val pos = 10000L + (i * 300L)
            onProgressTick(pos, t)
        }

        // Without debouncing, writeCount would be 20. With debouncing, it should be at most 2!
        assertTrue("Debouncing should dramatically reduce writes (actual writes: $writeCount)", writeCount <= 2)
    }

    @Test
    fun testOtaRegexValidation() {
        val validDecipher = "([a-zA-Z0-9_]+)\\.reverse\\(\\)"
        val validNSig = "([a-zA-Z0-9_-]{10,})"
        val invalidRegex = "([a-zA-Z0-9_+" // Missing closing bracket

        // Valid patterns should compile without exception
        var validCompiled = false
        try {
            Pattern.compile(validDecipher)
            Pattern.compile(validNSig)
            validCompiled = true
        } catch (e: Exception) {
            validCompiled = false
        }
        assertTrue("Valid regexes must compile", validCompiled)

        // Invalid pattern should throw PatternSyntaxException
        var invalidRejected = false
        try {
            Pattern.compile(invalidRegex)
        } catch (e: Exception) {
            invalidRejected = true
        }
        assertTrue("Invalid regex must be rejected by OTA engine", invalidRejected)
    }

    @Test
    fun testModelInfoProperties() {
        val model = PerformanceModelDownloadManager.SUPER_RES_MODEL
        assertEquals("gpu_video_enhancer", model.id)
        assertEquals("gpu_shader_engine", model.filename)
        assertEquals("Built-in shader has zero download size", 0L, model.expectedSizeBytes)
    }

    private val sampleTracks = listOf(
        YouTubeAudioTrack(
            id = "en_160",
            name = "English (Original)",
            language = "en",
            isOriginal = true,
            bitrate = 160,
            url = "https://rr1---sn-test.googlevideo.com/videoplayback?expire=1799999999&id=track_en_160"
        ),
        YouTubeAudioTrack(
            id = "en_128",
            name = "English (Original)",
            language = "en",
            isOriginal = true,
            bitrate = 128,
            url = "https://rr1---sn-test.googlevideo.com/videoplayback?expire=1799999999&id=track_en_128"
        ),
        YouTubeAudioTrack(
            id = "en_64",
            name = "English (Original)",
            language = "en",
            isOriginal = true,
            bitrate = 64,
            url = "https://rr1---sn-test.googlevideo.com/videoplayback?expire=1799999999&id=track_en_64"
        ),
        YouTubeAudioTrack(
            id = "hi_160",
            name = "Hindi",
            language = "hi",
            isOriginal = false,
            bitrate = 160,
            url = "https://rr1---sn-test.googlevideo.com/videoplayback?expire=1799999999&id=track_hi_160"
        ),
        YouTubeAudioTrack(
            id = "hi_128",
            name = "Hindi",
            language = "hi",
            isOriginal = false,
            bitrate = 128,
            url = "https://rr1---sn-test.googlevideo.com/videoplayback?expire=1799999999&id=track_hi_128"
        ),
        YouTubeAudioTrack(
            id = "hi_64",
            name = "Hindi",
            language = "hi",
            isOriginal = false,
            bitrate = 64,
            url = "https://rr1---sn-test.googlevideo.com/videoplayback?expire=1799999999&id=track_hi_64"
        )
    )

    @Before
    fun setUp() {
        YouTubeStreamResolver.invalidateAllCaches()
    }

    // =========================================================================
    // 1. Signed URL Caching & Expiration Tests
    // =========================================================================

    @Test
    fun testFreshUrlIsValidWithinTtl() {
        val now = System.currentTimeMillis()
        val testUrl = "https://rr1---sn.googlevideo.com/videoplayback?id=test1&expire=${(now + 3600_000) / 1000}"
        val isExpired = YouTubeStreamResolver.isStreamUrlExpired(testUrl, resolvedAtMs = now, ttlMs = 15 * 60 * 1000L)
        assertFalse("Freshly resolved URL must be valid within TTL", isExpired)
    }

    @Test
    fun testUrlExpiredByAgeExceedingTtl() {
        val now = System.currentTimeMillis()
        val testUrl = "https://rr1---sn.googlevideo.com/videoplayback?id=test2&expire=${(now + 3600_000) / 1000}"
        val resolvedAt = now - (16 * 60 * 1000L)
        val isExpired = YouTubeStreamResolver.isStreamUrlExpired(testUrl, resolvedAtMs = resolvedAt, ttlMs = 15 * 60 * 1000L)
        assertTrue("URL older than TTL must be flagged as expired", isExpired)
    }

    @Test
    fun testUrlExpiredByGoogleVideoExpireParam() {
        val now = System.currentTimeMillis()
        val expiredEpochSec = (now - 10_000L) / 1000
        val expiredUrl = "https://rr1---sn.googlevideo.com/videoplayback?id=test3&expire=$expiredEpochSec"
        val isExpired = YouTubeStreamResolver.isStreamUrlExpired(expiredUrl, resolvedAtMs = now, ttlMs = 15 * 60 * 1000L)
        assertTrue("URL with past expire query param must be flagged as expired", isExpired)
    }

    @Test
    fun testUrlFlaggedExpiredNearCutoffWindow() {
        val now = System.currentTimeMillis()
        val nearCutoffEpochSec = (now + 30_000L) / 1000
        val nearCutoffUrl = "https://rr1---sn.googlevideo.com/videoplayback?id=test4&expire=$nearCutoffEpochSec"
        val isExpired = YouTubeStreamResolver.isStreamUrlExpired(nearCutoffUrl, resolvedAtMs = now, ttlMs = 15 * 60 * 1000L)
        assertTrue("URL within 60s cutoff buffer must be flagged as expired to avoid playback drop", isExpired)
    }

    @Test
    fun testCacheInvalidationRemovesEntry() {
        val videoId = "sample_video_123"
        assertFalse("Cache should be empty initially", YouTubeStreamResolver.isStreamCachedAndValid(videoId))

        YouTubeStreamResolver.invalidateStreamCache(videoId)
        assertFalse("Cache should remain empty after invalidation", YouTubeStreamResolver.isStreamCachedAndValid(videoId))
    }

    // =========================================================================
    // 2. Audio Quality Bitrate Enforcement Tests
    // =========================================================================

    @Test
    fun testAudioQualitySelectionAutoPicksHighestBitrate() {
        val selected = YouTubeStreamResolver.selectAudioStreamForPreference(
            sampleTracks.filter { it.language == "hi" },
            AudioQualityPreference.AUTO
        )
        assertNotNull("Auto preference must return a stream", selected)
        assertEquals("Auto preference must select highest available bitrate (160 kbps)", 160, selected?.bitrate)
    }

    @Test
    fun testAudioQualitySelection160Kbps() {
        val selected = YouTubeStreamResolver.selectAudioStreamForPreference(
            sampleTracks.filter { it.language == "hi" },
            AudioQualityPreference.BITRATE_160
        )
        assertNotNull(selected)
        assertEquals("160 kbps setting must select 160 kbps stream", 160, selected?.bitrate)
    }

    @Test
    fun testAudioQualitySelection128Kbps() {
        val selected = YouTubeStreamResolver.selectAudioStreamForPreference(
            sampleTracks.filter { it.language == "hi" },
            AudioQualityPreference.BITRATE_128
        )
        assertNotNull(selected)
        assertEquals("128 kbps setting must select 128 kbps stream", 128, selected?.bitrate)
    }

    @Test
    fun testAudioQualitySelection64Kbps() {
        val selected = YouTubeStreamResolver.selectAudioStreamForPreference(
            sampleTracks.filter { it.language == "hi" },
            AudioQualityPreference.BITRATE_64
        )
        assertNotNull(selected)
        assertEquals("64 kbps setting must select 64 kbps stream", 64, selected?.bitrate)
    }

    @Test
    fun testAudioQualitySelectionFallbackWhenTargetUnavailable() {
        val limitedTracks = listOf(
            YouTubeAudioTrack("1", "Track 1", "hi", true, 160, "http://url1"),
            YouTubeAudioTrack("2", "Track 2", "hi", false, 48, "http://url2")
        )

        val selected = YouTubeStreamResolver.selectAudioStreamForPreference(
            limitedTracks,
            AudioQualityPreference.BITRATE_128
        )
        assertNotNull(selected)
        assertEquals("Must select 48 kbps (highest at or below 128 kbps)", 48, selected?.bitrate)
    }

    @Test
    fun testAudioQualitySelectionFallbackWhenAllAboveTarget() {
        val highBitrateOnly = listOf(
            YouTubeAudioTrack("1", "Track 1", "en", true, 192, "http://url1"),
            YouTubeAudioTrack("2", "Track 2", "en", false, 160, "http://url2")
        )

        val selected = YouTubeStreamResolver.selectAudioStreamForPreference(
            highBitrateOnly,
            AudioQualityPreference.BITRATE_64
        )
        assertNotNull(selected)
        assertEquals("Must fallback to closest available bitrate (160 kbps)", 160, selected?.bitrate)
    }

    @Test
    fun testAudioQualityNormalizationForBps() {
        val bpsTracks = listOf(
            YouTubeAudioTrack("1", "HQ", "en", true, 160000, "http://url1"),
            YouTubeAudioTrack("2", "MQ", "en", false, 128000, "http://url2"),
            YouTubeAudioTrack("3", "LQ", "en", false, 64000, "http://url3")
        )

        val selected = YouTubeStreamResolver.selectAudioStreamForPreference(
            bpsTracks,
            AudioQualityPreference.BITRATE_128
        )
        assertNotNull(selected)
        assertEquals("Bitrate in bps should be properly normalized to select 128 kbps", 128000, selected?.bitrate)
    }

    @Test
    fun testAudioQualityPreferenceParsing() {
        assertEquals(AudioQualityPreference.AUTO, AudioQualityPreference.fromPrefString("Auto (Adaptive - Recommended)"))
        assertEquals(AudioQualityPreference.BITRATE_160, AudioQualityPreference.fromPrefString("High Quality (160 kbps Opus - Studio Audio)"))
        assertEquals(AudioQualityPreference.BITRATE_128, AudioQualityPreference.fromPrefString("Normal Quality (128 kbps M4A - Clear & Balanced)"))
        assertEquals(AudioQualityPreference.BITRATE_64, AudioQualityPreference.fromPrefString("Data Saver (64 kbps - Ultra-Low Data)"))
        assertEquals(AudioQualityPreference.AUTO, AudioQualityPreference.fromPrefString(null))
        assertEquals(AudioQualityPreference.AUTO, AudioQualityPreference.fromPrefString("Unknown string"))
    }

    // =========================================================================
    // 3. Audio Language Selection Integration Tests
    // =========================================================================

    @Test
    fun testLanguageSelectionHindiPrioritized() {
        val prefLang = "hi"
        val languageMatched = sampleTracks.filter { it.language.equals(prefLang, ignoreCase = true) }
        assertEquals(3, languageMatched.size)
        assertTrue(languageMatched.all { it.language == "hi" })

        val finalTrack = YouTubeStreamResolver.selectAudioStreamForPreference(
            languageMatched,
            AudioQualityPreference.BITRATE_128
        )
        assertNotNull(finalTrack)
        assertEquals("hi", finalTrack?.language)
        assertEquals(128, finalTrack?.bitrate)
    }

    @Test
    fun testLanguageSelectionFallbackWhenRequestedLanguageUnavailable() {
        val prefLang = "ja"
        val languageMatched = sampleTracks.filter { it.language.equals(prefLang, ignoreCase = true) }
        val fallback = if (languageMatched.isNotEmpty()) languageMatched else sampleTracks.filter { it.isOriginal }.ifEmpty { sampleTracks }

        assertFalse("Fallback should not be empty", fallback.isEmpty())
        assertTrue("Fallback should prioritize original tracks", fallback.all { it.isOriginal })
        assertEquals("en", fallback.first().language)
    }

    // =========================================================================
    // 4. Video Quality & Progressive Fallback Tests
    // =========================================================================

    @Test
    fun testVideoQualitySelectionClosestMatch() {
        val options = listOf(
            StreamQualityOption("1080p", 1080, "http://v1080", "http://a"),
            StreamQualityOption("720p", 720, "http://v720", "http://a"),
            StreamQualityOption("480p", 480, "http://v480", "http://a"),
            StreamQualityOption("360p (Fast)", 360, "http://v360_fast", null)
        )

        val match720 = options.firstOrNull { it.resolution == 720 }
        assertNotNull(match720)
        assertEquals(720, match720?.resolution)

        val match1440 = options.firstOrNull { it.resolution <= 1440 }
        assertNotNull(match1440)
        assertEquals(1080, match1440?.resolution)

        val progressiveFast = options.firstOrNull { it.audioUrl == null }
        assertNotNull(progressiveFast)
        assertEquals(360, progressiveFast?.resolution)
        assertNull("Progressive fast muxed stream must have null separate audioUrl", progressiveFast?.audioUrl)
    }

    // =========================================================================
    // 5. HTTP 403 / 410 Recovery & Single Retry Guard Tests
    // =========================================================================

    @Test
    fun testHttpExpiredErrorStringMatching() {
        fun testMessageExpired(msg: String): Boolean {
            return msg.contains("response code: 403", ignoreCase = true) ||
                   msg.contains("response code: 410", ignoreCase = true) ||
                   msg.contains("HTTP 403", ignoreCase = true) ||
                   msg.contains("HTTP 410", ignoreCase = true) ||
                   msg.contains("403 Forbidden", ignoreCase = true) ||
                   msg.contains("410 Gone", ignoreCase = true)
        }

        assertTrue("403 Forbidden should be recognized as expired", testMessageExpired("Response code: 403 Forbidden"))
        assertTrue("410 Gone should be recognized as expired", testMessageExpired("HTTP 410 Gone error from googlevideo"))
        assertFalse("500 Server Error should not be recognized as expired", testMessageExpired("Response code: 500 Internal Error"))
        assertFalse("Timeout should not be recognized as expired", testMessageExpired("SocketTimeoutException: Read timed out"))
    }

    @Test
    fun testSingleRetryGuardPreventsInfiniteLoop() {
        var retryCount = 0
        var hasRetriedExpiredUrlForVideoId: String? = null
        val currentVideoId = "yt_test_video_1"

        fun onHttp403Encountered(): Boolean {
            if (hasRetriedExpiredUrlForVideoId != currentVideoId) {
                hasRetriedExpiredUrlForVideoId = currentVideoId
                retryCount++
                return true
            }
            return false
        }

        val retry1 = onHttp403Encountered()
        assertTrue("First 403 must trigger single retry", retry1)
        assertEquals(1, retryCount)

        val retry2 = onHttp403Encountered()
        assertFalse("Repeated 403 must NOT trigger another retry (prevents loop)", retry2)
        assertEquals(1, retryCount)

        val retry3 = onHttp403Encountered()
        assertFalse("Third 403 must be rejected", retry3)
        assertEquals(1, retryCount)

        val newVideoId = "yt_test_video_2"
        hasRetriedExpiredUrlForVideoId = null
        val retryNewVideo = if (hasRetriedExpiredUrlForVideoId != newVideoId) {
            hasRetriedExpiredUrlForVideoId = newVideoId
            retryCount++
            true
        } else false

        assertTrue("New video should have fresh retry capability", retryNewVideo)
        assertEquals(2, retryCount)
    }

    // =========================================================================
    // 6. SponsorBlock Functionality Tests
    // =========================================================================

    @Test
    fun testSponsorBlockEmptySegmentsReturnsNull() {
        SponsorBlockManager.clear()
        val skip = SponsorBlockManager.checkSkip(15000L)
        assertNull("Empty SponsorBlock segments must return null without crashing", skip)
    }

    @Test
    fun testSponsorBlockSegmentChaining() {
        val segments = listOf(
            SponsorSegment("sponsor", "skip", 10000L, 20000L),
            SponsorSegment("selfpromo", "skip", 20000L, 25000L)
        )

        val active = segments.filter { it.actionType == "skip" && 15000L in it.startMs until (it.endMs - 100L) }
        assertEquals(1, active.size)
        assertEquals(10000L, active.first().startMs)

        var targetEnd = active.maxOf { it.endMs }
        val chained = segments.filter { it.actionType == "skip" && targetEnd in it.startMs until it.endMs }
        assertEquals(1, chained.size)
        targetEnd = chained.maxOf { it.endMs }

        assertEquals("Contiguous segments must chain to skip seamlessly to 25s", 25000L, targetEnd)
    }

    // =========================================================================
    // 7. CipherSelfHealingResolver & OTA Fallback Tests
    // =========================================================================

    @Test
    fun testCipherSelfHealingPatterns() {
        val resolver = CipherSelfHealingResolver
        assertTrue("Self-healing must be available", resolver.isSelfHealingAvailable())
        assertNotNull("Decipher pattern must compile", resolver.getDecipherPattern())
        assertNotNull("n-sig pattern must compile", resolver.getNSigPattern())

        val testUrl = "https://rr1---sn-test.googlevideo.com/videoplayback?id=123"
        assertEquals(testUrl, resolver.repairStreamUrl(testUrl))
    }

    // =========================================================================
    // 8. Download Safety Tests
    // =========================================================================

    @Test
    fun testDownloadFilenameSanitization() {
        val dangerous = "../../../etc/passwd: *?\"<>|"
        val clean = YouTubeDownloaderHelper.sanitizeFileName(dangerous)
        assertFalse("Sanitized name must not contain directory traversal", clean.contains("../"))
        assertFalse("Sanitized name must not contain forbidden characters", clean.contains(":"))
        assertFalse("Sanitized name must not contain *", clean.contains("*"))
        assertFalse("Sanitized name must not contain ?", clean.contains("?"))
        assertFalse("Sanitized name must not contain \"", clean.contains("\""))
        assertFalse("Sanitized name must not contain <", clean.contains("<"))
        assertFalse("Sanitized name must not contain >", clean.contains(">"))
        assertFalse("Sanitized name must not contain |", clean.contains("|"))
    }

    // =========================================================================
    // 9. Merged vs Pure Audio & Background Playback Mode Tests
    // =========================================================================

    @Test
    fun testMergedVideoAudioOptionsIntegrity() {
        val qual = StreamQualityOption("1080p", 1080, "https://googlevideo.com/v1080", "https://googlevideo.com/a160")
        assertNotNull("Merged video stream must have associated audioUrl", qual.audioUrl)
        assertEquals("https://googlevideo.com/a160", qual.audioUrl)

        val resolved = ResolvedYouTubeStream(
            videoId = "v123",
            title = "Sample Title",
            channelTitle = "Channel",
            videoUrl = qual.videoUrl,
            audioUrl = qual.audioUrl,
            isMerged = true,
            qualityLabel = "1080p",
            resolution = 1080,
            availableQualities = listOf(qual),
            pureAudioUrl = qual.audioUrl,
            allAudioUrls = listOf(qual.audioUrl ?: ""),
            availableAudioTracks = sampleTracks
        )

        assertTrue("High resolution stream must be marked as merged", resolved.isMerged)
        assertNotNull("Pure audio URL must be available for audio-only mode", resolved.pureAudioUrl)
    }

    @Test
    fun testBackgroundPlaybackPureAudioTransition() {
        var isAudioOnlyMode = false
        var isBackgroundAutoSwitched = false

        val isBackgroundDataSaverEnabled = true
        if (isBackgroundDataSaverEnabled && !isAudioOnlyMode) {
            isBackgroundAutoSwitched = true
            isAudioOnlyMode = true
        }

        assertTrue("Background data saver must switch to pure audio mode", isAudioOnlyMode)
        assertTrue("Background switch flag must be marked active", isBackgroundAutoSwitched)

        if (isBackgroundAutoSwitched) {
            isBackgroundAutoSwitched = false
            isAudioOnlyMode = false
        }

        assertFalse("Returning to foreground must restore video playback", isAudioOnlyMode)
        assertFalse("Background auto switched flag must be cleared", isBackgroundAutoSwitched)
    }

    // =========================================================================
    // 10. Self-Healing Fallback & OTA Validation Tests
    // =========================================================================

    @Test
    fun testOtaRuleRejectionAndPreservation() {
        val lastKnownGoodDecipher = "([a-zA-Z0-9$]+)&&\\s*\\1\\.set"
        val corruptedDecipher = "([a-zA-Z0-9$[+"

        var activeDecipher = lastKnownGoodDecipher
        val isNewRuleValid = try {
            java.util.regex.Pattern.compile(corruptedDecipher)
            true
        } catch (e: Exception) {
            false
        }

        if (isNewRuleValid) {
            activeDecipher = corruptedDecipher
        }

        assertFalse("Corrupted remote regex must be rejected", isNewRuleValid)
        assertEquals("System must preserve last-known-good decipher rule", lastKnownGoodDecipher, activeDecipher)
    }

}
