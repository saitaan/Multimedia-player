package com.cleanplayer.app

import org.junit.Assert.*
import org.junit.Test
import java.net.ServerSocket
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Automated Tests for WebShare State Machine, Hotspot Race Conditions,
 * and Deterministic Network Resolution.
 */
class WebShareRaceAndStateTest {

    @Test
    fun testHotspotCallbackDelayedOver2500ms() {
        val sessionCounter = AtomicLong(1L)
        val activeSessionId = sessionCounter.get()
        var serverStarted = false
        var urlQrGenerated = false
        val delayMs = 3500L // Delayed beyond old 2500ms watchdog threshold

        // Simulate delayed Android LocalOnlyHotspot callback arriving at 3500ms
        val callbackArrived = true
        val sessionIdAtCallback = activeSessionId

        if (callbackArrived && sessionIdAtCallback == activeSessionId) {
            val validHotspotIp = "192.168.43.1"
            val port = 8080
            val finalUrl = "http://$validHotspotIp:$port"
            serverStarted = true
            urlQrGenerated = true
            assertEquals("http://192.168.43.1:8080", finalUrl)
        }

        assertTrue("Delayed callback (>2.5s) must successfully start server without timeout abort", serverStarted)
        assertTrue("WebShare URL QR must be generated after delayed callback", urlQrGenerated)
    }

    @Test
    fun testStaleCallbackFromPreviousSessionDiscarded() {
        var activeSessionId = 1L
        var serverStartsCount = 0

        fun onHotspotStarted(callbackSessionId: Long) {
            if (callbackSessionId != activeSessionId) {
                // Drop stale callback
                return
            }
            serverStartsCount++
        }

        // User stops session 1 and starts session 2
        activeSessionId = 2L

        // Old callback for session 1 arrives late
        onHotspotStarted(1L)
        assertEquals("Stale callback from session 1 must be dropped", 0, serverStartsCount)

        // Genuine callback for session 2 arrives
        onHotspotStarted(2L)
        assertEquals("Active session 2 callback must be processed", 1, serverStartsCount)
    }

    @Test
    fun testDuplicateCallbackArrivalIsIdempotent() {
        val serverStarts = AtomicInteger(0)
        val hasStarted = AtomicBoolean(false)

        fun onHotspotStarted() {
            if (hasStarted.compareAndSet(false, true)) {
                serverStarts.incrementAndGet()
            }
        }

        // Duplicate callbacks
        onHotspotStarted()
        onHotspotStarted()
        onHotspotStarted()

        assertEquals("Duplicate hotspot callbacks must result in exactly 1 server startup", 1, serverStarts.get())
    }

    @Test
    fun testRepeatedStartButtonTapsGuarded() {
        var state = WebShareManager.WebShareState.IDLE
        var startCount = 0

        fun onUserStartTap() {
            if (state == WebShareManager.WebShareState.STARTING_HOTSPOT ||
                state == WebShareManager.WebShareState.STARTING_SERVER ||
                state == WebShareManager.WebShareState.RUNNING) {
                // Ignore repeated tap
                return
            }
            state = WebShareManager.WebShareState.STARTING_HOTSPOT
            startCount++
        }

        onUserStartTap()
        onUserStartTap()
        onUserStartTap()

        assertEquals("Repeated start button taps must not launch competing sessions", 1, startCount)
    }

    @Test
    fun testCallbackFailureTransitionsToErrorAndAllowsRetry() {
        var state = WebShareManager.WebShareState.STARTING_HOTSPOT
        var errorMessage: String? = null

        fun onHotspotFailed(reasonCode: Int) {
            state = WebShareManager.WebShareState.ERROR
            errorMessage = "Hotspot failed with code $reasonCode"
        }

        onHotspotFailed(2) // ERROR_GENERIC
        assertEquals(WebShareManager.WebShareState.ERROR, state)
        assertNotNull(errorMessage)

        // Retry should be allowed
        fun onRetry() {
            state = WebShareManager.WebShareState.STARTING_HOTSPOT
        }
        onRetry()
        assertEquals(WebShareManager.WebShareState.STARTING_HOTSPOT, state)
    }

    @Test
    fun testVpnAndCellularInterfacesAreRejected() {
        val testInterfaces = listOf(
            "rmnet_data0" to true,
            "ccmni0" to true,
            "tun0" to true,
            "tap0" to true,
            "wg0" to true,
            "pdp0" to true,
            "dummy0" to true,
            "wlan0" to false,
            "ap0" to false,
            "swlan0" to false
        )

        for ((intfName, shouldReject) in testInterfaces) {
            val rejected = WebShareManager.isCellularOrVpn(intfName)
            assertEquals("Interface $intfName cellular/vpn rejection", shouldReject, rejected)
        }
    }

    @Test
    fun testDynamicPortHandlingAndShutdown() {
        // Test binding to dynamic port (port 0)
        val server = ServerSocket(0)
        val boundPort = server.localPort
        assertTrue("Bound port must be > 0", boundPort > 0)
        assertTrue("Bound port must not be fixed 8988", boundPort != 8988 || boundPort > 1024)

        val session = WebShareManager.WebShareSession(
            serverPort = boundPort,
            serverUrl = "http://192.168.43.1:$boundPort",
            isRunning = true,
            isReady = true
        )
        assertEquals("http://192.168.43.1:$boundPort", session.serverUrl)

        // Shutdown releases port
        server.close()
        assertTrue("Server socket must be closed", server.isClosed)

        // Next bind should acquire valid port
        val server2 = ServerSocket(0)
        assertTrue("Server restart acquires valid port", server2.localPort > 0)
        server2.close()
    }

    @Test
    fun testCleanShutdownResetsSessionState() {
        var session = WebShareManager.WebShareSession(
            ssid = "Hotspot",
            password = "pwd",
            serverUrl = "http://192.168.43.1:8080",
            isRunning = true,
            isReady = true
        )
        assertTrue(session.isRunning)

        // Simulate stopWebShare()
        session = WebShareManager.WebShareSession()
        assertFalse("Running state reset", session.isRunning)
        assertFalse("Ready state reset", session.isReady)
        assertEquals("", session.serverUrl)
        assertEquals(0, session.serverPort)
    }
}
