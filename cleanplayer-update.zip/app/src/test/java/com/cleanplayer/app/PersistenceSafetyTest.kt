package com.cleanplayer.app

import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.atomic.AtomicInteger

/**
 * Automated Tests for Memory & Storage Persistence Safety.
 *
 * Verifies:
 * 1. High-frequency runtime changes stay in RAM without triggering flash wear.
 * 2. Debounced save flushes only at controlled points.
 * 3. Final user-selected value is reliably conserved upon explicit commit.
 */
class PersistenceSafetyTest {

    @Test
    fun testRuntimeAdjustmentsDoNotTriggerExcessiveWrites() {
        val flashWriteCounter = AtomicInteger(0)
        var ramConfigValue = 10
        var lastPersistedValue = 10
        var lastSaveTimeMs = 0L

        fun onConfigChangedRuntime(newValue: Int, currentTimeMs: Long, forceFlush: Boolean = false) {
            // Update in RAM immediately
            ramConfigValue = newValue

            // Debounced controlled save
            if (forceFlush || (currentTimeMs - lastSaveTimeMs >= 5000L)) {
                lastSaveTimeMs = currentTimeMs
                lastPersistedValue = ramConfigValue
                flashWriteCounter.incrementAndGet()
            }
        }

        // Simulate 50 continuous slider/pulse changes over 2.5 seconds (e.g. 50ms intervals)
        for (i in 1..50) {
            val t = 1000L + (i * 50L) // 1050ms to 3500ms (span < 5000ms)
            onConfigChangedRuntime(i, t, forceFlush = false)
        }

        // Without debouncing, flashWriteCounter would be 50.
        // With debouncing, only the initial write happens!
        assertEquals("RAM holds latest adjusted value", 50, ramConfigValue)
        assertEquals("Flash writes must be tightly controlled during rapid adjustments", 1, flashWriteCounter.get())

        // User finishes adjusting and explicitly commits or exits screen
        onConfigChangedRuntime(ramConfigValue, currentTimeMs = 3600L, forceFlush = true)

        assertEquals("Final user value must be persisted upon flush", 50, lastPersistedValue)
        assertEquals("Only 2 total flash writes executed for 50+ adjustments", 2, flashWriteCounter.get())
    }

    @Test
    fun testResumePlaybackDebouncingSafety() {
        var flashWrites = 0
        var lastSaveTime = 0L
        var lastSavedPos = 0L

        fun onPlaybackTick(currentPosMs: Long, timeMs: Long) {
            if (timeMs - lastSaveTime >= 5000L || kotlin.math.abs((currentPosMs - lastSavedPos).toFloat()) >= 5000f) {
                lastSaveTime = timeMs
                lastSavedPos = currentPosMs
                flashWrites++
            }
        }

        // Simulate 100 ticks (30 seconds of playback ticking every 300ms)
        for (i in 1..100) {
            val now = 10000L + (i * 300L)
            val pos = 50000L + (i * 300L)
            onPlaybackTick(pos, now)
        }

        // 30 seconds should result in ~6 debounced writes instead of 100 writes!
        assertTrue("Flash writes should be debounced: $flashWrites <= 7", flashWrites <= 7)
    }
}
