plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.cleanplayer.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.cleanplayer.app"
        minSdk = 21
        targetSdk = 34
        versionCode = 31
        versionName = "3.8.6"

        ndk {
            abiFilters.addAll(listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64"))
        }
    }

    signingConfigs {
        create("cleanplayerDebug") {
            storeFile = file("cleanplayer-debug.keystore")
            storePassword = "androiddebugkey"
            keyAlias = "androiddebugkey"
            keyPassword = "androiddebugkey"
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
            signingConfig = signingConfigs.getByName("cleanplayerDebug")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("cleanplayerDebug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
        ignoreWarnings = true
    }
}

dependencies {
    // AndroidX & UI
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.media:media:1.7.0")

    // Room Database with KSP (100% Gradle 8.4+ & 9.x compatible)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // AndroidX Media3 (ExoPlayer) - Dedicated High-Performance Adaptive Engine
    val media3Version = "1.3.1"
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-exoplayer-dash:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")
    implementation("androidx.media3:media3-common:$media3Version")
    implementation("androidx.media3:media3-session:$media3Version")
    implementation("androidx.media3:media3-datasource:$media3Version")
    implementation("androidx.media3:media3-database:$media3Version")

    // AndroidX WorkManager
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    // LibVLC for Android (Native High-Performance C/C++ Multimedia Engine for Local Media)
    implementation("org.videolan.android:libvlc-all:3.6.0")

    // TeamNewPipe Extractor for Native Ad-Free YouTube Parsing
    implementation("com.github.teamnewpipe:newpipeextractor:0.26.5")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // ZXing Core for High-Performance Scannable Wi-Fi QR Code Generation
    implementation("com.google.zxing:core:3.5.3")
}
