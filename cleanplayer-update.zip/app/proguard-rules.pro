# LibVLC native bindings
-keep class org.videolan.libvlc.** { *; }
-keep class org.videolan.android.** { *; }

# CleanPlayer Models & Services
-keep class com.cleanplayer.app.** { *; }

# Media & SwipeRefreshLayout
-keep class androidx.media.** { *; }
-keep class androidx.swiperefreshlayout.** { *; }

# ZXing QR Code Generation
-keep class com.google.zxing.** { *; }
-dontwarn com.google.zxing.**
