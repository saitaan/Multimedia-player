# LibVLC native bindings
-keep class org.videolan.libvlc.** { *; }
-keep class org.videolan.android.** { *; }

# CleanPlayer Models & Services
-keep class com.cleanplayer.app.** { *; }

# Media & SwipeRefreshLayout
-keep class androidx.media.** { *; }
-keep class androidx.swiperefreshlayout.** { *; }

# ZXing QR Code Generation
-keep class com.google.zxing.** { *; }
-dontwarn com.google.zxing.**

# NewPipe Extractor & OkHttp
-keep class org.schabi.newpipe.extractor.** { *; }
-dontwarn org.schabi.newpipe.extractor.**
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**
