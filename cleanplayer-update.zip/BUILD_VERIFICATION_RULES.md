---
name: cleanplayer-master-expert
description: >-
  Expert instructions, architecture guidelines, and strict pre-flight rules for building,
  modifying, and compiling the CleanPlayer Android multimedia player. Use whenever the user asks
  about CleanPlayer, building the Android APK, updating YouTube streaming features, fixing
  compilation errors, or modifying player gestures, UI dialogs, and services.
allowed-tools: drive vm_shell
---
# CleanPlayer Build & Architecture Expert

A comprehensive guide for maintaining, updating, and compiling the CleanPlayer Android application (TeamNewPipe Extractor v0.26.5 + LibVLC + Media3 ExoPlayer).

## Historical Build Error Logs & Strict Compilation Rules

### 1. Class Scope Guard (Anti-Top-Level Leak)
- **Error Log:** `'this' is not defined in this context`, `Variable expected`, `Unresolved reference`.
- **Cause:** Appending new methods or variables past the final closing brace `}` of `class MainActivity`.
- **Rule:** All helper methods, dialog builders, receivers, and variables must reside strictly INSIDE `class MainActivity` or the respective class body.

### 2. Mandatory Android & Java Framework Imports
- **Error Logs:**
  - `MainActivity.kt: Unresolved reference: File`
  - `YouTubeDownloaderHelper.kt: Unresolved reference: View`
  - `Unresolved reference: Handler`, `Unresolved reference: Looper`
- **Rule:** Always ensure the following imports are explicitly present at the top of Kotlin files:
  - File & Storage I/O: `import java.io.File`, `import java.io.FileInputStream`, `import java.io.FileOutputStream`
  - UI Views: `import android.view.View` (for `View.generateViewId()`, `View.VISIBLE`, `View.GONE`)
  - Concurrency & Threading: `import android.os.Handler`, `import android.os.Looper`
  - Audio: `import android.media.AudioManager`
  - Gestures: `import android.view.GestureDetector`, `import android.view.MotionEvent`, `import android.view.ScaleGestureDetector`
  - Insets / Immersive: `import android.view.WindowInsets`, `import android.view.WindowInsetsController`
  - Media3: `import androidx.media3.common.Player`, `import androidx.media3.common.PlaybackException`, `import androidx.media3.ui.AspectRatioFrameLayout`, `import androidx.media3.ui.PlayerView`

### 3. Kotlin Self-Referencing Lambda Initialization Guard
- **Error Log:** `MainActivity.kt: Unresolved reference: adapter`
- **Cause:**
  ```kotlin
  // FAILS: Variable 'adapter' is not initialized when lambda is defined!
  val adapter = ShareSelectableAdapter(emptyList()) { adapter.getItems() }
  ```
- **Rule:** Always split declaration and initialization using `lateinit var`:
  ```kotlin
  lateinit var adapter: ShareSelectableAdapter
  adapter = ShareSelectableAdapter(emptyList()) { adapter.getItems() }
  ```

### 4. Local Nested Function Declaration Order (No Hoisting)
- **Error Log:** `YouTubeDownloaderHelper.kt: Unresolved reference: populateQualityOptions`
- **Cause:** In Kotlin, local functions defined inside another function are NOT hoisted. Calling a nested function before its declaration line triggers unresolved reference.
- **Rule:** A nested local function must be declared *before* any listener (e.g. `RadioGroup.setOnCheckedChangeListener`) or call site that invokes it.

### 5. Signature & Parameter Default Synchronization
- **Error Log:** `Cannot find a parameter with this name: share` / `Unresolved reference: share`
- **Cause:** Function was updated in caller sites with a new parameter (e.g. `showTab(..., share = true)`), but the function definition was missing `share: Boolean = false`.
- **Rule:** Always supply default arguments for new parameters in dispatcher methods and ensure definition and all call sites are 100% synchronized.

### 6. Helper & Manager Parameter Order
- **Error Log:** Type mismatch: `ImageLoaderHelper.loadImage(ImageView, String)`
- **Rule:** `ImageLoaderHelper.loadImage(url: String?, imageView: ImageView)` requires URL first, ImageView second. Never invert the argument order.

### 7. Manager Visibility & Public Contracts
- **Error Logs:**
  - `Cannot assign to 'currentPlayingVideo': the setter is private in 'YouTubeExoPlayerManager'`
  - `Unresolved reference: stop in 'YouTubeExoPlayerManager'`
- **Rule:**
  - `YouTubeExoPlayerManager.currentPlayingVideo` must have a public setter (`var currentPlayingVideo: YouTubeVideo? = null`).
  - `YouTubeExoPlayerManager` must expose `@Synchronized fun stop()`.
  - Callback properties (`onPlayerError`, `onSponsorSkipped`, `onVideoEnded`) must be declared public on the singleton before wiring in Activities.

### 8. Class-Level vs Local Helper Scoping
- **Error Log:** `Unresolved reference: ytGestureHideHandler`, `Unresolved reference: ytPrefs`
- **Rule:** UI feedback helpers, handlers, and runnables (e.g. `ytGestureHideHandler`, `ytGestureHideRunnable`, `ytPrefs`) must be declared at class level, never nested inside `onCreate` or other methods.

### 9. Dead & Phantom References Cleanup
- **Error Log:** `YouTubeDownloaderHelper.kt: Unresolved reference: loadingToast`
- **Rule:** When refactoring async callbacks or stream resolvers, ensure all temporary toast/dialog references like `loadingToast` are either declared or removed.

### 10. Strict Math Type Disambiguation for Kotlin Overloads
- **Error Log:** `Overload resolution ambiguity: abs(Float) or abs(Double)`
- **Rule:** Always pass explicit floats: `kotlin.math.abs(dy.toFloat())`, `kotlin.math.abs(dx.toFloat())`. Explicitly cast Int to Float when scaling.

### 11. Illegal Local Private Functions
- **Error Log:** `Modifier 'private' is not applicable to local function`
- **Rule:** `private fun` cannot be declared inside a method body. When removing deprecated features (e.g., Picture Mode, Video Color Profiles), delete the entire block cleanly rather than leaving dangling function stubs.

### 12. Playback Error Self-Healing
- **Rule:** In `onResume`, listen to `YouTubeExoPlayerManager.onPlayerError`: fallback to adaptive fast stream and switch center play button to retry state if stream URL expires or network drops.

### 13. 5GHz Turbo P2P Share Module Architecture
- 5th bottom tab (`nav_share`) positioned after YouTube in `bottom_nav_menu.xml`.
- Zero-copy direct streaming using `FileChannel.transferTo` and 256 KB jumbo buffers.
- Breakpoint / chunk-level resume protocol using `.part` files and byte-offset handshakes.
- Background persistence: Hardware locks `WifiLock(WIFI_MODE_FULL_LOW_LATENCY / FULL_HIGH_PERF)` and `WakeLock(PARTIAL_WAKE_LOCK)`.
- Back key interception: Hiding dialog or navigating back must call `moveTaskToBack(true)` rather than finishing the Activity, ensuring transfers continue non-stop.
- Progress Throttling: UI updates throttled to 400ms (2.5 updates/sec) to avoid choking the Main Looper during 80–100+ MB/s transfers.

### 14. Dialog Styling & Dimming
- Always set `backgroundDimAmount` to `0.65` (never 0.12).
- Dialog card surfaces must use solid opaque `#1A1B22` or `#1C1D24` (never semi-transparent hex like `#B3...` or `#CC...`), completely preventing background bleed-through.

### 15. Player Controls Auto-Hide
- Overlay controls (`layoutYtPlayerOverlay`) must auto-fade after 3.0 to 3.5 seconds of playback inactivity.
- Schedule hide when playback starts, resumes, seeks, or when user taps the player view.

### 16. YouTube Audio Mode & Visualizer
- In Audio Mode, the playback loop must actively feed `onPlaybackProgress(current, duration)` every 100ms.
- Render visualizer in full audio player and inside the bottom mini player.
- Never display unwanted promotional badge text over the audio canvas.

### 17. Shorts Player Navigation & Feed Cleanliness
- Home feed must NEVER show a horizontal Shorts shelf; main feed is strictly for clean full videos.
- Shorts player uses natural vertical swipe (fling up for next, fling down for previous).
- Do not add floating arrow buttons that clutter the Shorts canvas.

### 18. Media Notification Dismissal
- When paused, the service MUST call `stopForeground(STOP_FOREGROUND_DETACH)` and set `.setOngoing(false)``.
- Wire `setDeleteIntent` to `ACTION_STOP` so swiping the notification away stops the service cleanly.

### 19. Multi-Language Audio Track Switching
- Multi-language dubbed videos (e.g. Hindi, English) must be selectable via `YouTubeExoPlayerManager.getAvailableAudioTracks()` and `selectAudioTrack(track)`.

### 20. Remote CI/CD & Build Environment
- GitHub Actions workflows (`android_build.yml` and `build-apk.yml`) must include the curl/unzip Gradle 8.4 bootstrap step with Temurin JDK 17.
- ProGuard rules must keep `org.schabi.newpipe.extractor.**` and `okhttp3.**`.

## GitHub Actions CI/CD Compilation Architecture

### 1. Runner & Environment Configuration
- **Operating System:** `ubuntu-latest` (Ubuntu 24.04 LTS).
- **JDK Specification:** Eclipse Temurin JDK 17 (`actions/setup-java@v4` with `distribution: temurin`, `java-version: 17`).
- **Memory Optimization (`gradle.properties`):**
  ```properties
  org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m
  android.useAndroidX=true
  kotlin.code.style=official
  ```

### 2. Auto-Extract Project ZIP Pipeline Step
When updating the repository via master zip archives, CI must run:
```bash
for zip in *.zip; do
  if [ -f "$zip" ]; then
    echo "Extracting $zip..."
    unzip -o "$zip"
  fi
done

if [ ! -f "settings.gradle.kts" ] && [ ! -f "settings.gradle" ]; then
  SETTINGS_PATH=$(find . -name "settings.gradle.kts" -o -name "settings.gradle" | head -n 1)
  if [ -n "$SETTINGS_PATH" ]; then
    SRC_DIR=$(dirname "$SETTINGS_PATH")
    cp -r "$SRC_DIR"/* . 2>/dev/null || true
    cp -r "$SRC_DIR"/.* . 2>/dev/null || true
  fi
fi
```

### 3. Gradle 8.4 Binary Bootstrap Wrapper
To ensure reproducible, zero-drift builds regardless of the runner's pre-installed tools:
```bash
echo "=== Setting Up Gradle 8.4 ==="
curl -sL https://services.gradle.org/distributions/gradle-8.4-bin.zip -o gradle-8.4-bin.zip
unzip -q -o gradle-8.4-bin.zip
./gradle-8.4/bin/gradle wrapper --gradle-version 8.4 --distribution-type bin
chmod +x gradlew
```

### 4. Build Command & Stacktrace Capture
```bash
./gradlew assembleDebug --no-daemon --stacktrace
```
- `--no-daemon`: Prevents orphan worker leaks on ephemeral CI instances.
- `--stacktrace`: Ensures line-level compiler trace is emitted immediately upon any task failure.

### 5. Artifact Upload & APK Archival
- Action: `actions/upload-artifact@v4`
- Name: `CleanPlayer-APK`
- Path: `app/build/outputs/apk/debug/*.apk`

### 6. R8 / ProGuard Keep Rules for Native & Streaming Libraries
When R8 minification or compilation is performed:
```proguard
# TeamNewPipe Extractor
-keep class org.schabi.newpipe.extractor.** { *; }
-dontwarn org.schabi.newpipe.extractor.**

# OkHttp & Jackson Network Stack
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
-dontwarn okhttp3.**
-keep class com.fasterxml.jackson.** { *; }

# LibVLC Native Media Core
-keep class org.videolan.libvlc.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# Kotlin Coroutines & Attributes
-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod,*Annotation*
```

---

## Part 7: Field Verification & P2P Engine Rules (Rules 22 - 26)

### Rule 22: Never Pass Raw SQL Keywords in ContentResolver Queries
- **Root Cause:** Android 11+ (API 30+) `MediaProvider` enforces strict query parser validation. Passing raw SQL clauses like `LIMIT 80` in `sortOrder` throws `SQLiteException` / `IllegalArgumentException`.
- **Enforcement:** Never append `LIMIT X` or custom SQL clauses in `sortOrder`. Instead, use standard sort strings (e.g. `"${MediaStore.Video.Media.DATE_MODIFIED} DESC"`) and iterate the cursor with a client-side counter `while (cursor.moveToNext() && count < maxCount)`.

### Rule 23: Android 13/14 Nearby Devices Runtime Permission for Local-Only Hotspots
- **Root Cause:** `WifiManager.startLocalOnlyHotspot` on Android 13+ (API 33+) requires runtime permission `android.permission.NEARBY_WIFI_DEVICES`. If declared in Manifest but not granted by user at runtime, Android throws `SecurityException`.
- **Enforcement:** Always prompt the user using `registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions())` before triggering Sender/Receiver hotspot operations.

### Rule 24: Background Service Error Handling & Zombie State Prevention
- **Root Cause:** If a background transfer service catches a fatal exception (permission denied, hotspot failed, socket connect failure) without resetting its active flag (`isTransferActive.set(false)`) and calling `stopTransferInternal()`, the service becomes a zombie, leaving the UI showing `0.0 MB/s (0%)` indefinitely.
- **Enforcement:** Every catch block and callback failure (`onFailed`) must explicitly reset state, notify UI, release WakeLock/WifiLock, cancel notifications, and call `stopSelf()`.

### Rule 25: Universal Audio MediaStore Queries
- **Root Cause:** Filtering audio with `IS_MUSIC != 0` excludes voice notes, recordings, downloaded podcasts, and un-tagged audio files. Using `TITLE` instead of `DISPLAY_NAME` loses file extensions (`.mp3`, `.m4a`).
- **Enforcement:** Query audio with `SIZE > 0`, extract `DISPLAY_NAME` with extension fallback, and omit `IS_MUSIC` constraints.

### Rule 26: 1-Tap Termination on In-App Active Transfer Banners
- **Enforcement:** All persistent in-app transfer banners must provide both a `View Live` button and a direct 1-tap `Stop` button to instantly terminate the background service and clean up state.

### Rule 27: Storage Save Location Configuration & Zero-Toast Spam
- **Root Cause:** Hardcoding storage directories (`Download/CleanPlayer`) or displaying informational toasts instead of interactive pickers frustrates users. Toast spam on back-press or minimize clutters the UI.
- **Enforcement:** Always provide an interactive folder selection dialog with presets (`Download/CleanPlayer`, `Movies/CleanPlayer`, `Music/CleanPlayer`, `DCIM/CleanPlayer`, `Documents/CleanPlayer`, `Custom Folder...`). Never use Toast messages for static information or background transitions.

### Rule 28: Zero Dummy UI Elements (Full Interactive Surface Rule)
- **Root Cause:** Having clickable-looking rows, cards, or badges without click listeners (or where only an inner tiny button works) frustrates users and feels like broken/dummy controls.
- **Rule:** Every setting row, status badge, card, and list item must be active and wired to its respective action dialog or button trigger.

### Rule 29: Dynamic High-Resolution Wi-Fi QR Code Generation
- **Root Cause:** Rendering static placeholder vector icons (`ic_qr_code.xml`) prevents peer devices from connecting via camera/scanner.
- **Rule:** Never use static vector placeholders for QR codes. Dynamically generate standard Wi-Fi QR Bitmaps (`WIFI:T:WPA;S:<SSID>;P:<PASSWORD>;;`) using `com.google.zxing:core:3.5.3` and render directly to the `ImageView` with color filters cleared.

### Rule 30: Zero-Buffering Video-to-Audio Mode Switching & Single Progress Bar Contract
- **Root Cause:** Re-creating `ProgressiveMediaSource` and calling `prepare()` drops current buffers and triggers network re-fetching, causing audio buffering when toggling audio mode. Stacking `pbYtBottomMiniProgress` under `sbYtPlayer` renders dual progress bars. Hiding status bar in portrait causes system icon collisions.
- **Rule:**
  1. Toggle video track on `DefaultTrackSelector` (`setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true/false)`) for 0ms zero-buffering mode switches.
  2. Hide `pbYtBottomMiniProgress` whenever overlay controls (`layoutYtPlayerOverlay`) are visible.
  3. Preserve full App-Wide Immersive Mode (hide status bar, transparent bars by swipe).

### Rule 31: Dynamic Device Width for Dialogs & BottomSheets (Zero Truncation Rule)
- **Root Cause:** Hardcoding fixed dialog/card widths (e.g. `480dp`, `460dp`) wider than standard mobile screens (360–412dp) causes the dialog to overflow off-screen, clipping text on the left edge.
- **Rule:** Never hardcode fixed card widths exceeding 360dp. BottomSheetDialog layouts must use `match_parent` root containers. Dialog cards must use `match_parent` with `android:layout_marginStart="14dp"` and `android:layout_marginEnd="14dp"`.

### Rule 32: Import Deduplication Guard (No Conflicting/Duplicate Imports)
- **Root Cause:** In Kotlin, importing the exact same class twice (e.g., `import java.io.File` on two separate lines) triggers a fatal compilation error: `Conflicting import, imported name 'File' is ambiguous`.
- **Enforcement:** Never duplicate explicit imports. Ensure all imports in every Kotlin/Java file are strictly unique and deduplicated.

### Rule 33: Background-to-Foreground Video Mode Restoration & Surface Reattachment
- **Root Cause:** When screen is turned off or app minimized, `onAppBackgrounded` sets `isBackgroundAutoSwitched = true` and enters pure audio mode. When returning to foreground, `onAppForegrounded` had a contradictory guard `if (isBackgroundAutoSwitched && !isAudioOnlyMode)` which never executed. Furthermore, `updateAudioModeUI(false)` lacked `playerViewYt.visibility = View.VISIBLE`, leaving the player invisible and displaying only the audio thumbnail. Finally, `notchProgressRunnable` was removed in `onPause` but never reposted in `onResume`, freezing time display at 00:00.
- **Enforcement:**
  1. `onAppForegrounded` must trigger `switchToVideo(context)` whenever `isBackgroundAutoSwitched` is true.
  2. `updateAudioModeUI(false)` must explicitly set `playerViewYt.visibility = View.VISIBLE` and call `reattachPlayerView(playerViewYt)`.
  3. `MainActivity.onResume()` must restart `notchProgressRunnable` and ensure video surface is reattached.

### Rule 34: Landscape Fullscreen Navigation Bar Concealment & Aspect Ratio Zoom Contract
- **Root Cause:**
  1. `bottomNav` was not hidden during landscape/fullscreen mode, rendering bottom navigation tabs over video controls.
  2. `ScaleGestureDetector` tested single-frame delta `> 1.05f` instead of cumulative scaling, making pinch-to-zoom fail and leaving persistent black pillars.
  3. `GestureDetector` aborted `ACTION_DOWN` handling on `playerViewYt`, while `layoutYtPlayerOverlay` intercepted touches, breaking volume/brightness/seek gestures.
- **Enforcement:**
  1. Set `bottomNav.visibility = View.GONE` in landscape and fullscreen; restore in portrait.
  2. Accumulate pinch zoom factors (`cumulativeScale *= detector.scaleFactor`) to reliably trigger `RESIZE_MODE_ZOOM` and `RESIZE_MODE_FIT`.
  3. Attach unified touch handling across both `playerViewYt` and `layoutYtPlayerOverlay` for volume (right swipe), brightness (left swipe), seek (horizontal swipe), and double-tap (+10s/-10s/play-pause).

### Rule 35: FloatingActionButton Identifier Consistency
- **Root Cause:** Referencing `findViewById(R.id.btnFabPlay)` triggered compilation error `Unresolved reference: btnFabPlay` because the layout identifier is `R.id.fabPlay` and the activity member variable is `fabPlay`.
- **Enforcement:** Always reference `if (::fabPlay.isInitialized) fabPlay` or `R.id.fabPlay`.

### Rule 36: YouTube Real-time Polling & PiP Clean Surface Contract
- **Root Cause:**
  1. `notchProgressRunnable` only executed when `cardNotchPlayer.visibility == View.VISIBLE`, freezing YouTube player time display at `00:00 / 00:00`.
  2. Entering PiP mode did not hide `layoutYtPlayerOverlay`, cluttering the mini PiP window with full-sized controls.
  3. `applyAppWideImmersiveMode()` showed navigation bars when not in explicit fullscreen, rendering gray system gesture bars in landscape video mode.
- **Enforcement:**
  1. YouTube progress/time polling must execute unconditionally whenever `currentPlayingVideo != null`.
  2. Hide `layoutYtPlayerOverlay` completely when entering PiP mode.
  3. Set `isNavigationBarContrastEnforced = false` and hide navigation bars during landscape playback.

### Rule 37: P2P Receive QR Scanner Architecture
- **Root Cause:** In P2P Receive mode, there was no camera scanner to scan the sender's hotspot QR code, preventing receiver devices from connecting.
- **Enforcement:**
  1. Tapping 'Receive' checks `Manifest.permission.CAMERA` and displays an integrated `SurfaceView` camera QR code scanner.
  2. The scanner decodes Wi-Fi payloads (`WIFI:T:WPA;S:<SSID>;P:<PASSWORD>;;`), connects via `WifiNetworkSpecifier` / `WifiManager`, and connects receiver socket to sender host IP.
  3. Redundant background informational cards removed from `dialog_share_progress.xml` for a clean, focused transfer UI.

### Rule 38: Scanner & Network Framework Imports
- **Root Cause:** Calling `Executors.newSingleThreadExecutor()` and `WifiManager` without explicit imports triggered `Unresolved reference: Executors` and `Unresolved reference: WifiManager`.
- **Enforcement:** Always explicitly import `java.util.concurrent.Executors`, `android.net.wifi.WifiManager`, and `android.hardware.Camera`.

### Rule 39: YouTube Channel Page Navigation Contract
- **Root Cause:** Neither `tvYtDetailChannel` nor `cardYtDetailAvatar` had click listeners, so tapping on the channel name/avatar produced no action.
- **Enforcement:**
  1. Wire `tvYtDetailChannel`, `ivYtDetailAvatar`, `cardYtDetailAvatar`, and feed item `ivChannelAvatar` to `openYouTubeChannelPage(channelTitle, avatarUrl)`.
  2. Display channel profile details, handle, synchronized Subscribe button, and fetch channel video uploads via `YouTubeFeedRepository.searchVideos(channelTitle)`.

### Rule 40: Color Resource Declaration & CI/CD Workflow Resilience Contract
- **Root Cause:**
  1. Referencing `R.color.theme_background_secondary` without declaring it in `res/values/colors.xml` causes an unresolved reference compilation error.
  2. Having multiple redundant workflows (`android_build.yml` and `build-apk.yml`) with fragile `curl` commands caused build aborts in 13 seconds on CI.
- **Enforcement:**
  1. Ensure every `R.color.*` resource referenced in Kotlin/Java code is defined in `colors.xml`.
  2. Maintain a single, self-healing `build-apk.yml` workflow with multiple fallbacks for Gradle wrapper and compilation.

### Rule 41: YouTube App 1:1 UI Stabilization & Channel Page Contract
- **Root Cause:**
  1. PiP mode did not suppress overlay controls, causing media buttons, timestamps, and seekbar to clutter the tiny PiP window.
  2. `collapseYouTubePlayer()` restored `fabPlay.visibility = View.VISIBLE`, causing the local media orange play FAB to float awkwardly over the YouTube feed and mini-player.
  3. Player overlay controls had seekbar and time on a single row causing truncation, and `btnYtCenterPlayPause` was using a rectangular orange decoder badge and became invisible.
  4. Channel page was a bottom sheet with blank generic avatar and no banner/subscriber count.
- **Enforcement:**
  1. Enforce `isInPictureInPictureMode` guard in `showYouTubeOverlay()` to guarantee zero overlay obstruction in PiP.
  2. Unify FAB visibility via `updateFabPlayVisibility()` so `fabPlay` is strictly `View.GONE` whenever YouTube tab or player is active.
  3. Separate seekbar into a full-width top row and time/fullscreen on the bottom row, with circular translucent center play button (`bg_youtube_center_play`).
  4. Build full-screen 1:1 YouTube Channel Activity with banner, avatar, verified checkmark, handle, subscriber count in Indian numbering (e.g. 45.8 lakh), tabs, and actual channel uploads via `YouTubeFeedRepository.getChannelDetails`.

### Rule 42: Complete Removal of YouTube Shorts & Dedicated Shorts Player
- **Root Cause:** Shorts clutter the feed, create redundant vertical video players, and distract from long-form video playback.
- **Enforcement:**
  1. Completely remove `layoutYtShortsPlayer` and its associated touch gestures and controls.
  2. Remove `layoutYtShortsShelf` and `rvYouTubeShorts` from the feed so only clean long-form video cards are rendered.
  3. Remove `btnYtNavShorts` from the bottom navigation bar so only Home, Subscriptions, and You are present.
  4. Remove `YouTubeShortsAdapter.kt`, `item_youtube_shorts.xml`, and all Shorts fetchers from `YouTubeFeedRepository.kt`.

### Rule 43: Layout Drawable Resource Presence Guarantee
- **Root Cause:** AAPT2 build failure `:app:processDebugResources FAILED` occurred because `dialog_youtube_channel.xml` referenced `@drawable/ic_arrow_back` and `@drawable/ic_more_vert` without corresponding vector drawable XML definitions in `res/drawable/`.
- **Enforcement:** Ensure all vector drawables referenced in any layout (such as `ic_arrow_back`, `ic_more_vert`, `ic_verified`, `bg_chip_black`) exist in `res/drawable/`. Run an automated scan verifying that every single `@drawable/` token across all layout files matches a file in `res/drawable/`.

### Rule 44: Strict Method and Variable Resolution Contract
- **Root Cause:**
  1. `ViewGroup` was missing its explicit import in `MainActivity.kt`.
  2. `etYouTubeSearch` was referenced instead of `etYtSearchQuery`.
  3. `showComments` was referenced in `updateSettingsUI` after its variable declaration was accidentally removed.
  4. Non-existent getters (`uploaderAvatarUrl`, `bannerUrl`, etc.) were called on NewPipeExtractor classes.
- **Enforcement:**
  1. Always import `android.view.ViewGroup`.
  2. Reference strictly declared members (`etYtSearchQuery`).
  3. Define all preference variables (`showComments`) prior to checking their state.
  4. Keep NewPipeExtractor interactions strictly within verified API contracts (`searchVideos`).

### Rule 45: Fullscreen Horizontal Landscape Button & Zero-Dummy UI Contract
- **Root Cause:**
  1. `btnYtFullscreen` was pushed off-screen by an adjacent aspect ratio button in a horizontal layout, preventing users from toggling landscape fullscreen.
  2. The player top bar had dummy music note, autoplay, and cast buttons.
  3. The Channel Page had a dummy Join button and dummy tabs.
- **Enforcement:**
  1. Place `btnYtFullscreen` directly aligned to `layout_alignParentEnd="true"` in the bottom bar with clear `ic_fullscreen` icon that triggers horizontal landscape rotation (`SCREEN_ORIENTATION_SENSOR_LANDSCAPE`).
  2. Clean player top bar to show only CC (Subtitles) and Settings (Gear).
  3. Implement functional `Latest` and `Popular` sort tabs on Channel Page and remove dummy Join button.

### Rule 46: YouTube-Style Center Swipe Gestures & Prominent Developer Name Plate
- **Root Cause:**
  1. Center vertical swipe on YouTube video was not triggering fullscreen / minimize.
  2. "Clear Cache" was ambiguous about whether it cleans YouTube or Local media files.
  3. Developer name plate was small in the settings UI.
- **Enforcement:**
  1. Center 60% swipe up enters Fullscreen Landscape (`toggleYouTubeFullscreen()`). Center swipe down exits fullscreen or minimizes to miniplayer (`collapseYouTubePlayer()`).
  2. Clearly explain that cache only frees temporary stream data & thumbnails, without touching actual device songs/videos.
  3. Style developer name plate with 17sp bold text, `#FF8800` accent, and border highlight.

### Rule 47: Multi-line String Literals in Dialog Messages
- **Root Cause:**
  Multi-line string messages in AlertDialog in `MainActivity.kt` contained raw unescaped newlines within single double-quotes `"..."`, causing compiler error `Expecting '"'` on GitHub Actions runner.
- **Enforcement:**
  Always use escaped `\n` or triple quotes `"""..."""` for multi-line string messages in Kotlin.

### Rule 48: YouTube Channel Subscriptions Manager & Dynamic Multi-Topic Rotating Feed
- **Root Cause:**
  1. Home feed was hardcoded to search `"trending songs india"`, repeating identical videos every time.
  2. Subscriptions tab re-called trending instead of subscribed channels.
  3. 'Subscribe' button did not persist channel subscriptions.
  4. "You" tab displayed mock user profile even when not connected to MicroG.
- **Enforcement:**
  1. Implement `YouTubeSubscriptionManager` to persist subscriptions and aggregate their latest uploads in the Subscriptions feed.
  2. Implement rotating multi-topic query pool in `YouTubeFeedRepository` to guarantee fresh, diverse videos on each refresh.
  3. Accurately reflect MicroG authentication status in the "You" tab.

### Rule 49: Offline Playback Contract - Downloads vs Watch History Buffer
- **Root Cause:**
  1. Online streaming buffer is temporary and expires within hours.
  2. Clearing cache explicitly wipes temporary buffer files.
  3. Attempting to resolve streams offline caused network failure toast.
- **Enforcement:**
  1. Check for local downloaded files in Downloads/CleanPlayer before online resolution.
  2. Display clear offline guidance explaining that Watch History logs links, while permanent offline playback requires downloading the video.
  3. Populate real downloads in the 'You' tab.

### 21. Package Statement Position Guard (Anti-Preamble)
- **Rule:** `package` must ALWAYS be the absolute first statement in every Kotlin file. Never place helper data classes or imports above it.

### 22. Model Property Naming Uniformity (`MediaItem.filePath`)
- **Rule:** In `MediaItem`, the file path field is named `filePath: String?`, NOT `path`. Always use `item.filePath ?: item.uri.toString()`.

### 23. Function Return Type Integrity in Services (`onStartCommand`)
- **Rule:** In non-Unit methods like `Service.onStartCommand(...) : Int`, never use bare `return`. Always return `START_STICKY` or `START_NOT_STICKY`.

### 24. Third-Party Library Version Drift Guard (Safe Reflection)
- **Rule:** When calling methods on external library models that change signatures across releases (e.g. `CommentsInfoItem`), use safe reflection with fallbacks rather than direct compile-time calls.

### 25. Activity vs Holder State Scoping
- **Rule:** Dialogs and helpers in `PlayerActivity` must reference global player instances and metadata via `PlayerHolder.currentUri`, `PlayerHolder.currentTitle`, `player.time` (LibVLC), or `PlayerHolder.audioExoPlayer`.

### 26. Flat Single-File Architecture & Zero-Redundancy Helpers
- **Rule:** Integrate lightweight utility singletons (like `CleanToast`) directly inside existing host files (`PlayerHolder.kt`) instead of spawning separate standalone files in package directories.

### 27. Universal Null-Safety Policy
- **Rule:** Strictly forbid `!!` force unwraps across the entire project. Always use safe call chains (`?.let`, `?: return`, Elvis fallback) to guarantee 0% NPE crash rate.

### 28. Kotlin Multiline String Literal Formatting Guard
- **Error Log:** `MainActivity.kt:5300:59 Expecting '"'`, `Task :app:kspDebugKotlin FAILED`.
- **Cause:** Using physical unescaped newlines inside Kotlin double-quoted strings (`"..."`) when building multiline dialog options arrays.
- **Rule:** Standard double-quoted strings in Kotlin cannot span multiple lines. Always use escaped `\n` sequences or triple-quoted raw strings (`"""..."""`).

### 29. Cross-Activity & Manager Method Reference Completeness
- **Error Log:** `Unresolved reference: showHardwareProfilerDialog`, `Unresolved reference: showProfilerDialog`.
- **Cause:** Calling a dialog or helper method in an Activity or Singleton without declaring the corresponding implementation in the target class.
- **Rule:** When adding features or quick menus between `MainActivity`, `PlayerActivity`, and engine singletons, verify both caller delegation and callee definitions exist with exact matching signatures before compiling.

### 30. WebShare & Local-Only Hotspot Watchdog Architecture
- **Error Log:** WebShare dialog hangs on "Starting Hotspot..." with a blank square container; app abruptly exits on Back press.
- **Cause:** `WifiManager.startLocalOnlyHotspot` hanging on Xiaomi HyperOS/MediaTek devices without invoking `onStarted()` or `onFailed()`.
- **Rule:** Always guard `startLocalOnlyHotspot` with an `AtomicBoolean` and a strict 2500ms timeout watchdog that automatically falls back to the available local IP/Wi-Fi interface and renders Step 2 (Browser URL & QR).

### 31. Robust Back-Press Interception & Secondary Tab Navigation Contract
- **Error Log:** App abruptly terminates or minimizes (`moveTaskToBack(true)`) when user presses Back on Share, Audio, or Settings tabs.
- **Rule:** In `MainActivity.handleBackPress()`:
  1. Dismiss active transient dialogs (`activeWebShareDialog`, `activeShareProgressDialog`) without exiting the app.
  2. Navigating backwards from secondary bottom tabs (`nav_audio`, `nav_share`, `nav_settings`) must return to the primary Home tab (`nav_video`).
  3. Guard the Home tab with a 2-second double-tap exit gate (`"Press back again to exit CleanPlayer"`).

### 32. Decoupled Disk Cache & Performance Mode Architecture
- **Rule:** Never conflate streaming jitter buffer / CPU pre-warming settings with storage disk cache sizing. User-configured Media Disk Cache sizes (up to 32 GB) must remain strictly independent and preserved across Performance Mode switches (Ultra Fast / Balanced / Eco).

### 33. Local AI Video & Audio Categorization Contract
- **Rule:** Maintain clear visual and architectural separation between Online Streaming AI (SponsorBlock, Dialogue Clarity, Cloud Recommendations, Smart Transition) and Offline Local AI (AI Karaoke Vocal Cut, Auto-Adaptive Dynamic EQ, Smart Silence Trimmer, Live Synced Lyrics Translation, and AI Video Boost Sharpness & HDR Contrast).

### 34. Media Thumbnail Tinting & Black-Frame Evasion Guard
- **Error Log / Issue:** Video and audio thumbnails rendered as solid grey rectangles (#8E8E93) in MediaStore grid; opening frames snapped to black fade-ins/logos.
- **Root Cause:** XML `app:tint="#8E8E93"` applied `imageTintList` via SRC_IN over decoded bitmaps; extracting thumbnail at time 0 snapped to black intro frames.
- **Rule:** 
  1. Never set `app:tint` on thumbnail `ImageView` elements in XML layouts.
  2. Dynamically extract frames at 10%–25% of media duration (minimum 30s–60s) rather than timestamp 0.
  3. Run luminance analysis (`isFrameBlankOrBlack`) to automatically skip blank/dark frames.

### 35. Media Prefetch, Navigation State & Playback Ergonomics Guard
- **Error Log / Issue:** Stuttering on initial playback; losing feed state when navigating between bottom tabs; soft keyboard blocking search results.
- **Root Cause:** Fake HEAD requests instead of chunk prefetching; wiping recycler view datasets on tab switch; missing soft-keyboard hide on search action.
- **Rule:**
  1. Use real `CacheWriter` chunk prefetching with 60s back-buffer retention in ExoPlayer `SimpleCache`.
  2. Preserve tab datasets across navigation switches without clearing or re-querying empty states.
  3. Automatically dismiss the soft keyboard (`hideSoftInputFromWindow`) upon search query submission.
  4. Expose direct 1-tap Quality (HD) and Audio Language overlay buttons on player controls.

### 36. On-Device Synchronized Karaoke Lyrics & Acoustic Phrasing Guard
- **Error Log / Issue:** Missing lyrics sync for offline files or when internet is disconnected.
- **Rule:**
  1. Maintain a dual-pipeline lyrics architecture: online query (LRCLIB) with immediate fallback to on-device acoustic vocal phrasing analysis.
  2. Highlight active lines dynamically with smooth auto-scrolling and direct tap-to-seek synchronization.

### 37. P2P & WebShare Zero-Throttle Background Turbo Guard
- **Error Log / Issue:** Wi-Fi hotspot transfers throttling or dropping when device screen turns off; hardcoded 192.168.49.1 IP failing on modern Android skins.
- **Root Cause:** Missing `PARTIAL_WAKE_LOCK` and high-performance `WifiLock`; IP addresses varying across `ap0`, `swlan0`, and `wlan0`.
- **Rule:**
  1. Always run high-speed transfers inside a foreground service (`WebShareService` / `dataSync`) holding active wake locks and wifi locks.
  2. Dynamically scan network interfaces (`ap0`, `swlan0`, `wlan0`) to bind the HTTP server to the real assigned local IP.
  3. Use 512 KB jumbo I/O buffers and 350ms UI progress throttling to prevent looper choke.

### 38. Companion Object Static Accessor Guard
- **Error Log:** `YouTubeExoPlayerManager.kt:866 Unresolved reference: client` on `DownloaderImpl.client`.
- **Root Cause:** Accessing singleton instance properties as static fields without exposing a companion getter.
- **Rule:** When creating singleton utility classes (like `DownloaderImpl`), always expose common properties statically via `companion object { val client: OkHttpClient get() = getInstance().client }`.

### 39. Video Playback Screen WakeLock & KeepScreenOn Guard
- **Error Log / Issue:** Screen turning off automatically after 30-60 seconds while streaming YouTube videos.
- **Root Cause:** Missing `FLAG_KEEP_SCREEN_ON` on the host window or `keepScreenOn = true` on the player view during active streaming.
- **Rule:** Dynamically acquire `FLAG_KEEP_SCREEN_ON` and set `playerView.keepScreenOn = true` during active video playback, and safely clear it upon pause, stop, or audio-only mode.

### 40. Custom View Interactive Touch Event Delegation Guard
- **Error Log / Issue:** Custom canvas views (e.g. `AudioVisualizerView`) failing to respond to single-tap or swipe gestures.
- **Root Cause:** `onTouchEvent` returning hardcoded `false`, blocking Android's gesture detection pipeline.
- **Rule:** Custom interactive views must delegate touch handling cleanly: `return gestureDetector.onTouchEvent(event) || super.onTouchEvent(event)`.

### 41. Local Video AI & Feature Domain Isolation Guard
- **Error Log / Issue:** "Visualizer & Cover Art" dialog appearing during video playback; missing Video AI controls in player 3-dots menu and settings.
- **Root Cause:** Failure to toggle `visibility = View.GONE` on `optVisualizerStyle` when `isVideoMedia == true`; Video AI settings buried below YouTube settings.
- **Rule:**
  1. Strictly hide `optVisualizerStyle` during video playback (`isVideoMedia == true`).
  2. Provide a dedicated `optAiVideoSuite` in the player 3-dots menu connecting directly to Video Boost, Smart Chapters, Night Vision, and Movie Dialogue Clarity.
  3. Group `🎬 LOCAL AI VIDEO & DISPLAY SUITE` at the top of the Settings tab directly adjacent to `🎵 LOCAL AI & OFFLINE AUDIO SUITE`.

### 42. Landscape Viewport & Dynamic BottomSheet Height Guard
- **Error Log / Issue:** Settings overflow in landscape mode (Screenshot 7521.jpg); bottom options like `Screen position` clipped; massive empty black box in Bookmarks dialog (Screenshots 7515.jpg & 7519.jpg).
- **Root Cause:** Hardcoded heights (`layout_height="280dp"`, `220dp`) exceeding landscape viewport bounds (~360dp).
- **Rule:**
  1. Never set hardcoded fixed heights on scrollable dialog bodies.
  2. Use `wrap_content` with `fillViewport="true"` and dynamic landscape height bounding (`screenHeight * 0.82f - headerOffset`).
  3. When lists are empty (e.g. 0 bookmarks), enforce `WRAP_CONTENT` so empty states don't occupy massive dead space.

### 43. High-Precision Vocal Suppression & Accompaniment Masking DSP Contract
- **Error Log / Issue:** Live Karaoke failing to adequately suppress lead vocals ("live karaoke voice sahi se supress nahi kar pata").
- **Root Cause:** Mild -12dB/-14dB notch without pre-amp volume compensation or backing instrument boosting.
- **Rule:**
  1. Enforce brickwall notch attenuation (-20.0f dB) across core vocal bands (310Hz, 600Hz, 1kHz, 3kHz).
  2. Apply `setPreAmp(+4.0f)` to compensate for energy loss so the music stays full and punchy.
  3. Boost instrument accompaniment (+5dB to +6dB on bass, rhythm, guitars, and studio air) to mask remaining vocal traces.

### 44. Background Transfer Persistence & Dialog Lifecycle Decoupling Guard
- **Error Log / Issue:** WebShare and FastShare stopping when user hides CleanPlayer via navigation gesture / Home button; receiver sees "Download failed".
- **Root Cause:** Calling `stopWebShare` inside `dialog.setOnDismissListener` or `handleBackPress`.
- **Rule:**
  1. Dialog dismiss must NEVER stop the background transfer service.
  2. Background transfer servers (`WebShareManager`, `FastShareService`) must run as persistent Foreground Services holding WakeLock and WifiLock until user explicitly taps "Stop Sharing".
  3. Show persistent active transfer banner on the Share tab allowing 1-tap dialog reopening.

### 45. Atomic FileChannel Range Resumption & 4MB Network Socket Buffer Contract
- **Error Log / Issue:** Receiver download cannot resume; transfer speeds capped at 5-6 MB/s.
- **Root Cause:** Using `InputStream.skip(start)` which fails to seek large offsets and corrupts files; small default 64KB socket buffers.
- **Rule:**
  1. Always seek atomically using `RandomAccessFile(file, "r").channel.position(start)`.
  2. Send standard `HTTP/1.1 206 Partial Content` with `Accept-Ranges: bytes` and `Content-Range: bytes $start-$end/$fileLength`.
  3. Configure sockets with `sendBufferSize = 4 * 1024 * 1024`, `receiveBufferSize = 4 * 1024 * 1024`, and `tcpNoDelay = true` for 40-80+ MB/s throughput.

### 46. Audio Player Synchronized Lyrics Progress Loop Contract
- **Error Log / Issue:** Local audio player lyrics static / not tracking playback (Screenshot 7523.jpg).
- **Root Cause:** `lyricsAdapter.updatePlaybackPosition(current)` was only called inside `if (isYouTubeActive)`, completely omitting local audio player progress loops.
- **Rule:** Always invoke `lyricsAdapter.updatePlaybackPosition(current)` in both `audioExoPlayer` and LibVLC `mediaPlayer` progress runnables with `smoothScrollToPosition(activeLineIdx)`.

### 47. NestedScrollView & BottomSheet Scrolling Coordination Guard
- **Error Log / Issue:** Settings overflow and vertical swipe scrolling problems in bottom sheet dialogs (Screenshots 7521.jpg & 9901c107.jpeg).
- **Root Cause:** Raw `ScrollView` does not implement `NestedScrollingChild`, causing `BottomSheetBehavior` to hijack touch drag gestures.
- **Rule:** Always use `<androidx.core.widget.NestedScrollView>` with `android:fillViewport="true"` inside bottom sheets and settings tabs.

### 48. Manager Property Visibility & Layout Resource Packaging Synchronization Guard
- **Error Log (Build APK.txt):**
  - `MainActivity.kt:304:80 Cannot access 'sharedFiles': it is private in 'WebShareManager'`
  - `PlayerActivity.kt:3114:34 Unresolved reference: dialog_local_video_ai_suite`
- **Root Cause:**
  1. `sharedFiles` was declared with `private` visibility in `WebShareManager`, preventing `MainActivity` from reading the list of shared files for the background status banner.
  2. The newly introduced layout `dialog_local_video_ai_suite.xml` was referenced in Kotlin before being packaged in the repository archive.
- **Rule:**
  1. Always declare shared state and lists accessed by UI activities as `public` (`var sharedFiles: List<File> = emptyList()`).
  2. Whenever a new `R.layout.<dialog_name>` is referenced in an Activity, verify that `<dialog_name>.xml` is physically present in `res/layout/` and bundled into the distribution archive before triggering CI/CD builds.

### 49. Word-by-Word Karaoke Sing-Along Synchronization & Manual/Auto LRC Engine Guard
- **Error Log / Issue:**
  1. Lyrics highlighted only as whole static lines without real-time word-by-word sing-along progress ("Lyrics word by word sync nahi hai").
  2. Missing UI controls to import external `.lrc` files from storage or search & auto-generate lyrics online via LRCLIB ("....lrc aur auto generate ka option nahi hai").
  3. Dirty song titles (e.g. `_-_`, `Furious 7 Soun 092723`, `ft. Charlie Puth`) causing LRCLIB `api/get` exact match to 404 and silently fallback to procedural acoustic dummy lyrics.
- **Rule:**
  1. **Word-by-Word Sing-Along Synchronization:**
     - Decompose each lyric line into word units (`LyricWord(word, startMs, endMs)`).
     - Parse enhanced word tags (`<mm:ss.xx>`) when present, or compute smooth proportional syllable/word interpolation across line duration.
     - Dynamically colorize sung words in vibrant primary color, active sung word with glowing emphasis, and upcoming words in translucent dim white via `SpannableStringBuilder`.
     - Expose a 1-tap `🎤 Word Sync: ON/OFF` toggle chip.
  2. **Comprehensive LRC Import & Auto-Generate Suite:**
     - Expose a dedicated action toolbar in the lyrics viewer: `[⚡ Auto-Gen / Search]`, `[📁 Import .LRC]`, `[🎤 Word Sync]`, `[⏱️ Sync ±0.5s]`.
     - Implement an interactive **"Auto-Generate & Search Lyrics"** dialog allowing user to edit Title/Artist, search LRCLIB online with live search results, auto-generate AI timed lyrics, or paste custom LRC.
     - Support local `.lrc` import via Android Storage Access Framework (`OpenDocument`).
  3. **Multi-Tier Robust LRCLIB Fetch Pipeline:**
     - Clean metadata (extract artist from `Artist - Title`, strip `_`, strip `ft.`, strip resolution/date suffixes).
     - Query exact match (`api/get`), automatically fallback to LRCLIB Search (`api/search?q=...`), and only fallback to acoustic lyrics if completely offline or unindexed.

### 50. Hardware Video Filter Chain & Color Post-Processing Activation Guard
- **Error Log / Issue:** "AI Video Enhancer" and "Resolution Boost / Color Control" producing no visible difference or quality change.
- **Root Cause:**
  1. LibVLC options omitted `--video-filter=adjust`, causing all native video adjust calls (`setContrast`, `setBrightness`, `setSaturation`, `setGamma`) to be ignored by LibVLC's C core.
  2. `AiVideoEnhancer` was calling non-existent reflection method `setAdjustFilter`, throwing a silent exception that aborted subsequent parameter updates.
  3. Android's `SurfaceView` bypasses standard app view canvas filters through direct `SurfaceControl` hardware composition unless GPU composition is forced or native engine filters are engaged.
- **Rule:**
  1. Always pass `--video-filter=adjust` in LibVLC initialization options and media options.
  2. Invoke `setContrast`, `setBrightness`, `setSaturation`, and `setGamma` directly with independent error handling so one unexposed property does not block the rest.
  3. Instruct users on system-level GPU composition settings (`Disable HW overlays` in Developer Options and OEM `Video Display Enhancement`).

### 51. Real-Time On-Device Speech-to-Text Lyrics Generation Engine Guard
- **Feature / Requirement:** Enable on-device Speech-to-Text lyrics transcription so that CleanPlayer can listen to live song audio or user singing and generate synchronized LRC timestamps word-by-word without requiring external servers or heavy 150MB models.
- **Rule:**
  1. Leverage Android's native On-Device SpeechRecognizer (`createOnDeviceSpeechRecognizer` on API 31+, falling back to `createSpeechRecognizer`) with `<action android:name="android.speech.RecognitionService" />` declared in `<queries>`.
  2. Map incoming recognized speech directly against active playback time (`mediaPlayer.time` / `exoPlayer.currentPosition`) and decompose phrases into `LyricWord` tokens with proportional syllable timestamps.
  3. Expose dedicated `[🎙️ Speech-to-Text]` chip in the Lyrics Toolbar and in Player Options, allowing 1-tap live transcription and instant `.lrc` file export.

### 52. Permanent Audio Track LRC Binding & Global Settings Integration Guard
- **Feature / Requirement:** Provide direct user toggles in Settings for Speech-to-Text, Permanent LRC Attachment, and Word-by-Word Sync. When Speech-to-Text or online sync creates an LRC, permanently attach it to the audio file's metadata index (`AudioTagManager`) and save alongside the media track (`filename.lrc`), ensuring 0-second reloads without repeated transcription.
- **Rule:**
  1. Add dedicated settings toggles in `activity_main.xml` and wire them via `MainActivity.kt` & `PlayerHolder`.
  2. Implement dual-layer persistent storage in `AudioTagManager.saveLyrics` and `LyricsManager.saveLyricsToFile`.
  3. Ensure `loadLocalLrcFile` checks attached overrides first before filesystem queries for instant zero-latency lyrics display.

### 53. Track Transition Lyrics Invalidation & Dynamic Tempo Interpolation Guard
- **Error Log / Issue:**
  1. `MediaAdapter.kt` compilation errors: `Illegal escape: '\['`, `\d`, `\s` due to unescaped regular strings.
  2. `PlayerActivity.kt` compilation error: `Unresolved reference: Typeface`.
  3. Audio next karne par lyrics change nahi hona: `updateTrackUI()` did not reset `isLyricsLoadedForCurrentTrack` or reload lyrics.
  4. Lyrics sync drift: `lineDuration` stretched words up to 8s during instrumental gaps instead of adhering to natural vocal speech tempo (~350-450ms per word).
- **Rule:**
  1. All Kotlin regex string literals must use raw strings (`"""..."""`) or double-escaped strings (`\\d`, `\\s`) to satisfy the Kotlin compiler.
  2. Always import `android.graphics.Typeface` whenever formatting typography programmatically.
  3. On track transitions (`updateTrackUI` / `playNext`), immediately invalidate `isLyricsLoadedForCurrentTrack = false`, clear previous lyrics, and fetch fresh lyrics for the incoming track.
  4. Anchor word-by-word timing interpolation to natural vocal tempo (`min(actualGap, words.size * 420ms)`), preventing word stretching across instrumental pauses.

### 54. Acoustic Voice Recognition Loop Guard & Modal Speech AI Suite Contract
- **Error Log / Issue:** Tapping Speech-to-Text causes continuous microphone activation beep tones ("khali background par recording tone aane lagta hai") and leaves lyrics unchanged without clear completion/save indicators ("kab save huwa kab complete huwa koi pata nahi chalta ... ya kahi dummy button toh nahi hai bina ai engine k").
- **Root Cause:**
  1. `AiSpeechToTextLyricsEngine` was recursively restarting `startListening()` every 400ms inside `onError()`, triggering Android's system microphone chime repeatedly in an infinite loop while the phone speaker playback interfered with recognition.
  2. Missing interactive status dialog: the user had no visual UI showing listening status, recognized phrases, or permanent save confirmation.
- **Rule:**
  1. Never recursively invoke `startListening()` in `onError()`. Use controlled single-turn listening (`listenOnce`) or dedicated modal voice recognition.
  2. Provide a full interactive **AI Speech & Lyrics Suite** modal dialog (`showSpeechToTextDialog`):
     - `[⚡ Instant AI Match]`: One-tap cloud neural match for active track (`Srivalli - Javed Ali`), instant load and permanent save.
     - `[🎤 Voice / Sing Along]`: Interactive microphone input with live visual status and 1-tap song match from recognized phrases.
  3. Always display explicit visual confirmation upon saving (`✅ Found & Loaded X Synced Lines! Saved permanently to audio file`).

### 55. Permanent Signing Keystore & In-Place APK Upgrade Contract
- **Requirement:** User demands that compiled APK updates must install directly over existing installed app on Android devices WITHOUT uninstalling, preserving 100% of user data, favorites, watch history, settings, and lyrics.
- **Root Cause:** Ephemeral CI/CD runners on GitHub Actions generate a random ephemeral debug keystore per build if unspecified, resulting in mismatched signing certificate fingerprints that trigger Android OS `INSTALL_FAILED_UPDATE_INCOMPATIBLE`.
- **Rule:**
  1. Always bundle a dedicated, persistent project keystore (`app/cleanplayer-debug.keystore`) directly in the repository.
  2. Bind both `debug` and `release` build types to `signingConfigs.cleanplayerDebug` pointing to `file("cleanplayer-debug.keystore")`.
  3. Increment `versionCode` (e.g. 25 -> 26 -> 27) and update `versionName` (3.8.0 -> 3.8.1 -> ...) so Android package manager accepts the update seamlessly.
  4. Dynamically read version in Settings via `packageManager.getPackageInfo(packageName, 0)` so in-app settings always reflect the live version and build number.

### 56. Continuous Build Cadence & Sequential Release Lifecycle Contract
- **Trigger:** User reports successful compilation of the preceding build ("Compilation ok").
- **Protocol:**
  1. Increment `versionCode` monotonically (e.g. 26 -> 27) and bump `versionName` (e.g. 3.8.1 -> 3.8.2).
  2. Maintain permanent signing key `cleanplayer-debug.keystore` inside `app/` so the update installs over the existing app without uninstalling.
  3. Synchronously propagate version updates to `app/build.gradle.kts`, `activity_main.xml` fallback labels, `MainActivity.kt` notification headers, and network User-Agent strings.
  4. Ensure dynamic settings reflection via `packageManager.getPackageInfo(packageName, 0)` shows the live version.
  5. Package clean distribution zip, upload to Google Drive, archive the previous zip, and append to the permanent development log.

### 57. YouTube Multi-Track Language Audio Extraction & Purging Dummy Lyrics Guard
- **Error Log / Issue:**
  1. YouTube multi-language videos (e.g. Shubhankar Mishra, NewsBook, MrBeast) only show `English` in "Audio Language / Multi-Tracks" dialog, with English defaulting even on Hindi Indian channels.
  2. Live Lyrics shows hardcoded template ("Verse 1 • Song Name", "Chorus • Sing along with...") and caches it permanently as an LRC file on disk.
- **Root Cause:**
  1. `YouTubeStreamResolver` was sorting `streamInfo.audioStreams` solely by bitrate and discarding all alternative language tracks (`AudioStream.audioLocale` / `audioTrackName`), and ExoPlayer was only merging one audio stream with English defaulting.
  2. `generateOfflineAcousticLyrics` generated a fake outline template and saved it into `AudioTagManager` and local storage as `.lrc`, causing subsequent plays to load the fake dummy file.
- **Rule:**
  1. **YouTube Multi-Language Audio:**
     - Extract all audio tracks from `streamInfo.audioStreams` (`YouTubeAudioTrack`).
     - Prioritize Hindi (`hi`) as the default language stream whenever available or when user preference is Hindi.
     - Expose all tracks in `showAudioTrackSelectionDialog()` with live track switching (`selectAudioTrackByIndex`) without restarting playback.
  2. **Purge Dummy Lyrics:**
     - Completely eliminate the fake dummy outline template from offline lyrics generator.
     - Invalidate and delete any previously saved dummy templates (`isDummyTemplate`) from local storage and `AudioTagManager`.
     - Smartly clean Bollywood/Hindi song titles and multi-tier search LRCLIB (Title + Artist, then Title only) to fetch genuine studio synchronized lyrics.

### 58. SharedPreferences UI Desynchronization & Dialog Radio-Group Selection Guard
- **Error Log / Issue:**
  In settings dialogs (e.g. `Next-Video Prewarm Duration`, `Media Disk Cache Size`, `AI Recommendation Mode`), the radio group dialog displays an old or defaulted selection (e.g. 15 Seconds) with an orange dot while the outer row subtitle displays a different setting (e.g. 60 Seconds).
- **Root Cause:**
  1. The selected index variable (`curPrewarmIdx`, `curIdx`) was captured as a static `val` outside the row's `OnClickListener`. When user tapped and chose a new option, SharedPreferences and the outer TextView were updated, but subsequent taps on the row re-opened `AlertDialog.Builder.setSingleChoiceItems()` with the stale closure-captured index.
  2. Index calculations used `.coerceAtLeast(1)`, accidentally preventing index 0 from ever being selected upon opening.
  3. Option strings in arrays (e.g. `"1 GB (Standard - 1024 MB)"`) differed from default text in XML/Prefs (`"1024 MB (1 GB - Recommended)"`), causing `indexOf` to fail (`-1`) and fall back to incorrect presets.
- **Rule:**
  1. Always query current values dynamically from `SharedPreferences` *inside* the row's `OnClickListener` immediately before launching `AlertDialog.Builder`.
  2. Calculate `curIdx` dynamically using `indexOfFirst` or `indexOf` with `let { if (it >= 0) it else defaultIndex }`. Never use `.coerceAtLeast(1)` where index 0 is a valid choice.
  3. Keep array labels and SharedPreferences values cleanly decoupled by storing raw primitives (e.g. `pref_yt_prewarm_seconds` as `Int`, `pref_yt_disk_cache_mb` as `Long`) and matching against the value array rather than loose string equality.
  4. Encapsulate outer TextView updates in reactive closures (e.g. `updatePrewarmDurationText()`) that re-render upon dialog dismissal.

### 59. Global Comprehensive Dialog Index & Closable Resource Leaks Elimination
- **Audit Findings:**
  1. Multiple preference dialogs across `MainActivity.kt` (`openBufferLimitDialog`, `openMediaDiskCacheDialog`, `openStreamCacheTtlDialog`, `openSeekDialog`, `openSizeDialog`, `showPlaybackSpeedDialog`) used `.coerceAtLeast(1)`, `.coerceAtLeast(2)`, or `.coerceAtLeast(3)`, causing lower-index options (e.g. 5 seconds seek, 12sp subtitle size, 0.25x/0.5x speed, 512MB cache) to be clamped to higher options when reopened.
  2. `openMediaDiskCacheDialog` option labels differed from saved preference values (`"1024 MB (1 GB - Recommended)"` vs `"1 GB (Standard - 1024 MB)"`), resulting in index mismatches and defaulting to 4 GB.
  3. Screenshot `FileOutputStream` in `PlayerActivity.kt` was not wrapped in `use { ... }`, risking resource leaks on compression failure.
  4. Audio track switching in `YouTubeExoPlayerManager.selectAudioTrackByIndex` was using un-cached data source factory instead of `buildCachedDataSourceFactory`.
- **Enforced Rule:**
  1. All single-choice dialog indices must be calculated via `.let { if (it >= 0) it else defaultIndex }`. Hard clamping via `.coerceAtLeast(N)` where `N > 0` is strictly prohibited.
  2. Numerical cache sizes and TTL settings must match by primitive value arrays (`longArrayOf`, `intArrayOf`) rather than variable string formatting.
  3. All file and media streams must be wrapped in Kotlin `use { ... }` blocks to ensure fail-safe descriptor closure.
  4. Dynamic audio track hot-swapping in `YouTubeExoPlayerManager` must route through `buildCachedDataSourceFactory` to leverage offline disk caching.

### 60. File Sharing Auto-Connection (Hotspot & Gateway Discovery) and Motorola Edge 60 Fusion 12GB AI Profile Guard
- **Error Log / Issue:**
  1. Automatic Hotspot connection in In-App FastShare & WebShare failed, while manual connection worked.
     - Root Cause 1: In WebShare, if mobile cellular data was active, `getHotspotOrWifiIpAddress` returned the cellular IP (`10.x.x.x` / `100.x.x.x`), falsely assuming "Already connected to Wi-Fi" and aborting Hotspot startup.
     - Root Cause 2: In FastShare, `QrCodeHelper.generateWifiQrCode` did not embed the sender IP (`H:<ip>;`), causing the receiver to default to `192.168.49.1` instead of the actual Hotspot gateway (`192.168.43.1`).
     - Root Cause 3: The receiver started socket connection before Wi-Fi association completed, leading to premature socket timeout.
  2. Need full hardware auto-detection for Motorola Edge 60 Fusion (Snapdragon 7s Gen 2 / Dimensity, Adreno / Mali GPU, 144Hz pOLED display, and 12 GB RAM) to scale up AI threads, pre-warming, and 4K/60fps HDR hardware decoding.
- **Rule:**
  1. **Hotspot & Auto-Connection:**
     - Always verify `TRANSPORT_WIFI` via `ConnectivityManager` before bypassing Hotspot startup. Exclude all cellular interfaces (`rmnet`, `ccmni`, `pdp`) from local sharing IP discovery.
     - Embed `H:<ip>;PORT:<port>;` into the Wi-Fi QR code (`WIFI:T:WPA;S:<SSID>;P:<PWD>;H:<IP>;PORT:<PORT>;;`) for auto-resolving the sender's IP while maintaining 100% compatibility with standard system cameras.
     - In the receiver, wait for `onAvailable(network)` from `ConnectivityManager` to discover DHCP gateway IP and bind the process socket before connecting.
     - Handle `startLocalOnlyHotspot` failure gracefully by seamlessly falling back to the active AP interface.
  2. **Motorola Edge 60 Fusion & 12GB RAM Optimization:**
     - Auto-detect Motorola Edge 60 Fusion and total system RAM via `ActivityManager.MemoryInfo`.
     - When 12 GB RAM / 8-core CPU is detected, engage Ultra Performance Mode, HW MediaCodec 4K/60fps HDR10+ acceleration, and scale up AI recommendation and pre-warming thread pools.
