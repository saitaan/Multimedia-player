# CleanPlayer Android & GitHub Actions Build Verification Rules

This document serves as an exhaustive knowledge base and pre-flight checklist created from historical build logs and errors to guarantee zero compilation errors, zero playback errors, and seamless user experience.

---

### 1. Mandatory Android Import Auditing
- **Handlers & Loopers**: Whenever `Handler(...)` or `Looper.getMainLooper()` is referenced, ensure both `import android.os.Handler` and `import android.os.Looper` are explicitly present at the top of the file.
- **Widgets**: Any newly introduced layout components (e.g. `RelativeLayout`, `ProgressBar`, `MaterialCardView`, `AudioVisualizerView`) must be explicitly imported.

### 2. Method Signatures & Strict Parameter Order
- **ImageLoaderHelper**: `ImageLoaderHelper.loadImage(url: String?, imageView: ImageView, placeholderRes: Int = R.drawable.ic_video)`.
  - *Rule*: Parameter 1 is ALWAYS the `url` (String?). Parameter 2 is ALWAYS the `imageView` (ImageView). Never invert them.

### 3. Class-Level Property Scoping
- **SharedPreferences (`ytPrefs`)**: Shared instances must be declared at class level:
  `private val ytPrefs by lazy { getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE) }`
  Never declare shared preferences only within local helper methods if they are accessed across multiple functions or dialog listeners.

### 4. Adapter Methods & Data Access
- **RecyclerView Adapters**: Whenever calling `.getItems()` on an adapter (such as `YouTubeShortsAdapter` or `YouTubeFeedAdapter`), the adapter MUST declare:
  `fun getItems(): List<T> = items`
  Never query adapter collections without verifying the public getter.

### 5. View Binding & Lateinit Integrity
- **View References**: Every `@+id/<name>` accessed in Kotlin must have:
  1. A corresponding property declaration (e.g., `private lateinit var ivShortsDislike: ImageView`).
  2. A corresponding `findViewById` initialization in `initViews()`.
  Never reference a view ID directly without verifying both declaration and initialization.

### 6. Function Resolution & Helper Verification
- **Existence Check**: Never call functions (such as `showYouTubeSearch()` or `updateMiniPlayerUI()`) without verifying their declaration. If creating a new flow, implement the helper function completely.

### 7. Kotlin String Template Quotation Safety
- **No Nested Quotes**: In Kotlin string templates `"${...}"`, avoid nested double quotes (e.g. `"${if (x) \"A\" else \"B\"}"` or `"${err ?: \"Playback error\"}"`).
  - *Rule*: Always extract conditions, default values, or formatted strings into separate local `val` variables first, then interpolate simply as `"$myVar"`.

### 8. Dialog & Menu Index Mapping
- **Index Alignment**: In `AlertDialog.Builder.setItems(options) { _, which -> when (which) { ... } }`:
  - Strictly verify that index 0 corresponds to item 0, index 1 to item 1, ..., and index 4 to item 4 (e.g. `4 -> MicroGAuthManager.showAccountDialog(this)`).
  - Never duplicate or mismatch action branches.

### 9. Seamless Background Play & Back Navigation
- **No Premature Pausing**: Pressing Back while audio/video is playing should NEVER call `pause()` or kill background playback.
  - Full player -> collapses to miniplayer (`return true`).
  - Home feed with active playback -> triggers `MediaPlaybackService.start(...)` and calls `moveTaskToBack(true)` (`return true`).
  - Playback continues uninterrupted in background with system notification controls.

### 10. System Media Session & Notification Integration
- **Metadata Synchronization**: `MediaPlaybackService` must reflect live YouTube metadata (`title`, `channelTitle`, and thumbnail bitmap) in both `MediaSessionCompat` and `NotificationCompat.Builder`, enabling full lock screen and home screen widget support.
- **Rewind/Fast-Forward**: Media controls should rewind 10s on previous and forward 10s on next for video streams.

### 11. GitHub Actions Gradle Setup
- **Automated Wrapper**: Always include the automatic Gradle 8.4 wrapper setup step in all GitHub Actions workflow files (`android_build.yml` and `build-apk.yml`) to ensure remote builds pass without relying on pre-committed JARs.

### 12. Strict Class-Level Scope & Code Placement (Anti-Top-Level Leak)
- **Class Scope Containment**: When adding new helper methods, receivers, or dialog handlers in Kotlin, they MUST be placed strictly inside the target `class` body before the final closing brace `}`.
  - *Symptom if violated*: `'this' is not defined in this context`, `Unresolved reference: allYtFeedVideos`, `Variable expected`, `Unresolved reference: layoutInflater`.
  - *Audit*: Every Kotlin file must be checked to ensure no member functions or class property references reside at the file top-level outside class definitions.

### 13. Explicit Framework Imports for UI Insets, Audio & Gestures
- **WindowInsets & Edge-to-Edge**: Any usage of `WindowInsets` or `WindowInsetsController` requires:
  - `import android.view.WindowInsets`
  - `import android.view.WindowInsetsController`
- **Audio & Media Framework**: Any usage of `AudioManager` requires:
  - `import android.media.AudioManager`
- **Touch & Gesture Handling**: Any usage of `GestureDetector` or `MotionEvent` requires:
  - `import android.view.GestureDetector`
  - `import android.view.MotionEvent`

### 14. Kotlin Math Overload Disambiguation (`abs` & mixed float/int arithmetic)
- `kotlin.math.abs()`: Overload resolution ambiguity can happen if variables have implicit types. Always pass explicit float or double:
  `kotlin.math.abs(dy.toFloat())` or `kotlin.math.abs(dx.toFloat())`.
- Mixed arithmetic (Float / Int): Explicitly cast Int to Float when scaling (e.g. `((delta / h) * maxVolume.toFloat()).toInt()`).

### 15. Real-Time Manager Callback Verification
- When assigning callbacks on manager singletons (e.g. `YouTubeExoPlayerManager.onVideoEnded`), the target property MUST be explicitly declared in the manager class with public/internal visibility.

### 16. BottomSheetDialog Nested Scrolling & State Expansion
- **Nested Scrolling**: Any scrollable view inside a `BottomSheetDialog` MUST be `androidx.core.widget.NestedScrollView` with `android:fillViewport="true"` and `android:layout_height="0dp"` with `android:layout_weight="1"`. Standard `<ScrollView>` must NEVER be used inside a bottom sheet as it causes drag gesture conflicts and scroll freezes.
- **State Expansion**: Always configure `BottomSheetBehavior` with `state = STATE_EXPANDED` and `skipCollapsed = true` inside `setOnShowListener` to prevent content clipping and half-collapsed truncation.

### 17. Audio-Only Mode Gesture Decoupling & Pure Visualizer Surface
- **Gesture Isolation**: When `isAudioOnlyMode` is active, disable video-centric volume, brightness, and seek touch gestures so they do not conflict with user interactions.
- **Swipe Model Switching**: Touch events in audio mode must trigger horizontal fling listeners to cycle visualizer models (`nextModel()` / `prevModel()`).
- **Visualizer Priority**: In audio-only mode, hide video thumbnails in both detail and floating mini players, allowing `AudioVisualizerView` to occupy the active display area.
