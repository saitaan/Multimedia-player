# CleanPlayer Android & GitHub Actions Build Verification Rules

This document serves as an exhaustive knowledge base and pre-flight checklist created from historical build logs and errors to guarantee zero compilation errors, zero playback errors, and seamless user experience.

---

### 1. Mandatory Android Import Auditing
- **Handlers & Loopers**: Whenever `Handler(...)` or `Looper.getMainLooper()` is referenced, ensure both `import android.os.Handler` and `import android.os.Looper` are explicitly present at the top of the file.
- **Widgets**: Any newly introduced layout components (e.g. `RelativeLayout`, `ProgressBar`, `MaterialCardView`, `AudioVisualizerView`) must be explicitly imported.

### 2. Method Signatures & Strict Parameter Order
- **ImageLoaderHelper**: `ImageLoaderHelper.loadImage(url: String?, imageView: ImageView, placeholderRes: Int = R.drawable.ic_video)`.
  - *Rule*: Parameter 1 is ALWAYS the `url` (String?). Parameter 2 is ALWAYS the `imageView` (ImageView). Never invert them.

### 3. Class-Level Property Scoping
- **SharedPreferences (`ytPrefs`)**: Shared instances must be declared at class level:
  `private val ytPrefs by lazy { getSharedPreferences("cleanplayer_yt_prefs", Context.MODE_PRIVATE) }`
  Never declare shared preferences only within local helper methods if they are accessed across multiple functions or dialog listeners.

### 4. Adapter Methods & Data Access
- **RecyclerView Adapters**: Whenever calling `.getItems()` on an adapter (such as `YouTubeShortsAdapter` or `YouTubeFeedAdapter`), the adapter MUST declare:
  `fun getItems(): List<T> = items`
  Never query adapter collections without verifying the public getter.

### 5. View Binding & Lateinit Integrity
- **View References**: Every `@+id/<name>` accessed in Kotlin must have:
  1. A corresponding property declaration (e.g., `private lateinit var ivShortsDislike: ImageView`).
  2. A corresponding `findViewById` initialization in `initViews()`.
  Never reference a view ID directly without verifying both declaration and initialization.

### 6. Function Resolution & Helper Verification
- **Existence Check**: Never call functions (such as `showYouTubeSearch()` or `updateMiniPlayerUI()`) without verifying their declaration. If creating a new flow, implement the helper function completely.

### 7. Kotlin String Template Quotation Safety
- **No Nested Quotes**: In Kotlin string templates `"${...}"`, avoid nested double quotes (e.g. `"${if (x) \"A\" else \"B\"}"` or `"${err ?: \"Playback error\"}"`).
  - *Rule*: Always extract conditions, default values, or formatted strings into separate local `val` variables first, then interpolate simply as `"$myVar"`.

### 8. Dialog & Menu Index Mapping
- **Index Alignment**: In `AlertDialog.Builder.setItems(options) { _, which -> when (which) { ... } }`:
  - Strictly verify that index 0 corresponds to item 0, index 1 to item 1, ..., and index 4 to item 4 (e.g. `4 -> MicroGAuthManager.showAccountDialog(this)`).
  - Never duplicate or mismatch action branches.

### 9. Seamless Background Play & Back Navigation
- **No Premature Pausing**: Pressing Back while audio/video is playing should NEVER call `pause()` or kill background playback.
  - Full player -> collapses to miniplayer (`return true`).
  - Home feed with active playback -> triggers `MediaPlaybackService.start(...)` and calls `moveTaskToBack(true)` (`return true`).
  - Playback continues uninterrupted in background with system notification controls.

### 10. System Media Session & Notification Integration
- **Metadata Synchronization**: `MediaPlaybackService` must reflect live YouTube metadata (`title`, `channelTitle`, and thumbnail bitmap) in both `MediaSessionCompat` and `NotificationCompat.Builder`, enabling full lock screen and home screen widget support.
- **Rewind/Fast-Forward**: Media controls should rewind 10s on previous and forward 10s on next for video streams.

### 11. GitHub Actions Gradle Setup
- **Automated Wrapper**: Always include the automatic Gradle 8.4 wrapper setup step in all GitHub Actions workflow files (`android_build.yml` and `build-apk.yml`) to ensure remote builds pass without relying on pre-committed JARs.
