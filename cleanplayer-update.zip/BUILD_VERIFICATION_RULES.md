# CleanPlayer Build & Architecture Verification Rules

### 1. Class Scope Guard (Anti-Top-Level Leak)
- NEVER append new functions or properties past the final closing brace `}` of a Kotlin class.
- All helper methods, dialog builders, receivers, and variables must reside strictly INSIDE `class MainActivity` or the respective class body.

### 2. Mandatory Android Framework Imports
- Gestures: `import android.view.GestureDetector`, `import android.view.MotionEvent`, `import android.view.ScaleGestureDetector`
- Audio: `import android.media.AudioManager`
- Immersive / Edge-to-Edge: `import android.view.WindowInsets`, `import android.view.WindowInsetsController`
- Concurrency & UI: `import android.os.Handler`, `import android.os.Looper`
- Media3: `import androidx.media3.common.Player`, `import androidx.media3.common.PlaybackException`, `import androidx.media3.ui.AspectRatioFrameLayout`, `import androidx.media3.ui.PlayerView`

### 3. Strict Math Type Disambiguation for Kotlin Overloads
- `kotlin.math.abs()`: Always pass explicit float: `kotlin.math.abs(dy.toFloat())`, `kotlin.math.abs(dx.toFloat())`.
- Mixed arithmetic (Float / Int): Explicitly cast Int to Float when scaling.

### 4. Manager Callback Pre-Flight & Visibility Contracts
- Never wire callbacks on manager singletons unless explicitly declared with public visibility.
- `YouTubeExoPlayerManager.currentPlayingVideo` must have a public setter (`var currentPlayingVideo: YouTubeVideo? = null`).
- `YouTubeExoPlayerManager` must expose `@Synchronized fun stop()`.

### 5. Dialog Styling & Dimming
- Always set `backgroundDimAmount` to `0.65` (never 0.12).
- Dialog card surfaces must use solid opaque `#1A1B22` or `#1C1D24`.

### 6. Player Controls Auto-Hide
- Overlay controls (`layoutYtPlayerOverlay`) must auto-fade after 3.0 to 3.5 seconds of playback inactivity.

### 7. YouTube Audio Mode & Visualizer
- In Audio Mode, the playback loop must actively feed `onPlaybackProgress(current, duration)` every 100ms.

### 8. Shorts Player Navigation & Feed Cleanliness
- Home feed must NEVER show a horizontal Shorts shelf; main feed is strictly for clean full videos.
- Shorts player uses natural vertical swipe.

### 9. Media Notification Dismissal
- When paused, the service MUST call `stopForeground(STOP_FOREGROUND_DETACH)` and set `.setOngoing(false)`.

### 10. Multi-Language Audio Track Switching
- Multi-language dubbed videos must be selectable via `YouTubeExoPlayerManager.getAvailableAudioTracks()` and `selectAudioTrack(track)`.

### 11. Remote CI/CD & Build Environment
- Workflows must include the curl/unzip Gradle 8.4 bootstrap step with Temurin JDK 17.
- ProGuard rules must keep `org.schabi.newpipe.extractor.**` and `okhttp3.**`.

### 12. Class-Level vs Local Function Scoping (Anti-Unresolved Reference)
- UI feedback helpers, handlers, and runnables (e.g., `showYtGestureFeedback`, `ytGestureHideHandler`, `ytGestureHideRunnable`) must ALWAYS be declared as class members of `MainActivity`, never as local nested functions inside `onCreate` or gesture setup methods.

### 13. Miniplayer Live Video Surface Handoff
- Miniplayer must contain a dedicated `androidx.media3.ui.PlayerView` with `app:surface_type="texture_view"` (`playerViewYtMini`) alongside the static thumbnail `ImageView`.
- When minimizing (`collapseYouTubePlayer`): detach from main `playerViewYt` and attach to `playerViewYtMini`.
- When maximizing: detach from `playerViewYtMini` and re-attach to `playerViewYt`.

### 14. Fullscreen Zoom & Aspect Ratio Controls
- YouTube player controls must provide both:
  1. An aspect ratio toggle button (`btnYtAspectRatio`) cycling between:
     - `AspectRatioFrameLayout.RESIZE_MODE_FIT` (Original / Fit screen)
     - `AspectRatioFrameLayout.RESIZE_MODE_ZOOM` (Zoomed to fill / Edge-to-edge without black bars)
     - `AspectRatioFrameLayout.RESIZE_MODE_FILL` (Stretch to fill)
  2. A two-finger pinch-to-zoom gesture (`ScaleGestureDetector`):
     - Touch listener must intercept `event.pointerCount >= 2` and delegate directly to `ScaleGestureDetector`, bypassing single-finger brightness/volume/seek gestures.

### 15. Clean Removal of Deprecated/Unused Features
- When eliminating legacy or experimental features (e.g., Picture Mode, Video Color Profiles), remove all callers, button bindings, layout rows, and local functions completely. Never leave dangling function stubs or modified signatures inside method blocks.

### 16. Configurable Media Disk Cache & Stream URL TTL
- Users can customize the ExoPlayer media disk cache size (256 MB, 512 MB, 1 GB, 2 GB, 4 GB).
- Users can customize the NewPipe stream URL cache duration (2 Hours, 4 Hours, 8 Hours, 12 Hours, 24 Hours, 48 Hours).
- Both options must appear in the "You" settings screen and inside the player's YouTube Settings dialog.

### 17. 5GHz Turbo P2P Share Module Architecture
- 5th bottom tab (`nav_share`) positioned after YouTube in `bottom_nav_menu.xml`.
- Zero-copy direct streaming using `FileChannel.transferTo` and 256 KB jumbo buffers.
- Breakpoint / chunk-level resume protocol using `.part` files and byte-offset handshakes.
- Hardware locks: `WifiLock(WIFI_MODE_FULL_HIGH_PERF)` and `WakeLock(PARTIAL_WAKE_LOCK)`.
- Concurrent multi-file parallel streams vs single-stream sequential queue toggle.
- Full theme synchronization with `PlayerHolder.appThemeMode` (Pure Black OLED / Charcoal).

### 18. Mandatory Standard Java & Android UI Framework Imports
- Always ensure `import java.io.File` is explicitly imported whenever `File(...)` is referenced.
- Always ensure `import android.view.View` is explicitly imported whenever `View.generateViewId()`, `View.VISIBLE`, or `View.GONE` are referenced.

### 19. Kotlin Self-Referencing Lambda Initialization Guard
- An instantiated variable cannot be referenced inside its own constructor's trailing lambda (e.g. `val adapter = Adapter { adapter.getItems() }` triggers `Unresolved reference`). Always use `lateinit var adapter: Adapter` before instantiating.

### 20. Local Nested Function Declaration Order (No Hoisting in Kotlin)
- Local functions defined inside another function are NOT hoisted in Kotlin.
- Nested functions must be declared before any call site or listener (e.g. `RadioGroup.setOnCheckedChangeListener`) that invokes them.

### 21. Signature & Parameter Default Synchronization
- When adding a parameter to a navigation function (e.g. `share: Boolean = false` in `showTab(...)`), always provide default values and update all call sites across the entire Activity.
