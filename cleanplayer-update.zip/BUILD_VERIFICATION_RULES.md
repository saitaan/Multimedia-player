---
name: cleanplayer-master-expert
description: >-
  Expert instructions, architecture guidelines, and strict pre-flight rules for building,
  modifying, and compiling the CleanPlayer Android multimedia player. Use whenever the user asks
  about CleanPlayer, building the Android APK, updating YouTube streaming features, fixing
  compilation errors, or modifying player gestures, UI dialogs, and services.
allowed-tools: drive vm_shell
---
# CleanPlayer Build & Architecture Expert

A comprehensive guide for maintaining, updating, and compiling the CleanPlayer Android application (TeamNewPipe Extractor v0.26.5 + LibVLC + Media3 ExoPlayer).

## Historical Build Error Logs & Strict Compilation Rules

### 1. Class Scope Guard (Anti-Top-Level Leak)
- **Error Log:** `'this' is not defined in this context`, `Variable expected`, `Unresolved reference`.
- **Cause:** Appending new methods or variables past the final closing brace `}` of `class MainActivity`.
- **Rule:** All helper methods, dialog builders, receivers, and variables must reside strictly INSIDE `class MainActivity` or the respective class body.

### 2. Mandatory Android & Java Framework Imports
- **Error Logs:**
  - `MainActivity.kt: Unresolved reference: File`
  - `YouTubeDownloaderHelper.kt: Unresolved reference: View`
  - `Unresolved reference: Handler`, `Unresolved reference: Looper`
- **Rule:** Always ensure the following imports are explicitly present at the top of Kotlin files:
  - File & Storage I/O: `import java.io.File`, `import java.io.FileInputStream`, `import java.io.FileOutputStream`
  - UI Views: `import android.view.View` (for `View.generateViewId()`, `View.VISIBLE`, `View.GONE`)
  - Concurrency & Threading: `import android.os.Handler`, `import android.os.Looper`
  - Audio: `import android.media.AudioManager`
  - Gestures: `import android.view.GestureDetector`, `import android.view.MotionEvent`, `import android.view.ScaleGestureDetector`
  - Insets / Immersive: `import android.view.WindowInsets`, `import android.view.WindowInsetsController`
  - Media3: `import androidx.media3.common.Player`, `import androidx.media3.common.PlaybackException`, `import androidx.media3.ui.AspectRatioFrameLayout`, `import androidx.media3.ui.PlayerView`

### 3. Kotlin Self-Referencing Lambda Initialization Guard
- **Error Log:** `MainActivity.kt: Unresolved reference: adapter`
- **Cause:**
  ```kotlin
  // FAILS: Variable 'adapter' is not initialized when lambda is defined!
  val adapter = ShareSelectableAdapter(emptyList()) { adapter.getItems() }
  ```
- **Rule:** Always split declaration and initialization using `lateinit var`:
  ```kotlin
  lateinit var adapter: ShareSelectableAdapter
  adapter = ShareSelectableAdapter(emptyList()) { adapter.getItems() }
  ```

### 4. Local Nested Function Declaration Order (No Hoisting)
- **Error Log:** `YouTubeDownloaderHelper.kt: Unresolved reference: populateQualityOptions`
- **Cause:** In Kotlin, local functions defined inside another function are NOT hoisted. Calling a nested function before its declaration line triggers unresolved reference.
- **Rule:** A nested local function must be declared *before* any listener (e.g. `RadioGroup.setOnCheckedChangeListener`) or call site that invokes it.

### 5. Signature & Parameter Default Synchronization
- **Error Log:** `Cannot find a parameter with this name: share` / `Unresolved reference: share`
- **Cause:** Function was updated in caller sites with a new parameter (e.g. `showTab(..., share = true)`), but the function definition was missing `share: Boolean = false`.
- **Rule:** Always supply default arguments for new parameters in dispatcher methods and ensure definition and all call sites are 100% synchronized.

### 6. Helper & Manager Parameter Order
- **Error Log:** Type mismatch: `ImageLoaderHelper.loadImage(ImageView, String)`
- **Rule:** `ImageLoaderHelper.loadImage(url: String?, imageView: ImageView)` requires URL first, ImageView second. Never invert the argument order.

### 7. Manager Visibility & Public Contracts
- **Error Logs:**
  - `Cannot assign to 'currentPlayingVideo': the setter is private in 'YouTubeExoPlayerManager'`
  - `Unresolved reference: stop in 'YouTubeExoPlayerManager'`
- **Rule:**
  - `YouTubeExoPlayerManager.currentPlayingVideo` must have a public setter (`var currentPlayingVideo: YouTubeVideo? = null`).
  - `YouTubeExoPlayerManager` must expose `@Synchronized fun stop()`.
  - Callback properties (`onPlayerError`, `onSponsorSkipped`, `onVideoEnded`) must be declared public on the singleton before wiring in Activities.

### 8. Class-Level vs Local Helper Scoping
- **Error Log:** `Unresolved reference: ytGestureHideHandler`, `Unresolved reference: ytPrefs`
- **Rule:** UI feedback helpers, handlers, and runnables (e.g. `ytGestureHideHandler`, `ytGestureHideRunnable`, `ytPrefs`) must be declared at class level, never nested inside `onCreate` or other methods.

### 9. Dead & Phantom References Cleanup
- **Error Log:** `YouTubeDownloaderHelper.kt: Unresolved reference: loadingToast`
- **Rule:** When refactoring async callbacks or stream resolvers, ensure all temporary toast/dialog references like `loadingToast` are either declared or removed.

### 10. Strict Math Type Disambiguation for Kotlin Overloads
- **Error Log:** `Overload resolution ambiguity: abs(Float) or abs(Double)`
- **Rule:** Always pass explicit floats: `kotlin.math.abs(dy.toFloat())`, `kotlin.math.abs(dx.toFloat())`. Explicitly cast Int to Float when scaling.

### 11. Illegal Local Private Functions
- **Error Log:** `Modifier 'private' is not applicable to local function`
- **Rule:** `private fun` cannot be declared inside a method body. When removing deprecated features (e.g., Picture Mode, Video Color Profiles), delete the entire block cleanly rather than leaving dangling function stubs.

### 12. Playback Error Self-Healing
- **Rule:** In `onResume`, listen to `YouTubeExoPlayerManager.onPlayerError`: fallback to adaptive fast stream and switch center play button to retry state if stream URL expires or network drops.

### 13. 5GHz Turbo P2P Share Module Architecture
- 5th bottom tab (`nav_share`) positioned after YouTube in `bottom_nav_menu.xml`.
- Zero-copy direct streaming using `FileChannel.transferTo` and 256 KB jumbo buffers.
- Breakpoint / chunk-level resume protocol using `.part` files and byte-offset handshakes.
- Background persistence: Hardware locks `WifiLock(WIFI_MODE_FULL_LOW_LATENCY / FULL_HIGH_PERF)` and `WakeLock(PARTIAL_WAKE_LOCK)`.
- Back key interception: Hiding dialog or navigating back must call `moveTaskToBack(true)` rather than finishing the Activity, ensuring transfers continue non-stop.
- Progress Throttling: UI updates throttled to 400ms (2.5 updates/sec) to avoid choking the Main Looper during 80–100+ MB/s transfers.

### 14. Dialog Styling & Dimming
- Always set `backgroundDimAmount` to `0.65` (never 0.12).
- Dialog card surfaces must use solid opaque `#1A1B22` or `#1C1D24` (never semi-transparent hex like `#B3...` or `#CC...`), completely preventing background bleed-through.

### 15. Player Controls Auto-Hide
- Overlay controls (`layoutYtPlayerOverlay`) must auto-fade after 3.0 to 3.5 seconds of playback inactivity.
- Schedule hide when playback starts, resumes, seeks, or when user taps the player view.

### 16. YouTube Audio Mode & Visualizer
- In Audio Mode, the playback loop must actively feed `onPlaybackProgress(current, duration)` every 100ms.
- Render visualizer in full audio player and inside the bottom mini player.
- Never display unwanted promotional badge text over the audio canvas.

### 17. Shorts Player Navigation & Feed Cleanliness
- Home feed must NEVER show a horizontal Shorts shelf; main feed is strictly for clean full videos.
- Shorts player uses natural vertical swipe (fling up for next, fling down for previous).
- Do not add floating arrow buttons that clutter the Shorts canvas.

### 18. Media Notification Dismissal
- When paused, the service MUST call `stopForeground(STOP_FOREGROUND_DETACH)` and set `.setOngoing(false)``.
- Wire `setDeleteIntent` to `ACTION_STOP` so swiping the notification away stops the service cleanly.

### 19. Multi-Language Audio Track Switching
- Multi-language dubbed videos (e.g. Hindi, English) must be selectable via `YouTubeExoPlayerManager.getAvailableAudioTracks()` and `selectAudioTrack(track)`.

### 20. Remote CI/CD & Build Environment
- GitHub Actions workflows (`android_build.yml` and `build-apk.yml`) must include the curl/unzip Gradle 8.4 bootstrap step with Temurin JDK 17.
- ProGuard rules must keep `org.schabi.newpipe.extractor.**` and `okhttp3.**`.

## GitHub Actions CI/CD Compilation Architecture

### 1. Runner & Environment Configuration
- **Operating System:** `ubuntu-latest` (Ubuntu 24.04 LTS).
- **JDK Specification:** Eclipse Temurin JDK 17 (`actions/setup-java@v4` with `distribution: temurin`, `java-version: 17`).
- **Memory Optimization (`gradle.properties`):**
  ```properties
  org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m
  android.useAndroidX=true
  kotlin.code.style=official
  ```

### 2. Auto-Extract Project ZIP Pipeline Step
When updating the repository via master zip archives, CI must run:
```bash
for zip in *.zip; do
  if [ -f "$zip" ]; then
    echo "Extracting $zip..."
    unzip -o "$zip"
  fi
done

if [ ! -f "settings.gradle.kts" ] && [ ! -f "settings.gradle" ]; then
  SETTINGS_PATH=$(find . -name "settings.gradle.kts" -o -name "settings.gradle" | head -n 1)
  if [ -n "$SETTINGS_PATH" ]; then
    SRC_DIR=$(dirname "$SETTINGS_PATH")
    cp -r "$SRC_DIR"/* . 2>/dev/null || true
    cp -r "$SRC_DIR"/.* . 2>/dev/null || true
  fi
fi
```

### 3. Gradle 8.4 Binary Bootstrap Wrapper
To ensure reproducible, zero-drift builds regardless of the runner's pre-installed tools:
```bash
echo "=== Setting Up Gradle 8.4 ==="
curl -sL https://services.gradle.org/distributions/gradle-8.4-bin.zip -o gradle-8.4-bin.zip
unzip -q -o gradle-8.4-bin.zip
./gradle-8.4/bin/gradle wrapper --gradle-version 8.4 --distribution-type bin
chmod +x gradlew
```

### 4. Build Command & Stacktrace Capture
```bash
./gradlew assembleDebug --no-daemon --stacktrace
```
- `--no-daemon`: Prevents orphan worker leaks on ephemeral CI instances.
- `--stacktrace`: Ensures line-level compiler trace is emitted immediately upon any task failure.

### 5. Artifact Upload & APK Archival
- Action: `actions/upload-artifact@v4`
- Name: `CleanPlayer-APK`
- Path: `app/build/outputs/apk/debug/*.apk`

### 6. R8 / ProGuard Keep Rules for Native & Streaming Libraries
When R8 minification or compilation is performed:
```proguard
# TeamNewPipe Extractor
-keep class org.schabi.newpipe.extractor.** { *; }
-dontwarn org.schabi.newpipe.extractor.**

# OkHttp & Jackson Network Stack
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
-dontwarn okhttp3.**
-keep class com.fasterxml.jackson.** { *; }

# LibVLC Native Media Core
-keep class org.videolan.libvlc.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# Kotlin Coroutines & Attributes
-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod,*Annotation*
```

---

## Part 7: Field Verification & P2P Engine Rules (Rules 22 - 26)

### Rule 22: Never Pass Raw SQL Keywords in ContentResolver Queries
- **Root Cause:** Android 11+ (API 30+) `MediaProvider` enforces strict query parser validation. Passing raw SQL clauses like `LIMIT 80` in `sortOrder` throws `SQLiteException` / `IllegalArgumentException`.
- **Enforcement:** Never append `LIMIT X` or custom SQL clauses in `sortOrder`. Instead, use standard sort strings (e.g. `"${MediaStore.Video.Media.DATE_MODIFIED} DESC"`) and iterate the cursor with a client-side counter `while (cursor.moveToNext() && count < maxCount)`.

### Rule 23: Android 13/14 Nearby Devices Runtime Permission for Local-Only Hotspots
- **Root Cause:** `WifiManager.startLocalOnlyHotspot` on Android 13+ (API 33+) requires runtime permission `android.permission.NEARBY_WIFI_DEVICES`. If declared in Manifest but not granted by user at runtime, Android throws `SecurityException`.
- **Enforcement:** Always prompt the user using `registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions())` before triggering Sender/Receiver hotspot operations.

### Rule 24: Background Service Error Handling & Zombie State Prevention
- **Root Cause:** If a background transfer service catches a fatal exception (permission denied, hotspot failed, socket connect failure) without resetting its active flag (`isTransferActive.set(false)`) and calling `stopTransferInternal()`, the service becomes a zombie, leaving the UI showing `0.0 MB/s (0%)` indefinitely.
- **Enforcement:** Every catch block and callback failure (`onFailed`) must explicitly reset state, notify UI, release WakeLock/WifiLock, cancel notifications, and call `stopSelf()`.

### Rule 25: Universal Audio MediaStore Queries
- **Root Cause:** Filtering audio with `IS_MUSIC != 0` excludes voice notes, recordings, downloaded podcasts, and un-tagged audio files. Using `TITLE` instead of `DISPLAY_NAME` loses file extensions (`.mp3`, `.m4a`).
- **Enforcement:** Query audio with `SIZE > 0`, extract `DISPLAY_NAME` with extension fallback, and omit `IS_MUSIC` constraints.

### Rule 26: 1-Tap Termination on In-App Active Transfer Banners
- **Enforcement:** All persistent in-app transfer banners must provide both a `View Live` button and a direct 1-tap `Stop` button to instantly terminate the background service and clean up state.

### Rule 27: Storage Save Location Configuration & Zero-Toast Spam
- **Root Cause:** Hardcoding storage directories (`Download/CleanPlayer`) or displaying informational toasts instead of interactive pickers frustrates users. Toast spam on back-press or minimize clutters the UI.
- **Enforcement:** Always provide an interactive folder selection dialog with presets (`Download/CleanPlayer`, `Movies/CleanPlayer`, `Music/CleanPlayer`, `DCIM/CleanPlayer`, `Documents/CleanPlayer`, `Custom Folder...`). Never use Toast messages for static information or background transitions.

### Rule 28: Zero Dummy UI Elements (Full Interactive Surface Rule)
- **Root Cause:** Having clickable-looking rows, cards, or badges without click listeners (or where only an inner tiny button works) frustrates users and feels like broken/dummy controls.
- **Rule:** Every setting row, status badge, card, and list item must be active and wired to its respective action dialog or button trigger.

### Rule 29: Dynamic High-Resolution Wi-Fi QR Code Generation
- **Root Cause:** Rendering static placeholder vector icons (`ic_qr_code.xml`) prevents peer devices from connecting via camera/scanner.
- **Rule:** Never use static vector placeholders for QR codes. Dynamically generate standard Wi-Fi QR Bitmaps (`WIFI:T:WPA;S:<SSID>;P:<PASSWORD>;;`) using `com.google.zxing:core:3.5.3` and render directly to the `ImageView` with color filters cleared.

### Rule 30: Zero-Buffering Video-to-Audio Mode Switching & Single Progress Bar Contract
- **Root Cause:** Re-creating `ProgressiveMediaSource` and calling `prepare()` drops current buffers and triggers network re-fetching, causing audio buffering when toggling audio mode. Stacking `pbYtBottomMiniProgress` under `sbYtPlayer` renders dual progress bars. Hiding status bar in portrait causes system icon collisions.
- **Rule:**
  1. Toggle video track on `DefaultTrackSelector` (`setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true/false)`) for 0ms zero-buffering mode switches.
  2. Hide `pbYtBottomMiniProgress` whenever overlay controls (`layoutYtPlayerOverlay`) are visible.
  3. Preserve full App-Wide Immersive Mode (hide status bar, transparent bars by swipe).

### Rule 31: Dynamic Device Width for Dialogs & BottomSheets (Zero Truncation Rule)
- **Root Cause:** Hardcoding fixed dialog/card widths (e.g. `480dp`, `460dp`) wider than standard mobile screens (360–412dp) causes the dialog to overflow off-screen, clipping text on the left edge.
- **Rule:** Never hardcode fixed card widths exceeding 360dp. BottomSheetDialog layouts must use `match_parent` root containers. Dialog cards must use `match_parent` with `android:layout_marginStart="14dp"` and `android:layout_marginEnd="14dp"`.

### Rule 32: Import Deduplication Guard (No Conflicting/Duplicate Imports)
- **Root Cause:** In Kotlin, importing the exact same class twice (e.g., `import java.io.File` on two separate lines) triggers a fatal compilation error: `Conflicting import, imported name 'File' is ambiguous`.
- **Enforcement:** Never duplicate explicit imports. Ensure all imports in every Kotlin/Java file are strictly unique and deduplicated.

### Rule 33: Background-to-Foreground Video Mode Restoration & Surface Reattachment
- **Root Cause:** When screen is turned off or app minimized, `onAppBackgrounded` sets `isBackgroundAutoSwitched = true` and enters pure audio mode. When returning to foreground, `onAppForegrounded` had a contradictory guard `if (isBackgroundAutoSwitched && !isAudioOnlyMode)` which never executed. Furthermore, `updateAudioModeUI(false)` lacked `playerViewYt.visibility = View.VISIBLE`, leaving the player invisible and displaying only the audio thumbnail. Finally, `notchProgressRunnable` was removed in `onPause` but never reposted in `onResume`, freezing time display at 00:00.
- **Enforcement:**
  1. `onAppForegrounded` must trigger `switchToVideo(context)` whenever `isBackgroundAutoSwitched` is true.
  2. `updateAudioModeUI(false)` must explicitly set `playerViewYt.visibility = View.VISIBLE` and call `reattachPlayerView(playerViewYt)`.
  3. `MainActivity.onResume()` must restart `notchProgressRunnable` and ensure video surface is reattached.

### Rule 34: Landscape Fullscreen Navigation Bar Concealment & Aspect Ratio Zoom Contract
- **Root Cause:**
  1. `bottomNav` was not hidden during landscape/fullscreen mode, rendering bottom navigation tabs over video controls.
  2. `ScaleGestureDetector` tested single-frame delta `> 1.05f` instead of cumulative scaling, making pinch-to-zoom fail and leaving persistent black pillars.
  3. `GestureDetector` aborted `ACTION_DOWN` handling on `playerViewYt`, while `layoutYtPlayerOverlay` intercepted touches, breaking volume/brightness/seek gestures.
- **Enforcement:**
  1. Set `bottomNav.visibility = View.GONE` in landscape and fullscreen; restore in portrait.
  2. Accumulate pinch zoom factors (`cumulativeScale *= detector.scaleFactor`) to reliably trigger `RESIZE_MODE_ZOOM` and `RESIZE_MODE_FIT`.
  3. Attach unified touch handling across both `playerViewYt` and `layoutYtPlayerOverlay` for volume (right swipe), brightness (left swipe), seek (horizontal swipe), and double-tap (+10s/-10s/play-pause).

### Rule 35: FloatingActionButton Identifier Consistency
- **Root Cause:** Referencing `findViewById(R.id.btnFabPlay)` triggered compilation error `Unresolved reference: btnFabPlay` because the layout identifier is `R.id.fabPlay` and the activity member variable is `fabPlay`.
- **Enforcement:** Always reference `if (::fabPlay.isInitialized) fabPlay` or `R.id.fabPlay`.

### Rule 36: YouTube Real-time Polling & PiP Clean Surface Contract
- **Root Cause:**
  1. `notchProgressRunnable` only executed when `cardNotchPlayer.visibility == View.VISIBLE`, freezing YouTube player time display at `00:00 / 00:00`.
  2. Entering PiP mode did not hide `layoutYtPlayerOverlay`, cluttering the mini PiP window with full-sized controls.
  3. `applyAppWideImmersiveMode()` showed navigation bars when not in explicit fullscreen, rendering gray system gesture bars in landscape video mode.
- **Enforcement:**
  1. YouTube progress/time polling must execute unconditionally whenever `currentPlayingVideo != null`.
  2. Hide `layoutYtPlayerOverlay` completely when entering PiP mode.
  3. Set `isNavigationBarContrastEnforced = false` and hide navigation bars during landscape playback.

### Rule 37: P2P Receive QR Scanner Architecture
- **Root Cause:** In P2P Receive mode, there was no camera scanner to scan the sender's hotspot QR code, preventing receiver devices from connecting.
- **Enforcement:**
  1. Tapping 'Receive' checks `Manifest.permission.CAMERA` and displays an integrated `SurfaceView` camera QR code scanner.
  2. The scanner decodes Wi-Fi payloads (`WIFI:T:WPA;S:<SSID>;P:<PASSWORD>;;`), connects via `WifiNetworkSpecifier` / `WifiManager`, and connects receiver socket to sender host IP.
  3. Redundant background informational cards removed from `dialog_share_progress.xml` for a clean, focused transfer UI.

### Rule 38: Scanner & Network Framework Imports
- **Root Cause:** Calling `Executors.newSingleThreadExecutor()` and `WifiManager` without explicit imports triggered `Unresolved reference: Executors` and `Unresolved reference: WifiManager`.
- **Enforcement:** Always explicitly import `java.util.concurrent.Executors`, `android.net.wifi.WifiManager`, and `android.hardware.Camera`.

### Rule 39: YouTube Channel Page Navigation Contract
- **Root Cause:** Neither `tvYtDetailChannel` nor `cardYtDetailAvatar` had click listeners, so tapping on the channel name/avatar produced no action.
- **Enforcement:**
  1. Wire `tvYtDetailChannel`, `ivYtDetailAvatar`, `cardYtDetailAvatar`, and feed item `ivChannelAvatar` to `openYouTubeChannelPage(channelTitle, avatarUrl)`.
  2. Display channel profile details, handle, synchronized Subscribe button, and fetch channel video uploads via `YouTubeFeedRepository.searchVideos(channelTitle)`.

### Rule 40: Color Resource Declaration & CI/CD Workflow Resilience Contract
- **Root Cause:**
  1. Referencing `R.color.theme_background_secondary` without declaring it in `res/values/colors.xml` causes an unresolved reference compilation error.
  2. Having multiple redundant workflows (`android_build.yml` and `build-apk.yml`) with fragile `curl` commands caused build aborts in 13 seconds on CI.
- **Enforcement:**
  1. Ensure every `R.color.*` resource referenced in Kotlin/Java code is defined in `colors.xml`.
  2. Maintain a single, self-healing `build-apk.yml` workflow with multiple fallbacks for Gradle wrapper and compilation.

### Rule 41: YouTube App 1:1 UI Stabilization & Channel Page Contract
- **Root Cause:**
  1. PiP mode did not suppress overlay controls, causing media buttons, timestamps, and seekbar to clutter the tiny PiP window.
  2. `collapseYouTubePlayer()` restored `fabPlay.visibility = View.VISIBLE`, causing the local media orange play FAB to float awkwardly over the YouTube feed and mini-player.
  3. Player overlay controls had seekbar and time on a single row causing truncation, and `btnYtCenterPlayPause` was using a rectangular orange decoder badge and became invisible.
  4. Channel page was a bottom sheet with blank generic avatar and no banner/subscriber count.
- **Enforcement:**
  1. Enforce `isInPictureInPictureMode` guard in `showYouTubeOverlay()` to guarantee zero overlay obstruction in PiP.
  2. Unify FAB visibility via `updateFabPlayVisibility()` so `fabPlay` is strictly `View.GONE` whenever YouTube tab or player is active.
  3. Separate seekbar into a full-width top row and time/fullscreen on the bottom row, with circular translucent center play button (`bg_youtube_center_play`).
  4. Build full-screen 1:1 YouTube Channel Activity with banner, avatar, verified checkmark, handle, subscriber count in Indian numbering (e.g. 45.8 lakh), tabs, and actual channel uploads via `YouTubeFeedRepository.getChannelDetails`.

### Rule 42: Complete Removal of YouTube Shorts & Dedicated Shorts Player
- **Root Cause:** Shorts clutter the feed, create redundant vertical video players, and distract from long-form video playback.
- **Enforcement:**
  1. Completely remove `layoutYtShortsPlayer` and its associated touch gestures and controls.
  2. Remove `layoutYtShortsShelf` and `rvYouTubeShorts` from the feed so only clean long-form video cards are rendered.
  3. Remove `btnYtNavShorts` from the bottom navigation bar so only Home, Subscriptions, and You are present.
  4. Remove `YouTubeShortsAdapter.kt`, `item_youtube_shorts.xml`, and all Shorts fetchers from `YouTubeFeedRepository.kt`.

### Rule 43: Layout Drawable Resource Presence Guarantee
- **Root Cause:** AAPT2 build failure `:app:processDebugResources FAILED` occurred because `dialog_youtube_channel.xml` referenced `@drawable/ic_arrow_back` and `@drawable/ic_more_vert` without corresponding vector drawable XML definitions in `res/drawable/`.
- **Enforcement:** Ensure all vector drawables referenced in any layout (such as `ic_arrow_back`, `ic_more_vert`, `ic_verified`, `bg_chip_black`) exist in `res/drawable/`. Run an automated scan verifying that every single `@drawable/` token across all layout files matches a file in `res/drawable/`.

### Rule 44: Strict Method and Variable Resolution Contract
- **Root Cause:**
  1. `ViewGroup` was missing its explicit import in `MainActivity.kt`.
  2. `etYouTubeSearch` was referenced instead of `etYtSearchQuery`.
  3. `showComments` was referenced in `updateSettingsUI` after its variable declaration was accidentally removed.
  4. Non-existent getters (`uploaderAvatarUrl`, `bannerUrl`, etc.) were called on NewPipeExtractor classes.
- **Enforcement:**
  1. Always import `android.view.ViewGroup`.
  2. Reference strictly declared members (`etYtSearchQuery`).
  3. Define all preference variables (`showComments`) prior to checking their state.
  4. Keep NewPipeExtractor interactions strictly within verified API contracts (`searchVideos`).

### Rule 45: Fullscreen Horizontal Landscape Button & Zero-Dummy UI Contract
- **Root Cause:**
  1. `btnYtFullscreen` was pushed off-screen by an adjacent aspect ratio button in a horizontal layout, preventing users from toggling landscape fullscreen.
  2. The player top bar had dummy music note, autoplay, and cast buttons.
  3. The Channel Page had a dummy Join button and dummy tabs.
- **Enforcement:**
  1. Place `btnYtFullscreen` directly aligned to `layout_alignParentEnd="true"` in the bottom bar with clear `ic_fullscreen` icon that triggers horizontal landscape rotation (`SCREEN_ORIENTATION_SENSOR_LANDSCAPE`).
  2. Clean player top bar to show only CC (Subtitles) and Settings (Gear).
  3. Implement functional `Latest` and `Popular` sort tabs on Channel Page and remove dummy Join button.

### Rule 46: YouTube-Style Center Swipe Gestures & Prominent Developer Name Plate
- **Root Cause:**
  1. Center vertical swipe on YouTube video was not triggering fullscreen / minimize.
  2. "Clear Cache" was ambiguous about whether it cleans YouTube or Local media files.
  3. Developer name plate was small in the settings UI.
- **Enforcement:**
  1. Center 60% swipe up enters Fullscreen Landscape (`toggleYouTubeFullscreen()`). Center swipe down exits fullscreen or minimizes to miniplayer (`collapseYouTubePlayer()`).
  2. Clearly explain that cache only frees temporary stream data & thumbnails, without touching actual device songs/videos.
  3. Style developer name plate with 17sp bold text, `#FF8800` accent, and border highlight.
