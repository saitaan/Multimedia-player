package com.cleanplayer.app

import android.content.Context

object YouTubeHistoryManager {
    private const val PREF_NAME = "youtube_history_bookmarks"

    fun addHistory(context: Context, title: String, url: String) {
        if (url.isBlank() || title.isBlank()) return
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val history = prefs.getStringSet("history_list", emptySet())?.toMutableSet() ?: mutableSetOf()
        history.removeAll { it.startsWith("$url~~~") }
        history.add("$url~~~$title")
        prefs.edit().putStringSet("history_list", history).apply()
    }

    fun getHistory(context: Context): List<Pair<String, String>> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val history = prefs.getStringSet("history_list", emptySet()) ?: emptySet()
        return history.map {
            val parts = it.split("~~~", limit = 2)
            Pair(parts.getOrElse(0) { "" }, parts.getOrElse(1) { "YouTube Video" })
        }.reversed()
    }

    fun addBookmark(context: Context, title: String, url: String) {
        if (url.isBlank()) return
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val bookmarks = prefs.getStringSet("bookmarks_list", emptySet())?.toMutableSet() ?: mutableSetOf()
        bookmarks.removeAll { it.startsWith("$url~~~") }
        bookmarks.add("$url~~~$title")
        prefs.edit().putStringSet("bookmarks_list", bookmarks).apply()
    }

    fun getBookmarks(context: Context): List<Pair<String, String>> {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val bookmarks = prefs.getStringSet("bookmarks_list", emptySet()) ?: emptySet()
        return bookmarks.map {
            val parts = it.split("~~~", limit = 2)
            Pair(parts.getOrElse(0) { "" }, parts.getOrElse(1) { "Saved Video" })
        }
    }

    fun clearHistory(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove("history_list").apply()
    }

    fun clearBookmarks(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove("bookmarks_list").apply()
    }
}
