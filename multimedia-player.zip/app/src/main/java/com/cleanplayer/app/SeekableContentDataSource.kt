package com.cleanplayer.app

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.media3.common.C
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.IOException
import java.nio.channels.FileChannel

class SeekableContentDataSource(private val context: Context) : DataSource {

    private var pfd: ParcelFileDescriptor? = null
    private var fis: FileInputStream? = null
    private var channel: FileChannel? = null
    private var uri: Uri? = null
    private var bytesRemaining: Long = 0L
    private var opened = false

    override fun addTransferListener(transferListener: TransferListener) {}

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        val contentResolver = context.contentResolver
        val parcelFd = contentResolver.openFileDescriptor(dataSpec.uri, "r")
            ?: throw FileNotFoundException("Unable to open content URI: ${dataSpec.uri}")
        this.pfd = parcelFd

        val fileDescriptor = parcelFd.fileDescriptor
        val inputStream = FileInputStream(fileDescriptor)
        this.fis = inputStream
        val fileChannel = inputStream.channel
        this.channel = fileChannel

        val totalLength = parcelFd.statSize

        if (dataSpec.position > 0) {
            fileChannel.position(dataSpec.position)
        }

        bytesRemaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
            dataSpec.length
        } else if (totalLength >= 0) {
            val rem = totalLength - dataSpec.position
            if (rem < 0) 0L else rem
        } else {
            C.LENGTH_UNSET.toLong()
        }

        opened = true
        return bytesRemaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesRemaining == 0L) return C.RESULT_END_OF_INPUT

        val bytesToRead = if (bytesRemaining != C.LENGTH_UNSET.toLong()) {
            minOf(bytesRemaining, length.toLong()).toInt()
        } else {
            length
        }

        val bytesRead = fis?.read(buffer, offset, bytesToRead) ?: -1
        if (bytesRead == -1) {
            return C.RESULT_END_OF_INPUT
        }

        if (bytesRemaining != C.LENGTH_UNSET.toLong()) {
            bytesRemaining -= bytesRead
        }
        return bytesRead
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        uri = null
        try { channel?.close() } catch (_: IOException) {}
        try { fis?.close() } catch (_: IOException) {}
        try { pfd?.close() } catch (_: IOException) {}
        channel = null
        fis = null
        pfd = null
        opened = false
    }
}
