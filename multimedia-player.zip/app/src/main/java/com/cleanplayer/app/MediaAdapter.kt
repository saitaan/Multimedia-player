package com.cleanplayer.app

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class MediaAdapter(
    private var items: List<MediaItem>,
    private val onItemClickWithPos: (MediaItem, Int) -> Unit
) : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    constructor(items: List<MediaItem>, onItemClick: (MediaItem) -> Unit) :
            this(items, { item, _ -> onItemClick(item) })

    var currentPlayingUri: Uri? = null

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardMedia: MaterialCardView = view.findViewById(R.id.cardMedia)
        val ivMediaIcon: ImageView = view.findViewById(R.id.ivMediaIcon)
        val tvItemTitle: TextView = view.findViewById(R.id.tvItemTitle)
        val tvItemSubtitle: TextView = view.findViewById(R.id.tvItemSubtitle)
        val ivPlayStatus: ImageView = view.findViewById(R.id.ivPlayStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_media, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context
        val isCurrentTrack = (currentPlayingUri != null && currentPlayingUri == item.uri)

        holder.tvItemTitle.text = item.title

        if (item.isVideo) {
            holder.ivMediaIcon.setImageResource(R.drawable.ic_video)
            holder.ivMediaIcon.setColorFilter(
                ContextCompat.getColor(context, R.color.theme_primary)
            )
            holder.tvItemSubtitle.text = "${item.getFormattedDuration()} • ${item.getFormattedSize()}"
        } else {
            holder.ivMediaIcon.setImageResource(R.drawable.ic_audio)
            holder.ivMediaIcon.setColorFilter(
                ContextCompat.getColor(context, R.color.theme_accent_cyan)
            )
            val artistStr = if (!item.artist.isNullOrEmpty() && item.artist != "<unknown>") {
                "${item.artist} • "
            } else ""
            holder.tvItemSubtitle.text = "$artistStr${item.getFormattedDuration()}"
        }

        if (isCurrentTrack) {
            holder.cardMedia.strokeColor = ContextCompat.getColor(context, R.color.theme_primary)
            holder.cardMedia.strokeWidth = 3
            holder.tvItemTitle.setTextColor(ContextCompat.getColor(context, R.color.theme_primary))
            holder.ivPlayStatus.setImageResource(android.R.drawable.ic_media_pause)
            holder.ivPlayStatus.setColorFilter(ContextCompat.getColor(context, R.color.theme_primary))
        } else {
            holder.cardMedia.strokeColor = ContextCompat.getColor(context, R.color.theme_card_stroke)
            holder.cardMedia.strokeWidth = 1
            holder.tvItemTitle.setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
            holder.ivPlayStatus.setImageResource(android.R.drawable.ic_media_play)
            holder.ivPlayStatus.setColorFilter(ContextCompat.getColor(context, R.color.theme_primary))
        }

        holder.itemView.setOnClickListener {
            onItemClickWithPos(item, holder.bindingAdapterPosition)
        }
    }

    override fun getItemCount(): Int = items.size

    fun getItems(): List<MediaItem> = items

    fun updateList(newItems: List<MediaItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun setPlayingUri(uri: Uri?) {
        currentPlayingUri = uri
        notifyDataSetChanged()
    }
}

class FolderAdapter(
    private var folders: List<MediaFolder>,
    private val onFolderClick: (MediaFolder) -> Unit
) : RecyclerView.Adapter<FolderAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvFolderName: TextView = view.findViewById(R.id.tvFolderName)
        val tvFolderDetails: TextView = view.findViewById(R.id.tvFolderDetails)
        val tvFolderPath: TextView = view.findViewById(R.id.tvFolderPath)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val folder = folders[position]
        holder.tvFolderName.text = folder.folderName
        holder.tvFolderDetails.text = "${folder.count} videos • ${folder.getFormattedSize()}"
        holder.tvFolderPath.text = if (folder.folderPath.isNotEmpty()) folder.folderPath else "/storage/emulated/0/..."

        holder.itemView.setOnClickListener {
            onFolderClick(folder)
        }
    }

    override fun getItemCount(): Int = folders.size

    fun updateFolders(newFolders: List<MediaFolder>) {
        folders = newFolders
        notifyDataSetChanged()
    }
}
