package com.cleanplayer.app

import android.content.Context
import android.graphics.Color
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class MediaAdapter(
    private var items: List<MediaItem>,
    private val onItemClickWithPos: (MediaItem, Int) -> Unit
) : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    constructor(items: List<MediaItem>, onItemClick: (MediaItem) -> Unit) :
            this(items, { item, _ -> onItemClick(item) })

    var currentPlayingUri: Uri? = null

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardMedia: MaterialCardView = view.findViewById(R.id.cardMedia)
        val ivMediaIcon: ImageView = view.findViewById(R.id.ivMediaIcon)
        val tvItemTitle: TextView = view.findViewById(R.id.tvItemTitle)
        val tvItemSubtitle: TextView = view.findViewById(R.id.tvItemSubtitle)
        val ivPlayStatus: ImageView = view.findViewById(R.id.ivPlayStatus)
        val pbWatchProgress: View? = view.findViewById(R.id.pbWatchProgress)
        val ivPlayedCheck: ImageView? = view.findViewById(R.id.ivPlayedCheck)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_media, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.itemView.context
        val isCurrentTrack = (currentPlayingUri != null && currentPlayingUri == item.uri)

        holder.tvItemTitle.text = item.title

        val isMono = PlayerHolder.isMonochrome()
        val videoColor = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)
        val audioColor = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_accent_cyan)
        val primaryAccent = if (isMono) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)

        if (item.isVideo) {
            holder.ivMediaIcon.setImageResource(R.drawable.ic_video)
            holder.ivMediaIcon.setColorFilter(videoColor)
            holder.tvItemSubtitle.text = "${item.getFormattedDuration()} • ${item.getFormattedSize()}"

            // Read watch progress
            val prefs = context.getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            val resumeMs = prefs.getLong(item.filePath ?: item.uri.toString(), 0L)
            if (item.durationMs > 0 && resumeMs > 5000L) {
                val ratio = (resumeMs.toFloat() / item.durationMs.toFloat()).coerceIn(0f, 1f)
                holder.pbWatchProgress?.visibility = View.VISIBLE
                holder.pbWatchProgress?.setBackgroundColor(videoColor)
                val totalWidthPx = (106 * context.resources.displayMetrics.density).toInt()
                val progressWidthPx = (totalWidthPx * ratio).toInt().coerceAtLeast(4)
                val lp = holder.pbWatchProgress?.layoutParams
                if (lp != null) {
                    lp.width = progressWidthPx
                    holder.pbWatchProgress.layoutParams = lp
                }

                if (ratio > 0.90f) {
                    holder.ivPlayedCheck?.visibility = View.VISIBLE
                    holder.ivPlayedCheck?.setColorFilter(videoColor)
                } else {
                    holder.ivPlayedCheck?.visibility = View.GONE
                }
            } else {
                holder.pbWatchProgress?.visibility = View.GONE
                holder.ivPlayedCheck?.visibility = View.GONE
            }
        } else {
            holder.ivMediaIcon.setImageResource(R.drawable.ic_audio)
            holder.ivMediaIcon.setColorFilter(audioColor)
            val artistStr = if (!item.artist.isNullOrEmpty() && item.artist != "<unknown>") {
                "${item.artist} • "
            } else ""
            holder.tvItemSubtitle.text = "$artistStr${item.getFormattedDuration()}"
            holder.pbWatchProgress?.visibility = View.GONE
            holder.ivPlayedCheck?.visibility = View.GONE
        }

        if (isCurrentTrack) {
            holder.cardMedia.strokeColor = primaryAccent
            holder.cardMedia.strokeWidth = 2
            holder.tvItemTitle.setTextColor(primaryAccent)
        } else {
            val cardBg = if (isMono) Color.parseColor("#141414") else ContextCompat.getColor(context, R.color.theme_card_bg)
            val cardStroke = if (isMono) Color.parseColor("#2E2E2E") else ContextCompat.getColor(context, R.color.theme_card_stroke)
            holder.cardMedia.setCardBackgroundColor(cardBg)
            holder.cardMedia.strokeColor = cardStroke
            holder.cardMedia.strokeWidth = 1
            holder.tvItemTitle.setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
        }

        holder.itemView.setOnClickListener {
            onItemClickWithPos(item, holder.bindingAdapterPosition)
        }

        // 3-dots more menu matching 5222.jpg
        holder.ivPlayStatus.setOnClickListener {
            val options = arrayOf("Play", "File Information", "Share")
            AlertDialog.Builder(context)
                .setTitle(item.title)
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> onItemClickWithPos(item, holder.bindingAdapterPosition)
                        1 -> {
                            val info = "Name: ${item.title}\n\nPath: ${item.filePath ?: item.uri.toString()}\n\nDuration: ${item.getFormattedDuration()}\n\nSize: ${item.getFormattedSize()}"
                            AlertDialog.Builder(context)
                                .setTitle("File Information")
                                .setMessage(info)
                                .setPositiveButton("OK", null)
                                .show()
                        }
                        2 -> {
                            try {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = if (item.isVideo) "video/*" else "audio/*"
                                    putExtra(Intent.EXTRA_STREAM, item.uri)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Media"))
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun getItemCount(): Int = items.size

    fun getItems(): List<MediaItem> = items

    fun updateList(newItems: List<MediaItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    fun setPlayingUri(uri: Uri?) {
        currentPlayingUri = uri
        notifyDataSetChanged()
    }
}

class FolderAdapter(
    private var folders: List<MediaFolder>,
    private val onFolderClick: (MediaFolder) -> Unit
) : RecyclerView.Adapter<FolderAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvFolderName: TextView = view.findViewById(R.id.tvFolderName)
        val tvFolderDetails: TextView = view.findViewById(R.id.tvFolderDetails)
        val tvFolderPath: TextView = view.findViewById(R.id.tvFolderPath)
        val ivFolderIcon: ImageView? = view.findViewById(R.id.ivFolderIcon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val folder = folders[position]
        holder.tvFolderName.text = folder.folderName
        val isMono = PlayerHolder.isMonochrome()
        val folderColor = if (isMono) Color.WHITE else ContextCompat.getColor(holder.itemView.context, R.color.theme_primary)
        val detailsColor = if (isMono) Color.parseColor("#8E8E93") else ContextCompat.getColor(holder.itemView.context, R.color.theme_accent_cyan)
        holder.ivFolderIcon?.setColorFilter(folderColor)
        holder.tvFolderDetails.setTextColor(detailsColor)
        holder.tvFolderDetails.text = "${folder.count} videos • ${folder.getFormattedSize()}"
        holder.tvFolderPath.text = if (folder.folderPath.isNotEmpty()) folder.folderPath else "/storage/emulated/0/..."

        holder.itemView.setOnClickListener {
            onFolderClick(folder)
        }
    }

    override fun getItemCount(): Int = folders.size

    fun updateFolders(newFolders: List<MediaFolder>) {
        folders = newFolders
        notifyDataSetChanged()
    }
}
