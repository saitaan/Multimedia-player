package com.cleanplayer.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class MediaAdapter(
    private var items: List<MediaItem>,
    private val onItemClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<MediaAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivMediaIcon: ImageView = view.findViewById(R.id.ivMediaIcon)
        val tvItemTitle: TextView = view.findViewById(R.id.tvItemTitle)
        val tvItemSubtitle: TextView = view.findViewById(R.id.tvItemSubtitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_media, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.tvItemTitle.text = item.title

        if (item.isVideo) {
            holder.ivMediaIcon.setImageResource(R.drawable.ic_video)
            holder.ivMediaIcon.setColorFilter(
                ContextCompat.getColor(holder.itemView.context, R.color.theme_primary)
            )
            holder.tvItemSubtitle.text = "${item.getFormattedDuration()} • ${item.getFormattedSize()}"
        } else {
            holder.ivMediaIcon.setImageResource(R.drawable.ic_audio)
            holder.ivMediaIcon.setColorFilter(
                ContextCompat.getColor(holder.itemView.context, R.color.theme_accent_cyan)
            )
            val artistStr = if (!item.artist.isNullOrEmpty() && item.artist != "<unknown>") {
                "${item.artist} • "
            } else ""
            holder.tvItemSubtitle.text = "$artistStr${item.getFormattedDuration()}"
        }

        holder.itemView.setOnClickListener {
            onItemClick(item)
        }
    }

    override fun getItemCount(): Int = items.size

    fun updateList(newItems: List<MediaItem>) {
        items = newItems
        notifyDataSetChanged()
    }
}
