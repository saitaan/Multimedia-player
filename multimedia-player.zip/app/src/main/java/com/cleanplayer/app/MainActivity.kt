package com.cleanplayer.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnToolbarOpen: Button
    private lateinit var etSearch: EditText
    private lateinit var tabVideo: LinearLayout
    private lateinit var tabAudio: LinearLayout
    private lateinit var tabSettings: ScrollView
    private lateinit var bottomNav: BottomNavigationView

    private lateinit var rvVideos: RecyclerView
    private lateinit var layoutEmptyVideo: LinearLayout
    private lateinit var btnBrowseVideo: Button

    private lateinit var rvAudio: RecyclerView
    private lateinit var layoutEmptyAudio: LinearLayout
    private lateinit var btnBrowseAudio: Button

    // 1. Video Settings Views
    private lateinit var tvVideoColorStatus: TextView
    private lateinit var btnChangeVideoColor: Button
    private lateinit var tvWideColorStatus: TextView
    private lateinit var btnToggleWideColor: Button
    private lateinit var tvDeblockingStatus: TextView
    private lateinit var btnToggleDeblocking: Button
    private lateinit var tvHwDecodeStatus: TextView
    private lateinit var btnChangeHw: Button
    private lateinit var tvBgPipStatus: TextView
    private lateinit var btnChangeBgPip: Button
    private lateinit var tvResumeModeStatus: TextView
    private lateinit var btnChangeResumeMode: Button
    private lateinit var tvDoubleTapStatus: TextView
    private lateinit var btnChangeDoubleTap: Button
    private lateinit var tvAspectRatioStatus: TextView
    private lateinit var btnChangeAspectRatio: Button
    private lateinit var tvAudioBoostStatus: TextView
    private lateinit var btnToggleAudioBoost: Button

    // 2. Integrated Dolby, Spatial & Equalizer Audio Suite Views
    private lateinit var tvMasterProfileStatus: TextView
    private lateinit var btnChangeMasterProfile: Button
    private lateinit var tvDolbySurroundStatus: TextView
    private lateinit var btnChangeDolbySurround: Button
    private lateinit var tvEqualizerStatus: TextView
    private lateinit var btnChangeEqualizer: Button
    private lateinit var tvDialogueBoostStatus: TextView
    private lateinit var btnToggleDialogueBoost: Button
    private lateinit var tvDigitalPassthroughStatus: TextView
    private lateinit var btnTogglePassthrough: Button
    private lateinit var tvAudioOutputStatus: TextView
    private lateinit var btnChangeAudioOutput: Button
    private lateinit var tvHeadsetPauseStatus: TextView
    private lateinit var btnToggleHeadsetPause: Button
    private lateinit var tvTimeStretchStatus: TextView
    private lateinit var btnToggleTimeStretch: Button

    // 3. Subtitle Settings Views
    private lateinit var btnToggleSubAutoload: Button
    private lateinit var tvSubSizeStatus: TextView
    private lateinit var btnChangeSubSize: Button
    private lateinit var tvSubColorStatus: TextView
    private lateinit var btnChangeSubColor: Button
    private lateinit var tvSubBackgroundStatus: TextView
    private lateinit var btnChangeSubBackground: Button
    private lateinit var tvSubStyleStatus: TextView
    private lateinit var btnToggleSubStyle: Button
    private lateinit var tvSubEncodingStatus: TextView
    private lateinit var btnChangeSubEncoding: Button

    // 4. Gestures Settings Views
    private lateinit var tvGestureVolumeStatus: TextView
    private lateinit var btnToggleGestureVolume: Button
    private lateinit var tvGestureBrightnessStatus: TextView
    private lateinit var btnToggleGestureBrightness: Button
    private lateinit var tvGestureSeekStatus: TextView
    private lateinit var btnToggleGestureSeek: Button
    private lateinit var tvFastSeekStatus: TextView
    private lateinit var btnToggleFastSeek: Button

    // 5. Interface Settings Views
    private lateinit var tvAppThemeStatus: TextView
    private lateinit var btnChangeAppTheme: Button

    // 6. Advanced Settings Views
    private lateinit var btnClearResume: Button
    private lateinit var btnResetSettings: Button

    private var allVideos = listOf<MediaItem>()
    private var allAudio = listOf<MediaItem>()
    private var videoAdapter: MediaAdapter? = null
    private var audioAdapter: MediaAdapter? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val title = it.lastPathSegment?.substringAfterLast('/') ?: "Media File"
            val type = contentResolver.getType(it) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(it, title, isVideo, null)
        }
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        loadMediaFiles()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PlayerHolder.loadPreferences(this)
        setContentView(R.layout.activity_main)

        initViews()
        setupBottomNav()
        setupSearch()
        setupVideoSettings()
        setupAudioSuiteSettings()
        setupSubtitleSettings()
        setupGestureSettings()
        setupInterfaceAndAdvancedSettings()
        checkAndRequestPermissions()

        intent?.data?.let { uri ->
            val title = uri.lastPathSegment?.substringAfterLast('/') ?: "Media File"
            val type = intent?.type ?: contentResolver.getType(uri) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(uri, title, isVideo, null)
        }
    }

    override fun onResume() {
        super.onResume()
        updateSettingsUI()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        btnToolbarOpen = findViewById(R.id.btnToolbarOpen)
        etSearch = findViewById(R.id.etSearch)
        tabVideo = findViewById(R.id.tabVideo)
        tabAudio = findViewById(R.id.tabAudio)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)

        rvVideos = findViewById(R.id.rvVideos)
        layoutEmptyVideo = findViewById(R.id.layoutEmptyVideo)
        btnBrowseVideo = findViewById(R.id.btnBrowseVideo)

        rvAudio = findViewById(R.id.rvAudio)
        layoutEmptyAudio = findViewById(R.id.layoutEmptyAudio)
        btnBrowseAudio = findViewById(R.id.btnBrowseAudio)

        // Video Settings
        tvVideoColorStatus = findViewById(R.id.tvVideoColorStatus)
        btnChangeVideoColor = findViewById(R.id.btnChangeVideoColor)
        tvWideColorStatus = findViewById(R.id.tvWideColorStatus)
        btnToggleWideColor = findViewById(R.id.btnToggleWideColor)
        tvDeblockingStatus = findViewById(R.id.tvDeblockingStatus)
        btnToggleDeblocking = findViewById(R.id.btnToggleDeblocking)
        tvHwDecodeStatus = findViewById(R.id.tvHwDecodeStatus)
        btnChangeHw = findViewById(R.id.btnChangeHw)
        tvBgPipStatus = findViewById(R.id.tvBgPipStatus)
        btnChangeBgPip = findViewById(R.id.btnChangeBgPip)
        tvResumeModeStatus = findViewById(R.id.tvResumeModeStatus)
        btnChangeResumeMode = findViewById(R.id.btnChangeResumeMode)
        tvDoubleTapStatus = findViewById(R.id.tvDoubleTapStatus)
        btnChangeDoubleTap = findViewById(R.id.btnChangeDoubleTap)
        tvAspectRatioStatus = findViewById(R.id.tvAspectRatioStatus)
        btnChangeAspectRatio = findViewById(R.id.btnChangeAspectRatio)
        tvAudioBoostStatus = findViewById(R.id.tvAudioBoostStatus)
        btnToggleAudioBoost = findViewById(R.id.btnToggleAudioBoost)

        // Audio Suite Settings
        tvMasterProfileStatus = findViewById(R.id.tvMasterProfileStatus)
        btnChangeMasterProfile = findViewById(R.id.btnChangeMasterProfile)
        tvDolbySurroundStatus = findViewById(R.id.tvDolbySurroundStatus)
        btnChangeDolbySurround = findViewById(R.id.btnChangeDolbySurround)
        tvEqualizerStatus = findViewById(R.id.tvEqualizerStatus)
        btnChangeEqualizer = findViewById(R.id.btnChangeEqualizer)
        tvDialogueBoostStatus = findViewById(R.id.tvDialogueBoostStatus)
        btnToggleDialogueBoost = findViewById(R.id.btnToggleDialogueBoost)
        tvDigitalPassthroughStatus = findViewById(R.id.tvDigitalPassthroughStatus)
        btnTogglePassthrough = findViewById(R.id.btnTogglePassthrough)
        tvAudioOutputStatus = findViewById(R.id.tvAudioOutputStatus)
        btnChangeAudioOutput = findViewById(R.id.btnChangeAudioOutput)
        tvHeadsetPauseStatus = findViewById(R.id.tvHeadsetPauseStatus)
        btnToggleHeadsetPause = findViewById(R.id.btnToggleHeadsetPause)
        tvTimeStretchStatus = findViewById(R.id.tvTimeStretchStatus)
        btnToggleTimeStretch = findViewById(R.id.btnToggleTimeStretch)

        // Subtitle Settings
        btnToggleSubAutoload = findViewById(R.id.btnToggleSubAutoload)
        tvSubSizeStatus = findViewById(R.id.tvSubSizeStatus)
        btnChangeSubSize = findViewById(R.id.btnChangeSubSize)
        tvSubColorStatus = findViewById(R.id.tvSubColorStatus)
        btnChangeSubColor = findViewById(R.id.btnChangeSubColor)
        tvSubBackgroundStatus = findViewById(R.id.tvSubBackgroundStatus)
        btnChangeSubBackground = findViewById(R.id.btnChangeSubBackground)
        tvSubStyleStatus = findViewById(R.id.tvSubStyleStatus)
        btnToggleSubStyle = findViewById(R.id.btnToggleSubStyle)
        tvSubEncodingStatus = findViewById(R.id.tvSubEncodingStatus)
        btnChangeSubEncoding = findViewById(R.id.btnChangeSubEncoding)

        // Gesture Settings
        tvGestureVolumeStatus = findViewById(R.id.tvGestureVolumeStatus)
        btnToggleGestureVolume = findViewById(R.id.btnToggleGestureVolume)
        tvGestureBrightnessStatus = findViewById(R.id.tvGestureBrightnessStatus)
        btnToggleGestureBrightness = findViewById(R.id.btnToggleGestureBrightness)
        tvGestureSeekStatus = findViewById(R.id.tvGestureSeekStatus)
        btnToggleGestureSeek = findViewById(R.id.btnToggleGestureSeek)
        tvFastSeekStatus = findViewById(R.id.tvFastSeekStatus)
        btnToggleFastSeek = findViewById(R.id.btnToggleFastSeek)

        // Interface Settings
        tvAppThemeStatus = findViewById(R.id.tvAppThemeStatus)
        btnChangeAppTheme = findViewById(R.id.btnChangeAppTheme)

        // Advanced Settings
        btnClearResume = findViewById(R.id.btnClearResume)
        btnResetSettings = findViewById(R.id.btnResetSettings)

        rvVideos.layoutManager = LinearLayoutManager(this)
        rvAudio.layoutManager = LinearLayoutManager(this)

        val openFileAction = {
            filePickerLauncher.launch(arrayOf("video/*", "audio/*"))
        }

        btnToolbarOpen.setOnClickListener { openFileAction() }
        btnBrowseVideo.setOnClickListener { openFileAction() }
        btnBrowseAudio.setOnClickListener { openFileAction() }
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterMedia(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterMedia(query: String) {
        val q = query.trim().lowercase()
        val filteredVideos = if (q.isEmpty()) allVideos else allVideos.filter { it.title.lowercase().contains(q) }
        val filteredAudio = if (q.isEmpty()) allAudio else allAudio.filter {
            it.title.lowercase().contains(q) || (it.artist?.lowercase()?.contains(q) == true)
        }

        videoAdapter?.updateList(filteredVideos)
        audioAdapter?.updateList(filteredAudio)

        rvVideos.visibility = if (filteredVideos.isNotEmpty()) View.VISIBLE else View.GONE
        layoutEmptyVideo.visibility = if (filteredVideos.isEmpty()) View.VISIBLE else View.GONE

        rvAudio.visibility = if (filteredAudio.isNotEmpty()) View.VISIBLE else View.GONE
        layoutEmptyAudio.visibility = if (filteredAudio.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_video -> {
                    showTab(video = true, audio = false, settings = false)
                    toolbar.title = getString(R.string.app_name)
                    toolbar.subtitle = getString(R.string.nav_video)
                    findViewById<View>(R.id.layoutSearch).visibility = View.VISIBLE
                    true
                }
                R.id.nav_audio -> {
                    showTab(video = false, audio = true, settings = false)
                    toolbar.title = getString(R.string.app_name)
                    toolbar.subtitle = getString(R.string.nav_audio)
                    findViewById<View>(R.id.layoutSearch).visibility = View.VISIBLE
                    true
                }
                R.id.nav_settings -> {
                    showTab(video = false, audio = false, settings = true)
                    toolbar.title = getString(R.string.app_name)
                    toolbar.subtitle = getString(R.string.nav_settings)
                    findViewById<View>(R.id.layoutSearch).visibility = View.GONE
                    true
                }
                else -> false
            }
        }
    }

    private fun showTab(video: Boolean, audio: Boolean, settings: Boolean) {
        tabVideo.visibility = if (video) View.VISIBLE else View.GONE
        tabAudio.visibility = if (audio) View.VISIBLE else View.GONE
        tabSettings.visibility = if (settings) View.VISIBLE else View.GONE
    }

    // --- 1. Video Settings Handlers ---
    private fun setupVideoSettings() {
        val openVideoColorDialog = {
            AlertDialog.Builder(this)
                .setTitle("Picture Mode & Color Boost")
                .setSingleChoiceItems(PlayerHolder.videoProfileNames, PlayerHolder.videoColorProfile.coerceIn(0, 4)) { dialog, which ->
                    PlayerHolder.applyVideoColorProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeVideoColor.setOnClickListener { openVideoColorDialog() }
        findViewById<View>(R.id.rowVideoColor).setOnClickListener { openVideoColorDialog() }

        btnToggleWideColor.setOnClickListener {
            PlayerHolder.isWideColorGamutEnabled = !PlayerHolder.isWideColorGamutEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowWideColor).setOnClickListener {
            btnToggleWideColor.performClick()
        }

        btnToggleDeblocking.setOnClickListener {
            PlayerHolder.isDeblockingFilterEnabled = !PlayerHolder.isDeblockingFilterEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDeblocking).setOnClickListener {
            btnToggleDeblocking.performClick()
        }
        val hwOptions = arrayOf("Disabled (Software)", "Automatic (Recommended)", "Decoding Only", "Full Acceleration")
        val openHwDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_hw_decoding)
                .setSingleChoiceItems(hwOptions, PlayerHolder.hwAccelerationMode) { dialog, which ->
                    PlayerHolder.hwAccelerationMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeHw.setOnClickListener { openHwDialog() }
        findViewById<View>(R.id.rowHwDecode).setOnClickListener { openHwDialog() }

        val bgPipOptions = arrayOf("Stop Playback", "Play in Background", "Picture-in-Picture (PiP)")
        val openBgPipDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_bg_pip)
                .setSingleChoiceItems(bgPipOptions, PlayerHolder.backgroundPipMode) { dialog, which ->
                    PlayerHolder.backgroundPipMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeBgPip.setOnClickListener { openBgPipDialog() }
        findViewById<View>(R.id.rowBgPip).setOnClickListener { openBgPipDialog() }

        val resumeOptions = arrayOf("Never (Always start from beginning)", "Ask confirmation on open", "Always resume automatically")
        val openResumeDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_resume)
                .setSingleChoiceItems(resumeOptions, PlayerHolder.resumeMode) { dialog, which ->
                    PlayerHolder.resumeMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeResumeMode.setOnClickListener { openResumeDialog() }
        findViewById<View>(R.id.rowResumeMode).setOnClickListener { openResumeDialog() }

        val seekOptions = arrayOf("5 seconds", "10 seconds", "20 seconds", "30 seconds")
        val seekValues = arrayOf(5, 10, 20, 30)
        val openSeekDialog = {
            val currentIdx = seekValues.indexOf(PlayerHolder.doubleTapSeekSeconds).coerceAtLeast(1)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_double_tap)
                .setSingleChoiceItems(seekOptions, currentIdx) { dialog, which ->
                    PlayerHolder.doubleTapSeekSeconds = seekValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDoubleTap.setOnClickListener { openSeekDialog() }
        findViewById<View>(R.id.rowDoubleTap).setOnClickListener { openSeekDialog() }

        val aspectOptions = arrayOf("Best Fit (Default)", "Fit Screen", "Fill Screen", "16:9 Aspect Ratio", "4:3 Aspect Ratio")
        val openAspectDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_aspect_ratio)
                .setSingleChoiceItems(aspectOptions, PlayerHolder.defaultAspectRatio) { dialog, which ->
                    PlayerHolder.defaultAspectRatio = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAspectRatio.setOnClickListener { openAspectDialog() }
        findViewById<View>(R.id.rowAspectRatio).setOnClickListener { openAspectDialog() }

        btnToggleAudioBoost.setOnClickListener {
            PlayerHolder.isAudioBoostEnabled = !PlayerHolder.isAudioBoostEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowAudioBoost).setOnClickListener {
            btnToggleAudioBoost.performClick()
        }
    }

    // --- 2. Integrated Dolby, Spatial & Equalizer Audio Suite Handlers ---
    private fun setupAudioSuiteSettings() {
        // Master Profile Dialog
        val openMasterProfileDialog = {
            AlertDialog.Builder(this)
                .setTitle("Select Audio Profile")
                .setSingleChoiceItems(PlayerHolder.masterProfileNames, PlayerHolder.masterAudioProfile) { dialog, which ->
                    PlayerHolder.applyMasterProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeMasterProfile.setOnClickListener { openMasterProfileDialog() }
        findViewById<View>(R.id.rowMasterProfile).setOnClickListener { openMasterProfileDialog() }

        // Dolby & Spatial Virtualizer Mode
        val modes = arrayOf("Standard Stereo (Downmix)", "Dolby 3D Headphone (Binaural HRTF)", "Dolby ProLogic Surround (Matrix)", "Cinema 3D Soundstage (Wide Room)")
        val openDolbyDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_dolby_surround)
                .setSingleChoiceItems(modes, PlayerHolder.dolbySpatialMode) { dialog, which ->
                    PlayerHolder.dolbySpatialMode = which
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDolbySurround.setOnClickListener { openDolbyDialog() }
        findViewById<View>(R.id.rowDolbySurround).setOnClickListener { openDolbyDialog() }

        // 10-Band Equalizer Presets
        val openEqDialog = {
            val presets = PlayerHolder.equalizerPresets
            val currentIdx = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_equalizer)
                .setSingleChoiceItems(presets, currentIdx) { dialog, which ->
                    PlayerHolder.currentEqualizerPreset = which - 1
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeEqualizer.setOnClickListener { openEqDialog() }
        findViewById<View>(R.id.rowEqualizer).setOnClickListener { openEqDialog() }

        // Dialogue Boost (Night Mode) Toggle
        btnToggleDialogueBoost.setOnClickListener {
            PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
            PlayerHolder.masterAudioProfile = 4 // Custom
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDialogueBoost).setOnClickListener {
            btnToggleDialogueBoost.performClick()
        }

        // Digital Passthrough Toggle
        btnTogglePassthrough.setOnClickListener {
            PlayerHolder.isDolbyPassthroughEnabled = !PlayerHolder.isDolbyPassthroughEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDigitalPassthrough).setOnClickListener {
            btnTogglePassthrough.performClick()
        }

        // Audio Output Engine Dialog
        val engines = arrayOf("AudioTrack (Standard)", "OpenSL ES (Low Latency)", "AAudio (Modern NDK)")
        val openEngineDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_audio_output)
                .setSingleChoiceItems(engines, PlayerHolder.audioOutputEngine) { dialog, which ->
                    PlayerHolder.audioOutputEngine = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAudioOutput.setOnClickListener { openEngineDialog() }
        findViewById<View>(R.id.rowAudioOutput).setOnClickListener { openEngineDialog() }

        btnToggleHeadsetPause.setOnClickListener {
            PlayerHolder.isHeadsetPauseEnabled = !PlayerHolder.isHeadsetPauseEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHeadsetPause).setOnClickListener {
            btnToggleHeadsetPause.performClick()
        }

        btnToggleTimeStretch.setOnClickListener {
            PlayerHolder.isTimeStretchingEnabled = !PlayerHolder.isTimeStretchingEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowTimeStretching).setOnClickListener {
            btnToggleTimeStretch.performClick()
        }
    }

    // --- 3. Subtitle Settings Handlers ---
    private fun setupSubtitleSettings() {
        btnToggleSubAutoload.setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubAutoload).setOnClickListener {
            btnToggleSubAutoload.performClick()
        }

        val sizeLabels = arrayOf("Very Small (12sp)", "Small (14sp)", "Normal (18sp)", "Large (24sp)", "Huge (32sp)")
        val sizeValues = arrayOf("12", "14", "18", "24", "32")
        val openSizeDialog = {
            val currentIdx = sizeValues.indexOf(PlayerHolder.subFontSize).coerceAtLeast(2)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_sub_size)
                .setSingleChoiceItems(sizeLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontSize = sizeValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubSize.setOnClickListener { openSizeDialog() }
        findViewById<View>(R.id.rowSubSize).setOnClickListener { openSizeDialog() }

        val colorLabels = arrayOf("White", "Yellow", "Cyan", "Green")
        val colorValues = arrayOf("16777215", "16776960", "65535", "65280")
        val openColorDialog = {
            val currentIdx = colorValues.indexOf(PlayerHolder.subFontColor).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_sub_color)
                .setSingleChoiceItems(colorLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontColor = colorValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubColor.setOnClickListener { openColorDialog() }
        findViewById<View>(R.id.rowSubColor).setOnClickListener { openColorDialog() }

        val bgLabels = arrayOf("Transparent / None", "Translucent Box", "Solid Black Box")
        val openBgDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_sub_background)
                .setSingleChoiceItems(bgLabels, PlayerHolder.subBackgroundStyle) { dialog, which ->
                    PlayerHolder.subBackgroundStyle = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubBackground.setOnClickListener { openBgDialog() }
        findViewById<View>(R.id.rowSubBackground).setOnClickListener { openBgDialog() }

        btnToggleSubStyle.setOnClickListener {
            PlayerHolder.subFontStyle = if (PlayerHolder.subFontStyle == 1) 0 else 1
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubStyle).setOnClickListener {
            btnToggleSubStyle.performClick()
        }

        val encodings = arrayOf("UTF-8 (Default)", "Windows-1252 (Western)", "ISO-8859-1 (Latin)", "GBK (Chinese)", "Shift-JIS (Japanese)")
        val encValues = arrayOf("UTF-8", "WINDOWS-1252", "ISO-8859-1", "GBK", "SHIFT-JIS")
        val openEncDialog = {
            val currentIdx = encValues.indexOf(PlayerHolder.subEncoding).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_sub_encoding)
                .setSingleChoiceItems(encodings, currentIdx) { dialog, which ->
                    PlayerHolder.subEncoding = encValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubEncoding.setOnClickListener { openEncDialog() }
        findViewById<View>(R.id.rowSubEncoding).setOnClickListener { openEncDialog() }
    }

    // --- 4. Controls & Gestures Handlers ---
    private fun setupGestureSettings() {
        btnToggleGestureVolume.setOnClickListener {
            PlayerHolder.isVolumeGestureEnabled = !PlayerHolder.isVolumeGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureVolume).setOnClickListener { btnToggleGestureVolume.performClick() }

        btnToggleGestureBrightness.setOnClickListener {
            PlayerHolder.isBrightnessGestureEnabled = !PlayerHolder.isBrightnessGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureBrightness).setOnClickListener { btnToggleGestureBrightness.performClick() }

        btnToggleGestureSeek.setOnClickListener {
            PlayerHolder.isSeekGestureEnabled = !PlayerHolder.isSeekGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureSeek).setOnClickListener { btnToggleGestureSeek.performClick() }

        btnToggleFastSeek.setOnClickListener {
            PlayerHolder.isFastSeekEnabled = !PlayerHolder.isFastSeekEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowFastSeek).setOnClickListener { btnToggleFastSeek.performClick() }
    }

    // --- 5. Interface & Advanced Handlers ---
    private fun setupInterfaceAndAdvancedSettings() {
        val themes = arrayOf("Pure Black OLED (Default)", "Dark Charcoal")
        val openThemeDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_app_theme)
                .setSingleChoiceItems(themes, PlayerHolder.appThemeMode) { dialog, which ->
                    PlayerHolder.appThemeMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAppTheme.setOnClickListener { openThemeDialog() }
        findViewById<View>(R.id.rowAppTheme).setOnClickListener { openThemeDialog() }

        btnClearResume.setOnClickListener {
            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            prefs.edit().clear().apply()
            Toast.makeText(this, "Playback history cleared", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.rowClearResume).setOnClickListener { btnClearResume.performClick() }

        btnResetSettings.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_reset_settings)
                .setMessage("Restore all player settings to default values?")
                .setPositiveButton("Reset") { _, _ ->
                    PlayerHolder.resetPreferences(this)
                    updateSettingsUI()
                    Toast.makeText(this, "Settings restored to defaults", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.rowResetSettings).setOnClickListener { btnResetSettings.performClick() }
    }

    private fun updateSettingsUI() {
        // Video UI
        tvVideoColorStatus.text = when (PlayerHolder.videoColorProfile) {
            0 -> "Standard / Natural (Original)"
            1 -> "Vivid / AMOLED Boost (Recommended)"
            2 -> "Cinema / HDR Effect"
            3 -> "Sharp & Crisp Studio"
            else -> "Custom Color Tuning"
        }
        if (PlayerHolder.isWideColorGamutEnabled) {
            btnToggleWideColor.text = "ON"
            btnToggleWideColor.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
            tvWideColorStatus.text = "Enabled (10-bit dynamic colors)"
        } else {
            btnToggleWideColor.text = "OFF"
            btnToggleWideColor.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
            tvWideColorStatus.text = "Disabled (Standard sRGB)"
        }
        if (PlayerHolder.isDeblockingFilterEnabled) {
            btnToggleDeblocking.text = "ON"
            btnToggleDeblocking.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
            tvDeblockingStatus.text = "Enabled (Crisp gradients & deblocking)"
        } else {
            btnToggleDeblocking.text = "OFF"
            btnToggleDeblocking.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
            tvDeblockingStatus.text = "Disabled"
        }
        tvHwDecodeStatus.text = when (PlayerHolder.hwAccelerationMode) {
            0 -> "Disabled (Software FFmpeg)"
            2 -> "Decoding Only"
            3 -> "Full Acceleration"
            else -> "Automatic (Recommended)"
        }
        tvBgPipStatus.text = when (PlayerHolder.backgroundPipMode) {
            0 -> "Stop Playback"
            2 -> "Picture-in-Picture (PiP)"
            else -> "Play in Background"
        }
        tvResumeModeStatus.text = when (PlayerHolder.resumeMode) {
            0 -> "Never (Always start over)"
            2 -> "Always resume automatically"
            else -> "Ask confirmation"
        }
        tvDoubleTapStatus.text = "${PlayerHolder.doubleTapSeekSeconds} seconds"
        tvAspectRatioStatus.text = when (PlayerHolder.defaultAspectRatio) {
            1 -> "Fit Screen"
            2 -> "Fill Screen"
            3 -> "16:9"
            4 -> "4:3"
            else -> "Best Fit"
        }
        if (PlayerHolder.isAudioBoostEnabled) {
            btnToggleAudioBoost.text = "ON"
            btnToggleAudioBoost.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
            tvAudioBoostStatus.text = "Enabled (Up to 200%)"
        } else {
            btnToggleAudioBoost.text = "OFF"
            btnToggleAudioBoost.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
            tvAudioBoostStatus.text = "Disabled (Standard 100%)"
        }

        // Integrated Audio Suite UI
        tvMasterProfileStatus.text = PlayerHolder.masterProfileNames[PlayerHolder.masterAudioProfile.coerceIn(0, 4)]
        tvDolbySurroundStatus.text = when (PlayerHolder.dolbySpatialMode) {
            1 -> "Dolby 3D Headphone (Binaural HRTF)"
            2 -> "Dolby ProLogic Surround (Matrix)"
            3 -> "Cinema 3D Soundstage (Wide Room)"
            else -> "Standard Stereo (Downmix)"
        }
        val eqIdx = PlayerHolder.currentEqualizerPreset
        tvEqualizerStatus.text = if (eqIdx >= 0 && eqIdx < PlayerHolder.equalizerPresets.size - 1) {
            PlayerHolder.equalizerPresets[eqIdx + 1]
        } else {
            "Flat (Off)"
        }
        if (PlayerHolder.isDialogueBoostEnabled) {
            btnToggleDialogueBoost.text = "ON"
            btnToggleDialogueBoost.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
            tvDialogueBoostStatus.text = "Dynamic range compression: Clear speech (Enabled)"
        } else {
            btnToggleDialogueBoost.text = "OFF"
            btnToggleDialogueBoost.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
            tvDialogueBoostStatus.text = "Disabled"
        }

        if (PlayerHolder.isDolbyPassthroughEnabled) {
            btnTogglePassthrough.text = "ON"
            btnTogglePassthrough.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
            tvDigitalPassthroughStatus.text = "HDMI / S/PDIF Passthrough (Active)"
        } else {
            btnTogglePassthrough.text = "OFF"
            btnTogglePassthrough.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
            tvDigitalPassthroughStatus.text = "Disabled"
        }

        tvAudioOutputStatus.text = when (PlayerHolder.audioOutputEngine) {
            1 -> "OpenSL ES (Low Latency)"
            2 -> "AAudio (Modern NDK)"
            else -> "AudioTrack (Standard)"
        }

        if (PlayerHolder.isHeadsetPauseEnabled) {
            btnToggleHeadsetPause.text = "ON"
            btnToggleHeadsetPause.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
            tvHeadsetPauseStatus.text = "Auto-pause when unplugged (Enabled)"
        } else {
            btnToggleHeadsetPause.text = "OFF"
            btnToggleHeadsetPause.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
            tvHeadsetPauseStatus.text = "Disabled"
        }

        if (PlayerHolder.isTimeStretchingEnabled) {
            btnToggleTimeStretch.text = "ON"
            btnToggleTimeStretch.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
            tvTimeStretchStatus.text = "Pitch lock active (Enabled)"
        } else {
            btnToggleTimeStretch.text = "OFF"
            btnToggleTimeStretch.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
            tvTimeStretchStatus.text = "Disabled"
        }

        // Subtitle UI
        if (PlayerHolder.isSubAutoloadEnabled) {
            btnToggleSubAutoload.text = "ON"
            btnToggleSubAutoload.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
        } else {
            btnToggleSubAutoload.text = "OFF"
            btnToggleSubAutoload.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
        }
        tvSubSizeStatus.text = when (PlayerHolder.subFontSize) {
            "12" -> "Very Small (12sp)"
            "14" -> "Small (14sp)"
            "24" -> "Large (24sp)"
            "32" -> "Huge (32sp)"
            else -> "Normal (18sp)"
        }
        tvSubColorStatus.text = when (PlayerHolder.subFontColor) {
            "16776960" -> "Yellow"
            "65535" -> "Cyan"
            "65280" -> "Green"
            else -> "White"
        }
        tvSubBackgroundStatus.text = when (PlayerHolder.subBackgroundStyle) {
            1 -> "Translucent Box"
            2 -> "Solid Black Box"
            else -> "Transparent / None"
        }
        if (PlayerHolder.subFontStyle == 1) {
            btnToggleSubStyle.text = "BOLD"
            btnToggleSubStyle.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
            tvSubStyleStatus.text = "Bold font weight"
        } else {
            btnToggleSubStyle.text = "REG"
            btnToggleSubStyle.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
            tvSubStyleStatus.text = "Normal font weight"
        }
        tvSubEncodingStatus.text = PlayerHolder.subEncoding

        // Gestures UI
        btnToggleGestureVolume.text = if (PlayerHolder.isVolumeGestureEnabled) "ON" else "OFF"
        btnToggleGestureVolume.setTextColor(ContextCompat.getColor(this, if (PlayerHolder.isVolumeGestureEnabled) R.color.theme_primary else R.color.theme_text_secondary))
        tvGestureVolumeStatus.text = if (PlayerHolder.isVolumeGestureEnabled) "Right side swipe (Enabled)" else "Disabled"

        btnToggleGestureBrightness.text = if (PlayerHolder.isBrightnessGestureEnabled) "ON" else "OFF"
        btnToggleGestureBrightness.setTextColor(ContextCompat.getColor(this, if (PlayerHolder.isBrightnessGestureEnabled) R.color.theme_primary else R.color.theme_text_secondary))
        tvGestureBrightnessStatus.text = if (PlayerHolder.isBrightnessGestureEnabled) "Left side swipe (Enabled)" else "Disabled"

        btnToggleGestureSeek.text = if (PlayerHolder.isSeekGestureEnabled) "ON" else "OFF"
        btnToggleGestureSeek.setTextColor(ContextCompat.getColor(this, if (PlayerHolder.isSeekGestureEnabled) R.color.theme_primary else R.color.theme_text_secondary))
        tvGestureSeekStatus.text = if (PlayerHolder.isSeekGestureEnabled) "Horizontal drag (Enabled)" else "Disabled"

        btnToggleFastSeek.text = if (PlayerHolder.isFastSeekEnabled) "ON" else "OFF"
        btnToggleFastSeek.setTextColor(ContextCompat.getColor(this, if (PlayerHolder.isFastSeekEnabled) R.color.theme_primary else R.color.theme_text_secondary))
        tvFastSeekStatus.text = if (PlayerHolder.isFastSeekEnabled) "Seek to nearest keyframe (Enabled)" else "Exact frame seek (Disabled)"

        // Interface UI
        tvAppThemeStatus.text = if (PlayerHolder.appThemeMode == 0) "Pure Black OLED" else "Dark Charcoal"
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            storagePermissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            loadMediaFiles()
        }
    }

    private fun loadMediaFiles() {
        allVideos = MediaScanner.scanVideos(this)
        if (allVideos.isNotEmpty()) {
            rvVideos.visibility = View.VISIBLE
            layoutEmptyVideo.visibility = View.GONE
            if (videoAdapter == null) {
                videoAdapter = MediaAdapter(allVideos) { item ->
                    openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
                }
                rvVideos.adapter = videoAdapter
            } else {
                videoAdapter?.updateList(allVideos)
            }
        } else {
            rvVideos.visibility = View.GONE
            layoutEmptyVideo.visibility = View.VISIBLE
        }

        allAudio = MediaScanner.scanAudio(this)
        if (allAudio.isNotEmpty()) {
            rvAudio.visibility = View.VISIBLE
            layoutEmptyAudio.visibility = View.GONE
            if (audioAdapter == null) {
                audioAdapter = MediaAdapter(allAudio) { item ->
                    openPlayer(item.uri, item.title, isVideo = false, path = item.filePath)
                }
                rvAudio.adapter = audioAdapter
            } else {
                audioAdapter?.updateList(allAudio)
            }
        } else {
            rvAudio.visibility = View.GONE
            layoutEmptyAudio.visibility = View.VISIBLE
        }
    }

    private fun openPlayer(uri: Uri, title: String, isVideo: Boolean = true, path: String? = null) {
        val intent = Intent(this, PlayerActivity::class.java).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra("media_uri", uri.toString())
            putExtra("media_title", title)
            putExtra("is_video", isVideo)
            if (!path.isNullOrEmpty()) {
                putExtra("media_path", path)
            }
        }
        startActivity(intent)
    }
}
