@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.cleanplayer.app

import android.Manifest
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import android.widget.ImageButton
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    companion object {
        init {
            androidx.appcompat.app.AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        }
    }


    private lateinit var toolbar: MaterialToolbar
    private lateinit var btnToolbarSearch: ImageButton
    private lateinit var btnToolbarSort: ImageButton
    private lateinit var btnToolbarOpen: ImageButton
    private lateinit var fabPlay: FloatingActionButton
    private lateinit var etSearch: EditText
    private lateinit var tabVideo: LinearLayout
    private lateinit var tabAudio: LinearLayout
    private lateinit var tabSettings: ScrollView
    private lateinit var bottomNav: BottomNavigationView

    private lateinit var btnViewAllVideos: TextView
    private lateinit var btnViewFolders: TextView
    private lateinit var rvVideos: RecyclerView
    private lateinit var layoutFoldersContainer: LinearLayout
    private lateinit var rvFolders: RecyclerView
    private lateinit var layoutFolderDetailHeader: LinearLayout
    private lateinit var btnFolderBack: ImageButton
    private lateinit var tvFolderHeaderTitle: TextView
    private lateinit var tvFolderHeaderSubtitle: TextView
    private lateinit var rvFolderVideos: RecyclerView
    private lateinit var layoutEmptyVideo: LinearLayout
    private lateinit var btnBrowseVideo: Button

    private var isFolderViewActive: Boolean = false
    private var allFolders: List<MediaFolder> = emptyList()
    private var currentSelectedFolder: MediaFolder? = null
    private var folderAdapter: FolderAdapter? = null
    private var folderVideoAdapter: MediaAdapter? = null

    private lateinit var rvAudio: RecyclerView
    private lateinit var layoutEmptyAudio: LinearLayout
    private lateinit var btnBrowseAudio: Button

    // 1. Video Settings Views
    private lateinit var tvHighRefreshRateStatus: TextView
    private lateinit var btnToggleHighRefreshRate: Button
    private lateinit var tvDefaultOrientationStatus: TextView
    private lateinit var btnChangeOrientation: Button

    // Top Notch Mini-Player Views (matches 5203.jpg)
    private lateinit var cardNotchPlayer: View
    private lateinit var tvNotchTitle: TextView
    private lateinit var tvNotchArtist: TextView
    private lateinit var btnNotchClose: ImageButton
    private lateinit var btnNotchRepeat: ImageButton
    private lateinit var btnNotchPrev: ImageButton
    private lateinit var btnNotchPlayPause: ImageButton
    private lateinit var btnNotchNext: ImageButton
    private lateinit var btnNotchOpen: ImageButton
    private lateinit var tvNotchCurrent: TextView
    private lateinit var sbNotch: SeekBar
    private lateinit var tvNotchTotal: TextView
    private lateinit var tvVideoColorStatus: TextView
    private lateinit var btnChangeVideoColor: Button
    private lateinit var tvWideColorStatus: TextView
    private lateinit var btnToggleWideColor: Button
    private lateinit var tvDeblockingStatus: TextView
    private lateinit var btnToggleDeblocking: Button
    private lateinit var tvHwDecodeStatus: TextView
    private lateinit var btnChangeHw: Button
    private lateinit var tvBgPipStatus: TextView
    private lateinit var btnChangeBgPip: Button
    private lateinit var tvResumeModeStatus: TextView
    private lateinit var btnChangeResumeMode: Button
    private lateinit var tvDoubleTapStatus: TextView
    private lateinit var btnChangeDoubleTap: Button
    private lateinit var tvAspectRatioStatus: TextView
    private lateinit var btnChangeAspectRatio: Button
    private lateinit var tvAudioBoostStatus: TextView
    private lateinit var btnToggleAudioBoost: Button

    // 2. Integrated Dolby, Spatial & Equalizer Audio Suite Views
    private lateinit var tvMasterProfileStatus: TextView
    private lateinit var btnChangeMasterProfile: Button
    private lateinit var tvDolbySurroundStatus: TextView
    private lateinit var btnChangeDolbySurround: Button
    private lateinit var tvEqualizerStatus: TextView
    private lateinit var btnChangeEqualizer: Button
    private lateinit var tvDialogueBoostStatus: TextView
    private lateinit var btnToggleDialogueBoost: Button
    private lateinit var tvDigitalPassthroughStatus: TextView
    private lateinit var btnTogglePassthrough: Button
    private lateinit var tvAudioOutputStatus: TextView
    private lateinit var btnChangeAudioOutput: Button
    private lateinit var tvHeadsetPauseStatus: TextView
    private lateinit var btnToggleHeadsetPause: Button
    private lateinit var tvTimeStretchStatus: TextView
    private lateinit var btnToggleTimeStretch: Button

    // 3. Subtitle Settings Views
    private lateinit var btnToggleSubAutoload: Button
    private lateinit var tvSubSizeStatus: TextView
    private lateinit var btnChangeSubSize: Button
    private lateinit var tvSubColorStatus: TextView
    private lateinit var btnChangeSubColor: Button
    private lateinit var tvSubBackgroundStatus: TextView
    private lateinit var btnChangeSubBackground: Button
    private lateinit var tvSubStyleStatus: TextView
    private lateinit var btnToggleSubStyle: Button
    private lateinit var tvSubEncodingStatus: TextView
    private lateinit var btnChangeSubEncoding: Button

    // 4. Gestures Settings Views
    private lateinit var tvGestureVolumeStatus: TextView
    private lateinit var btnToggleGestureVolume: Button
    private lateinit var tvGestureBrightnessStatus: TextView
    private lateinit var btnToggleGestureBrightness: Button
    private lateinit var tvGestureSeekStatus: TextView
    private lateinit var btnToggleGestureSeek: Button
    private lateinit var tvFastSeekStatus: TextView
    private lateinit var btnToggleFastSeek: Button

    // 5. Interface Settings Views
    private lateinit var tvAppThemeStatus: TextView
    private lateinit var btnChangeAppTheme: Button

    // 6. Advanced Settings Views
    private lateinit var btnClearResume: Button
    private lateinit var btnResetSettings: Button

    private var allVideos = listOf<MediaItem>()
    private var allAudio = listOf<MediaItem>()
    private var videoAdapter: MediaAdapter? = null
    private var audioAdapter: MediaAdapter? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val title = it.lastPathSegment?.substringAfterLast('/') ?: "Media File"
            val type = contentResolver.getType(it) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(it, title, isVideo, null)
        }
    }

    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        loadMediaFiles()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        PlayerHolder.loadPreferences(this)
        if (PlayerHolder.isMonochrome()) {
            setTheme(R.style.Theme_Multimedia_Monochrome)
        } else {
            setTheme(R.style.Theme_Multimedia)
        }
        super.onCreate(savedInstanceState)
        applyHighRefreshRate()
        setContentView(R.layout.activity_main)

        onBackPressedDispatcher.addCallback(this) {
            if (isFolderViewActive && currentSelectedFolder != null) {
                closeFolderDetail()
            } else {
                finish()
            }
        }

        initViews()
        setupBottomNav()
        setupSearch()
        setupVideoSettings()
        setupAudioSuiteSettings()
        setupSubtitleSettings()
        setupGestureSettings()
        setupInterfaceAndAdvancedSettings()
        applyThemeUI()
        checkAndRequestPermissions()

        val openFullPlayer = {
            val uri = PlayerHolder.currentUri
            if (uri != null) {
                openPlayer(uri, PlayerHolder.currentTitle, isVideo = !PlayerHolder.isAudioOnly, path = PlayerHolder.currentPath)
            }
        }
        cardNotchPlayer.setOnClickListener { openFullPlayer() }
        btnNotchOpen.setOnClickListener { openFullPlayer() }

        btnNotchPlayPause.setOnClickListener {
            PlayerHolder.mediaPlayer?.let { player ->
                if (player.isPlaying) {
                    player.pause()
                    btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_play)
                    MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = false)
                } else {
                    player.play()
                    btnNotchPlayPause.setImageResource(android.R.drawable.ic_media_pause)
                    MediaPlaybackService.start(this, PlayerHolder.currentTitle, PlayerHolder.currentArtist, isPlaying = true)
                }
            }
        }

        btnNotchPrev.setOnClickListener {
            PlayerHolder.playPrevious(this)
            updateNotchPlayerUI()
            audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
        }

        btnNotchNext.setOnClickListener {
            PlayerHolder.playNext(this)
            updateNotchPlayerUI()
            audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
        }

        btnNotchRepeat.setOnClickListener {
            val mode = PlayerHolder.toggleRepeatMode()
            updateNotchRepeatUI(mode)
        }

        btnNotchClose.setOnClickListener {
            PlayerHolder.release()
            MediaPlaybackService.stop(this)
            cardNotchPlayer.visibility = View.GONE
            audioAdapter?.setPlayingUri(null)
        }

        sbNotch.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    tvNotchCurrent.text = formatTime(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                sb?.let {
                    PlayerHolder.mediaPlayer?.seekTo(it.progress.toLong())
                }
            }
        })

        intent?.data?.let { uri ->
            val title = uri.lastPathSegment?.substringAfterLast('/') ?: "Media File"
            val type = intent?.type ?: contentResolver.getType(uri) ?: ""
            val isVideo = !type.startsWith("audio/")
            openPlayer(uri, title, isVideo, null)
        }
    }

    private val notchProgressHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val notchProgressRunnable = object : Runnable {
        override fun run() {
            PlayerHolder.mediaPlayer?.let { player ->
                if (cardNotchPlayer.visibility == View.VISIBLE) {
                    val current = player.currentPosition
                    val duration = player.duration
                    if (duration > 0) {
                        sbNotch.max = duration.toInt()
                        sbNotch.progress = current.toInt()
                        tvNotchCurrent.text = formatTime(current)
                        tvNotchTotal.text = formatTime(duration)
                    }
                    val isPlaying = player.isPlaying
                    btnNotchPlayPause.setImageResource(
                        if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                }
            }
            notchProgressHandler.postDelayed(this, 1000)
        }
    }

    override fun onResume() {
        super.onResume()
        updateSettingsUI()
        updateNotchPlayerUI()
        audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
        notchProgressHandler.post(notchProgressRunnable)

        PlayerHolder.onTrackChangedListener = { item ->
            runOnUiThread {
                updateNotchPlayerUI()
                audioAdapter?.setPlayingUri(item.uri)
            }
        }
        PlayerHolder.onPlaybackStateChangedListener = { isPlaying ->
            runOnUiThread {
                btnNotchPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
                audioAdapter?.notifyDataSetChanged()
            }
        }
    }

    override fun onPause() {
        super.onPause()
        notchProgressHandler.removeCallbacks(notchProgressRunnable)
        PlayerHolder.onTrackChangedListener = null
        PlayerHolder.onPlaybackStateChangedListener = null
    }

    private fun updateNotchRepeatUI(mode: Int) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        when (mode) {
            1 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat_one)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            2 -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(primaryColor)
            }
            else -> {
                btnNotchRepeat.setImageResource(R.drawable.ic_repeat)
                btnNotchRepeat.setColorFilter(secondaryColor)
            }
        }
    }

    private fun updateNotchPlayerUI() {
        val player = PlayerHolder.mediaPlayer
        if (player != null && PlayerHolder.currentUri != null) {
            cardNotchPlayer.visibility = View.VISIBLE
            tvNotchTitle.text = PlayerHolder.currentTitle
            tvNotchTitle.isSelected = true
            tvNotchArtist.text = PlayerHolder.currentArtist
            val isPlaying = player.isPlaying
            btnNotchPlayPause.setImageResource(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            )
            updateNotchRepeatUI(PlayerHolder.repeatMode)
            val duration = player.duration
            if (duration > 0) {
                sbNotch.max = duration.toInt()
                sbNotch.progress = player.currentPosition.toInt()
                tvNotchCurrent.text = formatTime(player.currentPosition)
                tvNotchTotal.text = formatTime(duration)
            }
        } else {
            cardNotchPlayer.visibility = View.GONE
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (hours > 0) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(java.util.Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    private fun showSortDialog() {
        val sortOptions = arrayOf(
            getString(R.string.sort_name_asc),
            getString(R.string.sort_name_desc),
            getString(R.string.sort_date_newest),
            getString(R.string.sort_duration),
            getString(R.string.sort_size)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.sort_title)
            .setItems(sortOptions) { _, which ->
                when (which) {
                    0 -> {
                        allVideos = allVideos.sortedBy { it.title.lowercase() }
                        allAudio = allAudio.sortedBy { it.title.lowercase() }
                    }
                    1 -> {
                        allVideos = allVideos.sortedByDescending { it.title.lowercase() }
                        allAudio = allAudio.sortedByDescending { it.title.lowercase() }
                    }
                    2 -> {
                        allVideos = allVideos.sortedByDescending { it.id }
                        allAudio = allAudio.sortedByDescending { it.id }
                    }
                    3 -> {
                        allVideos = allVideos.sortedByDescending { it.durationMs }
                        allAudio = allAudio.sortedByDescending { it.durationMs }
                    }
                    4 -> {
                        allVideos = allVideos.sortedByDescending { it.sizeBytes }
                        allAudio = allAudio.sortedByDescending { it.sizeBytes }
                    }
                }
                videoAdapter?.updateList(allVideos)
                audioAdapter?.updateList(allAudio)
                updateFoldersData()
                Toast.makeText(this, "Sorted by ${sortOptions[which]}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        btnToolbarSearch = findViewById(R.id.btnToolbarSearch)
        btnToolbarSearch.setOnClickListener {
            val searchLayout = findViewById<View>(R.id.layoutSearch)
            searchLayout.visibility = if (searchLayout.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            if (searchLayout.visibility == View.VISIBLE) {
                etSearch.requestFocus()
            }
        }
        btnToolbarSort = findViewById(R.id.btnToolbarSort)
        btnToolbarSort.setOnClickListener { showSortDialog() }
        btnToolbarOpen = findViewById(R.id.btnToolbarOpen)
        fabPlay = findViewById(R.id.fabPlay)
        fabPlay.setOnClickListener {
            if (allVideos.isNotEmpty()) {
                val item = allVideos.first()
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } else if (allAudio.isNotEmpty()) {
                PlayerHolder.setPlaylistAndPlay(this, allAudio, 0)
                openPlayer(allAudio[0].uri, allAudio[0].title, isVideo = false, path = allAudio[0].filePath, artist = allAudio[0].artist)
            } else {
                Toast.makeText(this, "No media files found", Toast.LENGTH_SHORT).show()
            }
        }
        etSearch = findViewById(R.id.etSearch)
        tabVideo = findViewById(R.id.tabVideo)
        tabAudio = findViewById(R.id.tabAudio)
        tabSettings = findViewById(R.id.tabSettings)
        bottomNav = findViewById(R.id.bottomNav)

        btnViewAllVideos = findViewById(R.id.btnViewAllVideos)
        btnViewFolders = findViewById(R.id.btnViewFolders)
        rvVideos = findViewById(R.id.rvVideos)
        layoutFoldersContainer = findViewById(R.id.layoutFoldersContainer)
        rvFolders = findViewById(R.id.rvFolders)
        layoutFolderDetailHeader = findViewById(R.id.layoutFolderDetailHeader)
        btnFolderBack = findViewById(R.id.btnFolderBack)
        tvFolderHeaderTitle = findViewById(R.id.tvFolderHeaderTitle)
        tvFolderHeaderSubtitle = findViewById(R.id.tvFolderHeaderSubtitle)
        rvFolderVideos = findViewById(R.id.rvFolderVideos)
        layoutEmptyVideo = findViewById(R.id.layoutEmptyVideo)
        btnBrowseVideo = findViewById(R.id.btnBrowseVideo)

        rvFolders.layoutManager = LinearLayoutManager(this)
        rvFolderVideos.layoutManager = LinearLayoutManager(this)

        btnViewAllVideos.setOnClickListener {
            switchVideoViewMode(folders = false)
        }

        btnViewFolders.setOnClickListener {
            switchVideoViewMode(folders = true)
        }

        btnFolderBack.setOnClickListener {
            closeFolderDetail()
        }

        rvAudio = findViewById(R.id.rvAudio)
        layoutEmptyAudio = findViewById(R.id.layoutEmptyAudio)
        btnBrowseAudio = findViewById(R.id.btnBrowseAudio)

        // Video Settings
        tvHighRefreshRateStatus = findViewById(R.id.tvHighRefreshRateStatus)
        btnToggleHighRefreshRate = findViewById(R.id.btnToggleHighRefreshRate)
        tvDefaultOrientationStatus = findViewById(R.id.tvDefaultOrientationStatus)
        btnChangeOrientation = findViewById(R.id.btnChangeOrientation)

        // Notch Mini Player
        cardNotchPlayer = findViewById(R.id.cardNotchPlayer)
        tvNotchTitle = findViewById(R.id.tvNotchTitle)
        tvNotchArtist = findViewById(R.id.tvNotchArtist)
        btnNotchClose = findViewById(R.id.btnNotchClose)
        btnNotchRepeat = findViewById(R.id.btnNotchRepeat)
        btnNotchPrev = findViewById(R.id.btnNotchPrev)
        btnNotchPlayPause = findViewById(R.id.btnNotchPlayPause)
        btnNotchNext = findViewById(R.id.btnNotchNext)
        btnNotchOpen = findViewById(R.id.btnNotchOpen)
        tvNotchCurrent = findViewById(R.id.tvNotchCurrent)
        sbNotch = findViewById(R.id.sbNotch)
        tvNotchTotal = findViewById(R.id.tvNotchTotal)
        tvVideoColorStatus = findViewById(R.id.tvVideoColorStatus)
        btnChangeVideoColor = findViewById(R.id.btnChangeVideoColor)
        tvWideColorStatus = findViewById(R.id.tvWideColorStatus)
        btnToggleWideColor = findViewById(R.id.btnToggleWideColor)
        tvDeblockingStatus = findViewById(R.id.tvDeblockingStatus)
        btnToggleDeblocking = findViewById(R.id.btnToggleDeblocking)
        tvHwDecodeStatus = findViewById(R.id.tvHwDecodeStatus)
        btnChangeHw = findViewById(R.id.btnChangeHw)
        tvBgPipStatus = findViewById(R.id.tvBgPipStatus)
        btnChangeBgPip = findViewById(R.id.btnChangeBgPip)
        tvResumeModeStatus = findViewById(R.id.tvResumeModeStatus)
        btnChangeResumeMode = findViewById(R.id.btnChangeResumeMode)
        tvDoubleTapStatus = findViewById(R.id.tvDoubleTapStatus)
        btnChangeDoubleTap = findViewById(R.id.btnChangeDoubleTap)
        tvAspectRatioStatus = findViewById(R.id.tvAspectRatioStatus)
        btnChangeAspectRatio = findViewById(R.id.btnChangeAspectRatio)
        tvAudioBoostStatus = findViewById(R.id.tvAudioBoostStatus)
        btnToggleAudioBoost = findViewById(R.id.btnToggleAudioBoost)

        // Audio Suite Settings
        tvMasterProfileStatus = findViewById(R.id.tvMasterProfileStatus)
        btnChangeMasterProfile = findViewById(R.id.btnChangeMasterProfile)
        tvDolbySurroundStatus = findViewById(R.id.tvDolbySurroundStatus)
        btnChangeDolbySurround = findViewById(R.id.btnChangeDolbySurround)
        tvEqualizerStatus = findViewById(R.id.tvEqualizerStatus)
        btnChangeEqualizer = findViewById(R.id.btnChangeEqualizer)
        tvDialogueBoostStatus = findViewById(R.id.tvDialogueBoostStatus)
        btnToggleDialogueBoost = findViewById(R.id.btnToggleDialogueBoost)
        tvDigitalPassthroughStatus = findViewById(R.id.tvDigitalPassthroughStatus)
        btnTogglePassthrough = findViewById(R.id.btnTogglePassthrough)
        tvAudioOutputStatus = findViewById(R.id.tvAudioOutputStatus)
        btnChangeAudioOutput = findViewById(R.id.btnChangeAudioOutput)
        tvHeadsetPauseStatus = findViewById(R.id.tvHeadsetPauseStatus)
        btnToggleHeadsetPause = findViewById(R.id.btnToggleHeadsetPause)
        tvTimeStretchStatus = findViewById(R.id.tvTimeStretchStatus)
        btnToggleTimeStretch = findViewById(R.id.btnToggleTimeStretch)

        // Subtitle Settings
        btnToggleSubAutoload = findViewById(R.id.btnToggleSubAutoload)
        tvSubSizeStatus = findViewById(R.id.tvSubSizeStatus)
        btnChangeSubSize = findViewById(R.id.btnChangeSubSize)
        tvSubColorStatus = findViewById(R.id.tvSubColorStatus)
        btnChangeSubColor = findViewById(R.id.btnChangeSubColor)
        tvSubBackgroundStatus = findViewById(R.id.tvSubBackgroundStatus)
        btnChangeSubBackground = findViewById(R.id.btnChangeSubBackground)
        tvSubStyleStatus = findViewById(R.id.tvSubStyleStatus)
        btnToggleSubStyle = findViewById(R.id.btnToggleSubStyle)
        tvSubEncodingStatus = findViewById(R.id.tvSubEncodingStatus)
        btnChangeSubEncoding = findViewById(R.id.btnChangeSubEncoding)

        // Gesture Settings
        tvGestureVolumeStatus = findViewById(R.id.tvGestureVolumeStatus)
        btnToggleGestureVolume = findViewById(R.id.btnToggleGestureVolume)
        tvGestureBrightnessStatus = findViewById(R.id.tvGestureBrightnessStatus)
        btnToggleGestureBrightness = findViewById(R.id.btnToggleGestureBrightness)
        tvGestureSeekStatus = findViewById(R.id.tvGestureSeekStatus)
        btnToggleGestureSeek = findViewById(R.id.btnToggleGestureSeek)
        tvFastSeekStatus = findViewById(R.id.tvFastSeekStatus)
        btnToggleFastSeek = findViewById(R.id.btnToggleFastSeek)

        // Interface Settings
        tvAppThemeStatus = findViewById(R.id.tvAppThemeStatus)
        btnChangeAppTheme = findViewById(R.id.btnChangeAppTheme)

        // Advanced Settings
        btnClearResume = findViewById(R.id.btnClearResume)
        btnResetSettings = findViewById(R.id.btnResetSettings)

        rvVideos.layoutManager = LinearLayoutManager(this)
        rvAudio.layoutManager = LinearLayoutManager(this)

        val openFileAction = {
            filePickerLauncher.launch(arrayOf("video/*", "audio/*"))
        }

        btnToolbarOpen.setOnClickListener { openFileAction() }
        btnBrowseVideo.setOnClickListener { openFileAction() }
        btnBrowseAudio.setOnClickListener { openFileAction() }
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterMedia(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun filterMedia(query: String) {
        val q = query.trim().lowercase()
        val filteredVideos = if (q.isEmpty()) allVideos else allVideos.filter { it.title.lowercase().contains(q) }
        val filteredAudio = if (q.isEmpty()) allAudio else allAudio.filter {
            it.title.lowercase().contains(q) || (it.artist?.lowercase()?.contains(q) == true)
        }

        videoAdapter?.updateList(filteredVideos)
        audioAdapter?.updateList(filteredAudio)

        if (isFolderViewActive) {
            val filteredFolders = if (q.isEmpty()) allFolders else allFolders.filter { folder ->
                folder.folderName.lowercase().contains(q) || folder.videos.any { it.title.lowercase().contains(q) }
            }
            folderAdapter?.updateFolders(filteredFolders)
        }

        if (!isFolderViewActive) {
            rvVideos.visibility = if (filteredVideos.isNotEmpty()) View.VISIBLE else View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = if (filteredVideos.isEmpty()) View.VISIBLE else View.GONE
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            layoutEmptyVideo.visibility = if (allFolders.isEmpty()) View.VISIBLE else View.GONE
        }

        rvAudio.visibility = if (filteredAudio.isNotEmpty()) View.VISIBLE else View.GONE
        layoutEmptyAudio.visibility = if (filteredAudio.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun setupBottomNav() {
        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_video -> {
                    showTab(video = true, audio = false, settings = false)
                    switchVideoViewMode(folders = false)
                    true
                }
                R.id.nav_audio -> {
                    showTab(video = false, audio = true, settings = false)
                    true
                }
                R.id.nav_more -> {
                    showTab(video = false, audio = false, settings = true)
                    true
                }
                else -> false
            }
        }
    }

    private fun showTab(video: Boolean, audio: Boolean, settings: Boolean) {
        tabVideo.visibility = if (video) View.VISIBLE else View.GONE
        tabAudio.visibility = if (audio) View.VISIBLE else View.GONE
        tabSettings.visibility = if (settings) View.VISIBLE else View.GONE
    }

    // --- 1. Video Settings Handlers ---
    private fun setupVideoSettings() {
        btnToggleHighRefreshRate.setOnClickListener {
            PlayerHolder.isHighRefreshRateEnabled = !PlayerHolder.isHighRefreshRateEnabled
            PlayerHolder.savePreferences(this)
            applyHighRefreshRate()
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHighRefreshRate).setOnClickListener {
            btnToggleHighRefreshRate.performClick()
        }

        val orientationOptions = arrayOf("Auto Sensor (Free Rotation)", "Direct Landscape (Recommended)", "Portrait (Vertical)")
        val openOrientationDialog = {
            AlertDialog.Builder(this)
                .setTitle("Default Video Orientation")
                .setSingleChoiceItems(orientationOptions, PlayerHolder.defaultOrientation) { dialog, which ->
                    PlayerHolder.defaultOrientation = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeOrientation.setOnClickListener { openOrientationDialog() }
        findViewById<View>(R.id.rowDefaultOrientation).setOnClickListener { openOrientationDialog() }
        val openVideoColorDialog = {
            AlertDialog.Builder(this)
                .setTitle("Picture Mode & Color Boost")
                .setSingleChoiceItems(PlayerHolder.videoProfileNames, PlayerHolder.videoColorProfile.coerceIn(0, 4)) { dialog, which ->
                    PlayerHolder.applyVideoColorProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeVideoColor.setOnClickListener { openVideoColorDialog() }
        findViewById<View>(R.id.rowVideoColor).setOnClickListener { openVideoColorDialog() }

        btnToggleWideColor.setOnClickListener {
            PlayerHolder.isWideColorGamutEnabled = !PlayerHolder.isWideColorGamutEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowWideColor).setOnClickListener {
            btnToggleWideColor.performClick()
        }

        btnToggleDeblocking.setOnClickListener {
            PlayerHolder.isDeblockingFilterEnabled = !PlayerHolder.isDeblockingFilterEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDeblocking).setOnClickListener {
            btnToggleDeblocking.performClick()
        }
        val hwOptions = arrayOf("Disabled (Software)", "Automatic (Recommended)", "Decoding Only", "Full Acceleration")
        val openHwDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_hw_decoding)
                .setSingleChoiceItems(hwOptions, PlayerHolder.hwAccelerationMode) { dialog, which ->
                    PlayerHolder.hwAccelerationMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeHw.setOnClickListener { openHwDialog() }
        findViewById<View>(R.id.rowHwDecode).setOnClickListener { openHwDialog() }

        val bgPipOptions = arrayOf("Stop Playback", "Play in Background", "Picture-in-Picture (PiP)")
        val openBgPipDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_bg_pip)
                .setSingleChoiceItems(bgPipOptions, PlayerHolder.backgroundPipMode) { dialog, which ->
                    PlayerHolder.backgroundPipMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeBgPip.setOnClickListener { openBgPipDialog() }
        findViewById<View>(R.id.rowBgPip).setOnClickListener { openBgPipDialog() }

        val resumeOptions = arrayOf("Never (Always start from beginning)", "Ask confirmation on open", "Always resume automatically")
        val openResumeDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_resume)
                .setSingleChoiceItems(resumeOptions, PlayerHolder.resumeMode) { dialog, which ->
                    PlayerHolder.resumeMode = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeResumeMode.setOnClickListener { openResumeDialog() }
        findViewById<View>(R.id.rowResumeMode).setOnClickListener { openResumeDialog() }

        val seekOptions = arrayOf("5 seconds", "10 seconds", "20 seconds", "30 seconds")
        val seekValues = arrayOf(5, 10, 20, 30)
        val openSeekDialog = {
            val currentIdx = seekValues.indexOf(PlayerHolder.doubleTapSeekSeconds).coerceAtLeast(1)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_double_tap)
                .setSingleChoiceItems(seekOptions, currentIdx) { dialog, which ->
                    PlayerHolder.doubleTapSeekSeconds = seekValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDoubleTap.setOnClickListener { openSeekDialog() }
        findViewById<View>(R.id.rowDoubleTap).setOnClickListener { openSeekDialog() }

        val aspectOptions = arrayOf("Best Fit (Default)", "Fit Screen", "Fill Screen", "16:9 Aspect Ratio", "4:3 Aspect Ratio")
        val openAspectDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_aspect_ratio)
                .setSingleChoiceItems(aspectOptions, PlayerHolder.defaultAspectRatio) { dialog, which ->
                    PlayerHolder.defaultAspectRatio = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAspectRatio.setOnClickListener { openAspectDialog() }
        findViewById<View>(R.id.rowAspectRatio).setOnClickListener { openAspectDialog() }

        btnToggleAudioBoost.setOnClickListener {
            PlayerHolder.isAudioBoostEnabled = !PlayerHolder.isAudioBoostEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowAudioBoost).setOnClickListener {
            btnToggleAudioBoost.performClick()
        }
    }

    // --- 2. Integrated Dolby, Spatial & Equalizer Audio Suite Handlers ---
    private fun setupAudioSuiteSettings() {
        // Master Profile Dialog
        val openMasterProfileDialog = {
            AlertDialog.Builder(this)
                .setTitle("Select Audio Profile")
                .setSingleChoiceItems(PlayerHolder.masterProfileNames, PlayerHolder.masterAudioProfile) { dialog, which ->
                    PlayerHolder.applyMasterProfile(which)
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeMasterProfile.setOnClickListener { openMasterProfileDialog() }
        findViewById<View>(R.id.rowMasterProfile).setOnClickListener { openMasterProfileDialog() }

        // Dolby & Spatial Virtualizer Mode
        val modes = arrayOf("Standard Stereo (Downmix)", "Dolby 3D Headphone (Binaural HRTF)", "Dolby ProLogic Surround (Matrix)", "Cinema 3D Soundstage (Wide Room)")
        val openDolbyDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_dolby_surround)
                .setSingleChoiceItems(modes, PlayerHolder.dolbySpatialMode) { dialog, which ->
                    PlayerHolder.dolbySpatialMode = which
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeDolbySurround.setOnClickListener { openDolbyDialog() }
        findViewById<View>(R.id.rowDolbySurround).setOnClickListener { openDolbyDialog() }

        // 10-Band Equalizer Presets
        val openEqDialog = {
            val presets = PlayerHolder.equalizerPresets
            val currentIdx = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_equalizer)
                .setSingleChoiceItems(presets, currentIdx) { dialog, which ->
                    PlayerHolder.currentEqualizerPreset = which - 1
                    PlayerHolder.masterAudioProfile = 4 // Custom
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeEqualizer.setOnClickListener { openEqDialog() }
        findViewById<View>(R.id.rowEqualizer).setOnClickListener { openEqDialog() }

        // Dialogue Boost (Night Mode) Toggle
        btnToggleDialogueBoost.setOnClickListener {
            PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
            PlayerHolder.masterAudioProfile = 4 // Custom
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDialogueBoost).setOnClickListener {
            btnToggleDialogueBoost.performClick()
        }

        // Digital Passthrough Toggle
        btnTogglePassthrough.setOnClickListener {
            PlayerHolder.isDolbyPassthroughEnabled = !PlayerHolder.isDolbyPassthroughEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowDigitalPassthrough).setOnClickListener {
            btnTogglePassthrough.performClick()
        }

        // Audio Output Engine Dialog
        val engines = arrayOf("AudioTrack (Standard)", "OpenSL ES (Low Latency)", "AAudio (Modern NDK)")
        val openEngineDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_audio_output)
                .setSingleChoiceItems(engines, PlayerHolder.audioOutputEngine) { dialog, which ->
                    PlayerHolder.audioOutputEngine = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAudioOutput.setOnClickListener { openEngineDialog() }
        findViewById<View>(R.id.rowAudioOutput).setOnClickListener { openEngineDialog() }

        btnToggleHeadsetPause.setOnClickListener {
            PlayerHolder.isHeadsetPauseEnabled = !PlayerHolder.isHeadsetPauseEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowHeadsetPause).setOnClickListener {
            btnToggleHeadsetPause.performClick()
        }

        btnToggleTimeStretch.setOnClickListener {
            PlayerHolder.isTimeStretchingEnabled = !PlayerHolder.isTimeStretchingEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowTimeStretching).setOnClickListener {
            btnToggleTimeStretch.performClick()
        }
    }

    // --- 3. Subtitle Settings Handlers ---
    private fun setupSubtitleSettings() {
        btnToggleSubAutoload.setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubAutoload).setOnClickListener {
            btnToggleSubAutoload.performClick()
        }

        val sizeLabels = arrayOf("Very Small (12sp)", "Small (14sp)", "Normal (18sp)", "Large (24sp)", "Huge (32sp)")
        val sizeValues = arrayOf("12", "14", "18", "24", "32")
        val openSizeDialog = {
            val currentIdx = sizeValues.indexOf(PlayerHolder.subFontSize).coerceAtLeast(2)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_sub_size)
                .setSingleChoiceItems(sizeLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontSize = sizeValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubSize.setOnClickListener { openSizeDialog() }
        findViewById<View>(R.id.rowSubSize).setOnClickListener { openSizeDialog() }

        val colorLabels = arrayOf("White", "Yellow", "Cyan", "Green")
        val colorValues = arrayOf("16777215", "16776960", "65535", "65280")
        val openColorDialog = {
            val currentIdx = colorValues.indexOf(PlayerHolder.subFontColor).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_sub_color)
                .setSingleChoiceItems(colorLabels, currentIdx) { dialog, which ->
                    PlayerHolder.subFontColor = colorValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubColor.setOnClickListener { openColorDialog() }
        findViewById<View>(R.id.rowSubColor).setOnClickListener { openColorDialog() }

        val bgLabels = arrayOf("Transparent / None", "Translucent Box", "Solid Black Box")
        val openBgDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_sub_background)
                .setSingleChoiceItems(bgLabels, PlayerHolder.subBackgroundStyle) { dialog, which ->
                    PlayerHolder.subBackgroundStyle = which
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubBackground.setOnClickListener { openBgDialog() }
        findViewById<View>(R.id.rowSubBackground).setOnClickListener { openBgDialog() }

        btnToggleSubStyle.setOnClickListener {
            PlayerHolder.subFontStyle = if (PlayerHolder.subFontStyle == 1) 0 else 1
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowSubStyle).setOnClickListener {
            btnToggleSubStyle.performClick()
        }

        val encodings = arrayOf("UTF-8 (Default)", "Windows-1252 (Western)", "ISO-8859-1 (Latin)", "GBK (Chinese)", "Shift-JIS (Japanese)")
        val encValues = arrayOf("UTF-8", "WINDOWS-1252", "ISO-8859-1", "GBK", "SHIFT-JIS")
        val openEncDialog = {
            val currentIdx = encValues.indexOf(PlayerHolder.subEncoding).coerceAtLeast(0)
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_sub_encoding)
                .setSingleChoiceItems(encodings, currentIdx) { dialog, which ->
                    PlayerHolder.subEncoding = encValues[which]
                    PlayerHolder.savePreferences(this)
                    updateSettingsUI()
                    dialog.dismiss()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeSubEncoding.setOnClickListener { openEncDialog() }
        findViewById<View>(R.id.rowSubEncoding).setOnClickListener { openEncDialog() }
    }

    // --- 4. Controls & Gestures Handlers ---
    private fun setupGestureSettings() {
        btnToggleGestureVolume.setOnClickListener {
            PlayerHolder.isVolumeGestureEnabled = !PlayerHolder.isVolumeGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureVolume).setOnClickListener { btnToggleGestureVolume.performClick() }

        btnToggleGestureBrightness.setOnClickListener {
            PlayerHolder.isBrightnessGestureEnabled = !PlayerHolder.isBrightnessGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureBrightness).setOnClickListener { btnToggleGestureBrightness.performClick() }

        btnToggleGestureSeek.setOnClickListener {
            PlayerHolder.isSeekGestureEnabled = !PlayerHolder.isSeekGestureEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowGestureSeek).setOnClickListener { btnToggleGestureSeek.performClick() }

        btnToggleFastSeek.setOnClickListener {
            PlayerHolder.isFastSeekEnabled = !PlayerHolder.isFastSeekEnabled
            PlayerHolder.savePreferences(this)
            updateSettingsUI()
        }
        findViewById<View>(R.id.rowFastSeek).setOnClickListener { btnToggleFastSeek.performClick() }
    }

    // --- 5. Interface & Advanced Handlers ---
    private fun setupInterfaceAndAdvancedSettings() {
        val themes = arrayOf("Pure Black OLED (Default)", "Dark Charcoal", getString(R.string.theme_monochrome))
        val openThemeDialog = {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_app_theme)
                .setSingleChoiceItems(themes, PlayerHolder.appThemeMode) { dialog, which ->
                    if (PlayerHolder.appThemeMode != which) {
                        PlayerHolder.appThemeMode = which
                        PlayerHolder.savePreferences(this)
                        dialog.dismiss()
                        applyThemeUI()
                        recreate()
                    } else {
                        dialog.dismiss()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        btnChangeAppTheme.setOnClickListener { openThemeDialog() }
        findViewById<View>(R.id.rowAppTheme).setOnClickListener { openThemeDialog() }

        btnClearResume.setOnClickListener {
            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
            prefs.edit().clear().apply()
            Toast.makeText(this, "Playback history cleared", Toast.LENGTH_SHORT).show()
        }
        findViewById<View>(R.id.rowClearResume).setOnClickListener { btnClearResume.performClick() }

        btnResetSettings.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle(R.string.pref_reset_settings)
                .setMessage("Restore all player settings to default values?")
                .setPositiveButton("Reset") { _, _ ->
                    PlayerHolder.resetPreferences(this)
                    updateSettingsUI()
                    Toast.makeText(this, "Settings restored to defaults", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        findViewById<View>(R.id.rowResetSettings).setOnClickListener { btnResetSettings.performClick() }
    }

    private fun applyHighRefreshRate() {
        if (!PlayerHolder.isHighRefreshRateEnabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val modes = display?.supportedModes ?: emptyArray()
                val currentMode = display?.mode
                val targetMode = modes.filter {
                    currentMode == null || (it.physicalWidth == currentMode.physicalWidth && it.physicalHeight == currentMode.physicalHeight)
                }.maxByOrNull { it.refreshRate } ?: modes.maxByOrNull { it.refreshRate }

                targetMode?.let { mode ->
                    val params = window.attributes
                    params.preferredDisplayModeId = mode.modeId
                    window.attributes = params
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun updateToggleButton(btn: Button, isEnabled: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isEnabled) "ON" else "OFF"
        btn.setTextColor(if (isEnabled) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isEnabled) primaryColor else offStrokeColor)
    }

    private fun updateSubStyleButton(btn: Button, isBold: Boolean) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        val offStrokeColor = Color.parseColor("#333333")
        btn.text = if (isBold) "BOLD" else "REG"
        btn.setTextColor(if (isBold) primaryColor else secondaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(if (isBold) primaryColor else offStrokeColor)
    }

    private fun styleActionButton(btn: Button) {
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        btn.setTextColor(primaryColor)
        (btn as? com.google.android.material.button.MaterialButton)?.strokeColor =
            ColorStateList.valueOf(primaryColor)
    }

    private fun applyThemeUI() {
        val isMono = PlayerHolder.isMonochrome()
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()

        // 1. Bottom Navigation
        val navTint = if (isMono) {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint_mono)
        } else {
            ContextCompat.getColorStateList(this, R.color.nav_item_tint)
        }
        bottomNav.itemIconTintList = navTint
        bottomNav.itemTextColor = navTint

        // 2. Floating Action Button (FAB)
        fabPlay.backgroundTintList = ColorStateList.valueOf(PlayerHolder.getFabBgColorInt())
        fabPlay.setColorFilter(PlayerHolder.getFabIconColorInt())

        // 3. Top Tabs (VIDEOS / FOLDERS)
        if (isFolderViewActive) {
            btnViewFolders.setTextColor(primaryColor)
            btnViewAllVideos.setTextColor(secondaryColor)
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)
        }

        // 4. Search Bar
        val layoutSearch = findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.layoutSearch)
        layoutSearch?.boxStrokeColor = primaryColor
        layoutSearch?.hintTextColor = ColorStateList.valueOf(primaryColor)

        // 5. Notch Dynamic Island Player
        btnNotchPlayPause.setColorFilter(primaryColor)
        btnNotchOpen.setColorFilter(primaryColor)
        findViewById<ImageView>(R.id.ivNotchIcon)?.setColorFilter(primaryColor)
        sbNotch.progressTintList = ColorStateList.valueOf(primaryColor)
        sbNotch.thumbTintList = ColorStateList.valueOf(primaryColor)
        val notchStroke = if (isMono) Color.parseColor("#2E2E2E") else Color.parseColor("#2E3440")
        cardNotchPlayer.strokeColor = notchStroke

        // 6. Section Headers & App Name
        findViewById<TextView>(R.id.tvCatVideo)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatAudio)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatSubtitles)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatGestures)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatInterface)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatAdvanced)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvCatAbout)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvAboutAppName)?.setTextColor(primaryColor)
        findViewById<TextView>(R.id.tvMasterAudioTitle)?.setTextColor(primaryColor)
        tvVideoColorStatus.setTextColor(primaryColor)

        // 7. Browse Buttons
        btnBrowseVideo.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseVideo.setTextColor(if (isMono) Color.BLACK else Color.WHITE)
        btnBrowseAudio.backgroundTintList = ColorStateList.valueOf(primaryColor)
        btnBrowseAudio.setTextColor(if (isMono) Color.BLACK else Color.WHITE)

        // 8. Action Buttons ("Change", "Clear", "Reset")
        val actionButtons = listOf(
            btnChangeHw,
            btnChangeOrientation,
            btnChangeVideoColor,
            btnChangeMasterProfile,
            btnChangeDolbySurround,
            btnChangeEqualizer,
            btnChangeAudioOutput,
            btnChangeBgPip,
            btnChangeResumeMode,
            btnChangeDoubleTap,
            btnChangeAspectRatio,
            btnChangeSubSize,
            btnChangeSubColor,
            btnChangeSubBackground,
            btnChangeSubEncoding,
            btnChangeAppTheme,
            btnClearResume,
            btnResetSettings
        )
        for (btn in actionButtons) {
            styleActionButton(btn)
        }

        // 9. Update Settings Toggle Buttons
        updateSettingsUI()

        // 10. Notify media adapters so list items update their colors
        videoAdapter?.notifyDataSetChanged()
        audioAdapter?.notifyDataSetChanged()
        folderVideoAdapter?.notifyDataSetChanged()
        folderAdapter?.notifyDataSetChanged()
    }

    private fun updateSettingsUI() {
        // Video UI
        updateToggleButton(btnToggleHighRefreshRate, PlayerHolder.isHighRefreshRateEnabled)
        tvHighRefreshRateStatus.text = if (PlayerHolder.isHighRefreshRateEnabled) "Enabled (Auto 120Hz / High Refresh Rate)" else "Disabled (Standard 60Hz)"

        tvDefaultOrientationStatus.text = when (PlayerHolder.defaultOrientation) {
            0 -> "Auto Sensor (Free Rotation)"
            2 -> "Portrait (Vertical)"
            else -> "Direct Landscape (Recommended)"
        }
        tvVideoColorStatus.text = when (PlayerHolder.videoColorProfile) {
            0 -> "Standard / Natural (Original)"
            1 -> "Vivid / AMOLED Boost (Recommended)"
            2 -> "Cinema / HDR Effect"
            3 -> "Sharp & Crisp Studio"
            else -> "Custom Color Tuning"
        }

        updateToggleButton(btnToggleWideColor, PlayerHolder.isWideColorGamutEnabled)
        tvWideColorStatus.text = if (PlayerHolder.isWideColorGamutEnabled) "Enabled (10-bit dynamic colors)" else "Disabled (Standard sRGB)"

        updateToggleButton(btnToggleDeblocking, PlayerHolder.isDeblockingFilterEnabled)
        tvDeblockingStatus.text = if (PlayerHolder.isDeblockingFilterEnabled) "Enabled (Crisp gradients & deblocking)" else "Disabled"

        tvHwDecodeStatus.text = when (PlayerHolder.hwAccelerationMode) {
            0 -> "Disabled (Software FFmpeg)"
            2 -> "Decoding Only"
            3 -> "Full Acceleration"
            else -> "Automatic (Recommended)"
        }
        tvBgPipStatus.text = when (PlayerHolder.backgroundPipMode) {
            0 -> "Stop Playback"
            2 -> "Picture-in-Picture (PiP)"
            else -> "Play in Background"
        }
        tvResumeModeStatus.text = when (PlayerHolder.resumeMode) {
            0 -> "Never (Always start over)"
            2 -> "Always resume automatically"
            else -> "Ask confirmation"
        }
        tvDoubleTapStatus.text = "${PlayerHolder.doubleTapSeekSeconds} seconds"
        tvAspectRatioStatus.text = when (PlayerHolder.defaultAspectRatio) {
            1 -> "Fit Screen"
            2 -> "Fill Screen"
            3 -> "16:9"
            4 -> "4:3"
            else -> "Best Fit"
        }

        updateToggleButton(btnToggleAudioBoost, PlayerHolder.isAudioBoostEnabled)
        tvAudioBoostStatus.text = if (PlayerHolder.isAudioBoostEnabled) "Enabled (Up to 200%)" else "Disabled (Standard 100%)"

        // Integrated Audio Suite UI
        tvMasterProfileStatus.text = PlayerHolder.masterProfileNames[PlayerHolder.masterAudioProfile.coerceIn(0, 4)]
        tvDolbySurroundStatus.text = when (PlayerHolder.dolbySpatialMode) {
            1 -> "Dolby 3D Headphone (Binaural HRTF)"
            2 -> "Dolby ProLogic Surround (Matrix)"
            3 -> "Cinema 3D Soundstage (Wide Room)"
            else -> "Standard Stereo (Downmix)"
        }
        val eqIdx = PlayerHolder.currentEqualizerPreset
        tvEqualizerStatus.text = if (eqIdx >= 0 && eqIdx < PlayerHolder.equalizerPresets.size - 1) {
            PlayerHolder.equalizerPresets[eqIdx + 1]
        } else {
            "Flat (Off)"
        }

        updateToggleButton(btnToggleDialogueBoost, PlayerHolder.isDialogueBoostEnabled)
        tvDialogueBoostStatus.text = if (PlayerHolder.isDialogueBoostEnabled) "Dynamic range compression: Clear speech (Enabled)" else "Disabled"

        updateToggleButton(btnTogglePassthrough, PlayerHolder.isDolbyPassthroughEnabled)
        tvDigitalPassthroughStatus.text = if (PlayerHolder.isDolbyPassthroughEnabled) "HDMI / S/PDIF Passthrough (Active)" else "Disabled"

        tvAudioOutputStatus.text = when (PlayerHolder.audioOutputEngine) {
            1 -> "OpenSL ES (Low Latency)"
            2 -> "AAudio (Modern NDK)"
            else -> "AudioTrack (Standard)"
        }

        updateToggleButton(btnToggleHeadsetPause, PlayerHolder.isHeadsetPauseEnabled)
        tvHeadsetPauseStatus.text = if (PlayerHolder.isHeadsetPauseEnabled) "Auto-pause when unplugged (Enabled)" else "Disabled"

        updateToggleButton(btnToggleTimeStretch, PlayerHolder.isTimeStretchingEnabled)
        tvTimeStretchStatus.text = if (PlayerHolder.isTimeStretchingEnabled) "Pitch lock active (Enabled)" else "Disabled"

        // Subtitle UI
        updateToggleButton(btnToggleSubAutoload, PlayerHolder.isSubAutoloadEnabled)

        tvSubSizeStatus.text = when (PlayerHolder.subFontSize) {
            "12" -> "Very Small (12sp)"
            "14" -> "Small (14sp)"
            "24" -> "Large (24sp)"
            "32" -> "Huge (32sp)"
            else -> "Normal (18sp)"
        }
        tvSubColorStatus.text = when (PlayerHolder.subFontColor) {
            "16776960" -> "Yellow"
            "65535" -> "Cyan"
            "65280" -> "Green"
            else -> "White"
        }
        tvSubBackgroundStatus.text = when (PlayerHolder.subBackgroundStyle) {
            1 -> "Translucent Box"
            2 -> "Solid Black Box"
            else -> "Transparent / None"
        }

        updateSubStyleButton(btnToggleSubStyle, PlayerHolder.subFontStyle == 1)
        tvSubStyleStatus.text = if (PlayerHolder.subFontStyle == 1) "Bold font weight" else "Normal font weight"

        tvSubEncodingStatus.text = PlayerHolder.subEncoding

        // Gestures UI
        updateToggleButton(btnToggleGestureVolume, PlayerHolder.isVolumeGestureEnabled)
        tvGestureVolumeStatus.text = if (PlayerHolder.isVolumeGestureEnabled) "Right side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureBrightness, PlayerHolder.isBrightnessGestureEnabled)
        tvGestureBrightnessStatus.text = if (PlayerHolder.isBrightnessGestureEnabled) "Left side swipe (Enabled)" else "Disabled"

        updateToggleButton(btnToggleGestureSeek, PlayerHolder.isSeekGestureEnabled)
        tvGestureSeekStatus.text = if (PlayerHolder.isSeekGestureEnabled) "Horizontal drag (Enabled)" else "Disabled"

        updateToggleButton(btnToggleFastSeek, PlayerHolder.isFastSeekEnabled)
        tvFastSeekStatus.text = if (PlayerHolder.isFastSeekEnabled) "Seek to nearest keyframe (Enabled)" else "Exact frame seek (Disabled)"

        // Interface UI
        tvAppThemeStatus.text = when (PlayerHolder.appThemeMode) {
            PlayerHolder.THEME_MONOCHROME -> getString(R.string.theme_monochrome)
            PlayerHolder.THEME_CHARCOAL -> "Dark Charcoal"
            else -> "Pure Black OLED (Default)"
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = ArrayList<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            storagePermissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else {
            loadMediaFiles()
        }
    }

    private fun switchVideoViewMode(folders: Boolean) {
        isFolderViewActive = folders
        val primaryColor = PlayerHolder.getPrimaryColor(this)
        val secondaryColor = PlayerHolder.getSecondaryColorInt()
        if (folders) {
            btnViewAllVideos.setTextColor(secondaryColor)
            btnViewFolders.setTextColor(primaryColor)

            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.VISIBLE
            updateFoldersData()
        } else {
            btnViewAllVideos.setTextColor(primaryColor)
            btnViewFolders.setTextColor(secondaryColor)

            rvVideos.visibility = View.VISIBLE
            layoutFoldersContainer.visibility = View.GONE
            closeFolderDetail()
        }
    }

    private fun closeFolderDetail() {
        currentSelectedFolder = null
        layoutFolderDetailHeader.visibility = View.GONE
        rvFolderVideos.visibility = View.GONE
        rvFolders.visibility = View.VISIBLE
    }

    private fun updateFoldersData() {
        val folderMap = linkedMapOf<String, MediaFolder>()
        for (video in allVideos) {
            val key = if (video.folderPath.isNotEmpty()) video.folderPath else video.folderName
            val folder = folderMap.getOrPut(key) {
                MediaFolder(video.folderName, video.folderPath)
            }
            folder.videos.add(video)
        }
        allFolders = folderMap.values.toList()

        btnViewFolders.text = "FOLDERS"
        btnViewAllVideos.text = "VIDEOS"

        if (folderAdapter == null) {
            folderAdapter = FolderAdapter(allFolders) { folder ->
                openFolderDetail(folder)
            }
            rvFolders.adapter = folderAdapter
        } else {
            folderAdapter?.updateFolders(allFolders)
        }
    }

    private fun openFolderDetail(folder: MediaFolder) {
        currentSelectedFolder = folder
        rvFolders.visibility = View.GONE
        layoutFolderDetailHeader.visibility = View.VISIBLE
        rvFolderVideos.visibility = View.VISIBLE

        tvFolderHeaderTitle.text = folder.folderName
        tvFolderHeaderSubtitle.text = "${folder.count} videos • ${folder.getFormattedSize()}"

        folderVideoAdapter = MediaAdapter(folder.videos) { item, _ ->
            try {
                openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        }
        rvFolderVideos.adapter = folderVideoAdapter
    }

    private fun loadMediaFiles() {
        allVideos = MediaScanner.scanVideos(this)
        if (allVideos.isNotEmpty()) {
            layoutEmptyVideo.visibility = View.GONE
            if (videoAdapter == null) {
                videoAdapter = MediaAdapter(allVideos) { item, _ ->
                    try {
                        openPlayer(item.uri, item.title, isVideo = true, path = item.filePath)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
                rvVideos.adapter = videoAdapter
            } else {
                videoAdapter?.updateList(allVideos)
            }
            updateFoldersData()
            if (isFolderViewActive) {
                rvVideos.visibility = View.GONE
                layoutFoldersContainer.visibility = View.VISIBLE
            } else {
                rvVideos.visibility = View.VISIBLE
                layoutFoldersContainer.visibility = View.GONE
            }
        } else {
            rvVideos.visibility = View.GONE
            layoutFoldersContainer.visibility = View.GONE
            layoutEmptyVideo.visibility = View.VISIBLE
        }

        allAudio = MediaScanner.scanAudio(this)
        if (allAudio.isNotEmpty()) {
            rvAudio.visibility = View.VISIBLE
            layoutEmptyAudio.visibility = View.GONE
            if (audioAdapter == null) {
                audioAdapter = MediaAdapter(allAudio) { item, pos ->
                    try {
                        PlayerHolder.setPlaylistAndPlay(this, allAudio, pos)
                        audioAdapter?.setPlayingUri(item.uri)
                        updateNotchPlayerUI()
                        openPlayer(item.uri, item.title, isVideo = false, path = item.filePath, artist = item.artist)
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                }
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
                rvAudio.adapter = audioAdapter
            } else {
                audioAdapter?.updateList(allAudio)
                audioAdapter?.setPlayingUri(PlayerHolder.currentUri)
            }
        } else {
            rvAudio.visibility = View.GONE
            layoutEmptyAudio.visibility = View.VISIBLE
        }
    }

    private fun openPlayer(uri: Uri, title: String, isVideo: Boolean = true, path: String? = null, artist: String? = null) {
        PlayerHolder.isAudioOnly = !isVideo
        PlayerHolder.currentArtist = artist ?: "Unknown artist"
        val intent = Intent(this, PlayerActivity::class.java).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra("media_uri", uri.toString())
            putExtra("media_title", title)
            putExtra("media_artist", PlayerHolder.currentArtist)
            putExtra("is_video", isVideo)
            if (!path.isNullOrEmpty()) {
                putExtra("media_path", path)
            }
        }
        startActivity(intent)
    }
}
