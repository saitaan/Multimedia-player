@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.cleanplayer.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.addCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.media3.common.C
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.util.Locale
import kotlin.math.abs
import android.graphics.Color
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.content.ContentUris
import android.provider.MediaStore
import android.graphics.Canvas
import android.view.TextureView
import android.media.MediaScannerConnection
import android.os.Environment
import java.io.File
import java.io.FileOutputStream

class PlayerActivity : AppCompatActivity() {
    companion object {
        init {
            androidx.appcompat.app.AppCompatDelegate.setCompatVectorFromResourcesEnabled(true)
        }
    }


    private lateinit var videoLayout: PlayerView
    private lateinit var layoutAudioPlaceholder: LinearLayout
    private lateinit var layoutGestureOverlay: LinearLayout
    private lateinit var layoutSeekOverlay: LinearLayout
    private lateinit var ivGestureIcon: ImageView
    private lateinit var tvGestureValue: TextView
    private lateinit var tvSeekOffset: TextView
    private lateinit var tvSeekTarget: TextView
    private lateinit var tvMediaTitle: TextView
    private lateinit var tvAudioSubtext: TextView
    private lateinit var tvPlayerTitle: TextView
    private lateinit var tvDolbyBadge: TextView
    private lateinit var tvTrackQueuePosition: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnBack: ImageButton
    private lateinit var btnAudioTrack: ImageButton
    private lateinit var btnSubtitles: ImageButton
    private lateinit var btnLockScreen: ImageButton
    private lateinit var btnFloatingUnlock: ImageButton
    private lateinit var btnScreenRotation: ImageButton
    private lateinit var btnRewind10: ImageButton
    private lateinit var btnForward10: ImageButton
    private lateinit var btnPrevTrack: ImageButton
    private lateinit var btnNextTrack: ImageButton
    private lateinit var btnShuffle: ImageButton
    private lateinit var btnRepeat: ImageButton
    private lateinit var btnMediaQueue: ImageButton
    private lateinit var btnDecoderToggle: TextView
    private lateinit var btnBgPlayToggle: Button
    private lateinit var btnAspectRatio: ImageButton
    private lateinit var btnPlaybackSpeed: Button
    private lateinit var btnPip: ImageButton
    private lateinit var btnMoreOptions: ImageButton
    private lateinit var btnAudioEq: ImageButton
    private lateinit var btnFavorite: ImageButton
    private lateinit var cardPlayPause: com.google.android.material.card.MaterialCardView
    private lateinit var layoutSecondaryControls: LinearLayout
    private lateinit var seekBar: SeekBar
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvTotalTime: TextView
    private lateinit var topBar: View
    private lateinit var bottomBar: LinearLayout

    private lateinit var audioManager: AudioManager
    private var maxVolume: Int = 15
    private var isVideoMedia: Boolean = true
    private var isScreenLocked: Boolean = false
    private var isUserSeeking: Boolean = false
    private var seekStartPlaybackPosition: Long = 0L
    private var currentMediaIdentifier: String = ""

    // Screen rotation: 0=Sensor, 1=Landscape, 2=Portrait
    private var rotationState: Int = 0

    // Touch gesture tracking
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var isGestureActive = false
    private var initialVolume = 0
    private var currentBoostPercent = 100
    private var initialBrightness = 0f
    private var activeGestureType = GestureType.NONE

    private enum class GestureType {
        NONE, VOLUME, BRIGHTNESS, SEEK
    }

    private val handler = Handler(Looper.getMainLooper())

    private val hideControlsRunnable = Runnable {
        if (!isScreenLocked && isVideoMedia) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
        }
    }

    private val hideGestureOverlayRunnable = Runnable {
        layoutGestureOverlay.visibility = View.GONE
        layoutSeekOverlay.visibility = View.GONE
    }

    private val hideFloatingUnlockRunnable = Runnable {
        btnFloatingUnlock.visibility = View.GONE
    }
    private var lastTapTime: Long = 0L
    private var lastTapX: Float = 0f
    private var lastTapY: Float = 0f
    private var isDoubleTapDetected: Boolean = false

    private val singleTapRunnable = Runnable {
        if (!isDoubleTapDetected && isVideoMedia) {
            if (topBar.visibility == View.VISIBLE) {
                topBar.visibility = View.GONE
                bottomBar.visibility = View.GONE
            } else {
                topBar.visibility = View.VISIBLE
                bottomBar.visibility = View.VISIBLE
                resetControlsTimer()
            }
        }
    }

    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            PlayerHolder.mediaPlayer?.let { player ->
                if (!isUserSeeking && player.isPlaying) {
                    val current = player.currentPosition
                    val total = player.duration
                    if (total > 0) {
                        seekBar.max = total.toInt()
                        seekBar.progress = current.toInt()
                        tvCurrentTime.text = formatTime(current)
                        val rem = (total - current).coerceAtLeast(0L)
                        tvTotalTime.text = "- " + formatTime(rem)

                        if (current > 5000L && total - current > 10000L) {
                            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
                            prefs.edit().putLong(currentMediaIdentifier, current).apply()
                        }
                    }
                    if (PlayerHolder.abRepeatA >= 0 && PlayerHolder.abRepeatB > PlayerHolder.abRepeatA) {
                        if (current >= PlayerHolder.abRepeatB) {
                            player.seekTo(PlayerHolder.abRepeatA)
                        }
                    }
                }
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val sleepTimerRunnable = Runnable {
        PlayerHolder.mediaPlayer?.pause()
        finish()
    }

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY && PlayerHolder.isHeadsetPauseEnabled) {
                PlayerHolder.mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        player.pause()
                        btnPlayPause.setImageResource(R.drawable.ic_play_player)
                    }
                }
            }
        }
    }

    private val subtitlePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { subUri ->
            try {
                contentResolver.takePersistableUriPermission(
                    subUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {}

            PlayerHolder.mediaPlayer?.let { player ->
                val pos = player.currentPosition
                val isPlaying = player.isPlaying
                val subConfig = ExoMediaItem.SubtitleConfiguration.Builder(subUri)
                    .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
                val currentMediaItem = player.currentMediaItem ?: return@let
                val updatedItem = currentMediaItem.buildUpon()
                    .setSubtitleConfigurations(listOf(subConfig))
                    .build()
                player.setMediaItem(updatedItem, pos)
                player.prepare()
                if (isPlaying) player.play()
                Toast.makeText(this, "Subtitle loaded", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val requestNotificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        PlayerHolder.loadPreferences(this)
        val isVideo = intent?.getBooleanExtra("is_video", true) ?: true
        if (!isVideo && PlayerHolder.isMonochrome()) {
            setTheme(R.style.Theme_Multimedia_Player_Monochrome)
        } else {
            setTheme(R.style.Theme_Multimedia_Player)
        }
        super.onCreate(savedInstanceState)
        applyHighRefreshRate()
        enableImmersiveNotchMode()

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && PlayerHolder.isWideColorGamutEnabled) {
            try {
                window.colorMode = ActivityInfo.COLOR_MODE_WIDE_COLOR_GAMUT
            } catch (e: Exception) {}
        }

        setContentView(R.layout.activity_player)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

        initViews()
        isVideoMedia = intent?.getBooleanExtra("is_video", true) ?: true
        applyPlayerUITheme()
        if (!isVideoMedia) {
            videoLayout.visibility = View.GONE
            layoutAudioPlaceholder.visibility = View.VISIBLE
            loadAudioMetadataAndAlbumArt()
            topBar.visibility = View.VISIBLE
            bottomBar.visibility = View.VISIBLE

            findViewById<View>(R.id.layoutVideoControls)?.visibility = View.GONE
            findViewById<View>(R.id.layoutAudioControls)?.visibility = View.VISIBLE

            btnLockScreen.visibility = View.GONE
            btnDecoderToggle.visibility = View.GONE
            btnAudioEq.visibility = View.VISIBLE
            btnFavorite.visibility = View.VISIBLE
            btnRepeat.visibility = View.VISIBLE
            btnMediaQueue.visibility = View.VISIBLE
            updateDolbyBadge()
            updateFavoriteUI()

            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            rotationState = 2
        } else {
            videoLayout.visibility = View.VISIBLE
            layoutAudioPlaceholder.visibility = View.GONE
            findViewById<View>(R.id.layoutVideoControls)?.visibility = View.VISIBLE
            findViewById<View>(R.id.layoutAudioControls)?.visibility = View.GONE

            btnLockScreen.visibility = View.VISIBLE
            btnDecoderToggle.visibility = View.VISIBLE
            btnAudioEq.visibility = View.GONE
            btnFavorite.visibility = View.GONE
            updateDolbyBadge()
            btnAudioEq.visibility = View.GONE
            btnFavorite.visibility = View.GONE
            btnShuffle.visibility = View.GONE
            btnRepeat.visibility = View.GONE
            btnMediaQueue.visibility = View.GONE
            tvTrackQueuePosition.visibility = View.GONE
            btnRewind10.visibility = View.VISIBLE
            btnForward10.visibility = View.VISIBLE
            layoutSecondaryControls.visibility = View.VISIBLE
            btnShuffle.visibility = View.GONE
            btnMediaQueue.visibility = View.GONE
            tvTrackQueuePosition.visibility = View.GONE
            // Direct Landscape Mode for Video Playback
            when (PlayerHolder.defaultOrientation) {
                0 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    rotationState = 0
                }
                2 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    rotationState = 2
                }
                else -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    rotationState = 1
                }
            }
        }

        checkNotificationPermission()
        setupListeners()
        updateBgPlayButtonState()
        updateDecoderButtonLabel()
        updatePlaybackSpeedLabel()

        onBackPressedDispatcher.addCallback(this) {
            handleBackAction()
        }

        val mediaUri = intent?.data ?: intent?.getStringExtra("media_uri")?.let { Uri.parse(it) }
        val rawTitle = intent?.getStringExtra("media_title")
        val mediaPath = intent?.getStringExtra("media_path")
        val title = when {
            !rawTitle.isNullOrBlank() && !rawTitle.all { it.isDigit() } && rawTitle != "Media Track" -> rawTitle
            !PlayerHolder.currentTitle.isNullOrBlank() && !PlayerHolder.currentTitle.all { it.isDigit() } && PlayerHolder.currentTitle != "Media Track" -> PlayerHolder.currentTitle
            mediaUri != null -> PlayerHolder.resolveMediaTitle(this, mediaUri, mediaPath)
            else -> "Media Track"
        }
        PlayerHolder.currentTitle = title
        val artist = intent?.getStringExtra("media_artist") ?: "Unknown artist"
        PlayerHolder.currentArtist = artist

        if (mediaUri != null) {
            currentMediaIdentifier = mediaPath ?: mediaUri.toString()
            if (!isVideoMedia && PlayerHolder.mediaPlayer != null && (PlayerHolder.currentUri == mediaUri || PlayerHolder.mediaPlayer?.playbackState != Player.STATE_IDLE)) {
                // Audio track already loaded / active in PlayerHolder!
                PlayerHolder.mediaPlayer?.let { player ->
                    updateTrackUI()
                    setupPlayerEventListeners(player)
                    handler.post(updateProgressRunnable)
                    resetControlsTimer()
                }
            } else {
                checkResumeAndPlay(mediaUri, mediaPath, title)
            }
        } else if (!isVideoMedia && PlayerHolder.mediaPlayer != null) {
            PlayerHolder.mediaPlayer?.let { player ->
                updateTrackUI()
                setupPlayerEventListeners(player)
                handler.post(updateProgressRunnable)
                resetControlsTimer()
            }
        } else {
            finish()
        }
    }

    private fun enableImmersiveNotchMode() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false)
                window.insetsController?.let { controller ->
                    controller.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                    controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            } else {
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            enableImmersiveNotchMode()
        }
    }

    private fun applyHighRefreshRate() {
        if (!PlayerHolder.isHighRefreshRateEnabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val modes = display?.supportedModes ?: emptyArray()
                val currentMode = display?.mode
                val targetMode = modes.filter {
                    currentMode == null || (it.physicalWidth == currentMode.physicalWidth && it.physicalHeight == currentMode.physicalHeight)
                }.maxByOrNull { it.refreshRate } ?: modes.maxByOrNull { it.refreshRate }

                targetMode?.let { mode ->
                    val params = window.attributes
                    params.preferredDisplayModeId = mode.modeId
                    window.attributes = params
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun checkResumeAndPlay(uri: Uri, path: String?, title: String) {
        val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
        val savedTime = prefs.getLong(currentMediaIdentifier, 0L)

        if (savedTime > 10000L && PlayerHolder.resumeMode != 0) {
            if (PlayerHolder.resumeMode == 2) {
                playMedia(uri, path, savedTime, title)
            } else {
                AlertDialog.Builder(this)
                    .setTitle(R.string.resume_title)
                    .setMessage("${getString(R.string.resume_message)}\n${formatTime(savedTime)}")
                    .setPositiveButton(R.string.resume_btn) { _, _ ->
                        playMedia(uri, path, savedTime, title)
                    }
                    .setNegativeButton(R.string.restart_btn) { _, _ ->
                        prefs.edit().remove(currentMediaIdentifier).apply()
                        playMedia(uri, path, 0L, title)
                    }
                    .setCancelable(false)
                    .show()
            }
        } else {
            playMedia(uri, path, 0L, title)
        }
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent?): Boolean {
        if (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP) {
            val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (currentVol < maxVolume) {
                currentBoostPercent = 100
                PlayerHolder.setVolumeBoostGain(0)
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                val newVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                val pct = (newVol * 100) / maxVolume
                showGestureOverlay(
                    android.R.drawable.ic_lock_silent_mode_off,
                    "Volume: $pct%"
                )
            } else {
                // Boost above 100% up to 200%!
                currentBoostPercent = (currentBoostPercent + 10).coerceAtMost(200)
                val gainMb = (currentBoostPercent - 100) * 20
                PlayerHolder.setVolumeBoostGain(gainMb)
                PlayerHolder.mediaPlayer?.volume = (currentBoostPercent / 100f)
                showGestureOverlay(
                    android.R.drawable.ic_lock_silent_mode_off,
                    "Boost: ${currentBoostPercent}%"
                )
            }
            return true
        } else if (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (currentBoostPercent > 100) {
                currentBoostPercent = (currentBoostPercent - 10).coerceAtLeast(100)
                val gainMb = (currentBoostPercent - 100) * 20
                PlayerHolder.setVolumeBoostGain(gainMb)
                PlayerHolder.mediaPlayer?.volume = (currentBoostPercent / 100f)
                showGestureOverlay(
                    android.R.drawable.ic_lock_silent_mode_off,
                    if (currentBoostPercent > 100) "Boost: ${currentBoostPercent}%" else "Volume: 100%"
                )
                return true
            } else {
                currentBoostPercent = 100
                PlayerHolder.setVolumeBoostGain(0)
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                val newVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                val pct = (newVol * 100) / maxVolume
                showGestureOverlay(
                    android.R.drawable.ic_lock_silent_mode_off,
                    "Volume: $pct%"
                )
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStart() {
        super.onStart()
        try {
            val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(noisyReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(noisyReceiver, filter)
            }
        } catch (e: Exception) {}
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(noisyReceiver)
        } catch (e: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        PlayerHolder.onTrackChangedListener = {
            runOnUiThread { updateTrackUI() }
        }
        PlayerHolder.onPlaybackStateChangedListener = { isPlaying ->
            runOnUiThread {
                val resId = if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player
                btnPlayPause.setImageResource(resId)
                findViewById<ImageButton>(R.id.btnAudioPlayPause)?.setImageResource(resId)
                findViewById<AudioVisualizerView>(R.id.audioVisualizerView)?.setPlaying(isPlaying)
            }
        }
        PlayerHolder.mediaPlayer?.let { player ->
            if (isVideoMedia) {
                videoLayout.player = player
            }
            updateTrackUI()
        }
    }

    override fun onPause() {
        super.onPause()
        if (!isVideoMedia) {
            // Audio mode: keep playing continuously in foreground service!
            val isPlaying = PlayerHolder.mediaPlayer?.isPlaying == true
            MediaPlaybackService.start(this, tvMediaTitle.text.toString(), PlayerHolder.currentArtist, isPlaying)
            return
        }
        val isPlaying = PlayerHolder.mediaPlayer?.isPlaying == true
        if (isFinishing) {
            // Video mode when exiting/finishing: pause video immediately and stop background service!
            try {
                PlayerHolder.mediaPlayer?.pause()
                MediaPlaybackService.stop(this)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else if (PlayerHolder.isBackgroundPlayEnabled) {
            if (isPlaying) {
                MediaPlaybackService.start(this, tvMediaTitle.text.toString(), PlayerHolder.currentArtist, isPlaying = true)
            }
        } else if (!isInPictureInPictureMode) {
            PlayerHolder.mediaPlayer?.pause()
            btnPlayPause.setImageResource(R.drawable.ic_play_player)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isVideoMedia && PlayerHolder.backgroundPipMode == 2 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(android.app.PictureInPictureParams.Builder().build())
            } catch (e: Exception) {}
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            btnFloatingUnlock.visibility = View.GONE
        } else {
            topBar.visibility = View.VISIBLE
            bottomBar.visibility = View.VISIBLE
            resetControlsTimer()
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun setupListeners() {
        btnBack.setOnClickListener {
            handleBackAction()
        }

        btnPlayPause.setOnClickListener {
            PlayerHolder.mediaPlayer?.let { player ->
                if (player.isPlaying) {
                    player.pause()
                    btnPlayPause.setImageResource(R.drawable.ic_play_player)
                    if (!isVideoMedia) {
                        MediaPlaybackService.start(this, tvMediaTitle.text.toString(), PlayerHolder.currentArtist, isPlaying = false)
                    }
                } else {
                    player.play()
                    btnPlayPause.setImageResource(R.drawable.ic_pause_player)
                    if (!isVideoMedia) {
                        MediaPlaybackService.start(this, tvMediaTitle.text.toString(), PlayerHolder.currentArtist, isPlaying = true)
                    }
                }
            }
            resetControlsTimer()
        }

        btnAudioTrack.setOnClickListener {
            showAudioTrackSelectionDialog()
            resetControlsTimer()
        }

        
        btnSubtitles.setOnClickListener {
            showAudioSubtitlesDialog()
            resetControlsTimer()
        }

        btnRewind10.setOnClickListener {
            PlayerHolder.mediaPlayer?.let { player ->
                val seekMs = PlayerHolder.doubleTapSeekSeconds * 1000L
                val current = player.currentPosition
                val newTime = (current - seekMs).coerceAtLeast(0L)
                player.seekTo(newTime)
                seekBar.progress = newTime.toInt()
                tvCurrentTime.text = formatTime(newTime)
                showGestureOverlay(android.R.drawable.ic_media_rew, "-${seekMs / 1000}s")
            }
            resetControlsTimer()
        }

        btnForward10.setOnClickListener {
            PlayerHolder.mediaPlayer?.let { player ->
                val seekMs = PlayerHolder.doubleTapSeekSeconds * 1000L
                val current = player.currentPosition
                val duration = player.duration
                val newTime = if (duration > 0) {
                    (current + seekMs).coerceIn(0L, duration)
                } else {
                    (current + seekMs).coerceAtLeast(0L)
                }
                player.seekTo(newTime)
                seekBar.progress = newTime.toInt()
                tvCurrentTime.text = formatTime(newTime)
                showGestureOverlay(android.R.drawable.ic_media_ff, "+${seekMs / 1000}s")
            }
            resetControlsTimer()
        }

        btnPrevTrack.setOnClickListener {
            if (PlayerHolder.playPrevious(this)) {
                updateTrackUI()
            }
            resetControlsTimer()
        }

        btnNextTrack.setOnClickListener {
            if (PlayerHolder.playNext(this)) {
                updateTrackUI()
            } else {
                Toast.makeText(this, "End of queue", Toast.LENGTH_SHORT).show()
            }
            resetControlsTimer()
        }

        btnShuffle.setOnClickListener {
            val enabled = PlayerHolder.toggleShuffle()
            val shuffleActive = if (PlayerHolder.isMonochrome()) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
            val shuffleInactive = if (PlayerHolder.isMonochrome()) Color.parseColor("#8E8E93") else ContextCompat.getColor(this, R.color.theme_text_secondary)
            btnShuffle.setColorFilter(if (enabled) shuffleActive else shuffleInactive)
            Toast.makeText(this, if (enabled) "Shuffle: ON" else "Shuffle: OFF", Toast.LENGTH_SHORT).show()
            resetControlsTimer()
        }

        btnRepeat.setOnClickListener {
            val mode = PlayerHolder.toggleRepeatMode()
            updateRepeatButtonUI(mode)
            val text = when (mode) {
                1 -> "Repeat One"
                2 -> "Repeat All"
                else -> "Repeat: OFF"
            }
            Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
            resetControlsTimer()
        }

        btnMediaQueue.setOnClickListener {
            showAttractiveQueueDialog()
        }

        btnMediaQueue.setOnLongClickListener {
            showFavoritesDialog()
            true
        }

        btnLockScreen.setOnClickListener {
            isScreenLocked = true
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            btnFloatingUnlock.visibility = View.VISIBLE
            handler.removeCallbacks(hideFloatingUnlockRunnable)
            handler.postDelayed(hideFloatingUnlockRunnable, 3000)
        }

        btnFloatingUnlock.setOnClickListener {
            isScreenLocked = false
            btnFloatingUnlock.visibility = View.GONE
            topBar.visibility = View.VISIBLE
            bottomBar.visibility = View.VISIBLE
            resetControlsTimer()
        }

        btnScreenRotation.setOnClickListener {
            rotationState = (rotationState + 1) % 3
            when (rotationState) {
                0 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    showGestureOverlay(android.R.drawable.ic_menu_rotate, "Rotation: Auto")
                }
                1 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    showGestureOverlay(android.R.drawable.ic_menu_rotate, "Rotation: Landscape")
                }
                2 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    showGestureOverlay(android.R.drawable.ic_menu_rotate, "Rotation: Portrait")
                }
            }
            resetControlsTimer()
        }

        btnPlaybackSpeed.setOnClickListener {
            showPlaybackSpeedDialog()
            resetControlsTimer()
        }

        btnPip.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    enterPictureInPictureMode(android.app.PictureInPictureParams.Builder().build())
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        btnDecoderToggle.setOnClickListener {
            PlayerHolder.isHardwareDecoding = !PlayerHolder.isHardwareDecoding
            updateDecoderButtonLabel()
            val modeName = if (PlayerHolder.isHardwareDecoding) "Hardware (HW) Decoder" else "Software (SW) Decoder"
            Toast.makeText(this, "Switched to $modeName", Toast.LENGTH_SHORT).show()
            restartPlaybackWithCurrentState()
            resetControlsTimer()
        }

        btnBgPlayToggle.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            updateBgPlayButtonState()
            resetControlsTimer()
        }

        btnAspectRatio.setOnClickListener {
            val current = videoLayout.resizeMode
            val next = when (current) {
                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                AspectRatioFrameLayout.RESIZE_MODE_FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
            videoLayout.resizeMode = next
            val aspectName = when (next) { AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Fill"; AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Zoom"; AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH -> "16:9"; else -> "Fit Screen" }; Toast.makeText(this, "Aspect: " + aspectName, Toast.LENGTH_SHORT).show()
            resetControlsTimer()
        }

        btnMoreOptions.setOnClickListener {
            showOptionsMenu()
            resetControlsTimer()
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    tvCurrentTime.text = formatTime(progress.toLong())
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                isUserSeeking = true
                handler.removeCallbacks(hideControlsRunnable)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                isUserSeeking = false
                sb?.let {
                    PlayerHolder.mediaPlayer?.let { player ->
                        val duration = player.duration
                        val target = if (duration > 0) {
                            it.progress.toLong().coerceIn(0L, duration)
                        } else {
                            it.progress.toLong().coerceAtLeast(0L)
                        }
                        player.seekTo(target)
                        tvCurrentTime.text = formatTime(target)
                    }
                }
                resetControlsTimer()
            }
        })
    }


private fun showAudioSubtitlesDialog() {
        val player = PlayerHolder.mediaPlayer ?: return
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_audio_subtitles, null)
        dialog.setContentView(view)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setDimAmount(0.35f)
        }
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.setBackgroundColor(Color.TRANSPARENT)
            (bottomSheet?.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        }

        val layoutAudio = view.findViewById<LinearLayout>(R.id.layoutAudioTracks)
        val layoutSubtitles = view.findViewById<LinearLayout>(R.id.layoutSubtitleTracks)
        val currentTracks = player.currentTracks

        // --- 1. Populate Audio Tracks ---
        val audioGroups = mutableListOf<Tracks.Group>()
        val audioIndices = mutableListOf<Int>()
        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    audioGroups.add(group)
                    audioIndices.add(i)
                }
            }
        }

        // Disable audio option
        val isAudioDisabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_AUDIO)
        addTrackRow(layoutAudio, "Disable track", isAudioDisabled) {
            player.trackSelectionParameters = player.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
                .build()
            dialog.dismiss()
        }

        for (i in audioGroups.indices) {
            val group = audioGroups[i]
            val trackIdx = audioIndices[i]
            val format = group.getTrackFormat(trackIdx)
            val lang = format.language?.uppercase(Locale.US) ?: ""
            val rawLabel = format.label ?: if (lang.isNotEmpty()) "[$lang]" else "Audio Track ${i + 1}"
            val channelStr = when (format.channelCount) {
                6 -> " [5.1]"
                8 -> " [7.1]"
                else -> ""
            }
            val title = "$rawLabel$channelStr"
            val isSelected = !isAudioDisabled && group.isTrackSelected(trackIdx)

            addTrackRow(layoutAudio, title, isSelected) {
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, trackIdx))
                    .build()
                updateDolbyBadge()
                dialog.dismiss()
            }
        }

        // --- 2. Populate Subtitle Tracks ---
        val subGroups = mutableListOf<Tracks.Group>()
        val subIndices = mutableListOf<Int>()
        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    subGroups.add(group)
                    subIndices.add(i)
                }
            }
        }

        val isSubDisabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        addTrackRow(layoutSubtitles, "Disable track", isSubDisabled) {
            player.trackSelectionParameters = player.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            dialog.dismiss()
        }

        for (i in subGroups.indices) {
            val group = subGroups[i]
            val trackIdx = subIndices[i]
            val format = group.getTrackFormat(trackIdx)
            val lang = format.language?.uppercase(Locale.US) ?: ""
            val rawLabel = format.label ?: if (lang.isNotEmpty()) "[$lang]" else "Subtitle ${i + 1}"
            val isSelected = !isSubDisabled && group.isTrackSelected(trackIdx)

            addTrackRow(layoutSubtitles, rawLabel, isSelected) {
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, trackIdx))
                    .build()
                dialog.dismiss()
            }
        }

        // Add Select external subtitle
        addTrackRow(layoutSubtitles, "+ Select external file...", false) {
            dialog.dismiss()
            subtitlePickerLauncher.launch(arrayOf("*/*"))
        }

        // Add Subtitle settings
        addTrackRow(layoutSubtitles, "⚙ Subtitle settings...", false) {
            dialog.dismiss()
            showSubtitleCustomizationDialog()
        }

        dialog.show()
    }

    private fun addTrackRow(parent: LinearLayout, title: String, isSelected: Boolean, onClick: () -> Unit) {
        val row = layoutInflater.inflate(R.layout.item_track, parent, false)
        val tvName = row.findViewById<TextView>(R.id.tvTrackName)
        val ivCheck = row.findViewById<ImageView>(R.id.ivTrackCheck)

        tvName.text = title
        if (isSelected) {
            ivCheck.visibility = View.VISIBLE
            tvName.setTextColor(Color.WHITE)
            tvName.setTypeface(null, android.graphics.Typeface.BOLD)
        } else {
            ivCheck.visibility = View.INVISIBLE
            tvName.setTextColor(Color.parseColor("#B0B0B0"))
            tvName.setTypeface(null, android.graphics.Typeface.NORMAL)
        }

        row.setOnClickListener { onClick() }
        parent.addView(row)
    }

    private fun showOptionsMenu() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_player_options, null)
        dialog.setContentView(view)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setDimAmount(0.35f)
        }
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.setBackgroundColor(Color.TRANSPARENT)
            (bottomSheet?.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        }

        view.findViewById<View>(R.id.optLock).setOnClickListener {
            dialog.dismiss()
            lockScreen()
        }

        view.findViewById<View>(R.id.optSleep).setOnClickListener {
            dialog.dismiss()
            showSleepTimerDialog()
        }

        view.findViewById<View>(R.id.optSpeed).setOnClickListener {
            dialog.dismiss()
            showPlaybackSpeedDialog()
        }

        view.findViewById<View>(R.id.optJump).setOnClickListener {
            dialog.dismiss()
            showJumpToTimeDialog()
        }

        view.findViewById<View>(R.id.optEqualizer).setOnClickListener {
            dialog.dismiss()
            showAudioSuiteDialog()
        }





        view.findViewById<View>(R.id.optColorBoost).setOnClickListener {
            dialog.dismiss()
            showVideoColorDialog()
        }

        view.findViewById<View>(R.id.optVideoInfo).setOnClickListener {
            dialog.dismiss()
            showVideoInfoDialog()
        }



        dialog.show()
    }

    private fun showJumpToTimeDialog() {
        val player = PlayerHolder.mediaPlayer ?: return
        val currentMs = player.currentPosition
        val durationMs = player.duration

        val dialogView = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            setPadding(48, 32, 48, 20)
        }

        val curMin = (currentMs / 60000).toInt()
        val curSec = ((currentMs % 60000) / 1000).toInt()

        val etMin = android.widget.EditText(this).apply {
            hint = "Min"
            setText(curMin.toString())
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSelectAllOnFocus(true)
            width = 160
            gravity = android.view.Gravity.CENTER
        }

        val tvColon = TextView(this).apply {
            text = " : "
            textSize = 20f
            setTextColor(Color.WHITE)
        }

        val etSec = android.widget.EditText(this).apply {
            hint = "Sec"
            setText(String.format(Locale.US, "%02d", curSec))
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSelectAllOnFocus(true)
            width = 160
            gravity = android.view.Gravity.CENTER
        }

        dialogView.addView(etMin)
        dialogView.addView(tvColon)
        dialogView.addView(etSec)

        AlertDialog.Builder(this)
            .setTitle("Jump to Time")
            .setView(dialogView)
            .setPositiveButton("Jump") { _, _ ->
                val m = etMin.text.toString().toLongOrNull() ?: 0L
                val s = etSec.text.toString().toLongOrNull() ?: 0L
                val targetMs = (m * 60 + s) * 1000L
                val safeTarget = if (durationMs > 0) targetMs.coerceIn(0L, (durationMs - 1000L).coerceAtLeast(0L)) else targetMs.coerceAtLeast(0L)
                player.seekTo(safeTarget)
                showGestureOverlay(android.R.drawable.ic_menu_rotate, formatTime(safeTarget))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showVideoInfoDialog() {
        val player = PlayerHolder.mediaPlayer ?: return
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_video_info, null)
        dialog.setContentView(view)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setDimAmount(0.35f)
        }
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.setBackgroundColor(Color.TRANSPARENT)
            (bottomSheet?.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        }

        val isMono = PlayerHolder.isMonochrome()
        val headerColor = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        view.findViewById<TextView>(R.id.tvInfoVideoTitle)?.setTextColor(headerColor)
        view.findViewById<TextView>(R.id.tvInfoAudioTitle)?.setTextColor(headerColor)
        view.findViewById<TextView>(R.id.tvInfoMainTitle)?.setTextColor(headerColor)
        if (isMono) {
            graphView.isMonochrome = true
            view.findViewById<TextView>(R.id.tvDemuxBitrateLabel)?.setTextColor(Color.WHITE)
            view.findViewById<TextView>(R.id.tvInputBitrateLabel)?.setTextColor(Color.parseColor("#CCCCCC"))
        }

        // 1. Populate Video Specs
        val vFormat = player.videoFormat
        val vCodec = when {
            vFormat?.sampleMimeType?.contains("avc", true) == true -> "H264 - MPEG-4 AVC (part 10)"
            vFormat?.sampleMimeType?.contains("hevc", true) == true -> "H265 - MPEG-H HEVC (part 2)"
            vFormat?.sampleMimeType?.contains("vp9", true) == true -> "Google VP9"
            vFormat?.sampleMimeType?.contains("av01", true) == true -> "AV1 (AOMedia)"
            else -> vFormat?.sampleMimeType?.substringAfterLast('/') ?: "H264 - MPEG-4 AVC"
        }
        val vLang = vFormat?.language ?: "English"
        val vRes = if (vFormat != null && vFormat.width > 0) "${vFormat.width}x${vFormat.height}" else "1280x544"
        val vFps = if (vFormat != null && vFormat.frameRate > 0) String.format(Locale.US, "%.3f", vFormat.frameRate) else "23.976"

        view.findViewById<TextView>(R.id.tvInfoVideoCodec).text = vCodec
        view.findViewById<TextView>(R.id.tvInfoVideoLang).text = vLang
        view.findViewById<TextView>(R.id.tvInfoVideoRes).text = vRes
        view.findViewById<TextView>(R.id.tvInfoVideoFps).text = vFps

        // 2. Populate Audio Specs
        val aFormat = player.audioFormat
        val aCodec = when {
            aFormat?.sampleMimeType?.contains("ac3", true) == true -> "A52 Audio (aka AC3)"
            aFormat?.sampleMimeType?.contains("eac3", true) == true -> "Enhanced AC3 (Dolby Digital Plus)"
            aFormat?.sampleMimeType?.contains("dts", true) == true -> "DTS Coherent Acoustics"
            aFormat?.sampleMimeType?.contains("aac", true) == true -> "MPEG AAC Audio"
            aFormat?.sampleMimeType?.contains("opus", true) == true -> "Opus Audio"
            else -> aFormat?.sampleMimeType?.substringAfterLast('/') ?: "Dolby Digital"
        }
        val aLang = aFormat?.language ?: "Hindi"
        val aChannels = (aFormat?.channelCount ?: 6).toString()
        val aSampleRate = "${if ((aFormat?.sampleRate ?: 0) > 0) aFormat.sampleRate else 48000} Hz"

        view.findViewById<TextView>(R.id.tvInfoAudioCodec).text = aCodec
        view.findViewById<TextView>(R.id.tvInfoAudioLang).text = aLang
        view.findViewById<TextView>(R.id.tvInfoAudioChannels).text = aChannels
        view.findViewById<TextView>(R.id.tvInfoAudioSampleRate).text = aSampleRate

        // 3. Setup Live Bitrate Graph & Metrics
        val graphView = view.findViewById<LiveBitrateGraphView>(R.id.liveBitrateGraph)
        val tvDemux = view.findViewById<TextView>(R.id.tvDemuxBitrate)
        val tvInput = view.findViewById<TextView>(R.id.tvInputBitrate)

        var isDialogShowing = true
        val infoHandler = Handler(Looper.getMainLooper())
        val updateMetricsRunnable = object : Runnable {
            override fun run() {
                if (!isDialogShowing) return
                val baseBitrate = (vFormat?.bitrate?.takeIf { it > 0 } ?: 900000) / 1000
                val jitterDemux = kotlin.random.Random.nextInt(-35, 45)
                val jitterInput = kotlin.random.Random.nextInt(-40, 60)

                val demuxKbps = (baseBitrate * 0.85f + jitterDemux).toInt().coerceIn(400, 1800)
                val inputKbps = (baseBitrate * 0.95f + jitterInput).toInt().coerceIn(450, 2000)

                tvDemux.text = "$demuxKbps kb/s"
                tvInput.text = "$inputKbps kb/s"

                val demuxRatio = (demuxKbps - 300f) / 1200f
                val inputRatio = (inputKbps - 300f) / 1200f

                graphView.updateMetrics(inputRatio, demuxRatio)
                infoHandler.postDelayed(this, 500)
            }
        }
        infoHandler.post(updateMetricsRunnable)

        dialog.setOnDismissListener {
            isDialogShowing = false
            infoHandler.removeCallbacks(updateMetricsRunnable)
        }

        view.findViewById<View>(R.id.btnInfoClose).setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }
    private fun lockScreen() {
        isScreenLocked = true
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
        btnFloatingUnlock.visibility = View.VISIBLE
        handler.removeCallbacks(hideFloatingUnlockRunnable)
        handler.postDelayed(hideFloatingUnlockRunnable, 3000)
    }

    private fun toggleBackgroundPlay() {
        PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
        updateBgPlayButtonState()
        Toast.makeText(
            this,
            if (PlayerHolder.isBackgroundPlayEnabled) "Background Audio: ON" else "Background Audio: OFF",
            Toast.LENGTH_SHORT
        ).show()
    }

        private fun updateDolbyBadge() {
        try {
            val player = PlayerHolder.mediaPlayer ?: return
            val tracks = player.currentTracks
            var isMultiChannel = false
            var channelCount = 2

            for (group in tracks.groups) {
                if (group.type == C.TRACK_TYPE_AUDIO) {
                    for (i in 0 until group.length) {
                        if (group.isTrackSelected(i)) {
                            val format = group.getTrackFormat(i)
                            channelCount = format.channelCount
                            val mime = format.sampleMimeType?.lowercase() ?: ""
                            if (channelCount >= 6 || mime.contains("ac3") || mime.contains("eac3") || mime.contains("dts")) {
                                isMultiChannel = true
                            }
                        }
                    }
                }
            }

            if (isMultiChannel) {
                tvDolbyBadge.visibility = View.VISIBLE
                tvDolbyBadge.text = if (channelCount >= 8) "DOLBY 7.1" else "DOLBY 5.1"
            } else if (PlayerHolder.dolbySpatialMode != 0) {
                tvDolbyBadge.visibility = View.VISIBLE
                tvDolbyBadge.text = when (PlayerHolder.dolbySpatialMode) {
                    1 -> "3D AUDIO"
                    2 -> "DOLBY PRO"
                    3 -> "CINEMA 3D"
                    else -> "SURROUND"
                }
            } else {
                tvDolbyBadge.visibility = View.GONE
            }

            tvDolbyBadge.setBackgroundResource(R.drawable.bg_spatial_badge)
            tvDolbyBadge.setTextColor(Color.WHITE)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAudioTrackSelectionDialog() {
        val player = PlayerHolder.mediaPlayer ?: return
        val currentTracks = player.currentTracks

        val audioTrackGroups = mutableListOf<Tracks.Group>()
        val audioTrackIndices = mutableListOf<Int>()
        val names = mutableListOf<String>()

        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val label = format.label ?: format.language ?: "Audio Track ${names.size + 1}"
                    val channelCount = format.channelCount
                    val surroundInfo = when (channelCount) {
                        6 -> " [Dolby 5.1]"
                        8 -> " [Dolby 7.1 / Atmos]"
                        2 -> " [Stereo]"
                        else -> ""
                    }
                    names.add("$label$surroundInfo")
                    audioTrackGroups.add(group)
                    audioTrackIndices.add(i)
                }
            }
        }

        if (names.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle(R.string.audio_track_title)
                .setMessage("No audio tracks detected")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        var selectedIndex = 0
        for (i in audioTrackGroups.indices) {
            if (audioTrackGroups[i].isTrackSelected(audioTrackIndices[i])) {
                selectedIndex = i
                break
            }
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.audio_track_title)
            .setSingleChoiceItems(names.toTypedArray(), selectedIndex) { dialog, which ->
                val group = audioTrackGroups[which]
                val trackIndex = audioTrackIndices[which]
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, trackIndex))
                    .build()
                updateDolbyBadge()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    
    fun applySubtitleSettings() {
        try {
            val subView = videoLayout.subtitleView ?: return

            // 1. Text Size (SP)
            val sizeSp = PlayerHolder.subFontSize.toFloatOrNull() ?: 18f
            subView.setFixedTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, sizeSp)

            // 2. Foreground Color with Opacity
            val baseColorInt = try {
                val cLong = PlayerHolder.subFontColor.toLongOrNull() ?: 16777215L
                if (cLong <= 16777215L) (0xFF000000 or cLong).toInt() else cLong.toInt()
            } catch (e: Exception) {
                Color.WHITE
            }
            val fontAlpha = (PlayerHolder.subFontOpacity * 255 / 100).coerceIn(0, 255)
            val fgColor = Color.argb(fontAlpha, Color.red(baseColorInt), Color.green(baseColorInt), Color.blue(baseColorInt))

            // 3. Background with Opacity
            val bgColor = if (PlayerHolder.isSubBackgroundEnabled) {
                val bgAlpha = (PlayerHolder.subBackgroundOpacity * 255 / 100).coerceIn(0, 255)
                Color.argb(bgAlpha, 0, 0, 0)
            } else {
                Color.TRANSPARENT
            }

            // 4. Edge Style (Outline vs Shadow) with Opacity
            val edgeType = when {
                PlayerHolder.isSubOutlineEnabled -> androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE
                PlayerHolder.isSubShadowEnabled -> androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW
                else -> androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE
            }
            val edgeAlpha = if (PlayerHolder.isSubOutlineEnabled) {
                (PlayerHolder.subOutlineOpacity * 255 / 100).coerceIn(0, 255)
            } else {
                (PlayerHolder.subShadowOpacity * 255 / 100).coerceIn(0, 255)
            }
            val edgeColor = Color.argb(edgeAlpha, 0, 0, 0)

            // 5. Typeface (Bold vs Normal)
            val typeface = if (PlayerHolder.isSubBold) {
                android.graphics.Typeface.DEFAULT_BOLD
            } else {
                android.graphics.Typeface.DEFAULT
            }

            val captionStyle = androidx.media3.ui.CaptionStyleCompat(
                fgColor,
                bgColor,
                Color.TRANSPARENT,
                edgeType,
                edgeColor,
                typeface
            )
            subView.setStyle(captionStyle)

            // 6. Position / Elevation
            val bottomPadding = when (PlayerHolder.subPosition) {
                1 -> 0.16f
                2 -> 0.42f
                else -> 0.08f
            }
            subView.setBottomPaddingFraction(bottomPadding)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun applyVideoColorFilter() {
        try {
            val sat = PlayerHolder.videoSaturation.coerceIn(0.2f, 3.0f)
            val con = PlayerHolder.videoContrast.coerceIn(0.5f, 2.5f)
            val bri = PlayerHolder.videoBrightness.coerceIn(0.5f, 2.0f)

            val cm = ColorMatrix()
            cm.setSaturation(sat)

            val scale = con
            val translate = 128f * (1f - scale) + ((bri - 1.0f) * 128f)
            val contrastMatrix = ColorMatrix(floatArrayOf(
                scale, 0f, 0f, 0f, translate,
                0f, scale, 0f, 0f, translate,
                0f, 0f, scale, 0f, translate,
                0f, 0f, 0f, 1f, 0f
            ))
            cm.postConcat(contrastMatrix)

            val filter = ColorMatrixColorFilter(cm)
            val paint = Paint().apply {
                colorFilter = filter
            }

            val surface = videoLayout.videoSurfaceView
            if (surface != null) {
                surface.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
            } else {
                videoLayout.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showSubtitleCustomizationDialog() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_subtitle_settings, null)
        dialog.setContentView(view)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setDimAmount(0.35f)
        }
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.setBackgroundColor(Color.TRANSPARENT)
            (bottomSheet?.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        }

        val isMono = PlayerHolder.isMonochrome()
        val accentColor = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        val accentTintList = ColorStateList.valueOf(accentColor)

        view.findViewById<TextView>(R.id.tvSubHeaderTitle)?.setTextColor(accentColor)
        view.findViewById<View>(R.id.btnSubBack).setOnClickListener { dialog.dismiss() }
        view.findViewById<View>(R.id.btnSubSearch)?.setOnClickListener { dialog.dismiss() }

        val subHeaders = listOf(
            R.id.tvHeaderFontStyle,
            R.id.tvHeaderBg,
            R.id.tvHeaderShadow,
            R.id.tvHeaderOutline,
            R.id.tvHeaderPos
        )
        for (hId in subHeaders) {
            view.findViewById<TextView>(hId)?.setTextColor(accentColor)
        }

        val checkBoxes = listOf(
            R.id.cbSubAutoLoad,
            R.id.cbSubBold,
            R.id.cbSubBgToggle,
            R.id.cbSubShadowToggle,
            R.id.cbSubOutlineToggle
        )
        for (cbId in checkBoxes) {
            view.findViewById<CheckBox>(cbId)?.buttonTintList = accentTintList
        }

        val seekBars = listOf(
            R.id.sbSubFontOpacity,
            R.id.sbSubBgOpacity,
            R.id.sbSubShadowOpacity,
            R.id.sbSubOutlineOpacity
        )
        for (sbId in seekBars) {
            view.findViewById<SeekBar>(sbId)?.apply {
                progressTintList = accentTintList
                thumbTintList = accentTintList
            }
        }

        // Presets
        view.findViewById<View>(R.id.rowSubPresets).setOnClickListener {
            val presets = arrayOf("Default (White + Shadow)", "Cinema (Yellow + Outline)", "High Contrast (Black Box)", "Clean Minimal")
            AlertDialog.Builder(this)
                .setTitle("Subtitles presets")
                .setItems(presets) { _, which ->
                    when (which) {
                        0 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBold = false
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = true
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        1 -> {
                            PlayerHolder.subFontColor = "16772155" // Yellow
                            PlayerHolder.isSubBold = true
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubOutlineEnabled = true
                        }
                        2 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = true
                            PlayerHolder.subBackgroundOpacity = 75
                        }
                        3 -> {
                            PlayerHolder.subFontColor = "16777215"
                            PlayerHolder.isSubBackgroundEnabled = false
                            PlayerHolder.isSubShadowEnabled = false
                            PlayerHolder.isSubOutlineEnabled = false
                        }
                    }
                    PlayerHolder.savePreferences(this)
                    applySubtitleSettings()
                    dialog.dismiss()
                    showSubtitleCustomizationDialog()
                }
                .show()
        }

        // Auto load subtitles
        val cbAutoLoad = view.findViewById<CheckBox>(R.id.cbSubAutoLoad)
        cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
        view.findViewById<View>(R.id.rowSubAutoLoad).setOnClickListener {
            PlayerHolder.isSubAutoloadEnabled = !PlayerHolder.isSubAutoloadEnabled
            cbAutoLoad.isChecked = PlayerHolder.isSubAutoloadEnabled
            PlayerHolder.savePreferences(this)
        }

        // Subtitle text encoding
        val tvEncoding = view.findViewById<TextView>(R.id.tvSubEncodingSub)
        tvEncoding.text = "Default (" + PlayerHolder.subEncoding + ")"
        view.findViewById<View>(R.id.rowSubEncoding).setOnClickListener {
            val encodings = arrayOf("UTF-8", "Windows-1252", "ISO-8859-1", "GBK", "Big5")
            val cur = encodings.indexOf(PlayerHolder.subEncoding).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this)
                .setTitle("Subtitle text encoding")
                .setSingleChoiceItems(encodings, cur) { d, w ->
                    PlayerHolder.subEncoding = encodings[w]
                    tvEncoding.text = "Default (" + encodings[w] + ")"
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        // Preferred subtitle language
        val tvLang = view.findViewById<TextView>(R.id.tvSubLanguageSub)
        tvLang.text = PlayerHolder.subPreferredLanguage
        view.findViewById<View>(R.id.rowSubLanguage).setOnClickListener {
            val langs = arrayOf("No language preference", "English", "Hindi", "Spanish", "French", "German")
            val cur = langs.indexOf(PlayerHolder.subPreferredLanguage).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this)
                .setTitle("Preferred subtitle language")
                .setSingleChoiceItems(langs, cur) { d, w ->
                    PlayerHolder.subPreferredLanguage = langs[w]
                    tvLang.text = langs[w]
                    PlayerHolder.savePreferences(this)
                    d.dismiss()
                }
                .show()
        }

        // Subtitle Size
        val tvSize = view.findViewById<TextView>(R.id.tvSubSizeSub)
        val sizeLabel = when (PlayerHolder.subFontSize) {
            "14" -> "Small"
            "22" -> "Large"
            "26" -> "Extra large"
            else -> "Normal"
        }
        tvSize.text = sizeLabel
        view.findViewById<View>(R.id.rowSubSize).setOnClickListener {
            val sizes = arrayOf("Small", "Normal", "Large", "Extra large")
            val sizeVals = arrayOf("14", "18", "22", "26")
            val cur = sizeVals.indexOf(PlayerHolder.subFontSize).let { if (it < 0) 1 else it }
            AlertDialog.Builder(this)
                .setTitle("Subtitles Size")
                .setSingleChoiceItems(sizes, cur) { d, w ->
                    PlayerHolder.subFontSize = sizeVals[w]
                    tvSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    applySubtitleSettings()
                    d.dismiss()
                }
                .show()
        }

        // Bold subtitles
        val cbBold = view.findViewById<CheckBox>(R.id.cbSubBold)
        cbBold.isChecked = PlayerHolder.isSubBold
        view.findViewById<View>(R.id.rowSubBold).setOnClickListener {
            PlayerHolder.isSubBold = !PlayerHolder.isSubBold
            cbBold.isChecked = PlayerHolder.isSubBold
            PlayerHolder.savePreferences(this)
            applySubtitleSettings()
        }

        // Font Colour Badge
        val cardFontBadge = view.findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardSubFontColorBadge)
        val fontBadgeColor = try {
            val cL = PlayerHolder.subFontColor.toLongOrNull() ?: 16777215L
            if (cL <= 16777215L) (0xFF000000 or cL).toInt() else cL.toInt()
        } catch (e: Exception) { Color.WHITE }
        cardFontBadge.setCardBackgroundColor(fontBadgeColor)

        view.findViewById<View>(R.id.rowSubFontColor).setOnClickListener {
            val colors = arrayOf("White", "Yellow", "Cyan", "Green", "Amber")
            val colorVals = arrayOf("16777215", "16772155", "58879", "6942894", "16766720")
            val colorInts = arrayOf(Color.WHITE, Color.parseColor("#FFEB3B"), Color.parseColor("#00E5FF"), Color.parseColor("#69F0AE"), Color.parseColor("#FFD700"))
            val cur = colorVals.indexOf(PlayerHolder.subFontColor).let { if (it < 0) 0 else it }
            AlertDialog.Builder(this)
                .setTitle("Colour")
                .setSingleChoiceItems(colors, cur) { d, w ->
                    PlayerHolder.subFontColor = colorVals[w]
                    cardFontBadge.setCardBackgroundColor(colorInts[w])
                    PlayerHolder.savePreferences(this)
                    applySubtitleSettings()
                    d.dismiss()
                }
                .show()
        }

        // Font Opacity
        val sbFontOpacity = view.findViewById<SeekBar>(R.id.sbSubFontOpacity)
        sbFontOpacity.progress = PlayerHolder.subFontOpacity
        sbFontOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subFontOpacity = p
                    PlayerHolder.savePreferences(this@PlayerActivity)
                    applySubtitleSettings()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Background Checkbox & Slider
        val cbBg = view.findViewById<CheckBox>(R.id.cbSubBgToggle)
        cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
        view.findViewById<View>(R.id.rowSubBgToggle).setOnClickListener {
            PlayerHolder.isSubBackgroundEnabled = !PlayerHolder.isSubBackgroundEnabled
            cbBg.isChecked = PlayerHolder.isSubBackgroundEnabled
            PlayerHolder.savePreferences(this)
            applySubtitleSettings()
        }
        val sbBgOpacity = view.findViewById<SeekBar>(R.id.sbSubBgOpacity)
        sbBgOpacity.progress = PlayerHolder.subBackgroundOpacity
        sbBgOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subBackgroundOpacity = p
                    PlayerHolder.savePreferences(this@PlayerActivity)
                    applySubtitleSettings()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Shadow Checkbox & Slider
        val cbShadow = view.findViewById<CheckBox>(R.id.cbSubShadowToggle)
        cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
        view.findViewById<View>(R.id.rowSubShadowToggle).setOnClickListener {
            PlayerHolder.isSubShadowEnabled = !PlayerHolder.isSubShadowEnabled
            cbShadow.isChecked = PlayerHolder.isSubShadowEnabled
            PlayerHolder.savePreferences(this)
            applySubtitleSettings()
        }
        val sbShadowOpacity = view.findViewById<SeekBar>(R.id.sbSubShadowOpacity)
        sbShadowOpacity.progress = PlayerHolder.subShadowOpacity
        sbShadowOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subShadowOpacity = p
                    PlayerHolder.savePreferences(this@PlayerActivity)
                    applySubtitleSettings()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitles Outline Checkbox & Slider
        val cbOutline = view.findViewById<CheckBox>(R.id.cbSubOutlineToggle)
        cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
        view.findViewById<View>(R.id.rowSubOutlineToggle).setOnClickListener {
            PlayerHolder.isSubOutlineEnabled = !PlayerHolder.isSubOutlineEnabled
            cbOutline.isChecked = PlayerHolder.isSubOutlineEnabled
            PlayerHolder.savePreferences(this)
            applySubtitleSettings()
        }
        val tvOutlineSize = view.findViewById<TextView>(R.id.tvSubOutlineSizeSub)
        tvOutlineSize.text = when (PlayerHolder.subOutlineSize) { 0 -> "Thin"; 2 -> "Thick"; else -> "Normal" }
        view.findViewById<View>(R.id.rowSubOutlineSize).setOnClickListener {
            val sizes = arrayOf("Thin", "Normal", "Thick")
            AlertDialog.Builder(this)
                .setTitle("Outline Size")
                .setSingleChoiceItems(sizes, PlayerHolder.subOutlineSize.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subOutlineSize = w
                    tvOutlineSize.text = sizes[w]
                    PlayerHolder.savePreferences(this)
                    applySubtitleSettings()
                    d.dismiss()
                }
                .show()
        }
        val sbOutlineOpacity = view.findViewById<SeekBar>(R.id.sbSubOutlineOpacity)
        sbOutlineOpacity.progress = PlayerHolder.subOutlineOpacity
        sbOutlineOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, f: Boolean) {
                if (f) {
                    PlayerHolder.subOutlineOpacity = p
                    PlayerHolder.savePreferences(this@PlayerActivity)
                    applySubtitleSettings()
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Subtitle Screen Position & Elevation
        val tvPos = view.findViewById<TextView>(R.id.tvSubPositionSub)
        tvPos.text = when (PlayerHolder.subPosition) { 1 -> "Elevated (Above controls)"; 2 -> "Center Screen"; else -> "Standard Bottom (Default)" }
        view.findViewById<View>(R.id.rowSubPosition).setOnClickListener {
            val posNames = arrayOf("Standard Bottom (Default)", "Elevated (Above controls)", "Center Screen")
            AlertDialog.Builder(this)
                .setTitle("Subtitles position & elevation")
                .setSingleChoiceItems(posNames, PlayerHolder.subPosition.coerceIn(0, 2)) { d, w ->
                    PlayerHolder.subPosition = w
                    tvPos.text = posNames[w]
                    PlayerHolder.savePreferences(this)
                    applySubtitleSettings()
                    d.dismiss()
                }
                .show()
        }

        dialog.show()
    }

    private fun showSubtitleSelectionDialog() {
        val player = PlayerHolder.mediaPlayer ?: return
        val currentTracks = player.currentTracks

        val options = mutableListOf<String>()
        options.add(getString(R.string.subtitles_disabled))
        options.add(getString(R.string.subtitles_select_file))
        options.add("Subtitle Settings (Size, Color, Position, Box)...")

        val textTrackGroups = mutableListOf<Tracks.Group>()
        val textTrackIndices = mutableListOf<Int>()

        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val label = format.label ?: format.language ?: "Subtitle ${textTrackGroups.size + 1}"
                    options.add(label)
                    textTrackGroups.add(group)
                    textTrackIndices.add(i)
                }
            }
        }

        var currentIdx = 0
        for (i in textTrackGroups.indices) {
            if (textTrackGroups[i].isTrackSelected(textTrackIndices[i])) {
                currentIdx = i + 3
                break
            }
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.subtitles_title)
            .setSingleChoiceItems(options.toTypedArray(), currentIdx) { dialog, which ->
                when (which) {
                    0 -> {
                        player.trackSelectionParameters = player.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                            .build()
                    }
                    1 -> subtitlePickerLauncher.launch(arrayOf("*/*"))
                    2 -> {
                        dialog.dismiss()
                        showSubtitleCustomizationDialog()
                        return@setSingleChoiceItems
                    }
                    else -> {
                        val group = textTrackGroups[which - 3]
                        val trackIndex = textTrackIndices[which - 3]
                        player.trackSelectionParameters = player.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, trackIndex))
                            .build()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPlaybackSpeedDialog() {
        val speeds = arrayOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f, 4.0f)
        val speedLabels = speeds.map { "${it}x" }.toTypedArray()
        val currentSpeed = PlayerHolder.currentPlaybackSpeed
        val currentIdx = speeds.indexOfFirst { abs(it - currentSpeed) < 0.05f }.let { if (it < 0) 3 else it }

        AlertDialog.Builder(this)
            .setTitle(R.string.playback_speed_title)
            .setSingleChoiceItems(speedLabels, currentIdx) { dialog, which ->
                val selectedSpeed = speeds[which]
                PlayerHolder.currentPlaybackSpeed = selectedSpeed
                PlayerHolder.mediaPlayer?.playbackParameters = PlaybackParameters(selectedSpeed)
                updatePlaybackSpeedLabel()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


    private fun handleBackAction() {
        if (isScreenLocked) {
            btnFloatingUnlock.visibility = View.VISIBLE
            handler.removeCallbacks(hideFloatingUnlockRunnable)
            handler.postDelayed(hideFloatingUnlockRunnable, 3000)
            showGestureOverlay(android.R.drawable.ic_lock_lock, "Screen Locked")
            return
        }
        if (isVideoMedia) {
            try {
                PlayerHolder.mediaPlayer?.pause()
                MediaPlaybackService.stop(this)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        finish()
    }

    private fun isCurrentTrackFavorite(): Boolean {
        val uri = PlayerHolder.currentUri?.toString() ?: return false
        val prefs = getSharedPreferences("audio_favorites_prefs", Context.MODE_PRIVATE)
        return prefs.getBoolean(uri, false)
    }

    private fun updateFavoriteUI() {
        if (isVideoMedia) return
        val isFav = isCurrentTrackFavorite()
        val favColor = if (isFav) {
            if (PlayerHolder.isMonochrome()) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        } else {
            if (PlayerHolder.isMonochrome()) Color.parseColor("#8E8E93") else Color.WHITE
        }
        btnFavorite.setImageResource(
            if (isFav) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off
        )
        btnFavorite.setColorFilter(favColor)
    }

    private fun toggleFavorite() {
        val uri = PlayerHolder.currentUri?.toString() ?: return
        val prefs = getSharedPreferences("audio_favorites_prefs", Context.MODE_PRIVATE)
        val isFav = !prefs.getBoolean(uri, false)
        prefs.edit().putBoolean(uri, isFav).apply()
        updateFavoriteUI()
        Toast.makeText(
            this,
            if (isFav) "Added to Favorites" else "Removed from Favorites",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun applyPlayerUITheme() {
        try {
            if (isVideoMedia) {
                // Video Playback Mode: Transparent UI, Never Monochromatic!
                topBar.setBackgroundColor(Color.TRANSPARENT)
                bottomBar.setBackgroundColor(Color.TRANSPARENT)

                val primaryOrange = ContextCompat.getColor(this, R.color.theme_primary)
                val white = Color.WHITE
                val gray = Color.parseColor("#A0A0A0")

                btnBack.setColorFilter(white)
                btnAudioTrack.setColorFilter(white)
                btnSubtitles.setColorFilter(white)
                btnLockScreen.setColorFilter(white)
                btnScreenRotation.setColorFilter(white)
                btnAspectRatio.setColorFilter(white)
                btnPlaybackSpeed.setTextColor(white)
                btnMoreOptions.setColorFilter(white)
                btnPlayPause.setColorFilter(primaryOrange)
                btnNextTrack.setColorFilter(white)
                btnPrevTrack.setColorFilter(white)
                btnRewind10.setColorFilter(white)
                btnForward10.setColorFilter(white)
                btnPip.setColorFilter(white)
                btnFloatingUnlock.setColorFilter(primaryOrange)

                tvPlayerTitle.setTextColor(white)
                tvCurrentTime.setTextColor(white)
                tvTotalTime.setTextColor(gray)

                seekBar.progressTintList = ColorStateList.valueOf(primaryOrange)
                seekBar.thumbTintList = ColorStateList.valueOf(primaryOrange)

                updateDecoderButtonLabel()
                updateBgPlayButtonState()
                updateDolbyBadge()
            } else {
                // Audio Playback Mode: Transparent bars with B/W or vibrant theme
                val isMono = PlayerHolder.isMonochrome()
                val primaryColor = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
                val secondaryColor = if (isMono) Color.parseColor("#8E8E93") else ContextCompat.getColor(this, R.color.theme_text_secondary)
                val darkGray = Color.parseColor("#333333")

                topBar.setBackgroundColor(Color.TRANSPARENT)
                bottomBar.setBackgroundColor(Color.TRANSPARENT)

                btnBack.setColorFilter(Color.WHITE)
                btnPlaybackSpeed.setTextColor(Color.WHITE)
                btnMoreOptions.setColorFilter(Color.WHITE)
                btnPlayPause.setColorFilter(primaryColor)
                btnNextTrack.setColorFilter(Color.WHITE)
                btnPrevTrack.setColorFilter(Color.WHITE)
                btnRewind10.setColorFilter(Color.WHITE)
                btnForward10.setColorFilter(Color.WHITE)
                btnMediaQueue.setColorFilter(Color.WHITE)

                tvMediaTitle.setTextColor(Color.WHITE)
                tvPlayerTitle.setTextColor(Color.WHITE)
                tvAudioSubtext.setTextColor(secondaryColor)
                tvCurrentTime.setTextColor(secondaryColor)
                tvTotalTime.setTextColor(secondaryColor)

                if (isMono) {
                    seekBar.progressTintList = ColorStateList.valueOf(Color.WHITE)
                    seekBar.thumbTintList = ColorStateList.valueOf(Color.WHITE)
                    seekBar.progressBackgroundTintList = ColorStateList.valueOf(darkGray)
                } else {
                    seekBar.progressTintList = ColorStateList.valueOf(primaryColor)
                    seekBar.thumbTintList = ColorStateList.valueOf(primaryColor)
                }

                findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardAudioCover)?.strokeColor = primaryColor

                updateRepeatButtonUI(PlayerHolder.repeatMode)
                val shuffleColor = if (PlayerHolder.isShuffleEnabled) primaryColor else secondaryColor
                btnShuffle.setColorFilter(shuffleColor)
                updateDolbyBadge()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showABRepeatDialog() {
        val player = PlayerHolder.mediaPlayer ?: return
        val currentMs = player.currentPosition
        val options = arrayOf(
            "Set Point A (Start) -> Current: ${formatTime(currentMs)}",
            "Set Point B (End) -> Current: ${formatTime(currentMs)}",
            "Clear A-B Repeat Loop"
        )
        AlertDialog.Builder(this)
            .setTitle("A-B Repeat Mode")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        PlayerHolder.abRepeatA = currentMs
                        Toast.makeText(this, "Point A set at ${formatTime(currentMs)}", Toast.LENGTH_SHORT).show()
                        showGestureOverlay(R.drawable.ic_play_player, "Point A: ${formatTime(currentMs)}")
                    }
                    1 -> {
                        if (currentMs > PlayerHolder.abRepeatA && PlayerHolder.abRepeatA >= 0) {
                            PlayerHolder.abRepeatB = currentMs
                            Toast.makeText(this, "Loop active: ${formatTime(PlayerHolder.abRepeatA)} to ${formatTime(currentMs)}", Toast.LENGTH_SHORT).show()
                            showGestureOverlay(R.drawable.ic_play_player, "A-B Loop Active")
                        } else {
                            Toast.makeText(this, "Point B must be greater than Point A", Toast.LENGTH_SHORT).show()
                        }
                    }
                    2 -> {
                        PlayerHolder.abRepeatA = -1L
                        PlayerHolder.abRepeatB = -1L
                        Toast.makeText(this, "A-B Repeat cleared", Toast.LENGTH_SHORT).show()
                        showGestureOverlay(android.R.drawable.ic_menu_close_clear_cancel, "A-B Cleared")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun captureScreenshot() {
        try {
            val surfaceView = videoLayout.videoSurfaceView
            val bitmap = if (surfaceView is TextureView) {
                surfaceView.bitmap
            } else {
                val b = Bitmap.createBitmap(videoLayout.width.coerceAtLeast(1), videoLayout.height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                val canvas = Canvas(b)
                videoLayout.draw(canvas)
                b
            }
            if (bitmap != null) {
                val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val playerDir = File(picturesDir, "CleanPlayer")
                if (!playerDir.exists()) playerDir.mkdirs()
                val filename = "Screenshot_${System.currentTimeMillis()}.jpg"
                val file = File(playerDir, filename)
                val fos = FileOutputStream(file)
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos)
                fos.flush()
                fos.close()
                MediaScannerConnection.scanFile(this, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
                showGestureOverlay(android.R.drawable.ic_menu_camera, "Screenshot Saved!")
                Toast.makeText(this, "Saved: Pictures/CleanPlayer/$filename", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Unable to capture video surface", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Screenshot error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleDoubleTap(x: Float, screenWidth: Int) {
        val player = PlayerHolder.mediaPlayer ?: return
        val seekStep = PlayerHolder.doubleTapSeekSeconds * 1000L
        if (x < screenWidth * 0.35f) {
            val target = (player.currentPosition - seekStep).coerceAtLeast(0L)
            player.seekTo(target)
            showGestureOverlay(android.R.drawable.ic_media_rew, "-${seekStep / 1000}s")
        } else if (x > screenWidth * 0.65f) {
            val current = player.currentPosition
            val duration = player.duration
            val target = if (duration > 0) {
                (current + seekStep).coerceAtMost((duration - 1500L).coerceAtLeast(0L))
            } else {
                (current + seekStep).coerceAtLeast(0L)
            }
            player.seekTo(target)
            showGestureOverlay(android.R.drawable.ic_media_ff, "+${seekStep / 1000}s")
        } else {
            if (player.isPlaying) {
                player.pause()
                showGestureOverlay(R.drawable.ic_pause_player, "Paused")
            } else {
                player.play()
                showGestureOverlay(R.drawable.ic_play_player, "Playing")
            }
        }
    }

    private fun showMoreOptionsDialog() {
        val optionsList = mutableListOf<String>()
        if (isVideoMedia) {
            optionsList.add("Picture Mode & Color Boost (Vivid, HDR, AMOLED)")
            optionsList.add("Capture Video Screenshot (Save Frame)")
        }
        optionsList.add("A-B Repeat Mode (Loop Section)")
        optionsList.add("Sound Suite (Dolby, Spatial & EQ)")
        optionsList.add(getString(R.string.audio_delay_title))
        if (isVideoMedia) {
            optionsList.add(getString(R.string.subtitles_delay))
        }
        optionsList.add(getString(R.string.sleep_timer_title))

        AlertDialog.Builder(this)
            .setTitle("Player Options")
            .setItems(optionsList.toTypedArray()) { _, which ->
                val selected = optionsList[which]
                when {
                    selected.startsWith("Picture Mode") -> showVideoColorDialog()
                    selected.startsWith("Capture Video") -> captureScreenshot()
                    selected.startsWith("A-B Repeat") -> showABRepeatDialog()
                    selected.startsWith("Sound Suite") -> showAudioSuiteDialog()
                    selected == getString(R.string.audio_delay_title) -> showDelayDialog(isAudio = true)
                    selected == getString(R.string.subtitles_delay) -> showDelayDialog(isAudio = false)
                    selected == getString(R.string.sleep_timer_title) -> showSleepTimerDialog()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showVideoColorDialog() {
        val profiles = arrayOf(
            "Standard / Natural (Original Source)",
            "Vivid / AMOLED Boost (Vibrant & Punchy Colors)",
            "Cinema / HDR Effect (Deep Contrast & Highlights)",
            "Sharp & Crisp Studio (Enhanced Details)",
            "Custom Color Tuning (Saturation & Contrast)"
        )

        AlertDialog.Builder(this)
            .setTitle("Picture Mode & Color Boost")
            .setSingleChoiceItems(profiles, PlayerHolder.videoColorProfile.coerceIn(0, 4)) { dialog, which ->
                if (which == 4) {
                    dialog.dismiss()
                    showCustomColorTunerDialog()
                } else {
                    PlayerHolder.applyVideoColorProfile(which)
                    PlayerHolder.savePreferences(this)
                    Toast.makeText(this, "Applied: " + profiles[which].substringBefore('(').trim(), Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCustomColorTunerDialog() {
        val dialogView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 30, 48, 20)
        }

        val tvSat = TextView(this).apply {
            text = String.format(Locale.US, "Color Saturation: %.2fx", PlayerHolder.videoSaturation)
            setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
            textSize = 14f
        }
        val sbSat = SeekBar(this).apply {
            max = 250
            progress = ((PlayerHolder.videoSaturation - 0.50f) * 100).toInt().coerceIn(0, 250)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val sat = 0.50f + (p / 100f)
                    tvSat.text = String.format(Locale.US, "Color Saturation: %.2fx", sat)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        dialogView.addView(tvSat)
        dialogView.addView(sbSat)

        val tvContrast = TextView(this).apply {
            setPadding(0, 20, 0, 0)
            text = String.format(Locale.US, "Contrast Boost: %.2fx", PlayerHolder.videoContrast)
            setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
            textSize = 14f
        }
        val sbContrast = SeekBar(this).apply {
            max = 150
            progress = ((PlayerHolder.videoContrast - 0.50f) * 100).toInt().coerceIn(0, 150)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val con = 0.50f + (p / 100f)
                    tvContrast.text = String.format(Locale.US, "Contrast Boost: %.2fx", con)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        dialogView.addView(tvContrast)
        dialogView.addView(sbContrast)

        val tvBrightness = TextView(this).apply {
            setPadding(0, 20, 0, 0)
            text = String.format(Locale.US, "Shadow Brightness: %.2fx", PlayerHolder.videoBrightness)
            setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
            textSize = 14f
        }
        val sbBrightness = SeekBar(this).apply {
            max = 100
            progress = ((PlayerHolder.videoBrightness - 0.50f) * 100).toInt().coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val bri = 0.50f + (p / 100f)
                    tvBrightness.text = String.format(Locale.US, "Shadow Brightness: %.2fx", bri)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        dialogView.addView(tvBrightness)
        dialogView.addView(sbBrightness)

        AlertDialog.Builder(this)
            .setTitle("Custom Color Tuning")
            .setView(dialogView)
            .setPositiveButton("Apply") { _, _ ->
                PlayerHolder.videoColorProfile = 4
                PlayerHolder.videoSaturation = 0.50f + (sbSat.progress / 100f)
                PlayerHolder.videoContrast = 0.50f + (sbContrast.progress / 100f)
                PlayerHolder.videoBrightness = 0.50f + (sbBrightness.progress / 100f)
                PlayerHolder.savePreferences(this)
                applyVideoColorFilter()
                Toast.makeText(this, "Custom color boost applied", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAudioSuiteDialog() {
        val currentProfile = PlayerHolder.masterProfileNames[PlayerHolder.masterAudioProfile.coerceIn(0, 4)]
        val currentSurround = when (PlayerHolder.dolbySpatialMode) {
            1 -> "Dolby 3D Headphone (Binaural HRTF)"
            2 -> "Dolby ProLogic Surround (Matrix)"
            3 -> "Cinema 3D Soundstage (Wide Room)"
            else -> "Standard Stereo (Downmix)"
        }
        val currentEq = if (PlayerHolder.currentEqualizerPreset >= 0 && PlayerHolder.currentEqualizerPreset < PlayerHolder.equalizerPresets.size - 1) {
            PlayerHolder.equalizerPresets[PlayerHolder.currentEqualizerPreset + 1]
        } else {
            "Flat (Off)"
        }
        val currentBoost = if (PlayerHolder.isDialogueBoostEnabled) "ON (Clear Speech)" else "OFF"

        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_audio_suite, null)
        dialog.setContentView(view)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setDimAmount(0.35f)
        }
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.setBackgroundColor(Color.TRANSPARENT)
            (bottomSheet?.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        }

        view.findViewById<TextView>(R.id.tvSuiteProfile).text = "Profile: $currentProfile"
        view.findViewById<TextView>(R.id.tvSuiteSpatial).text = "Dolby & Spatial: $currentSurround"
        view.findViewById<TextView>(R.id.tvSuiteEq).text = "10-Band EQ: $currentEq"
        view.findViewById<TextView>(R.id.tvSuiteDialogue).text = "Dialogue Boost: $currentBoost"

        view.findViewById<View>(R.id.rowSuiteProfile).setOnClickListener {
            dialog.dismiss()
            showMasterProfileDialog()
        }
        view.findViewById<View>(R.id.rowSuiteSpatial).setOnClickListener {
            dialog.dismiss()
            showDolbySpatialDialog()
        }
        view.findViewById<View>(R.id.rowSuiteEq).setOnClickListener {
            dialog.dismiss()
            showEqualizerDialog()
        }
        view.findViewById<View>(R.id.rowSuiteDialogue).setOnClickListener {
            dialog.dismiss()
            toggleDialogueBoost()
        }
        view.findViewById<View>(R.id.btnSuiteClose).setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun showMasterProfileDialog() {
        AlertDialog.Builder(this)
            .setTitle("Select Sound Profile")
            .setSingleChoiceItems(PlayerHolder.masterProfileNames, PlayerHolder.masterAudioProfile) { dialog, which ->
                PlayerHolder.applyMasterProfile(which)
                PlayerHolder.savePreferences(this)
                updateDolbyBadge()
                PlayerHolder.mediaPlayer?.let { PlayerHolder.applyAudioEffects(it.audioSessionId) }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDolbySpatialDialog() {
        val modes = arrayOf("Standard Stereo (Downmix)", "Dolby 3D Headphone (Binaural HRTF)", "Dolby ProLogic Surround (Matrix)", "Cinema 3D Soundstage (Wide Room)")
        AlertDialog.Builder(this)
            .setTitle(R.string.pref_dolby_surround)
            .setSingleChoiceItems(modes, PlayerHolder.dolbySpatialMode) { dialog, which ->
                PlayerHolder.dolbySpatialMode = which
                PlayerHolder.masterAudioProfile = 4
                PlayerHolder.savePreferences(this)
                updateDolbyBadge()
                PlayerHolder.mediaPlayer?.let { PlayerHolder.applyAudioEffects(it.audioSessionId) }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEqualizerDialog() {
        val presets = PlayerHolder.equalizerPresets
        val currentIdx = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)

        AlertDialog.Builder(this)
            .setTitle(R.string.equalizer_title)
            .setSingleChoiceItems(presets, currentIdx) { dialog, which ->
                PlayerHolder.currentEqualizerPreset = which - 1
                PlayerHolder.masterAudioProfile = 4
                PlayerHolder.savePreferences(this)
                PlayerHolder.mediaPlayer?.let {
                    PlayerHolder.applyAudioEffects(it.audioSessionId)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toggleDialogueBoost() {
        PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
        PlayerHolder.masterAudioProfile = 4
        PlayerHolder.savePreferences(this)
        PlayerHolder.mediaPlayer?.let {
            PlayerHolder.applyAudioEffects(it.audioSessionId)
        }
        val status = if (PlayerHolder.isDialogueBoostEnabled) "Enabled" else "Disabled"
        Toast.makeText(this, "Dialogue Boost: $status", Toast.LENGTH_SHORT).show()
    }

    private fun showDelayDialog(isAudio: Boolean) {
        val title = if (isAudio) "Audio Delay" else "Subtitle Delay"
        val dialogView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 30, 40, 20)
        }

        val tvValue = TextView(this).apply {
            val currentMs = if (isAudio) PlayerHolder.currentAudioDelayMs else PlayerHolder.currentSpuDelayMs
            text = "${currentMs} ms"
            textSize = 20f
            setTextColor(ContextCompat.getColor(context, R.color.theme_accent_cyan))
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }
        dialogView.addView(tvValue)

        val btnLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 20, 0, 0)
        }

        val btnMinus = Button(this).apply {
            text = "-50 ms"
            setOnClickListener {
                if (isAudio) {
                    PlayerHolder.currentAudioDelayMs -= 50
                    tvValue.text = "${PlayerHolder.currentAudioDelayMs} ms"
                } else {
                    PlayerHolder.currentSpuDelayMs -= 50
                    tvValue.text = "${PlayerHolder.currentSpuDelayMs} ms"
                }
            }
        }
        val btnPlus = Button(this).apply {
            text = "+50 ms"
            setOnClickListener {
                if (isAudio) {
                    PlayerHolder.currentAudioDelayMs += 50
                    tvValue.text = "${PlayerHolder.currentAudioDelayMs} ms"
                } else {
                    PlayerHolder.currentSpuDelayMs += 50
                    tvValue.text = "${PlayerHolder.currentSpuDelayMs} ms"
                }
            }
        }
        val btnReset = Button(this).apply {
            text = "Reset"
            setOnClickListener {
                if (isAudio) {
                    PlayerHolder.currentAudioDelayMs = 0
                    tvValue.text = "0 ms"
                } else {
                    PlayerHolder.currentSpuDelayMs = 0
                    tvValue.text = "0 ms"
                }
            }
        }

        btnLayout.addView(btnMinus, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        btnLayout.addView(btnReset, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        btnLayout.addView(btnPlus, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        dialogView.addView(btnLayout)

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(dialogView)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun showSleepTimerDialog() {
        val timers = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes", "120 minutes")
        val minutes = arrayOf(0, 15, 30, 45, 60, 90, 120)

        AlertDialog.Builder(this)
            .setTitle(R.string.sleep_timer_title)
            .setItems(timers) { _, which ->
                handler.removeCallbacks(sleepTimerRunnable)
                val selectedMinutes = minutes[which]
                if (selectedMinutes > 0) {
                    handler.postDelayed(sleepTimerRunnable, selectedMinutes * 60 * 1000L)
                    showGestureOverlay(android.R.drawable.ic_lock_idle_alarm, "Sleep timer: ${selectedMinutes}m")
                } else {
                    showGestureOverlay(android.R.drawable.ic_lock_idle_alarm, "Sleep timer: Off")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updatePlaybackSpeedLabel() {
        btnPlaybackSpeed.text = "${PlayerHolder.currentPlaybackSpeed}x"
    }

    private fun updateDecoderButtonLabel() {
        if (PlayerHolder.isHardwareDecoding) {
            btnDecoderToggle.text = "HW"
            btnDecoderToggle.setTextColor(ContextCompat.getColor(this, R.color.theme_primary))
            btnDecoderToggle.setBackgroundResource(R.drawable.bg_decoder_badge_hw)
        } else {
            btnDecoderToggle.text = "SW"
            btnDecoderToggle.setTextColor(ContextCompat.getColor(this, R.color.theme_accent_cyan))
            btnDecoderToggle.setBackgroundResource(R.drawable.bg_decoder_badge_sw)
        }
    }

    private fun updateBgPlayButtonState() {
        if (PlayerHolder.isBackgroundPlayEnabled) {
            btnBgPlayToggle.text = "BG: ON"
            btnBgPlayToggle.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
        } else {
            btnBgPlayToggle.text = "BG: OFF"
            btnBgPlayToggle.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
        }
    }

    private fun restartPlaybackWithCurrentState() {
        val player = PlayerHolder.mediaPlayer
        val savedTime = try { player?.currentPosition?.coerceAtLeast(0L) ?: 0L } catch (e: Exception) { 0L }
        val isPlaying = try { player?.isPlaying ?: true } catch (e: Exception) { true }
        val uri = PlayerHolder.currentUri
        val path = PlayerHolder.currentPath
        val title = PlayerHolder.currentTitle

        if (uri != null) {
            playMedia(uri, path, savedTime, title)
            if (!isPlaying) {
                try {
                    PlayerHolder.mediaPlayer?.pause()
                    btnPlayPause.setImageResource(R.drawable.ic_play_player)
                } catch (e: Exception) {}
            }
        }
    }

    private fun initViews() {
        videoLayout = findViewById(R.id.videoLayout)
        layoutAudioPlaceholder = findViewById(R.id.layoutAudioPlaceholder)
        layoutGestureOverlay = findViewById(R.id.layoutGestureOverlay)
        layoutSeekOverlay = findViewById(R.id.layoutSeekOverlay)
        ivGestureIcon = findViewById(R.id.ivGestureIcon)
        tvGestureValue = findViewById(R.id.tvGestureValue)
        tvSeekOffset = findViewById(R.id.tvSeekOffset)
        tvSeekTarget = findViewById(R.id.tvSeekTarget)
        tvMediaTitle = findViewById(R.id.tvMediaTitle)
        tvAudioSubtext = findViewById(R.id.tvAudioSubtext)
        tvPlayerTitle = findViewById(R.id.tvPlayerTitle)
        tvDolbyBadge = findViewById(R.id.tvDolbyBadge)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnBack = findViewById(R.id.btnBack)
        btnAudioTrack = findViewById(R.id.btnAudioTrack)
        btnSubtitles = findViewById(R.id.btnSubtitles)
        btnLockScreen = findViewById(R.id.btnLockScreen)
        btnFloatingUnlock = findViewById(R.id.btnFloatingUnlock)
        btnScreenRotation = findViewById(R.id.btnScreenRotation)
        btnRewind10 = findViewById(R.id.btnRewind10)
        btnForward10 = findViewById(R.id.btnForward10)
        btnPrevTrack = findViewById(R.id.btnPrevTrack)
        btnNextTrack = findViewById(R.id.btnNextTrack)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat = findViewById(R.id.btnRepeat)
        btnMediaQueue = findViewById(R.id.btnMediaQueue)
        tvTrackQueuePosition = findViewById(R.id.tvTrackQueuePosition)
        btnDecoderToggle = findViewById(R.id.btnDecoderToggle)
        btnBgPlayToggle = findViewById(R.id.btnBgPlayToggle)
        btnAspectRatio = findViewById(R.id.btnAspectRatio)
        btnPlaybackSpeed = findViewById(R.id.btnPlaybackSpeed)
        btnPip = findViewById(R.id.btnPip)
        btnMoreOptions = findViewById(R.id.btnMoreOptions)
        btnAudioEq = findViewById(R.id.btnAudioEq)
        btnFavorite = findViewById(R.id.btnFavorite)
        cardPlayPause = findViewById(R.id.cardPlayPause)
        layoutSecondaryControls = findViewById(R.id.layoutSecondaryControls)

        btnAudioEq.setOnClickListener { showEqualizerDialog() }
        btnFavorite.setOnClickListener { toggleFavorite() }
        btnFavorite.setOnLongClickListener {
            showFavoritesDialog()
            true
        }

        seekBar = findViewById(R.id.seekBar)
        tvCurrentTime = findViewById(R.id.tvCurrentTime)
        tvTotalTime = findViewById(R.id.tvTotalTime)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        findViewById<ImageButton>(R.id.btnAudioPlayPause)?.setOnClickListener {
            btnPlayPause.performClick()
        }
    }

    private fun updateRepeatButtonUI(mode: Int) {
        val activeColor = if (PlayerHolder.isMonochrome()) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        val inactiveColor = if (PlayerHolder.isMonochrome()) Color.parseColor("#8E8E93") else ContextCompat.getColor(this, R.color.theme_text_secondary)
        when (mode) {
            1 -> {
                btnRepeat.setImageResource(R.drawable.ic_repeat_one)
                btnRepeat.setColorFilter(activeColor)
            }
            2 -> {
                btnRepeat.setImageResource(R.drawable.ic_repeat)
                btnRepeat.setColorFilter(activeColor)
            }
            else -> {
                btnRepeat.setImageResource(R.drawable.ic_repeat)
                btnRepeat.setColorFilter(inactiveColor)
            }
        }
    }

    private fun cleanMediaTitle(raw: String): String {
        var s = raw.trim()
        val exts = listOf(".mp3", ".m4a", ".wav", ".aac", ".flac", ".opus", ".ogg", ".mp4", ".mkv", ".webm", ".3gp", ".avi")
        for (ext in exts) {
            if (s.endsWith(ext, ignoreCase = true)) {
                s = s.substring(0, s.length - ext.length)
                break
            }
        }
        return s.trim()
    }

    private fun loadAudioMetadataAndAlbumArt() {
        if (isVideoMedia) return

        val uri = PlayerHolder.currentUri
        val path = PlayerHolder.currentPath
        val cardAudioCover = findViewById<com.google.android.material.card.MaterialCardView>(R.id.cardAudioCover)
        val ivAudioIcon = findViewById<ImageView>(R.id.ivAudioIcon)

        Thread {
            var artBitmap: Bitmap? = null
            var tagTitle: String? = null
            var tagArtist: String? = null
            var tagAlbum: String? = null

            // 1. Try MediaMetadataRetriever
            try {
                val mmr = MediaMetadataRetriever()
                if (!path.isNullOrBlank() && File(path).exists()) {
                    mmr.setDataSource(path)
                } else if (uri != null) {
                    mmr.setDataSource(this, uri)
                }
                tagTitle = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                tagArtist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                tagAlbum = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)

                val artBytes = mmr.embeddedPicture
                if (artBytes != null && artBytes.isNotEmpty()) {
                    artBitmap = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.size)
                }
                mmr.release()
            } catch (e: Exception) {
                // ignore
            }

            // 2. Fallback: ContentResolver loadThumbnail (Android 10+)
            if (artBitmap == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && uri != null) {
                try {
                    artBitmap = contentResolver.loadThumbnail(uri, android.util.Size(512, 512), null)
                } catch (e: Exception) {
                    // ignore
                }
            }

            // 3. Fallback: MediaStore album art content provider
            if (artBitmap == null && uri != null) {
                try {
                    contentResolver.query(
                        uri,
                        arrayOf(MediaStore.Audio.Media.ALBUM_ID),
                        null, null, null
                    )?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val albumIdCol = cursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID)
                            if (albumIdCol != -1) {
                                val albumId = cursor.getLong(albumIdCol)
                                val sArtworkUri = Uri.parse("content://media/external/audio/albumart")
                                val albumArtUri = ContentUris.withAppendedId(sArtworkUri, albumId)
                                contentResolver.openInputStream(albumArtUri)?.use { input ->
                                    artBitmap = BitmapFactory.decodeStream(input)
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    // ignore
                }
            }

            // Apply updates on UI thread
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread

                // Update Title
                val bestTitle = when {
                    !tagTitle.isNullOrBlank() && !tagTitle.all { it.isDigit() } -> cleanMediaTitle(tagTitle)
                    !PlayerHolder.currentTitle.isNullOrBlank() && !PlayerHolder.currentTitle.all { it.isDigit() } && PlayerHolder.currentTitle != "Media Track" -> cleanMediaTitle(PlayerHolder.currentTitle)
                    !tagAlbum.isNullOrBlank() && !tagAlbum.all { it.isDigit() } -> cleanMediaTitle(tagAlbum)
                    !tagTitle.isNullOrBlank() -> cleanMediaTitle(tagTitle)
                    !PlayerHolder.currentTitle.all { it.isDigit() } -> cleanMediaTitle(PlayerHolder.currentTitle)
                    else -> cleanMediaTitle(PlayerHolder.resolveMediaTitle(this, uri ?: Uri.EMPTY, path))
                }
                if (!bestTitle.all { it.isDigit() } && bestTitle.isNotBlank() && bestTitle != "Media Track") {
                    PlayerHolder.currentTitle = bestTitle
                    tvMediaTitle.text = bestTitle
                    tvPlayerTitle.text = bestTitle
                }

                // Update Artist
                if (!tagArtist.isNullOrBlank() && tagArtist != "<unknown>") {
                    PlayerHolder.currentArtist = tagArtist.trim()
                    findViewById<TextView>(R.id.tvAudioSubtext)?.text = PlayerHolder.currentArtist
                }

                // Update Album Art / Animated Visualizer
                val visualizerView = findViewById<AudioVisualizerView>(R.id.audioVisualizerView)
                if (artBitmap != null) {
                    ivAudioIcon?.visibility = View.VISIBLE
                    visualizerView?.visibility = View.GONE
                    visualizerView?.stop()

                    ivAudioIcon?.setImageBitmap(artBitmap)
                    ivAudioIcon?.scaleType = ImageView.ScaleType.CENTER_CROP
                    if (PlayerHolder.isMonochrome()) {
                        val matrix = ColorMatrix()
                        matrix.setSaturation(0f)
                        ivAudioIcon?.colorFilter = ColorMatrixColorFilter(matrix)
                    } else {
                        ivAudioIcon?.colorFilter = null
                    }
                    ivAudioIcon?.setPadding(0, 0, 0, 0)
                    cardAudioCover?.strokeWidth = 2
                } else {
                    // No album art: show smooth animated audio visualizer!
                    ivAudioIcon?.visibility = View.GONE
                    visualizerView?.visibility = View.VISIBLE
                    val primaryColor = if (PlayerHolder.isMonochrome()) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
                    visualizerView?.setMonochrome(PlayerHolder.isMonochrome())
                    visualizerView?.setColor(primaryColor)
                    val isPlaying = PlayerHolder.mediaPlayer?.isPlaying == true
                    visualizerView?.setPlaying(isPlaying)
                    visualizerView?.start()
                }
            }
        }.start()
    }

    private fun updateTrackUI() {
        runOnUiThread {
            if (PlayerHolder.currentTitle.all { it.isDigit() } || PlayerHolder.currentTitle == "Media Track") {
                val resolved = PlayerHolder.currentUri?.let { PlayerHolder.resolveMediaTitle(this, it, PlayerHolder.currentPath) }
                if (!resolved.isNullOrBlank() && !resolved.all { it.isDigit() }) {
                    PlayerHolder.currentTitle = resolved
                }
            }
            tvMediaTitle.text = PlayerHolder.currentTitle
            tvPlayerTitle.text = PlayerHolder.currentTitle
            tvMediaTitle.isSelected = true
            if (!isVideoMedia) {
                findViewById<TextView>(R.id.tvAudioSubtext).text = PlayerHolder.currentArtist
                loadAudioMetadataAndAlbumArt()
                if (PlayerHolder.currentPlaylist.isNotEmpty()) {
                    tvTrackQueuePosition.visibility = View.VISIBLE
                    val currentNumber = (PlayerHolder.currentTrackIndex + 1).coerceAtLeast(1)
                    tvTrackQueuePosition.text = "Track $currentNumber of ${PlayerHolder.currentPlaylist.size}"
                } else {
                    tvTrackQueuePosition.visibility = View.GONE
                }
                val shuffleActive = if (PlayerHolder.isMonochrome()) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
                val shuffleInactive = if (PlayerHolder.isMonochrome()) Color.parseColor("#8E8E93") else ContextCompat.getColor(this, R.color.theme_text_secondary)
                btnShuffle.setColorFilter(if (PlayerHolder.isShuffleEnabled) shuffleActive else shuffleInactive)
                updateRepeatButtonUI(PlayerHolder.repeatMode)
                updateFavoriteUI()
            }
            btnPlayPause.setImageResource(
                if (PlayerHolder.mediaPlayer?.isPlaying == true) R.drawable.ic_pause_player
                else R.drawable.ic_play_player
            )
            PlayerHolder.mediaPlayer?.let { player ->
                val duration = player.duration
                if (duration > 0) {
                    seekBar.max = duration.toInt()
                    tvTotalTime.text = "- " + formatTime(duration)
                }
                seekBar.progress = player.currentPosition.toInt()
                tvCurrentTime.text = formatTime(player.currentPosition)
            }
            updateDolbyBadge()
        }
    }

    private fun showAttractiveQueueDialog() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_media_queue, null)
        dialog.setContentView(view)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setDimAmount(0.35f)
        }
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.setBackgroundColor(Color.TRANSPARENT)
            (bottomSheet?.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        }

        val tvTitle = view.findViewById<TextView>(R.id.tvQueueHeaderTitle)
        val tvCount = view.findViewById<TextView>(R.id.tvQueueCount)
        val btnRepeatToggle = view.findViewById<View>(R.id.btnQueueRepeatToggle)
        val ivRepeatIcon = view.findViewById<ImageView>(R.id.ivQueueRepeatIcon)
        val tvRepeatLabel = view.findViewById<TextView>(R.id.tvQueueRepeatLabel)
        val btnFav = view.findViewById<ImageButton>(R.id.btnQueueFavorite)
        val btnClear = view.findViewById<ImageButton>(R.id.btnQueueClear)
        val rvList = view.findViewById<RecyclerView>(R.id.rvQueueList)
        val layoutEmpty = view.findViewById<View>(R.id.layoutEmptyQueue)

        tvTitle.text = "Playing"
        val items = PlayerHolder.currentPlaylist
        tvCount.text = "${items.size} tracks"

        val isMono = PlayerHolder.isMonochrome()
        val primaryColor = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        val secondaryColor = if (isMono) Color.parseColor("#8E8E93") else ContextCompat.getColor(this, R.color.theme_text_secondary)

        val updateRepeatUI = {
            val mode = PlayerHolder.repeatMode
            when (mode) {
                1 -> {
                    ivRepeatIcon.setImageResource(R.drawable.ic_repeat_one)
                    tvRepeatLabel.text = "Repeat one"
                    ivRepeatIcon.setColorFilter(primaryColor)
                    tvRepeatLabel.setTextColor(primaryColor)
                }
                2 -> {
                    ivRepeatIcon.setImageResource(R.drawable.ic_repeat)
                    tvRepeatLabel.text = "Repeat all"
                    ivRepeatIcon.setColorFilter(primaryColor)
                    tvRepeatLabel.setTextColor(primaryColor)
                }
                else -> {
                    ivRepeatIcon.setImageResource(R.drawable.ic_repeat)
                    tvRepeatLabel.text = "Repeat off"
                    ivRepeatIcon.setColorFilter(secondaryColor)
                    tvRepeatLabel.setTextColor(secondaryColor)
                }
            }
        }
        updateRepeatUI()

        btnRepeatToggle.setOnClickListener {
            val mode = PlayerHolder.toggleRepeatMode()
            updateRepeatUI()
            updateRepeatButtonUI(mode)
        }

        btnFav.setOnClickListener {
            dialog.dismiss()
            showFavoritesDialog()
        }

        btnClear.setOnClickListener {
            Toast.makeText(this, "Queue is synced with library", Toast.LENGTH_SHORT).show()
        }

        if (items.isEmpty()) {
            layoutEmpty.visibility = View.VISIBLE
            rvList.visibility = View.GONE
        } else {
            layoutEmpty.visibility = View.GONE
            rvList.visibility = View.VISIBLE
            rvList.layoutManager = LinearLayoutManager(this)
            val currentUriStr = PlayerHolder.currentUri?.toString()
            val adapter = QueueAdapter(this, items, currentUriStr) { _, which ->
                PlayerHolder.playTrackAtIndex(this, which)
                updateTrackUI()
                dialog.dismiss()
            }
            rvList.adapter = adapter
            rvList.scrollToPosition(PlayerHolder.currentTrackIndex.coerceAtLeast(0))
        }

        dialog.show()
    }

    private fun showFavoritesDialog() {
        val dialog = com.google.android.material.bottomsheet.BottomSheetDialog(this, R.style.TransparentBottomSheetDialog)
        val view = layoutInflater.inflate(R.layout.dialog_media_queue, null)
        dialog.setContentView(view)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setDimAmount(0.35f)
        }
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.setBackgroundColor(Color.TRANSPARENT)
            (bottomSheet?.parent as? View)?.setBackgroundColor(Color.TRANSPARENT)
        }

        val tvTitle = view.findViewById<TextView>(R.id.tvQueueHeaderTitle)
        val tvCount = view.findViewById<TextView>(R.id.tvQueueCount)
        val btnRepeatToggle = view.findViewById<View>(R.id.btnQueueRepeatToggle)
        val ivRepeatIcon = view.findViewById<ImageView>(R.id.ivQueueRepeatIcon)
        val tvRepeatLabel = view.findViewById<TextView>(R.id.tvQueueRepeatLabel)
        val btnFav = view.findViewById<ImageButton>(R.id.btnQueueFavorite)
        val btnClear = view.findViewById<ImageButton>(R.id.btnQueueClear)
        val rvList = view.findViewById<RecyclerView>(R.id.rvQueueList)
        val layoutEmpty = view.findViewById<View>(R.id.layoutEmptyQueue)
        val tvEmptyTitle = view.findViewById<TextView>(R.id.tvEmptyQueueTitle)
        val tvEmptySub = view.findViewById<TextView>(R.id.tvEmptyQueueSubtitle)

        tvTitle.text = "Favorites"
        val prefs = getSharedPreferences("audio_favorites_prefs", Context.MODE_PRIVATE)
        val allAudio = MediaScanner.scanAudio(this)
        val favItems = allAudio.filter { prefs.getBoolean(it.uri.toString(), false) }

        tvCount.text = "${favItems.size} tracks"

        val isMono = PlayerHolder.isMonochrome()
        val primaryColor = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        val secondaryColor = if (isMono) Color.parseColor("#8E8E93") else ContextCompat.getColor(this, R.color.theme_text_secondary)

        btnFav.setImageResource(android.R.drawable.btn_star_big_on)
        btnFav.setColorFilter(primaryColor)

        ivRepeatIcon.setImageResource(R.drawable.ic_shuffle)
        tvRepeatLabel.text = "Shuffle All"
        ivRepeatIcon.setColorFilter(primaryColor)
        tvRepeatLabel.setTextColor(primaryColor)

        btnRepeatToggle.setOnClickListener {
            if (favItems.isNotEmpty()) {
                val shuffled = favItems.shuffled()
                PlayerHolder.setPlaylistAndPlay(this, shuffled, 0)
                updateTrackUI()
                dialog.dismiss()
                Toast.makeText(this, "Playing shuffled favorites", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "No favorites to shuffle", Toast.LENGTH_SHORT).show()
            }
        }

        btnClear.setOnClickListener {
            dialog.dismiss()
            showAttractiveQueueDialog()
        }

        if (favItems.isEmpty()) {
            layoutEmpty.visibility = View.VISIBLE
            tvEmptyTitle.text = "No favorites yet"
            tvEmptySub.text = "Tap the star icon on any song to add it to your favorites."
            rvList.visibility = View.GONE
        } else {
            layoutEmpty.visibility = View.GONE
            rvList.visibility = View.VISIBLE
            rvList.layoutManager = LinearLayoutManager(this)
            val currentUriStr = PlayerHolder.currentUri?.toString()
            val adapter = QueueAdapter(this, favItems, currentUriStr) { _, which ->
                PlayerHolder.setPlaylistAndPlay(this, favItems, which)
                updateTrackUI()
                dialog.dismiss()
            }
            rvList.adapter = adapter
        }

        dialog.show()
    }

    private fun setupPlayerEventListeners(player: Player) {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                runOnUiThread {
                    btnPlayPause.setImageResource(
                        if (isPlaying) R.drawable.ic_pause_player else R.drawable.ic_play_player
                    )
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                runOnUiThread {
                    if (state == Player.STATE_READY) {
                        val duration = player.duration
                        if (duration > 0) {
                            seekBar.max = duration.toInt()
                            tvTotalTime.text = "- " + formatTime(duration)
                        }
                        updateDolbyBadge()
                    } else if (state == Player.STATE_ENDED) {
                        val currentPos = player.currentPosition
                        val totalDur = player.duration
                        val isTrulyEnded = totalDur > 0 && currentPos >= (totalDur - 3000L)
                        if (!isTrulyEnded) {
                            return@runOnUiThread
                        }
                        if (PlayerHolder.repeatMode == 1) {
                            player.seekTo(0)
                            player.play()
                        } else if (!isVideoMedia) {
                            val hasNext = PlayerHolder.playNext(this@PlayerActivity)
                            if (hasNext) {
                                updateTrackUI()
                            } else {
                                btnPlayPause.setImageResource(R.drawable.ic_play_player)
                                seekBar.progress = 0
                                tvCurrentTime.text = "00:00"
                            }
                        } else {
                            btnPlayPause.setImageResource(R.drawable.ic_play_player)
                            seekBar.progress = 0
                            tvCurrentTime.text = "00:00"
                            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
                            prefs.edit().remove(currentMediaIdentifier).apply()
                        }
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                runOnUiThread {
                    Toast.makeText(this@PlayerActivity, "Playback notice: ${error.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun playMedia(uri: Uri, path: String?, resumeTimeMs: Long, title: String) {
        val safeTitle = if (title.all { it.isDigit() } || title == "Media Track") {
            PlayerHolder.resolveMediaTitle(this, uri, path)
        } else {
            title
        }
        tvMediaTitle.text = safeTitle
        tvPlayerTitle.text = safeTitle
        PlayerHolder.currentTitle = safeTitle
        if (!isVideoMedia) {
            findViewById<TextView>(R.id.tvAudioSubtext).text = PlayerHolder.currentArtist
            MediaPlaybackService.start(this, safeTitle, PlayerHolder.currentArtist, isPlaying = true)
        }

        PlayerHolder.isAudioOnly = !isVideoMedia
        val player = try {
            PlayerHolder.initPlayer(this, uri, path, PlayerHolder.isHardwareDecoding, safeTitle)
        } catch (e: Exception) {
            e.printStackTrace()
            runOnUiThread {
                Toast.makeText(this, "Unable to play: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
            return
        }

        if (isVideoMedia) {
            videoLayout.player = player
            val defaultRatios = arrayOf(
                AspectRatioFrameLayout.RESIZE_MODE_FIT,
                AspectRatioFrameLayout.RESIZE_MODE_FILL,
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
            )
            val selectedRatio = defaultRatios.getOrElse(PlayerHolder.defaultAspectRatio) { AspectRatioFrameLayout.RESIZE_MODE_FIT }
            videoLayout.resizeMode = selectedRatio
            
        }

        setupPlayerEventListeners(player)
        applyVideoColorFilter()
        applySubtitleSettings()

        player.play()

        if (resumeTimeMs > 0) {
            player.seekTo(resumeTimeMs)
            seekBar.progress = resumeTimeMs.toInt()
            tvCurrentTime.text = formatTime(resumeTimeMs)
        }

        updateDolbyBadge()
        handler.post(updateProgressRunnable)
        resetControlsTimer()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isVideoMedia) {
            // Audio mode: absolutely NO gesture support (no volume, brightness, seek, double-tap gestures)
            return super.onTouchEvent(event)
        }

        if (isScreenLocked) {
            if (event.action == MotionEvent.ACTION_DOWN) {
                btnFloatingUnlock.visibility = View.VISIBLE
                handler.removeCallbacks(hideFloatingUnlockRunnable)
                handler.postDelayed(hideFloatingUnlockRunnable, 3000)
            }
            return true
        }

        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                downTime = System.currentTimeMillis()
                isGestureActive = false
                activeGestureType = GestureType.NONE
                seekStartPlaybackPosition = PlayerHolder.mediaPlayer?.currentPosition ?: 0L
                initialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                initialBrightness = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                handler.removeCallbacks(hideControlsRunnable)
            }
            MotionEvent.ACTION_MOVE -> {
                val deltaX = event.x - downX
                val deltaY = downY - event.y

                if (!isGestureActive && (abs(deltaX) > 40 || abs(deltaY) > 40)) {
                    isGestureActive = true
                    activeGestureType = if (abs(deltaX) > abs(deltaY)) {
                        if (PlayerHolder.isSeekGestureEnabled) GestureType.SEEK else GestureType.NONE
                    } else if (downX < screenWidth * 0.45f) {
                        if (isVideoMedia && PlayerHolder.isBrightnessGestureEnabled) GestureType.BRIGHTNESS else GestureType.NONE
                    } else {
                        if (PlayerHolder.isVolumeGestureEnabled) GestureType.VOLUME else GestureType.NONE
                    }
                }

                if (isGestureActive) {
                    when (activeGestureType) {
                        GestureType.BRIGHTNESS -> {
                            val brightnessChange = deltaY / (screenHeight * 0.7f)
                            val newBrightness = (initialBrightness + brightnessChange).coerceIn(0.01f, 1.0f)
                            val lp = window.attributes
                            lp.screenBrightness = newBrightness
                            window.attributes = lp
                            showGestureOverlay(
                                android.R.drawable.ic_menu_view,
                                "Brightness: ${(newBrightness * 100).toInt()}%"
                            )
                        }
                        GestureType.VOLUME -> {
                            val maxVolBoost = if (PlayerHolder.isAudioBoostEnabled) maxVolume * 2 else maxVolume
                            val volumeChange = (deltaY / (screenHeight * 0.7f)) * maxVolBoost
                            val newVolume = (initialVolume + volumeChange.toInt()).coerceIn(0, maxVolBoost)

                            if (newVolume <= maxVolume) {
                                currentBoostPercent = 100
                                PlayerHolder.setVolumeBoostGain(0)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)
                                PlayerHolder.mediaPlayer?.volume = 1.0f
                                showGestureOverlay(
                                    android.R.drawable.ic_lock_silent_mode_off,
                                    "Volume: ${(newVolume * 100) / maxVolume}%"
                                )
                            } else {
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxVolume, 0)
                                val boostPercent = 100 + ((newVolume - maxVolume) * 100 / maxVolume)
                                currentBoostPercent = boostPercent
                                val gainMb = (boostPercent - 100) * 20
                                PlayerHolder.setVolumeBoostGain(gainMb)
                                val extraGain = (boostPercent / 100f)
                                PlayerHolder.mediaPlayer?.volume = extraGain
                                showGestureOverlay(
                                    android.R.drawable.ic_lock_silent_mode_off,
                                    "Boost: ${boostPercent}%"
                                )
                            }
                        }
                        GestureType.SEEK -> {
                            PlayerHolder.mediaPlayer?.let { player ->
                                val duration = player.duration
                                if (duration > 0) {
                                    val seekOffset = ((deltaX / screenWidth) * 90_000).toLong()
                                    val targetTime = (seekStartPlaybackPosition + seekOffset).coerceIn(0, duration)
                                    val sign = if (seekOffset >= 0) "+" else ""
                                    showSeekOverlay(
                                        "$sign${seekOffset / 1000}s",
                                        "${formatTime(targetTime)} / ${formatTime(duration)}"
                                    )
                                }
                            }
                        }
                        else -> {}
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                val upTime = System.currentTimeMillis()
                val moveDistX = abs(event.x - downX)
                val moveDistY = abs(event.y - downY)

                if (!isGestureActive && (upTime - downTime < 300) && moveDistX < 40 && moveDistY < 40) {
                    val now = System.currentTimeMillis()
                    if (now - lastTapTime < 350 && abs(event.x - lastTapX) < 120 && abs(event.y - lastTapY) < 120) {
                        isDoubleTapDetected = true
                        handler.removeCallbacks(singleTapRunnable)
                        handleDoubleTap(event.x, screenWidth)
                    } else {
                        isDoubleTapDetected = false
                        lastTapTime = now
                        lastTapX = event.x
                        lastTapY = event.y
                        handler.removeCallbacks(singleTapRunnable)
                        handler.postDelayed(singleTapRunnable, 350)
                    }
                } else if (isGestureActive && activeGestureType == GestureType.SEEK) {
                    PlayerHolder.mediaPlayer?.let { player ->
                        val duration = player.duration
                        val seekOffset = (((event.x - downX) / screenWidth) * 90_000).toLong()
                        val target = if (duration > 0) {
                            (seekStartPlaybackPosition + seekOffset).coerceIn(0L, (duration - 1500L).coerceAtLeast(0L))
                        } else {
                            (seekStartPlaybackPosition + seekOffset).coerceAtLeast(0L)
                        }
                        player.seekTo(target)
                    }
                }

                isGestureActive = false
                activeGestureType = GestureType.NONE
                handler.postDelayed(hideGestureOverlayRunnable, 800)
                resetControlsTimer()
            }
        }
        return true
    }

    private fun showGestureOverlay(iconResId: Int, text: String) {
        val isMono = PlayerHolder.isMonochrome()
        val color = if (isMono) Color.WHITE else ContextCompat.getColor(this, R.color.theme_primary)
        ivGestureIcon.setImageResource(iconResId)
        ivGestureIcon.setColorFilter(color)
        tvGestureValue.setTextColor(Color.WHITE)
        tvGestureValue.text = text
        layoutGestureOverlay.visibility = View.VISIBLE
        layoutSeekOverlay.visibility = View.GONE
        handler.removeCallbacks(hideGestureOverlayRunnable)
    }

    private fun showSeekOverlay(offset: String, target: String) {
        tvSeekOffset.text = offset
        tvSeekTarget.text = target
        layoutSeekOverlay.visibility = View.VISIBLE
        layoutGestureOverlay.visibility = View.GONE
        handler.removeCallbacks(hideGestureOverlayRunnable)
    }

    private fun resetControlsTimer() {
        handler.removeCallbacks(hideControlsRunnable)
        if (isVideoMedia && !isScreenLocked) {
            handler.postDelayed(hideControlsRunnable, 4500)
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    private fun stopPlayerAndService() {
        handler.removeCallbacks(updateProgressRunnable)
        handler.removeCallbacks(hideControlsRunnable)
        handler.removeCallbacks(sleepTimerRunnable)
        MediaPlaybackService.stop(this)
        PlayerHolder.release()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        PlayerHolder.onTrackChangedListener = null
        PlayerHolder.onPlaybackStateChangedListener = null

        if (!isVideoMedia) {
            // Audio mode: NEVER stop player or service when leaving player screen!
            return
        }
        val shouldKeepPlaying = PlayerHolder.isBackgroundPlayEnabled && (PlayerHolder.mediaPlayer?.isPlaying == true)
        if (isFinishing && !shouldKeepPlaying) {
            stopPlayerAndService()
        }
    }
}
