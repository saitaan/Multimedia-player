package com.cleanplayer.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.addCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.util.Locale
import kotlin.math.abs

class PlayerActivity : AppCompatActivity() {

    private lateinit var videoLayout: PlayerView
    private lateinit var layoutAudioPlaceholder: LinearLayout
    private lateinit var layoutGestureOverlay: LinearLayout
    private lateinit var layoutSeekOverlay: LinearLayout
    private lateinit var ivGestureIcon: ImageView
    private lateinit var tvGestureValue: TextView
    private lateinit var tvSeekOffset: TextView
    private lateinit var tvSeekTarget: TextView
    private lateinit var tvMediaTitle: TextView
    private lateinit var tvPlayerTitle: TextView
    private lateinit var tvDolbyBadge: TextView
    private lateinit var tvTrackQueuePosition: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnBack: ImageButton
    private lateinit var btnAudioTrack: ImageButton
    private lateinit var btnSubtitles: ImageButton
    private lateinit var btnLockScreen: ImageButton
    private lateinit var btnFloatingUnlock: ImageButton
    private lateinit var btnScreenRotation: ImageButton
    private lateinit var btnRewind10: ImageButton
    private lateinit var btnForward10: ImageButton
    private lateinit var btnPrevTrack: ImageButton
    private lateinit var btnNextTrack: ImageButton
    private lateinit var btnShuffle: ImageButton
    private lateinit var btnRepeat: ImageButton
    private lateinit var btnPlaylistQueue: ImageButton
    private lateinit var btnDecoderToggle: Button
    private lateinit var btnBgPlayToggle: Button
    private lateinit var btnAspectRatio: Button
    private lateinit var btnPlaybackSpeed: Button
    private lateinit var btnPip: ImageButton
    private lateinit var btnMoreOptions: ImageButton
    private lateinit var seekBar: SeekBar
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvTotalTime: TextView
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout

    private lateinit var audioManager: AudioManager
    private var maxVolume: Int = 15
    private var isVideoMedia: Boolean = true
    private var isScreenLocked: Boolean = false
    private var isUserSeeking: Boolean = false
    private var currentMediaIdentifier: String = ""

    // Screen rotation: 0=Sensor, 1=Landscape, 2=Portrait
    private var rotationState: Int = 0

    // Touch gesture tracking
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var isGestureActive = false
    private var initialVolume = 0
    private var initialBrightness = 0f
    private var activeGestureType = GestureType.NONE

    private enum class GestureType {
        NONE, VOLUME, BRIGHTNESS, SEEK
    }

    private val handler = Handler(Looper.getMainLooper())

    private val hideControlsRunnable = Runnable {
        if (!isScreenLocked && isVideoMedia) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
        }
    }

    private val hideGestureOverlayRunnable = Runnable {
        layoutGestureOverlay.visibility = View.GONE
        layoutSeekOverlay.visibility = View.GONE
    }

    private val hideFloatingUnlockRunnable = Runnable {
        btnFloatingUnlock.visibility = View.GONE
    }

    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            PlayerHolder.mediaPlayer?.let { player ->
                if (!isUserSeeking && player.isPlaying) {
                    val current = player.currentPosition
                    val total = player.duration
                    if (total > 0) {
                        seekBar.max = total.toInt()
                        seekBar.progress = current.toInt()
                        tvCurrentTime.text = formatTime(current)
                        tvTotalTime.text = formatTime(total)

                        if (current > 5000L && total - current > 10000L) {
                            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
                            prefs.edit().putLong(currentMediaIdentifier, current).apply()
                        }
                    }
                }
            }
            handler.postDelayed(this, 1000)
        }
    }

    private val sleepTimerRunnable = Runnable {
        PlayerHolder.mediaPlayer?.pause()
        finish()
    }

    private val noisyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY && PlayerHolder.isHeadsetPauseEnabled) {
                PlayerHolder.mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        player.pause()
                        btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
                    }
                }
            }
        }
    }

    private val subtitlePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { subUri ->
            try {
                contentResolver.takePersistableUriPermission(
                    subUri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {}

            PlayerHolder.mediaPlayer?.let { player ->
                val pos = player.currentPosition
                val isPlaying = player.isPlaying
                val subConfig = MediaItem.SubtitleConfiguration.Builder(subUri)
                    .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
                val currentMediaItem = player.currentMediaItem ?: return@let
                val updatedItem = currentMediaItem.buildUpon()
                    .setSubtitleConfigurations(listOf(subConfig))
                    .build()
                player.setMediaItem(updatedItem, pos)
                player.prepare()
                if (isPlaying) player.play()
                Toast.makeText(this, "Subtitle loaded", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val requestNotificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PlayerHolder.loadPreferences(this)
        applyHighRefreshRate()
        enableImmersiveNotchMode()

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && PlayerHolder.isWideColorGamutEnabled) {
            try {
                window.colorMode = ActivityInfo.COLOR_MODE_WIDE_COLOR_GAMUT
            } catch (e: Exception) {}
        }

        setContentView(R.layout.activity_player)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

        initViews()

        isVideoMedia = intent?.getBooleanExtra("is_video", true) ?: true
        if (!isVideoMedia) {
            videoLayout.visibility = View.GONE
            layoutAudioPlaceholder.visibility = View.VISIBLE
            topBar.visibility = View.VISIBLE
            bottomBar.visibility = View.VISIBLE
            btnAspectRatio.visibility = View.GONE
            btnLockScreen.visibility = View.GONE
            btnSubtitles.visibility = View.GONE
            btnAudioTrack.visibility = View.GONE
            btnPip.visibility = View.GONE
            btnScreenRotation.visibility = View.GONE
            btnDecoderToggle.visibility = View.GONE
            btnBgPlayToggle.visibility = View.GONE
            btnShuffle.visibility = View.VISIBLE
            btnRepeat.visibility = View.VISIBLE
            btnPlaylistQueue.visibility = View.VISIBLE
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            rotationState = 2
        } else {
            btnShuffle.visibility = View.GONE
            btnPlaylistQueue.visibility = View.GONE
            tvTrackQueuePosition.visibility = View.GONE
            // Direct Landscape Mode for Video Playback
            when (PlayerHolder.defaultOrientation) {
                0 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    rotationState = 0
                }
                2 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    rotationState = 2
                }
                else -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    rotationState = 1
                }
            }
        }

        checkNotificationPermission()
        setupListeners()
        updateBgPlayButtonState()
        updateDecoderButtonLabel()
        updatePlaybackSpeedLabel()

        onBackPressedDispatcher.addCallback(this) {
            finish()
        }

        val mediaUri = intent?.data ?: intent?.getStringExtra("media_uri")?.let { Uri.parse(it) }
        val title = intent?.getStringExtra("media_title") ?: mediaUri?.lastPathSegment ?: "Media Track"
        val artist = intent?.getStringExtra("media_artist") ?: "Unknown artist"
        PlayerHolder.currentArtist = artist
        val mediaPath = intent?.getStringExtra("media_path")

        if (mediaUri != null) {
            currentMediaIdentifier = mediaPath ?: mediaUri.toString()
            if (!isVideoMedia && PlayerHolder.mediaPlayer != null && (PlayerHolder.currentUri == mediaUri || PlayerHolder.mediaPlayer?.playbackState != Player.STATE_IDLE)) {
                // Audio track already loaded / active in PlayerHolder!
                updateTrackUI()
                setupPlayerEventListeners(PlayerHolder.mediaPlayer!!)
                handler.post(updateProgressRunnable)
                resetControlsTimer()
            } else {
                checkResumeAndPlay(mediaUri, mediaPath, title)
            }
        } else if (!isVideoMedia && PlayerHolder.mediaPlayer != null) {
            updateTrackUI()
            setupPlayerEventListeners(PlayerHolder.mediaPlayer!!)
            handler.post(updateProgressRunnable)
            resetControlsTimer()
        } else {
            finish()
        }
    }

    private fun enableImmersiveNotchMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let { controller ->
                controller.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            enableImmersiveNotchMode()
        }
    }

    private fun applyHighRefreshRate() {
        if (!PlayerHolder.isHighRefreshRateEnabled) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    display
                } else {
                    @Suppress("DEPRECATION")
                    windowManager.defaultDisplay
                }
                val modes = display?.supportedModes ?: emptyArray()
                val currentMode = display?.mode
                val targetMode = modes.filter {
                    currentMode == null || (it.physicalWidth == currentMode.physicalWidth && it.physicalHeight == currentMode.physicalHeight)
                }.maxByOrNull { it.refreshRate } ?: modes.maxByOrNull { it.refreshRate }

                targetMode?.let { mode ->
                    val params = window.attributes
                    params.preferredDisplayModeId = mode.modeId
                    window.attributes = params
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun checkResumeAndPlay(uri: Uri, path: String?, title: String) {
        val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
        val savedTime = prefs.getLong(currentMediaIdentifier, 0L)

        if (savedTime > 10000L && PlayerHolder.resumeMode != 0) {
            if (PlayerHolder.resumeMode == 2) {
                playMedia(uri, path, savedTime, title)
            } else {
                AlertDialog.Builder(this)
                    .setTitle(R.string.resume_title)
                    .setMessage("${getString(R.string.resume_message)}\n${formatTime(savedTime)}")
                    .setPositiveButton(R.string.resume_btn) { _, _ ->
                        playMedia(uri, path, savedTime, title)
                    }
                    .setNegativeButton(R.string.restart_btn) { _, _ ->
                        prefs.edit().remove(currentMediaIdentifier).apply()
                        playMedia(uri, path, 0L, title)
                    }
                    .setCancelable(false)
                    .show()
            }
        } else {
            playMedia(uri, path, 0L, title)
        }
    }

    override fun onStart() {
        super.onStart()
        try {
            val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            registerReceiver(noisyReceiver, filter)
        } catch (e: Exception) {}
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(noisyReceiver)
        } catch (e: Exception) {}
    }

    override fun onResume() {
        super.onResume()
        PlayerHolder.onTrackChangedListener = {
            runOnUiThread { updateTrackUI() }
        }
        PlayerHolder.onPlaybackStateChangedListener = { isPlaying ->
            runOnUiThread {
                btnPlayPause.setImageResource(
                    if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            }
        }
        PlayerHolder.mediaPlayer?.let { player ->
            if (isVideoMedia) {
                videoLayout.player = player
            }
            updateTrackUI()
        }
    }

    override fun onPause() {
        super.onPause()
        if (!isVideoMedia) {
            // Audio mode: NEVER pause on back! Keep playing continuously in foreground service!
            val isPlaying = PlayerHolder.mediaPlayer?.isPlaying == true
            MediaPlaybackService.start(this, tvMediaTitle.text.toString(), PlayerHolder.currentArtist, isPlaying)
            return
        }
        val isPlaying = PlayerHolder.mediaPlayer?.isPlaying == true
        if (PlayerHolder.isBackgroundPlayEnabled) {
            if (isPlaying) {
                MediaPlaybackService.start(this, tvMediaTitle.text.toString(), PlayerHolder.currentArtist, isPlaying = true)
            }
        } else if (isFinishing) {
            stopPlayerAndService()
        } else if (!isInPictureInPictureMode) {
            PlayerHolder.mediaPlayer?.pause()
            btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isVideoMedia && PlayerHolder.backgroundPipMode == 2 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(android.app.PictureInPictureParams.Builder().build())
            } catch (e: Exception) {}
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            btnFloatingUnlock.visibility = View.GONE
        } else {
            topBar.visibility = View.VISIBLE
            bottomBar.visibility = View.VISIBLE
            resetControlsTimer()
        }
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun setupListeners() {
        btnBack.setOnClickListener {
            finish()
        }

        btnPlayPause.setOnClickListener {
            PlayerHolder.mediaPlayer?.let { player ->
                if (player.isPlaying) {
                    player.pause()
                    btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
                    if (!isVideoMedia) {
                        MediaPlaybackService.start(this, tvMediaTitle.text.toString(), PlayerHolder.currentArtist, isPlaying = false)
                    }
                } else {
                    player.play()
                    btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
                    if (!isVideoMedia) {
                        MediaPlaybackService.start(this, tvMediaTitle.text.toString(), PlayerHolder.currentArtist, isPlaying = true)
                    }
                }
            }
            resetControlsTimer()
        }

        btnAudioTrack.setOnClickListener {
            showAudioTrackSelectionDialog()
            resetControlsTimer()
        }

        btnSubtitles.setOnClickListener {
            showSubtitleSelectionDialog()
            resetControlsTimer()
        }

        btnRewind10.setOnClickListener {
            PlayerHolder.mediaPlayer?.let { player ->
                val seekMs = PlayerHolder.doubleTapSeekSeconds * 1000L
                val newTime = (player.currentPosition - seekMs).coerceAtLeast(0L)
                player.seekTo(newTime)
            }
            resetControlsTimer()
        }

        btnForward10.setOnClickListener {
            PlayerHolder.mediaPlayer?.let { player ->
                val seekMs = PlayerHolder.doubleTapSeekSeconds * 1000L
                val newTime = (player.currentPosition + seekMs).coerceAtMost(player.duration)
                player.seekTo(newTime)
            }
            resetControlsTimer()
        }

        btnPrevTrack.setOnClickListener {
            if (PlayerHolder.playPrevious(this)) {
                updateTrackUI()
            }
            resetControlsTimer()
        }

        btnNextTrack.setOnClickListener {
            if (PlayerHolder.playNext(this)) {
                updateTrackUI()
            } else {
                Toast.makeText(this, "End of playlist", Toast.LENGTH_SHORT).show()
            }
            resetControlsTimer()
        }

        btnShuffle.setOnClickListener {
            val enabled = PlayerHolder.toggleShuffle()
            btnShuffle.setColorFilter(
                ContextCompat.getColor(this, if (enabled) R.color.theme_primary else R.color.theme_text_secondary)
            )
            Toast.makeText(this, if (enabled) "Shuffle: ON" else "Shuffle: OFF", Toast.LENGTH_SHORT).show()
            resetControlsTimer()
        }

        btnRepeat.setOnClickListener {
            val mode = PlayerHolder.toggleRepeatMode()
            updateRepeatButtonUI(mode)
            val text = when (mode) {
                1 -> "Repeat One"
                2 -> "Repeat All"
                else -> "Repeat: OFF"
            }
            Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
            resetControlsTimer()
        }

        btnPlaylistQueue.setOnClickListener {
            showPlaylistDialog()
            resetControlsTimer()
        }

        btnLockScreen.setOnClickListener {
            isScreenLocked = true
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            btnFloatingUnlock.visibility = View.VISIBLE
            handler.removeCallbacks(hideFloatingUnlockRunnable)
            handler.postDelayed(hideFloatingUnlockRunnable, 3000)
        }

        btnFloatingUnlock.setOnClickListener {
            isScreenLocked = false
            btnFloatingUnlock.visibility = View.GONE
            topBar.visibility = View.VISIBLE
            bottomBar.visibility = View.VISIBLE
            resetControlsTimer()
        }

        btnScreenRotation.setOnClickListener {
            rotationState = (rotationState + 1) % 3
            when (rotationState) {
                0 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    showGestureOverlay(android.R.drawable.ic_menu_rotate, "Rotation: Auto")
                }
                1 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                    showGestureOverlay(android.R.drawable.ic_menu_rotate, "Rotation: Landscape")
                }
                2 -> {
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                    showGestureOverlay(android.R.drawable.ic_menu_rotate, "Rotation: Portrait")
                }
            }
            resetControlsTimer()
        }

        btnPlaybackSpeed.setOnClickListener {
            showPlaybackSpeedDialog()
            resetControlsTimer()
        }

        btnPip.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    enterPictureInPictureMode(android.app.PictureInPictureParams.Builder().build())
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        btnDecoderToggle.setOnClickListener {
            PlayerHolder.isHardwareDecoding = !PlayerHolder.isHardwareDecoding
            updateDecoderButtonLabel()
            restartPlaybackWithCurrentState()
            resetControlsTimer()
        }

        btnBgPlayToggle.setOnClickListener {
            PlayerHolder.isBackgroundPlayEnabled = !PlayerHolder.isBackgroundPlayEnabled
            updateBgPlayButtonState()
            resetControlsTimer()
        }

        btnAspectRatio.setOnClickListener {
            val current = videoLayout.resizeMode
            val next = when (current) {
                AspectRatioFrameLayout.RESIZE_MODE_FIT -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                AspectRatioFrameLayout.RESIZE_MODE_FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
            videoLayout.resizeMode = next
            btnAspectRatio.text = when (next) {
                AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Fill"
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Zoom"
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH -> "16:9"
                else -> getString(R.string.aspect_best_fit)
            }
            resetControlsTimer()
        }

        btnMoreOptions.setOnClickListener {
            showMoreOptionsDialog()
            resetControlsTimer()
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    tvCurrentTime.text = formatTime(progress.toLong())
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                isUserSeeking = true
                handler.removeCallbacks(hideControlsRunnable)
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                isUserSeeking = false
                sb?.let {
                    PlayerHolder.mediaPlayer?.seekTo(it.progress.toLong())
                }
                resetControlsTimer()
            }
        })
    }

    private fun updateDolbyBadge() {
        try {
            val player = PlayerHolder.mediaPlayer ?: return
            val tracks = player.currentTracks
            var isMultiChannel = false
            var channelCount = 2

            for (group in tracks.groups) {
                if (group.type == C.TRACK_TYPE_AUDIO) {
                    for (i in 0 until group.length) {
                        if (group.isTrackSelected(i)) {
                            val format = group.getTrackFormat(i)
                            channelCount = format.channelCount
                            val mime = format.sampleMimeType?.lowercase() ?: ""
                            if (channelCount >= 6 || mime.contains("ac3") || mime.contains("eac3") || mime.contains("dts")) {
                                isMultiChannel = true
                            }
                        }
                    }
                }
            }

            if (isMultiChannel) {
                tvDolbyBadge.visibility = View.VISIBLE
                tvDolbyBadge.text = if (channelCount >= 8) "DOLBY 7.1" else "DOLBY 5.1"
            } else if (PlayerHolder.dolbySpatialMode != 0) {
                tvDolbyBadge.visibility = View.VISIBLE
                tvDolbyBadge.text = when (PlayerHolder.dolbySpatialMode) {
                    1 -> "3D AUDIO"
                    2 -> "DOLBY PRO"
                    3 -> "CINEMA 3D"
                    else -> "SURROUND"
                }
            } else {
                tvDolbyBadge.visibility = View.GONE
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showAudioTrackSelectionDialog() {
        val player = PlayerHolder.mediaPlayer ?: return
        val currentTracks = player.currentTracks

        val audioTrackGroups = mutableListOf<Tracks.Group>()
        val audioTrackIndices = mutableListOf<Int>()
        val names = mutableListOf<String>()

        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val label = format.label ?: format.language ?: "Audio Track ${names.size + 1}"
                    val channelCount = format.channelCount
                    val surroundInfo = when (channelCount) {
                        6 -> " [Dolby 5.1]"
                        8 -> " [Dolby 7.1 / Atmos]"
                        2 -> " [Stereo]"
                        else -> ""
                    }
                    names.add("$label$surroundInfo")
                    audioTrackGroups.add(group)
                    audioTrackIndices.add(i)
                }
            }
        }

        if (names.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle(R.string.audio_track_title)
                .setMessage("No audio tracks detected")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        var selectedIndex = 0
        for (i in audioTrackGroups.indices) {
            if (audioTrackGroups[i].isTrackSelected(audioTrackIndices[i])) {
                selectedIndex = i
                break
            }
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.audio_track_title)
            .setSingleChoiceItems(names.toTypedArray(), selectedIndex) { dialog, which ->
                val group = audioTrackGroups[which]
                val trackIndex = audioTrackIndices[which]
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex)))
                    .build()
                updateDolbyBadge()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSubtitleSelectionDialog() {
        val player = PlayerHolder.mediaPlayer ?: return
        val currentTracks = player.currentTracks

        val options = mutableListOf<String>()
        options.add(getString(R.string.subtitles_disabled))
        options.add(getString(R.string.subtitles_select_file))

        val textTrackGroups = mutableListOf<Tracks.Group>()
        val textTrackIndices = mutableListOf<Int>()

        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val label = format.label ?: format.language ?: "Subtitle ${textTrackGroups.size + 1}"
                    options.add(label)
                    textTrackGroups.add(group)
                    textTrackIndices.add(i)
                }
            }
        }

        var currentIdx = 0
        for (i in textTrackGroups.indices) {
            if (textTrackGroups[i].isTrackSelected(textTrackIndices[i])) {
                currentIdx = i + 2
                break
            }
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.subtitles_title)
            .setSingleChoiceItems(options.toTypedArray(), currentIdx) { dialog, which ->
                when (which) {
                    0 -> {
                        player.trackSelectionParameters = player.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                            .build()
                    }
                    1 -> subtitlePickerLauncher.launch(arrayOf("*/*"))
                    else -> {
                        val group = textTrackGroups[which - 2]
                        val trackIndex = textTrackIndices[which - 2]
                        player.trackSelectionParameters = player.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, listOf(trackIndex)))
                            .build()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPlaybackSpeedDialog() {
        val speeds = arrayOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f, 4.0f)
        val speedLabels = speeds.map { "${it}x" }.toTypedArray()
        val currentSpeed = PlayerHolder.currentPlaybackSpeed
        val currentIdx = speeds.indexOfFirst { abs(it - currentSpeed) < 0.05f }.let { if (it < 0) 3 else it }

        AlertDialog.Builder(this)
            .setTitle(R.string.playback_speed_title)
            .setSingleChoiceItems(speedLabels, currentIdx) { dialog, which ->
                val selectedSpeed = speeds[which]
                PlayerHolder.currentPlaybackSpeed = selectedSpeed
                PlayerHolder.mediaPlayer?.playbackParameters = PlaybackParameters(selectedSpeed)
                updatePlaybackSpeedLabel()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showMoreOptionsDialog() {
        val optionsList = mutableListOf<String>()
        if (isVideoMedia) {
            optionsList.add("Picture Mode & Color Boost (Vivid, HDR, AMOLED)")
        }
        optionsList.add("Sound Suite (Dolby, Spatial & EQ)")
        optionsList.add(getString(R.string.audio_delay_title))
        if (isVideoMedia) {
            optionsList.add(getString(R.string.subtitles_delay))
        }
        optionsList.add(getString(R.string.sleep_timer_title))

        AlertDialog.Builder(this)
            .setTitle("Player Options")
            .setItems(optionsList.toTypedArray()) { _, which ->
                val selected = optionsList[which]
                when {
                    selected.startsWith("Picture Mode") -> showVideoColorDialog()
                    selected.startsWith("Sound Suite") -> showAudioSuiteDialog()
                    selected == getString(R.string.audio_delay_title) -> showDelayDialog(isAudio = true)
                    selected == getString(R.string.subtitles_delay) -> showDelayDialog(isAudio = false)
                    selected == getString(R.string.sleep_timer_title) -> showSleepTimerDialog()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showVideoColorDialog() {
        val profiles = arrayOf(
            "Standard / Natural (Original Source)",
            "Vivid / AMOLED Boost (Vibrant & Punchy Colors)",
            "Cinema / HDR Effect (Deep Contrast & Highlights)",
            "Sharp & Crisp Studio (Enhanced Details)",
            "Custom Color Tuning (Saturation & Contrast)"
        )

        AlertDialog.Builder(this)
            .setTitle("Picture Mode & Color Boost")
            .setSingleChoiceItems(profiles, PlayerHolder.videoColorProfile.coerceIn(0, 4)) { dialog, which ->
                if (which == 4) {
                    dialog.dismiss()
                    showCustomColorTunerDialog()
                } else {
                    PlayerHolder.applyVideoColorProfile(which)
                    PlayerHolder.savePreferences(this)
                    Toast.makeText(this, "Applied: " + profiles[which].substringBefore('(').trim(), Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCustomColorTunerDialog() {
        val dialogView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 30, 48, 20)
        }

        val tvSat = TextView(this).apply {
            text = String.format(Locale.US, "Color Saturation: %.2fx", PlayerHolder.videoSaturation)
            setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
            textSize = 14f
        }
        val sbSat = SeekBar(this).apply {
            max = 250
            progress = ((PlayerHolder.videoSaturation - 0.50f) * 100).toInt().coerceIn(0, 250)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val sat = 0.50f + (p / 100f)
                    tvSat.text = String.format(Locale.US, "Color Saturation: %.2fx", sat)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        dialogView.addView(tvSat)
        dialogView.addView(sbSat)

        val tvContrast = TextView(this).apply {
            setPadding(0, 20, 0, 0)
            text = String.format(Locale.US, "Contrast Boost: %.2fx", PlayerHolder.videoContrast)
            setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
            textSize = 14f
        }
        val sbContrast = SeekBar(this).apply {
            max = 150
            progress = ((PlayerHolder.videoContrast - 0.50f) * 100).toInt().coerceIn(0, 150)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val con = 0.50f + (p / 100f)
                    tvContrast.text = String.format(Locale.US, "Contrast Boost: %.2fx", con)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        dialogView.addView(tvContrast)
        dialogView.addView(sbContrast)

        val tvBrightness = TextView(this).apply {
            setPadding(0, 20, 0, 0)
            text = String.format(Locale.US, "Shadow Brightness: %.2fx", PlayerHolder.videoBrightness)
            setTextColor(ContextCompat.getColor(context, R.color.theme_text_primary))
            textSize = 14f
        }
        val sbBrightness = SeekBar(this).apply {
            max = 100
            progress = ((PlayerHolder.videoBrightness - 0.50f) * 100).toInt().coerceIn(0, 100)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val bri = 0.50f + (p / 100f)
                    tvBrightness.text = String.format(Locale.US, "Shadow Brightness: %.2fx", bri)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        dialogView.addView(tvBrightness)
        dialogView.addView(sbBrightness)

        AlertDialog.Builder(this)
            .setTitle("Custom Color Tuning")
            .setView(dialogView)
            .setPositiveButton("Apply") { _, _ ->
                PlayerHolder.videoColorProfile = 4
                PlayerHolder.videoSaturation = 0.50f + (sbSat.progress / 100f)
                PlayerHolder.videoContrast = 0.50f + (sbContrast.progress / 100f)
                PlayerHolder.videoBrightness = 0.50f + (sbBrightness.progress / 100f)
                PlayerHolder.savePreferences(this)
                Toast.makeText(this, "Custom color boost applied", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAudioSuiteDialog() {
        val currentProfile = PlayerHolder.masterProfileNames[PlayerHolder.masterAudioProfile.coerceIn(0, 4)]
        val currentSurround = when (PlayerHolder.dolbySpatialMode) {
            1 -> "Dolby 3D Headphone (Binaural HRTF)"
            2 -> "Dolby ProLogic Surround (Matrix)"
            3 -> "Cinema 3D Soundstage (Wide Room)"
            else -> "Standard Stereo (Downmix)"
        }
        val currentEq = if (PlayerHolder.currentEqualizerPreset >= 0 && PlayerHolder.currentEqualizerPreset < PlayerHolder.equalizerPresets.size - 1) {
            PlayerHolder.equalizerPresets[PlayerHolder.currentEqualizerPreset + 1]
        } else {
            "Flat (Off)"
        }
        val currentBoost = if (PlayerHolder.isDialogueBoostEnabled) "ON (Clear Speech)" else "OFF"

        val items = arrayOf(
            "Profile: $currentProfile",
            "Dolby & Spatial: $currentSurround",
            "10-Band EQ: $currentEq",
            "Dialogue Boost: $currentBoost"
        )

        AlertDialog.Builder(this)
            .setTitle("Dolby, Spatial & Equalizer Suite")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showMasterProfileDialog()
                    1 -> showDolbySpatialDialog()
                    2 -> showEqualizerDialog()
                    3 -> toggleDialogueBoost()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showMasterProfileDialog() {
        AlertDialog.Builder(this)
            .setTitle("Select Sound Profile")
            .setSingleChoiceItems(PlayerHolder.masterProfileNames, PlayerHolder.masterAudioProfile) { dialog, which ->
                PlayerHolder.applyMasterProfile(which)
                PlayerHolder.savePreferences(this)
                updateDolbyBadge()
                PlayerHolder.mediaPlayer?.let { PlayerHolder.applyAudioEffects(it.audioSessionId) }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDolbySpatialDialog() {
        val modes = arrayOf("Standard Stereo (Downmix)", "Dolby 3D Headphone (Binaural HRTF)", "Dolby ProLogic Surround (Matrix)", "Cinema 3D Soundstage (Wide Room)")
        AlertDialog.Builder(this)
            .setTitle(R.string.pref_dolby_surround)
            .setSingleChoiceItems(modes, PlayerHolder.dolbySpatialMode) { dialog, which ->
                PlayerHolder.dolbySpatialMode = which
                PlayerHolder.masterAudioProfile = 4
                PlayerHolder.savePreferences(this)
                updateDolbyBadge()
                PlayerHolder.mediaPlayer?.let { PlayerHolder.applyAudioEffects(it.audioSessionId) }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEqualizerDialog() {
        val presets = PlayerHolder.equalizerPresets
        val currentIdx = (PlayerHolder.currentEqualizerPreset + 1).coerceIn(0, presets.size - 1)

        AlertDialog.Builder(this)
            .setTitle(R.string.equalizer_title)
            .setSingleChoiceItems(presets, currentIdx) { dialog, which ->
                PlayerHolder.currentEqualizerPreset = which - 1
                PlayerHolder.masterAudioProfile = 4
                PlayerHolder.savePreferences(this)
                PlayerHolder.mediaPlayer?.let {
                    PlayerHolder.applyAudioEffects(it.audioSessionId)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toggleDialogueBoost() {
        PlayerHolder.isDialogueBoostEnabled = !PlayerHolder.isDialogueBoostEnabled
        PlayerHolder.masterAudioProfile = 4
        PlayerHolder.savePreferences(this)
        PlayerHolder.mediaPlayer?.let {
            PlayerHolder.applyAudioEffects(it.audioSessionId)
        }
        val status = if (PlayerHolder.isDialogueBoostEnabled) "Enabled" else "Disabled"
        Toast.makeText(this, "Dialogue Boost: $status", Toast.LENGTH_SHORT).show()
    }

    private fun showDelayDialog(isAudio: Boolean) {
        val title = if (isAudio) "Audio Delay" else "Subtitle Delay"
        val dialogView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 30, 40, 20)
        }

        val tvValue = TextView(this).apply {
            val currentMs = if (isAudio) PlayerHolder.currentAudioDelayMs else PlayerHolder.currentSpuDelayMs
            text = "${currentMs} ms"
            textSize = 20f
            setTextColor(ContextCompat.getColor(context, R.color.theme_accent_cyan))
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }
        dialogView.addView(tvValue)

        val btnLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 20, 0, 0)
        }

        val btnMinus = Button(this).apply {
            text = "-50 ms"
            setOnClickListener {
                if (isAudio) {
                    PlayerHolder.currentAudioDelayMs -= 50
                    tvValue.text = "${PlayerHolder.currentAudioDelayMs} ms"
                } else {
                    PlayerHolder.currentSpuDelayMs -= 50
                    tvValue.text = "${PlayerHolder.currentSpuDelayMs} ms"
                }
            }
        }
        val btnPlus = Button(this).apply {
            text = "+50 ms"
            setOnClickListener {
                if (isAudio) {
                    PlayerHolder.currentAudioDelayMs += 50
                    tvValue.text = "${PlayerHolder.currentAudioDelayMs} ms"
                } else {
                    PlayerHolder.currentSpuDelayMs += 50
                    tvValue.text = "${PlayerHolder.currentSpuDelayMs} ms"
                }
            }
        }
        val btnReset = Button(this).apply {
            text = "Reset"
            setOnClickListener {
                if (isAudio) {
                    PlayerHolder.currentAudioDelayMs = 0
                    tvValue.text = "0 ms"
                } else {
                    PlayerHolder.currentSpuDelayMs = 0
                    tvValue.text = "0 ms"
                }
            }
        }

        btnLayout.addView(btnMinus, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        btnLayout.addView(btnReset, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        btnLayout.addView(btnPlus, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        dialogView.addView(btnLayout)

        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(dialogView)
            .setPositiveButton("Done", null)
            .show()
    }

    private fun showSleepTimerDialog() {
        val timers = arrayOf("Off", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes", "120 minutes")
        val minutes = arrayOf(0, 15, 30, 45, 60, 90, 120)

        AlertDialog.Builder(this)
            .setTitle(R.string.sleep_timer_title)
            .setItems(timers) { _, which ->
                handler.removeCallbacks(sleepTimerRunnable)
                val selectedMinutes = minutes[which]
                if (selectedMinutes > 0) {
                    handler.postDelayed(sleepTimerRunnable, selectedMinutes * 60 * 1000L)
                    showGestureOverlay(android.R.drawable.ic_lock_idle_alarm, "Sleep timer: ${selectedMinutes}m")
                } else {
                    showGestureOverlay(android.R.drawable.ic_lock_idle_alarm, "Sleep timer: Off")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun updatePlaybackSpeedLabel() {
        btnPlaybackSpeed.text = "${PlayerHolder.currentPlaybackSpeed}x"
    }

    private fun updateDecoderButtonLabel() {
        btnDecoderToggle.text = if (PlayerHolder.isHardwareDecoding) {
            getString(R.string.decoder_hw)
        } else {
            getString(R.string.decoder_sw)
        }
        btnDecoderToggle.setTextColor(
            ContextCompat.getColor(
                this,
                if (PlayerHolder.isHardwareDecoding) R.color.theme_primary else R.color.theme_accent_cyan
            )
        )
    }

    private fun updateBgPlayButtonState() {
        if (PlayerHolder.isBackgroundPlayEnabled) {
            btnBgPlayToggle.text = "BG: ON"
            btnBgPlayToggle.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light))
        } else {
            btnBgPlayToggle.text = "BG: OFF"
            btnBgPlayToggle.setTextColor(ContextCompat.getColor(this, R.color.theme_text_secondary))
        }
    }

    private fun restartPlaybackWithCurrentState() {
        val player = PlayerHolder.mediaPlayer
        val savedTime = try { player?.currentPosition?.coerceAtLeast(0L) ?: 0L } catch (e: Exception) { 0L }
        val isPlaying = try { player?.isPlaying ?: true } catch (e: Exception) { true }
        val uri = PlayerHolder.currentUri
        val path = PlayerHolder.currentPath
        val title = PlayerHolder.currentTitle

        if (uri != null) {
            playMedia(uri, path, savedTime, title)
            if (!isPlaying) {
                try {
                    PlayerHolder.mediaPlayer?.pause()
                    btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
                } catch (e: Exception) {}
            }
        }
    }

    private fun initViews() {
        videoLayout = findViewById(R.id.videoLayout)
        layoutAudioPlaceholder = findViewById(R.id.layoutAudioPlaceholder)
        layoutGestureOverlay = findViewById(R.id.layoutGestureOverlay)
        layoutSeekOverlay = findViewById(R.id.layoutSeekOverlay)
        ivGestureIcon = findViewById(R.id.ivGestureIcon)
        tvGestureValue = findViewById(R.id.tvGestureValue)
        tvSeekOffset = findViewById(R.id.tvSeekOffset)
        tvSeekTarget = findViewById(R.id.tvSeekTarget)
        tvMediaTitle = findViewById(R.id.tvMediaTitle)
        tvPlayerTitle = findViewById(R.id.tvPlayerTitle)
        tvDolbyBadge = findViewById(R.id.tvDolbyBadge)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnBack = findViewById(R.id.btnBack)
        btnAudioTrack = findViewById(R.id.btnAudioTrack)
        btnSubtitles = findViewById(R.id.btnSubtitles)
        btnLockScreen = findViewById(R.id.btnLockScreen)
        btnFloatingUnlock = findViewById(R.id.btnFloatingUnlock)
        btnScreenRotation = findViewById(R.id.btnScreenRotation)
        btnRewind10 = findViewById(R.id.btnRewind10)
        btnForward10 = findViewById(R.id.btnForward10)
        btnPrevTrack = findViewById(R.id.btnPrevTrack)
        btnNextTrack = findViewById(R.id.btnNextTrack)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat = findViewById(R.id.btnRepeat)
        btnPlaylistQueue = findViewById(R.id.btnPlaylistQueue)
        tvTrackQueuePosition = findViewById(R.id.tvTrackQueuePosition)
        btnDecoderToggle = findViewById(R.id.btnDecoderToggle)
        btnBgPlayToggle = findViewById(R.id.btnBgPlayToggle)
        btnAspectRatio = findViewById(R.id.btnAspectRatio)
        btnPlaybackSpeed = findViewById(R.id.btnPlaybackSpeed)
        btnPip = findViewById(R.id.btnPip)
        btnMoreOptions = findViewById(R.id.btnMoreOptions)
        seekBar = findViewById(R.id.seekBar)
        tvCurrentTime = findViewById(R.id.tvCurrentTime)
        tvTotalTime = findViewById(R.id.tvTotalTime)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
    }

    private fun updateRepeatButtonUI(mode: Int) {
        when (mode) {
            1 -> {
                btnRepeat.setImageResource(R.drawable.ic_repeat_one)
                btnRepeat.setColorFilter(ContextCompat.getColor(this, R.color.theme_primary))
            }
            2 -> {
                btnRepeat.setImageResource(R.drawable.ic_repeat)
                btnRepeat.setColorFilter(ContextCompat.getColor(this, R.color.theme_primary))
            }
            else -> {
                btnRepeat.setImageResource(R.drawable.ic_repeat)
                btnRepeat.setColorFilter(ContextCompat.getColor(this, R.color.theme_text_secondary))
            }
        }
    }

    private fun updateTrackUI() {
        runOnUiThread {
            tvMediaTitle.text = PlayerHolder.currentTitle
            tvPlayerTitle.text = PlayerHolder.currentTitle
            tvMediaTitle.isSelected = true
            if (!isVideoMedia) {
                findViewById<TextView>(R.id.tvAudioSubtext).text = PlayerHolder.currentArtist
                if (PlayerHolder.currentPlaylist.isNotEmpty()) {
                    tvTrackQueuePosition.visibility = View.VISIBLE
                    val currentNumber = (PlayerHolder.currentTrackIndex + 1).coerceAtLeast(1)
                    tvTrackQueuePosition.text = "Track $currentNumber of ${PlayerHolder.currentPlaylist.size}"
                } else {
                    tvTrackQueuePosition.visibility = View.GONE
                }
                btnShuffle.setColorFilter(
                    ContextCompat.getColor(this, if (PlayerHolder.isShuffleEnabled) R.color.theme_primary else R.color.theme_text_secondary)
                )
                updateRepeatButtonUI(PlayerHolder.repeatMode)
            }
            btnPlayPause.setImageResource(
                if (PlayerHolder.mediaPlayer?.isPlaying == true) android.R.drawable.ic_media_pause
                else android.R.drawable.ic_media_play
            )
            PlayerHolder.mediaPlayer?.let { player ->
                val duration = player.duration
                if (duration > 0) {
                    seekBar.max = duration.toInt()
                    tvTotalTime.text = formatTime(duration)
                }
                seekBar.progress = player.currentPosition.toInt()
                tvCurrentTime.text = formatTime(player.currentPosition)
            }
            updateDolbyBadge()
        }
    }

    private fun showPlaylistDialog() {
        val items = PlayerHolder.currentPlaylist
        if (items.isEmpty()) {
            Toast.makeText(this, "Playlist is empty", Toast.LENGTH_SHORT).show()
            return
        }
        val names = items.mapIndexed { idx, item ->
            val prefix = if (idx == PlayerHolder.currentTrackIndex) "▶ " else "${idx + 1}. "
            val artist = if (!item.artist.isNullOrEmpty() && item.artist != "<unknown>") " - ${item.artist}" else ""
            "$prefix${item.title}$artist"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Current Playlist (${items.size} tracks)")
            .setSingleChoiceItems(names, PlayerHolder.currentTrackIndex.coerceAtLeast(0)) { dialog, which ->
                PlayerHolder.playTrackAtIndex(this, which)
                updateTrackUI()
                dialog.dismiss()
            }
            .setNeutralButton("Back to Library") { dialog, _ ->
                dialog.dismiss()
                finish()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun setupPlayerEventListeners(player: Player) {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                runOnUiThread {
                    btnPlayPause.setImageResource(
                        if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                    )
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                runOnUiThread {
                    if (state == Player.STATE_READY) {
                        val duration = player.duration
                        if (duration > 0) {
                            seekBar.max = duration.toInt()
                            tvTotalTime.text = formatTime(duration)
                        }
                        updateDolbyBadge()
                    } else if (state == Player.STATE_ENDED) {
                        if (PlayerHolder.repeatMode == 1) {
                            player.seekTo(0)
                            player.play()
                        } else if (!isVideoMedia) {
                            val hasNext = PlayerHolder.playNext(this@PlayerActivity)
                            if (hasNext) {
                                updateTrackUI()
                            } else {
                                btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
                                seekBar.progress = 0
                                tvCurrentTime.text = "00:00"
                            }
                        } else {
                            btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
                            seekBar.progress = 0
                            tvCurrentTime.text = "00:00"
                            val prefs = getSharedPreferences("media_resume_prefs", Context.MODE_PRIVATE)
                            prefs.edit().remove(currentMediaIdentifier).apply()
                        }
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                runOnUiThread {
                    AlertDialog.Builder(this@PlayerActivity)
                        .setTitle("Playback Notice")
                        .setMessage("Unable to render this track: ${error.message}")
                        .setPositiveButton("OK") { _, _ -> finish() }
                        .setCancelable(false)
                        .show()
                }
            }
        })
    }

    private fun playMedia(uri: Uri, path: String?, resumeTimeMs: Long, title: String) {
        tvMediaTitle.text = title
        tvPlayerTitle.text = title
        if (!isVideoMedia) {
            findViewById<TextView>(R.id.tvAudioSubtext).text = PlayerHolder.currentArtist
            MediaPlaybackService.start(this, title, PlayerHolder.currentArtist, isPlaying = true)
        }

        PlayerHolder.isAudioOnly = !isVideoMedia
        val player = try {
            PlayerHolder.initPlayer(this, uri, path, PlayerHolder.isHardwareDecoding)
        } catch (e: Exception) {
            e.printStackTrace()
            runOnUiThread {
                Toast.makeText(this, "Failed to load media: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                finish()
            }
            return
        }

        if (isVideoMedia) {
            videoLayout.player = player
            val defaultRatios = arrayOf(
                AspectRatioFrameLayout.RESIZE_MODE_FIT,
                AspectRatioFrameLayout.RESIZE_MODE_FILL,
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
            )
            val selectedRatio = defaultRatios.getOrElse(PlayerHolder.defaultAspectRatio) { AspectRatioFrameLayout.RESIZE_MODE_FIT }
            videoLayout.resizeMode = selectedRatio
            btnAspectRatio.text = when (selectedRatio) {
                AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Fill"
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Zoom"
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH -> "16:9"
                else -> getString(R.string.aspect_best_fit)
            }
        }

        setupPlayerEventListeners(player)

        player.play()

        if (resumeTimeMs > 0) {
            player.seekTo(resumeTimeMs)
            seekBar.progress = resumeTimeMs.toInt()
            tvCurrentTime.text = formatTime(resumeTimeMs)
        }

        updateDolbyBadge()
        handler.post(updateProgressRunnable)
        resetControlsTimer()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isScreenLocked) {
            if (event.action == MotionEvent.ACTION_DOWN) {
                btnFloatingUnlock.visibility = View.VISIBLE
                handler.removeCallbacks(hideFloatingUnlockRunnable)
                handler.postDelayed(hideFloatingUnlockRunnable, 3000)
            }
            return true
        }

        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                downTime = System.currentTimeMillis()
                isGestureActive = false
                activeGestureType = GestureType.NONE
                initialVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                initialBrightness = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                handler.removeCallbacks(hideControlsRunnable)
            }
            MotionEvent.ACTION_MOVE -> {
                val deltaX = event.x - downX
                val deltaY = downY - event.y

                if (!isGestureActive && (abs(deltaX) > 40 || abs(deltaY) > 40)) {
                    isGestureActive = true
                    activeGestureType = if (abs(deltaX) > abs(deltaY)) {
                        if (PlayerHolder.isSeekGestureEnabled) GestureType.SEEK else GestureType.NONE
                    } else if (downX < screenWidth * 0.45f) {
                        if (PlayerHolder.isBrightnessGestureEnabled) GestureType.BRIGHTNESS else GestureType.NONE
                    } else {
                        if (PlayerHolder.isVolumeGestureEnabled) GestureType.VOLUME else GestureType.NONE
                    }
                }

                if (isGestureActive) {
                    when (activeGestureType) {
                        GestureType.BRIGHTNESS -> {
                            val brightnessChange = deltaY / (screenHeight * 0.7f)
                            val newBrightness = (initialBrightness + brightnessChange).coerceIn(0.01f, 1.0f)
                            val lp = window.attributes
                            lp.screenBrightness = newBrightness
                            window.attributes = lp
                            showGestureOverlay(
                                android.R.drawable.ic_menu_view,
                                "Brightness: ${(newBrightness * 100).toInt()}%"
                            )
                        }
                        GestureType.VOLUME -> {
                            val maxVolBoost = if (PlayerHolder.isAudioBoostEnabled) maxVolume * 2 else maxVolume
                            val volumeChange = (deltaY / (screenHeight * 0.7f)) * maxVolBoost
                            val newVolume = (initialVolume + volumeChange.toInt()).coerceIn(0, maxVolBoost)

                            if (newVolume <= maxVolume) {
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0)
                                PlayerHolder.mediaPlayer?.volume = 1.0f
                                showGestureOverlay(
                                    android.R.drawable.ic_lock_silent_mode_off,
                                    "Volume: ${(newVolume * 100) / maxVolume}%"
                                )
                            } else {
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, maxVolume, 0)
                                val boostPercent = 100 + ((newVolume - maxVolume) * 100 / maxVolume)
                                val extraGain = (boostPercent / 100f)
                                PlayerHolder.mediaPlayer?.volume = extraGain
                                showGestureOverlay(
                                    android.R.drawable.ic_lock_silent_mode_off,
                                    "Boost: ${boostPercent}%"
                                )
                            }
                        }
                        GestureType.SEEK -> {
                            PlayerHolder.mediaPlayer?.let { player ->
                                val duration = player.duration
                                if (duration > 0) {
                                    val seekOffset = ((deltaX / screenWidth) * 60_000).toLong()
                                    val targetTime = (player.currentPosition + seekOffset).coerceIn(0, duration)
                                    val sign = if (seekOffset >= 0) "+" else ""
                                    showSeekOverlay(
                                        "$sign${seekOffset / 1000}s",
                                        "${formatTime(targetTime)} / ${formatTime(duration)}"
                                    )
                                }
                            }
                        }
                        else -> {}
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                val upTime = System.currentTimeMillis()
                val moveDistX = abs(event.x - downX)
                val moveDistY = abs(event.y - downY)

                if (!isGestureActive && (upTime - downTime < 300) && moveDistX < 30 && moveDistY < 30) {
                    if (topBar.visibility == View.VISIBLE) {
                        topBar.visibility = View.GONE
                        bottomBar.visibility = View.GONE
                    } else {
                        topBar.visibility = View.VISIBLE
                        bottomBar.visibility = View.VISIBLE
                        resetControlsTimer()
                    }
                } else if (isGestureActive && activeGestureType == GestureType.SEEK) {
                    PlayerHolder.mediaPlayer?.let { player ->
                        val duration = player.duration
                        if (duration > 0) {
                            val seekOffset = (((event.x - downX) / screenWidth) * 60_000).toLong()
                            player.seekTo((player.currentPosition + seekOffset).coerceIn(0, duration))
                        }
                    }
                }

                isGestureActive = false
                activeGestureType = GestureType.NONE
                handler.postDelayed(hideGestureOverlayRunnable, 800)
                resetControlsTimer()
            }
        }
        return true
    }

    private fun showGestureOverlay(iconResId: Int, text: String) {
        ivGestureIcon.setImageResource(iconResId)
        tvGestureValue.text = text
        layoutGestureOverlay.visibility = View.VISIBLE
        layoutSeekOverlay.visibility = View.GONE
        handler.removeCallbacks(hideGestureOverlayRunnable)
    }

    private fun showSeekOverlay(offset: String, target: String) {
        tvSeekOffset.text = offset
        tvSeekTarget.text = target
        layoutSeekOverlay.visibility = View.VISIBLE
        layoutGestureOverlay.visibility = View.GONE
        handler.removeCallbacks(hideGestureOverlayRunnable)
    }

    private fun resetControlsTimer() {
        handler.removeCallbacks(hideControlsRunnable)
        if (isVideoMedia && !isScreenLocked) {
            handler.postDelayed(hideControlsRunnable, 4500)
        }
    }

    private fun formatTime(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60

        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    private fun stopPlayerAndService() {
        handler.removeCallbacks(updateProgressRunnable)
        handler.removeCallbacks(hideControlsRunnable)
        handler.removeCallbacks(sleepTimerRunnable)
        MediaPlaybackService.stop(this)
        PlayerHolder.release()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        PlayerHolder.onTrackChangedListener = null
        PlayerHolder.onPlaybackStateChangedListener = null

        if (!isVideoMedia) {
            // Audio mode: NEVER stop player or service when leaving player screen!
            return
        }
        val shouldKeepPlaying = PlayerHolder.isBackgroundPlayEnabled && (PlayerHolder.mediaPlayer?.isPlaying == true)
        if (isFinishing && !shouldKeepPlaying) {
            stopPlayerAndService()
        }
    }
}
