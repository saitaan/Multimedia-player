package com.cleanplayer.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.media.audiofx.Visualizer
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

class AudioVisualizerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        const val MODEL_STUDIO_BARS = 0      // Symmetrical rounded pillars
        const val MODEL_RETRO_LED_MATRIX = 1 // Stacked square LED blocks (Image 1)
        const val MODEL_CYBERPUNK_LASER = 2  // Fine needle spikes with golden glow (Image 2)
    }

    var currentModel = MODEL_STUDIO_BARS
    var onModelChangedListener: ((model: Int, name: String) -> Unit)? = null

    // Audio FFT & Processing
    private var visualizer: Visualizer? = null
    private val barCount = 32
    private val currentHeights = FloatArray(barCount) { 0.15f }
    private val targetHeights = FloatArray(barCount) { 0.15f }
    private val peakHeights = FloatArray(barCount) { 0.15f }
    private val peakHoldFrames = IntArray(barCount) { 0 }

    // Laser spikes high-density data (Model 2)
    private val spikeCount = 80
    private val currentSpikes = FloatArray(spikeCount) { 0.10f }
    private val targetSpikes = FloatArray(spikeCount) { 0.10f }

    private val barRect = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }

    private var isPlaying = false
    private var isMonochrome = false
    private var accentColor = Color.parseColor("#FF9800")
    private var phase = 0.0
    private var hasRealFftData = false
    private var lastFftTime = 0L

    private val animRunnable = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow || !isPlaying || visibility != View.VISIBLE) {
                isRunning = false
                return
            }
            updateData()
            invalidate()
            postDelayed(this, 25) // ~40fps, highly responsive yet power efficient
        }
    }

    private var isRunning = false

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (e1 == null) return false
            val dx = e2.x - e1.x
            val dy = e2.y - e1.y
            if (abs(dx) > abs(dy) && abs(dx) > 50) {
                if (dx < 0) {
                    val name = nextModel()
                    onModelChangedListener?.invoke(currentModel, name)
                } else {
                    val name = prevModel()
                    onModelChangedListener?.invoke(currentModel, name)
                }
                return true
            }
            return false
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            val name = nextModel()
            onModelChangedListener?.invoke(currentModel, name)
            return true
        }
    })

    fun nextModel(): String {
        currentModel = (currentModel + 1) % 3
        invalidate()
        return getModelName()
    }

    fun prevModel(): String {
        currentModel = (currentModel + 2) % 3
        invalidate()
        return getModelName()
    }

    fun setModel(model: Int) {
        currentModel = model.coerceIn(0, 2)
        invalidate()
    }

    fun getModelName(): String {
        return when (currentModel) {
            MODEL_STUDIO_BARS -> "Visualizer: Studio Soundwave"
            MODEL_RETRO_LED_MATRIX -> "Visualizer: Retro LED Matrix"
            MODEL_CYBERPUNK_LASER -> "Visualizer: Cyberpunk Laser"
            else -> "Visualizer"
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (gestureDetector.onTouchEvent(event)) {
            return true
        }
        return super.onTouchEvent(event)
    }

    fun linkToAudio(audioSessionId: Int = 0) {
        try {
            releaseVisualizer()
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                val captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(512)
                val v = Visualizer(audioSessionId).apply {
                    setCaptureSize(captureSize)
                    setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                        override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                            if (waveform != null && isPlaying) {
                                processWaveform(waveform)
                            }
                        }

                        override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                            if (fft != null && isPlaying) {
                                processFft(fft)
                            }
                        }
                    }, Visualizer.getMaxCaptureRate(), true, true)
                    enabled = true
                }
                visualizer = v
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun processWaveform(waveform: ByteArray) {
        hasRealFftData = true
        lastFftTime = System.currentTimeMillis()
        if (waveform.isEmpty()) return

        val step = (waveform.size / barCount).coerceAtLeast(1)
        for (i in 0 until barCount) {
            var sum = 0.0
            val start = (i * step).coerceAtMost(waveform.size - 1)
            val end = ((i + 1) * step).coerceAtMost(waveform.size)
            var count = 0
            for (k in start until end) {
                val sample = abs(waveform[k].toInt() - 128)
                sum += sample
                count++
            }
            val avg = if (count > 0) sum / count else 0.0
            val normalized = (avg / 35.0).toFloat().coerceIn(0.08f, 0.98f)
            targetHeights[i] = (targetHeights[i] * 0.4f) + (normalized * 0.6f)
        }

        val spikeStep = (waveform.size / spikeCount).coerceAtLeast(1)
        for (i in 0 until spikeCount) {
            val k = (i * spikeStep).coerceAtMost(waveform.size - 1)
            val sample = abs(waveform[k].toInt() - 128)
            val normalized = (sample / 35.0).toFloat().coerceIn(0.06f, 0.98f)
            targetSpikes[i] = (targetSpikes[i] * 0.4f) + (normalized * 0.6f)
        }
    }

    fun releaseVisualizer() {
        try {
            visualizer?.enabled = false
            visualizer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        visualizer = null
    }

    private fun processFft(fft: ByteArray) {
        hasRealFftData = true
        lastFftTime = System.currentTimeMillis()
        val n = fft.size / 2
        if (n <= 0) return

        // 1. Process 32 standard frequency bins (bass, mid, treble)
        val step = (n / barCount).coerceAtLeast(1)
        for (i in 0 until barCount) {
            var sum = 0.0
            val start = (i * step).coerceAtMost(n - 1)
            val end = ((i + 1) * step).coerceAtMost(n)
            var count = 0
            for (k in start until end) {
                val r = fft[2 * k].toFloat()
                val im = fft[2 * k + 1].toFloat()
                sum += hypot(r.toDouble(), im.toDouble())
                count++
            }
            val avg = if (count > 0) sum / count else 0.0
            // Apply human ear log weighting: bass boost slightly
            val weight = 1.0f + (1.0f - (i.toFloat() / barCount)) * 0.8f
            val normalized = ((avg / 65.0) * weight).toFloat().coerceIn(0.08f, 0.98f)
            targetHeights[i] = normalized
        }

        // 2. Process 80 dense spike bins for Model 2
        val spikeStep = (n / spikeCount).coerceAtLeast(1)
        for (i in 0 until spikeCount) {
            val k = (i * spikeStep).coerceAtMost(n - 1)
            val r = fft[2 * k].toFloat()
            val im = fft[2 * k + 1].toFloat()
            val mag = hypot(r.toDouble(), im.toDouble())
            val weight = 1.0f + (1.0f - (i.toFloat() / spikeCount)) * 0.6f
            val normalized = ((mag / 65.0) * weight).toFloat().coerceIn(0.06f, 0.98f)
            targetSpikes[i] = normalized
        }
    }

    fun setMonochrome(mono: Boolean) {
        isMonochrome = mono
        invalidate()
    }

    fun setColor(color: Int) {
        accentColor = color
        invalidate()
    }

    fun setPlaying(playing: Boolean) {
        isPlaying = playing
        if (playing) {
            start()
        } else {
            stop()
        }
    }

    fun start() {
        isPlaying = true
        if (!isRunning) {
            isRunning = true
            removeCallbacks(animRunnable)
            post(animRunnable)
        }
    }

    fun stop() {
        isPlaying = false
        isRunning = false
        removeCallbacks(animRunnable)
        for (i in 0 until barCount) {
            targetHeights[i] = 0.02f
            currentHeights[i] = 0.02f
            peakHeights[i] = 0.02f
            peakHoldFrames[i] = 0
        }
        for (i in 0 until spikeCount) {
            targetSpikes[i] = 0.02f
            currentSpikes[i] = 0.02f
        }
        invalidate()
    }

    fun onPlaybackProgress(posMs: Long, durationMs: Long) {
        if (!isPlaying || posMs <= 0L) return
        if (!hasRealFftData || (System.currentTimeMillis() - lastFftTime > 600)) {
            updateRhythmFromPosition(posMs)
        }
    }

    private fun updateRhythmFromPosition(posMs: Long) {
        if (!isPlaying || posMs <= 0L) return
        val beatSec = posMs / 1000.0

        val kickPhase = (beatSec % 0.45) / 0.45
        val kickEnergy = ((1.0 - kickPhase) * (1.0 - kickPhase) * (1.0 - kickPhase)).toFloat().coerceIn(0f, 1f)

        val snarePhase = ((beatSec + 0.22) % 0.45) / 0.45
        val snareEnergy = ((1.0 - snarePhase) * (1.0 - snarePhase)).toFloat().coerceIn(0f, 1f)

        for (i in 0 until barCount) {
            val freqRatio = i.toFloat() / barCount
            val h = when {
                freqRatio < 0.3f -> 0.12f + kickEnergy * 0.86f
                freqRatio < 0.7f -> 0.10f + snareEnergy * 0.75f
                else -> 0.08f + (kickEnergy * 0.5f)
            }
            targetHeights[i] = h.coerceIn(0.05f, 0.98f)
        }

        for (i in 0 until spikeCount) {
            val ratio = i.toFloat() / spikeCount
            val s = if (ratio < 0.4f) {
                0.10f + kickEnergy * 0.90f
            } else {
                0.08f + snareEnergy * 0.65f
            }
            targetSpikes[i] = s.coerceIn(0.05f, 0.98f)
        }
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility != View.VISIBLE) {
            stop()
        } else if (isPlaying) {
            start()
        }
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility != View.VISIBLE) {
            stop()
        } else if (isPlaying) {
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isPlaying && visibility == View.VISIBLE) start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
        releaseVisualizer()
    }

    private fun updateData() {
        if (!isPlaying) {
            // When paused: freeze completely and keep bars flat
            for (i in 0 until barCount) {
                targetHeights[i] = 0.02f
                currentHeights[i] = 0.02f
                peakHeights[i] = 0.02f
            }
            for (i in 0 until spikeCount) {
                targetSpikes[i] = 0.02f
                currentSpikes[i] = 0.02f
            }
            return
        }
        val now = System.currentTimeMillis()
        val useSimulation = !hasRealFftData || (now - lastFftTime > 800)

        phase += 0.08
        if (isPlaying) {
            if (useSimulation) {
                // Fallback rhythmic beat simulation if audio permission or visualizer not yet available
                for (i in 0 until barCount) {
                    val wave1 = sin(phase + i * 0.32)
                    val wave2 = sin(phase * 1.6 - i * 0.22)
                    val noise = Random.nextFloat() * 0.20f
                    val h = (0.22f + (wave1 * wave2).toFloat() * 0.45f + noise).coerceIn(0.10f, 0.95f)
                    targetHeights[i] = h
                }
                for (i in 0 until spikeCount) {
                    val wave1 = sin(phase * 1.8 + i * 0.25)
                    val noise = Random.nextFloat() * 0.28f
                    val h = (0.15f + abs(wave1).toFloat() * 0.55f + noise).coerceIn(0.08f, 0.95f)
                    targetSpikes[i] = h
                }
            }
        } else {
            for (i in 0 until barCount) {
                targetHeights[i] = 0.08f
            }
            for (i in 0 until spikeCount) {
                targetSpikes[i] = 0.05f
            }
        }

        // Smooth interpolation
        for (i in 0 until barCount) {
            val diff = targetHeights[i] - currentHeights[i]
            currentHeights[i] += diff * 0.35f

            // Peak drop calculation (for LED matrix)
            if (currentHeights[i] > peakHeights[i]) {
                peakHeights[i] = currentHeights[i]
                peakHoldFrames[i] = 8 // hold for 8 frames
            } else {
                if (peakHoldFrames[i] > 0) {
                    peakHoldFrames[i]--
                } else {
                    peakHeights[i] = (peakHeights[i] - 0.025f).coerceAtLeast(currentHeights[i])
                }
            }
        }

        for (i in 0 until spikeCount) {
            val diff = targetSpikes[i] - currentSpikes[i]
            currentSpikes[i] += diff * 0.40f
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        when (currentModel) {
            MODEL_STUDIO_BARS -> drawStudioBars(canvas, w, h)
            MODEL_RETRO_LED_MATRIX -> drawRetroLedMatrix(canvas, w, h)
            MODEL_CYBERPUNK_LASER -> drawCyberpunkLaser(canvas, w, h)
        }
    }

    // --- Model 0: Studio Symmetrical Bars (Default Style in Screenshot 5487) ---
    private fun drawStudioBars(canvas: Canvas, w: Float, h: Float) {
        val paddingHorizontal = w * 0.07f
        val usableWidth = w - (paddingHorizontal * 2)
        val barSpacing = usableWidth * 0.015f
        val barWidth = (usableWidth - (barSpacing * (barCount - 1))) / barCount
        val cornerRadius = barWidth / 2f
        val centerY = h / 2f

        for (i in 0 until barCount) {
            val left = paddingHorizontal + i * (barWidth + barSpacing)
            val right = left + barWidth
            val barH = (h * 0.72f) * currentHeights[i].coerceIn(0.08f, 0.95f)
            val top = centerY - (barH / 2f)
            val bottom = centerY + (barH / 2f)

            barRect.set(left, top, right, bottom)

            if (isMonochrome) {
                paint.shader = LinearGradient(
                    left, top, left, bottom,
                    Color.WHITE,
                    Color.parseColor("#707070"),
                    Shader.TileMode.CLAMP
                )
            } else {
                paint.shader = LinearGradient(
                    left, top, left, bottom,
                    Color.WHITE,
                    Color.parseColor("#44000000") or (accentColor and 0x00FFFFFF),
                    Shader.TileMode.CLAMP
                )
            }

            canvas.drawRoundRect(barRect, cornerRadius, cornerRadius, paint)
        }
    }

    // --- Model 1: Retro Digital LED Matrix (Image 1 - Stacked Blocks with Peak Drops) ---
    private fun drawRetroLedMatrix(canvas: Canvas, w: Float, h: Float) {
        val paddingHorizontal = w * 0.06f
        val usableWidth = w - (paddingHorizontal * 2)
        val barSpacing = usableWidth * 0.018f
        val barWidth = (usableWidth - (barSpacing * (barCount - 1))) / barCount
        val totalBlocks = 18
        val paddingBottom = h * 0.12f
        val usableHeight = h * 0.76f
        val blockGap = 2.5f
        val blockHeight = (usableHeight - (blockGap * (totalBlocks - 1))) / totalBlocks
        val blockCorner = 2.0f

        for (i in 0 until barCount) {
            val left = paddingHorizontal + i * (barWidth + barSpacing)
            val right = left + barWidth

            val litBlocks = (currentHeights[i] * totalBlocks).toInt().coerceIn(1, totalBlocks)
            val peakBlock = (peakHeights[i] * totalBlocks).toInt().coerceIn(1, totalBlocks)

            for (b in 0 until totalBlocks) {
                val blockBottom = h - paddingBottom - b * (blockHeight + blockGap)
                val blockTop = blockBottom - blockHeight

                barRect.set(left, blockTop, right, blockBottom)

                if (b < litBlocks) {
                    // Block is lit: Color gradient from bottom to top
                    val blockRatio = b.toFloat() / totalBlocks
                    val blockColor = if (isMonochrome) {
                        if (blockRatio > 0.75f) Color.WHITE else Color.parseColor("#B0B0B0")
                    } else {
                        when {
                            blockRatio > 0.82f -> Color.parseColor("#FF5252") // Red top
                            blockRatio > 0.60f -> Color.parseColor("#FFD740") // Yellow mid
                            else -> Color.parseColor("#7C4DFF")               // Deep purple / accent bottom
                        }
                    }
                    paint.shader = null
                    paint.color = blockColor
                    canvas.drawRoundRect(barRect, blockCorner, blockCorner, paint)
                } else if (b == peakBlock && peakBlock >= litBlocks) {
                    // Peak indicator block floating at top
                    paint.shader = null
                    paint.color = if (isMonochrome) Color.WHITE else Color.parseColor("#FF5252")
                    canvas.drawRoundRect(barRect, blockCorner, blockCorner, paint)
                } else {
                    // Unlit faint background block
                    paint.shader = null
                    paint.color = Color.parseColor("#14FFFFFF")
                    canvas.drawRoundRect(barRect, blockCorner, blockCorner, paint)
                }
            }
        }
    }

    // --- Model 2: Cyberpunk Golden Laser Needles (Image 2 - Mirrored Glowing Spikes) ---
    private fun drawCyberpunkLaser(canvas: Canvas, w: Float, h: Float) {
        val paddingHorizontal = w * 0.04f
        val usableWidth = w - (paddingHorizontal * 2)
        val spikeSpacing = usableWidth / spikeCount
        val centerY = h / 2f
        val maxAmplitude = h * 0.42f

        // Draw central glowing baseline
        linePaint.strokeWidth = 2.5f
        linePaint.shader = LinearGradient(
            0f, centerY, w, centerY,
            Color.parseColor("#44FFE082"),
            Color.parseColor("#FFFFFFFF"),
            Shader.TileMode.MIRROR
        )
        canvas.drawLine(0f, centerY, w, centerY, linePaint)

        // Draw fine vertical needle spikes
        linePaint.strokeWidth = 2.0f
        for (i in 0 until spikeCount) {
            val x = paddingHorizontal + i * spikeSpacing
            val spikeH = maxAmplitude * currentSpikes[i].coerceIn(0.05f, 0.98f)
            val top = centerY - spikeH
            val bottom = centerY + spikeH

            if (isMonochrome) {
                linePaint.shader = LinearGradient(
                    x, top, x, bottom,
                    Color.parseColor("#33FFFFFF"),
                    Color.WHITE,
                    Shader.TileMode.MIRROR
                )
            } else {
                // Golden / Amber luxury metallic glow gradient (Image 2 style)
                linePaint.shader = LinearGradient(
                    x, centerY, x, top,
                    Color.parseColor("#FFFFFF"),
                    Color.parseColor("#FFD54F"),
                    Shader.TileMode.CLAMP
                )
            }

            // Draw upper needle spike
            canvas.drawLine(x, centerY, x, top, linePaint)

            // Draw lower mirrored needle spike
            if (!isMonochrome) {
                linePaint.shader = LinearGradient(
                    x, centerY, x, bottom,
                    Color.parseColor("#FFFFFF"),
                    Color.parseColor("#FFB300"),
                    Shader.TileMode.CLAMP
                )
            }
            canvas.drawLine(x, centerY, x, bottom, linePaint)
        }
    }
}
