package com.cleanplayer.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin
import kotlin.random.Random

class AudioVisualizerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val barCount = 28
    private val barRect = RectF()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val currentHeights = FloatArray(barCount) { 0.15f }
    private val targetHeights = FloatArray(barCount) { 0.15f }

    private var isPlaying = false
    private var isMonochrome = false
    private var accentColor = Color.parseColor("#FF9800")
    private var phase = 0.0

    private val animRunnable = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            updateBars()
            invalidate()
            postDelayed(this, 16) // ~60fps
        }
    }

    private var isRunning = false

    fun setMonochrome(mono: Boolean) {
        isMonochrome = mono
        invalidate()
    }

    fun setColor(color: Int) {
        accentColor = color
        invalidate()
    }

    fun setPlaying(playing: Boolean) {
        isPlaying = playing
        if (playing) {
            start()
        }
    }

    fun start() {
        if (!isRunning) {
            isRunning = true
            removeCallbacks(animRunnable)
            post(animRunnable)
        }
    }

    fun stop() {
        isRunning = false
        removeCallbacks(animRunnable)
        // Reset to gentle resting line
        for (i in 0 until barCount) {
            targetHeights[i] = 0.12f
            currentHeights[i] = 0.12f
        }
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isPlaying) start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stop()
    }

    private fun updateBars() {
        phase += 0.08
        if (isPlaying) {
            for (i in 0 until barCount) {
                // Generate a realistic frequency-like spectrum
                val wave1 = sin(phase + i * 0.35)
                val wave2 = sin(phase * 1.5 - i * 0.2)
                val noise = Random.nextFloat() * 0.25f
                val height = (0.25f + (wave1 * wave2).toFloat() * 0.45f + noise).coerceIn(0.10f, 0.95f)
                targetHeights[i] = height
            }
        } else {
            for (i in 0 until barCount) {
                targetHeights[i] = 0.10f
            }
        }

        // Smoothly interpolate current heights towards target
        for (i in 0 until barCount) {
            val diff = targetHeights[i] - currentHeights[i]
            currentHeights[i] += diff * 0.25f
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        val paddingHorizontal = w * 0.08f
        val usableWidth = w - (paddingHorizontal * 2)
        val barSpacing = usableWidth * 0.015f
        val barWidth = (usableWidth - (barSpacing * (barCount - 1))) / barCount
        val cornerRadius = barWidth / 2f
        val centerY = h / 2f

        for (i in 0 until barCount) {
            val left = paddingHorizontal + i * (barWidth + barSpacing)
            val right = left + barWidth
            val barH = (h * 0.70f) * currentHeights[i].coerceIn(0.08f, 0.95f)
            val top = centerY - (barH / 2f)
            val bottom = centerY + (barH / 2f)

            barRect.set(left, top, right, bottom)

            if (isMonochrome) {
                // Monochrome: sleek white to subtle gray gradient
                paint.shader = LinearGradient(
                    left, top, left, bottom,
                    Color.WHITE,
                    Color.parseColor("#707070"),
                    Shader.TileMode.CLAMP
                )
            } else {
                // Colored: Vibrant accent color to darker tone
                paint.shader = LinearGradient(
                    left, top, left, bottom,
                    accentColor,
                    Color.parseColor("#33000000") or (accentColor and 0x00FFFFFF),
                    Shader.TileMode.CLAMP
                )
            }

            canvas.drawRoundRect(barRect, cornerRadius, cornerRadius, paint)
        }
    }
}
