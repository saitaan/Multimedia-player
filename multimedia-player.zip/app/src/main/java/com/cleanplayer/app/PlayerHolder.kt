@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.cleanplayer.app

import android.content.Context
import android.graphics.Color
import androidx.core.content.ContextCompat
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.media3.common.C
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer

object PlayerHolder {
    private const val PREFS_NAME = "multimedia_settings_prefs"

    var mediaPlayer: ExoPlayer? = null
    var currentUri: Uri? = null
    var currentPath: String? = null
    var currentTitle: String = "Media Track"
    var currentArtist: String = "Unknown artist"
    var currentPfd: ParcelFileDescriptor? = null

    // Playlist Queue Management
    val currentPlaylist: MutableList<MediaItem> = mutableListOf()
    var currentTrackIndex: Int = -1
    var isShuffleEnabled: Boolean = false
    var repeatMode: Int = 0 // 0=Off, 1=Repeat One, 2=Repeat All

    // Listeners for UI sync
    var onTrackChangedListener: ((MediaItem) -> Unit)? = null
    var onPlaybackStateChangedListener: ((Boolean) -> Unit)? = null

    // Native Hardware-Accelerated Audio Effects Suite
    var equalizer: Equalizer? = null
    var virtualizer: Virtualizer? = null
    var bassBoost: BassBoost? = null
    var loudnessEnhancer: LoudnessEnhancer? = null

    // Playback Session State
    var isAudioOnly: Boolean = false
    var currentPlaybackSpeed: Float = 1.0f
    var currentAudioDelayMs: Long = 0L
    var currentSpuDelayMs: Long = 0L

    // --- VIDEO QUALITY & COLOR ENHANCER ---
    var videoColorProfile: Int = 1 // 0=Standard, 1=Vivid AMOLED Boost (Recommended), 2=Cinema HDR, 3=Sharp Studio, 4=Custom
    var videoContrast: Float = 1.15f
    var videoBrightness: Float = 1.05f
    var videoSaturation: Float = 1.25f
    var videoGamma: Float = 1.0f
    var isWideColorGamutEnabled: Boolean = true
    var isDeblockingFilterEnabled: Boolean = true
    var isHighRefreshRateEnabled: Boolean = true // Auto 120Hz / Max Display Refresh Rate
    var defaultOrientation: Int = 1 // 0=Auto Sensor, 1=Direct Landscape (Default), 2=Portrait

    // --- INTEGRATED DOLBY, SPATIAL & EQUALIZER AUDIO SUITE ---
    var masterAudioProfile: Int = 0 // 0=Cinema, 1=Music, 2=Speech, 3=Pure, 4=Custom
    var dolbySpatialMode: Int = 1 // 0=Stereo, 1=Dolby 3D Headphone, 2=Dolby ProLogic, 3=Cinema 3D
    var currentEqualizerPreset: Int = 8 // Default Rock/Dynamic
    var isDialogueBoostEnabled: Boolean = true // Dynamic speech clarity boost
    var isDolbyPassthroughEnabled: Boolean = false
    var audioOutputEngine: Int = 0
    var isHeadsetPauseEnabled: Boolean = true
    var isTimeStretchingEnabled: Boolean = true // Pitch lock

    // --- VIDEO SETTINGS ---
    var hwAccelerationMode: Int = 1 // 0=Disabled, 1=Automatic, 2=Decoding Only, 3=Full Acceleration
    var isHardwareDecoding: Boolean
        get() = hwAccelerationMode != 0
        set(value) { hwAccelerationMode = if (value) 1 else 0 }
    var backgroundPipMode: Int = 1 // 0=Stop, 1=Background Play, 2=Picture-in-Picture
    var isBackgroundPlayEnabled: Boolean
        get() = backgroundPipMode == 1
        set(value) { backgroundPipMode = if (value) 1 else 0 }
    var resumeMode: Int = 1 // 0=Never, 1=Ask, 2=Always
    var doubleTapSeekSeconds: Int = 10 // 5, 10, 20, 30
    var defaultAspectRatio: Int = 0 // 0=Best Fit, 1=Fit Screen, 2=Fill Screen, 3=16:9, 4=4:3
    var isAudioBoostEnabled: Boolean = true // Up to 200% volume

    // --- SUBTITLE SETTINGS ---
    var isSubAutoloadEnabled: Boolean = true
    var subFontSize: String = "18"
    var subFontColor: String = "16777215"
    var subBackgroundStyle: Int = 0
    var subFontStyle: Int = 1
    var subEncoding: String = "UTF-8"
    var subPosition: Int = 0 // 0=Bottom, 1=Elevated, 2=Center

    // --- SUBTITLE ADVANCED SETTINGS (Matching Standard Settings) ---
    var isPlaybackHistoryEnabled: Boolean = true
    var isVideoQueueHistoryEnabled: Boolean = true
    var isAudioQueueHistoryEnabled: Boolean = true
    var subPreferredLanguage: String = "No language preference"
    var isSubBold: Boolean = false
    var subFontOpacity: Int = 100
    var isSubBackgroundEnabled: Boolean = false
    var subBackgroundColor: String = "0"
    var subBackgroundOpacity: Int = 60
    var isSubShadowEnabled: Boolean = true
    var subShadowColor: String = "0"
    var subShadowOpacity: Int = 80
    var isSubOutlineEnabled: Boolean = true
    var subOutlineSize: Int = 1 // 0=Thin, 1=Normal, 2=Thick
    var subOutlineColor: String = "0"
    var subOutlineOpacity: Int = 100


    // --- GESTURES & CONTROLS ---
    var isVolumeGestureEnabled: Boolean = true
    var isBrightnessGestureEnabled: Boolean = true
    var isSeekGestureEnabled: Boolean = true
    var isFastSeekEnabled: Boolean = true

    // --- INTERFACE & THEMES ---
    const val THEME_OLED: Int = 0
    const val THEME_CHARCOAL: Int = 1
    const val THEME_MONOCHROME: Int = 2
    var appThemeMode: Int = THEME_OLED

    // --- ADVANCED A-B REPEAT ---
    var abRepeatA: Long = -1L
    var abRepeatB: Long = -1L

    fun isMonochrome(): Boolean = appThemeMode == THEME_MONOCHROME

    fun getPrimaryColor(context: Context): Int {
        return if (isMonochrome()) Color.WHITE else ContextCompat.getColor(context, R.color.theme_primary)
    }

    fun getPrimaryColorInt(): Int {
        return if (isMonochrome()) Color.WHITE else Color.parseColor("#FF8800")
    }

    fun getSecondaryColorInt(): Int {
        return if (isMonochrome()) Color.parseColor("#8E8E93") else Color.parseColor("#9E9E9E")
    }

    fun getNavCheckedColorInt(): Int {
        return if (isMonochrome()) Color.WHITE else Color.parseColor("#FF8800")
    }

    fun getNavUncheckedColorInt(): Int {
        return if (isMonochrome()) Color.parseColor("#8E8E93") else Color.parseColor("#9E9E9E")
    }

    fun getFabBgColorInt(): Int {
        return if (isMonochrome()) Color.WHITE else Color.parseColor("#FF8800")
    }

    fun getFabIconColorInt(): Int {
        return if (isMonochrome()) Color.BLACK else Color.WHITE
    }

    val equalizerPresets = arrayOf(
        "Flat (Off)", "Classical", "Club", "Dance", "Full Bass",
        "Full Treble", "Live", "Party", "Pop", "Rock", "Soft", "Techno", "Vocal"
    )

    val masterProfileNames = arrayOf(
        "Cinema 3D & Dolby (Immersive Movies)",
        "Music & Bass Boost (Concert Hall)",
        "Speech & Dialogue Clarity (Night Mode)",
        "Pure Studio (Flat & Natural)",
        "Custom Configuration"
    )

    val videoProfileNames = arrayOf(
        "Standard / Natural (Original)",
        "Vivid / AMOLED Boost (Vibrant & Punchy)",
        "Cinema / HDR Effect (Deep Contrast)",
        "Sharp & Crisp (Enhanced Details)",
        "Custom Tuning"
    )

    fun applyVideoColorProfile(profileIndex: Int) {
        videoColorProfile = profileIndex
        when (profileIndex) {
            0 -> {
                videoContrast = 1.0f
                videoBrightness = 1.0f
                videoSaturation = 1.0f
                videoGamma = 1.0f
            }
            1 -> {
                videoContrast = 1.15f
                videoBrightness = 1.05f
                videoSaturation = 1.25f
                videoGamma = 1.0f
            }
            2 -> {
                videoContrast = 1.20f
                videoBrightness = 1.02f
                videoSaturation = 1.18f
                videoGamma = 1.08f
            }
            3 -> {
                videoContrast = 1.10f
                videoBrightness = 1.0f
                videoSaturation = 1.10f
                videoGamma = 1.0f
            }
        }
    }

    fun applyMasterProfile(profileIndex: Int) {
        masterAudioProfile = profileIndex
        when (profileIndex) {
            0 -> {
                dolbySpatialMode = 1
                currentEqualizerPreset = 8
                isDialogueBoostEnabled = true
            }
            1 -> {
                dolbySpatialMode = 3
                currentEqualizerPreset = 3
                isDialogueBoostEnabled = false
            }
            2 -> {
                dolbySpatialMode = 2
                currentEqualizerPreset = 11
                isDialogueBoostEnabled = true
            }
            3 -> {
                dolbySpatialMode = 0
                currentEqualizerPreset = -1
                isDialogueBoostEnabled = false
            }
        }
    }

    fun loadPreferences(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        videoColorProfile = prefs.getInt("video_color_profile", 1)
        videoContrast = prefs.getFloat("video_contrast", 1.15f)
        videoBrightness = prefs.getFloat("video_brightness", 1.05f)
        videoSaturation = prefs.getFloat("video_saturation", 1.25f)
        videoGamma = prefs.getFloat("video_gamma", 1.0f)
        isWideColorGamutEnabled = prefs.getBoolean("wide_color_gamut", true)
        isDeblockingFilterEnabled = prefs.getBoolean("deblocking_filter", true)
        isHighRefreshRateEnabled = prefs.getBoolean("high_refresh_rate", true)
        defaultOrientation = prefs.getInt("default_orientation", 1)

        masterAudioProfile = prefs.getInt("master_audio_profile", 0)
        dolbySpatialMode = prefs.getInt("dolby_spatial_mode", 1)
        currentEqualizerPreset = prefs.getInt("equalizer_preset", 8)
        isDialogueBoostEnabled = prefs.getBoolean("dialogue_boost", true)
        isDolbyPassthroughEnabled = prefs.getBoolean("dolby_passthrough", false)
        audioOutputEngine = prefs.getInt("audio_output_engine", 0)
        isHeadsetPauseEnabled = prefs.getBoolean("headset_pause", true)
        isTimeStretchingEnabled = prefs.getBoolean("time_stretching", true)

        hwAccelerationMode = prefs.getInt("hw_acceleration_mode", 1)
        backgroundPipMode = prefs.getInt("background_pip_mode", 1)
        resumeMode = prefs.getInt("resume_mode", 1)
        doubleTapSeekSeconds = prefs.getInt("double_tap_seek", 10)
        defaultAspectRatio = prefs.getInt("default_aspect_ratio", 0)
        isAudioBoostEnabled = prefs.getBoolean("audio_boost", true)

        isSubAutoloadEnabled = prefs.getBoolean("sub_autoload", true)
        subFontSize = prefs.getString("sub_font_size", "18") ?: "18"
        subFontColor = prefs.getString("sub_font_color", "16777215") ?: "16777215"
        subBackgroundStyle = prefs.getInt("sub_background_style", 0)
        subFontStyle = prefs.getInt("sub_font_style", 1)
        subEncoding = prefs.getString("sub_encoding", "UTF-8") ?: "UTF-8"
        subPosition = prefs.getInt("sub_position", 0)

        isPlaybackHistoryEnabled = prefs.getBoolean("playback_history", true)
        isVideoQueueHistoryEnabled = prefs.getBoolean("video_queue_history", true)
        isAudioQueueHistoryEnabled = prefs.getBoolean("audio_queue_history", true)
        subPreferredLanguage = prefs.getString("sub_pref_lang", "No language preference") ?: "No language preference"
        isSubBold = prefs.getBoolean("sub_bold", false)
        subFontOpacity = prefs.getInt("sub_font_opacity", 100)
        isSubBackgroundEnabled = prefs.getBoolean("sub_bg_enabled", false)
        subBackgroundColor = prefs.getString("sub_bg_color", "0") ?: "0"
        subBackgroundOpacity = prefs.getInt("sub_bg_opacity", 60)
        isSubShadowEnabled = prefs.getBoolean("sub_shadow_enabled", true)
        subShadowColor = prefs.getString("sub_shadow_color", "0") ?: "0"
        subShadowOpacity = prefs.getInt("sub_shadow_opacity", 80)
        isSubOutlineEnabled = prefs.getBoolean("sub_outline_enabled", true)
        subOutlineSize = prefs.getInt("sub_outline_size", 1)
        subOutlineColor = prefs.getString("sub_outline_color", "0") ?: "0"
        subOutlineOpacity = prefs.getInt("sub_outline_opacity", 100)


        isVolumeGestureEnabled = prefs.getBoolean("gesture_volume", true)
        isBrightnessGestureEnabled = prefs.getBoolean("gesture_brightness", true)
        isSeekGestureEnabled = prefs.getBoolean("gesture_seek", true)
        isFastSeekEnabled = prefs.getBoolean("fast_seek", true)

        appThemeMode = prefs.getInt("app_theme_mode", 0)
    }

    fun savePreferences(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().apply {
            putInt("video_color_profile", videoColorProfile)
            putFloat("video_contrast", videoContrast)
            putFloat("video_brightness", videoBrightness)
            putFloat("video_saturation", videoSaturation)
            putFloat("video_gamma", videoGamma)
            putBoolean("wide_color_gamut", isWideColorGamutEnabled)
            putBoolean("deblocking_filter", isDeblockingFilterEnabled)
            putBoolean("high_refresh_rate", isHighRefreshRateEnabled)
            putInt("default_orientation", defaultOrientation)

            putInt("master_audio_profile", masterAudioProfile)
            putInt("dolby_spatial_mode", dolbySpatialMode)
            putInt("equalizer_preset", currentEqualizerPreset)
            putBoolean("dialogue_boost", isDialogueBoostEnabled)
            putBoolean("dolby_passthrough", isDolbyPassthroughEnabled)
            putInt("audio_output_engine", audioOutputEngine)
            putBoolean("headset_pause", isHeadsetPauseEnabled)
            putBoolean("time_stretching", isTimeStretchingEnabled)

            putInt("hw_acceleration_mode", hwAccelerationMode)
            putInt("background_pip_mode", backgroundPipMode)
            putInt("resume_mode", resumeMode)
            putInt("double_tap_seek", doubleTapSeekSeconds)
            putInt("default_aspect_ratio", defaultAspectRatio)
            putBoolean("audio_boost", isAudioBoostEnabled)

            putBoolean("sub_autoload", isSubAutoloadEnabled)
            putString("sub_font_size", subFontSize)
            putString("sub_font_color", subFontColor)
            putInt("sub_background_style", subBackgroundStyle)
            putInt("sub_font_style", subFontStyle)
            putString("sub_encoding", subEncoding)
            putInt("sub_position", subPosition)

            putBoolean("playback_history", isPlaybackHistoryEnabled)
            putBoolean("video_queue_history", isVideoQueueHistoryEnabled)
            putBoolean("audio_queue_history", isAudioQueueHistoryEnabled)
            putString("sub_pref_lang", subPreferredLanguage)
            putBoolean("sub_bold", isSubBold)
            putInt("sub_font_opacity", subFontOpacity)
            putBoolean("sub_bg_enabled", isSubBackgroundEnabled)
            putString("sub_bg_color", subBackgroundColor)
            putInt("sub_bg_opacity", subBackgroundOpacity)
            putBoolean("sub_shadow_enabled", isSubShadowEnabled)
            putString("sub_shadow_color", subShadowColor)
            putInt("sub_shadow_opacity", subShadowOpacity)
            putBoolean("sub_outline_enabled", isSubOutlineEnabled)
            putInt("sub_outline_size", subOutlineSize)
            putString("sub_outline_color", subOutlineColor)
            putInt("sub_outline_opacity", subOutlineOpacity)


            putBoolean("gesture_volume", isVolumeGestureEnabled)
            putBoolean("gesture_brightness", isBrightnessGestureEnabled)
            putBoolean("gesture_seek", isSeekGestureEnabled)
            putBoolean("fast_seek", isFastSeekEnabled)

            putInt("app_theme_mode", appThemeMode)
            apply()
        }
    }

    fun resetPreferences(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
        loadPreferences(context)
    }

    fun setPlaylistAndPlay(context: Context, playlist: List<MediaItem>, startIndex: Int) {
        currentPlaylist.clear()
        currentPlaylist.addAll(playlist)
        playTrackAtIndex(context, startIndex)
    }

    fun playTrackAtIndex(context: Context, index: Int, resumeTimeMs: Long = 0L) {
        if (index !in currentPlaylist.indices) return
        currentTrackIndex = index
        val item = currentPlaylist[index]
        currentUri = item.uri
        currentPath = item.filePath
        currentTitle = item.title
        currentArtist = item.artist ?: "Unknown artist"
        isAudioOnly = !item.isVideo

        val player = initPlayer(context, item.uri, item.filePath, isHardwareDecoding, item.title)
        if (resumeTimeMs > 0) {
            player.seekTo(resumeTimeMs)
        }
        player.play()

        if (!item.isVideo) {
            MediaPlaybackService.start(context, currentTitle, currentArtist, isPlaying = true)
        }
        onTrackChangedListener?.invoke(item)
    }

    fun playNext(context: Context): Boolean {
        if (currentPlaylist.isEmpty()) return false
        val nextIdx = if (isShuffleEnabled) {
            val candidates = currentPlaylist.indices.filter { it != currentTrackIndex }
            if (candidates.isNotEmpty()) candidates.random() else currentTrackIndex
        } else {
            if (currentTrackIndex + 1 < currentPlaylist.size) {
                currentTrackIndex + 1
            } else if (repeatMode == 2) {
                0
            } else {
                -1
            }
        }

        if (nextIdx in currentPlaylist.indices) {
            playTrackAtIndex(context, nextIdx)
            return true
        }
        return false
    }

    fun playPrevious(context: Context): Boolean {
        if (currentPlaylist.isEmpty()) return false
        mediaPlayer?.let { player ->
            if (player.currentPosition > 3000L) {
                player.seekTo(0L)
                return true
            }
        }
        val prevIdx = if (currentTrackIndex - 1 >= 0) {
            currentTrackIndex - 1
        } else if (repeatMode == 2) {
            currentPlaylist.size - 1
        } else {
            0
        }

        if (prevIdx in currentPlaylist.indices) {
            playTrackAtIndex(context, prevIdx)
            return true
        }
        return false
    }

    fun toggleRepeatMode(): Int {
        repeatMode = when (repeatMode) {
            0 -> 2 // Repeat All
            2 -> 1 // Repeat One
            else -> 0 // Off
        }
        mediaPlayer?.repeatMode = when (repeatMode) {
            1 -> Player.REPEAT_MODE_ONE
            2 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        return repeatMode
    }

    fun toggleShuffle(): Boolean {
        isShuffleEnabled = !isShuffleEnabled
        return isShuffleEnabled
    }

    fun resolveMediaTitle(context: Context, uri: Uri, path: String?): String {
        try {
            context.contentResolver.query(
                uri,
                arrayOf(android.provider.MediaStore.MediaColumns.TITLE, android.provider.MediaStore.MediaColumns.DISPLAY_NAME),
                null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val tIdx = cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.TITLE)
                    val nIdx = cursor.getColumnIndex(android.provider.MediaStore.MediaColumns.DISPLAY_NAME)
                    val tVal = if (tIdx != -1) cursor.getString(tIdx) else null
                    val nVal = if (nIdx != -1) cursor.getString(nIdx) else null
                    val candidate = when {
                        !tVal.isNullOrBlank() && !tVal.all { it.isDigit() } -> MediaScanner.cleanMediaTitle(tVal)
                        !nVal.isNullOrBlank() && !nVal.substringBeforeLast('.').all { it.isDigit() } -> MediaScanner.cleanMediaTitle(nVal)
                        !tVal.isNullOrBlank() -> MediaScanner.cleanMediaTitle(tVal)
                        !nVal.isNullOrBlank() -> MediaScanner.cleanMediaTitle(nVal)
                        else -> null
                    }
                    if (!candidate.isNullOrBlank()) return candidate
                }
            }
        } catch (e: Exception) {}

        if (!path.isNullOrBlank()) {
            val f = java.io.File(path)
            if (f.exists() && f.name.isNotBlank()) {
                val fName = f.name
                if (!fName.substringBeforeLast('.').all { it.isDigit() }) {
                    return MediaScanner.cleanMediaTitle(fName)
                }
            }
        }

        val seg = uri.lastPathSegment?.substringAfterLast('/')
        if (!seg.isNullOrBlank() && !seg.all { it.isDigit() }) {
            return MediaScanner.cleanMediaTitle(seg)
        }

        return "Media Track"
    }

    fun initPlayer(context: Context, uri: Uri, path: String?, hwDecode: Boolean, title: String? = null): ExoPlayer {
        release()
        currentUri = uri
        currentPath = path

        val resolved = when {
            !title.isNullOrBlank() && !title.all { it.isDigit() } -> title
            !currentTitle.isNullOrBlank() && !currentTitle.all { it.isDigit() } && currentTitle != "Media Track" -> currentTitle
            else -> resolveMediaTitle(context, uri, path)
        }
        currentTitle = resolved

        val renderersFactory = DefaultRenderersFactory(context.applicationContext).apply {
            setEnableDecoderFallback(true)
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        }

        val extractorsFactory = androidx.media3.extractor.DefaultExtractorsFactory().apply {
            setConstantBitrateSeekingEnabled(true)
        }
        val mediaSourceFactory = androidx.media3.exoplayer.source.DefaultMediaSourceFactory(context.applicationContext, extractorsFactory)

        val player = ExoPlayer.Builder(context.applicationContext, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setSeekBackIncrementMs(doubleTapSeekSeconds * 1000L)
            .setSeekForwardIncrementMs(doubleTapSeekSeconds * 1000L)
            .setSeekParameters(androidx.media3.exoplayer.SeekParameters.DEFAULT)
            .build()

        mediaPlayer = player

        val playbackUri = if (uri != null && uri != android.net.Uri.EMPTY) {
            uri
        } else if (!path.isNullOrBlank()) {
            val file = java.io.File(path)
            if (file.exists() && file.canRead()) {
                android.net.Uri.fromFile(file)
            } else {
                android.net.Uri.parse(path)
            }
        } else {
            uri ?: android.net.Uri.EMPTY
        }
        val mediaItem = ExoMediaItem.fromUri(playbackUri)
        player.setMediaItem(mediaItem)
        player.prepare()

        if (currentPlaybackSpeed != 1.0f) {
            player.playbackParameters = PlaybackParameters(currentPlaybackSpeed)
        }

        player.repeatMode = when (repeatMode) {
            1 -> Player.REPEAT_MODE_ONE
            2 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                onPlaybackStateChangedListener?.invoke(isPlaying)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    val cur = player.currentPosition
                    val dur = player.duration
                    val trulyEnded = dur > 0 && cur >= (dur - 2500L)
                    if (!trulyEnded) return
                    if (repeatMode == 1) {
                        player.seekTo(0)
                        player.play()
                    } else if (isAudioOnly) {
                        val hasNext = playNext(context)
                        if (!hasNext) {
                            player.seekTo(0)
                            player.pause()
                            MediaPlaybackService.start(context, currentTitle, currentArtist, isPlaying = false)
                        }
                    }
                }
            }
        })

        try {
            applyAudioEffects(player.audioSessionId)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return player
    }

    fun applyAudioEffects(audioSessionId: Int) {
        if (audioSessionId == C.AUDIO_SESSION_ID_UNSET) return
        activeAudioSessionId = audioSessionId

        try {
            // 1. Equalizer
            equalizer?.release()
            equalizer = Equalizer(0, audioSessionId).apply {
                if (currentEqualizerPreset in 0 until numberOfPresets) {
                    usePreset(currentEqualizerPreset.toShort())
                    enabled = true
                } else {
                    enabled = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            // 2. Dolby & Spatial Virtualizer (3D Audio)
            virtualizer?.release()
            virtualizer = Virtualizer(0, audioSessionId).apply {
                if (dolbySpatialMode > 0) {
                    enabled = true
                    val strength = when (dolbySpatialMode) {
                        1 -> 1000.toShort() // 3D Binaural Headphone
                        2 -> 750.toShort()  // Dolby Surround Matrix
                        3 -> 950.toShort()  // Cinema 3D Wide
                        else -> 500.toShort()
                    }
                    setStrength(strength)
                } else {
                    enabled = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            // 3. Bass Boost
            bassBoost?.release()
            bassBoost = BassBoost(0, audioSessionId).apply {
                if (masterAudioProfile == 1 || currentEqualizerPreset == 4) {
                    enabled = true
                    setStrength(800.toShort())
                } else {
                    enabled = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            // 4. Dialogue Boost / Speech Clarity (LoudnessEnhancer)
            loudnessEnhancer?.release()
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply {
                if (isDialogueBoostEnabled) {
                    enabled = true
                    setTargetGain(600) // 6dB dynamic dialogue gain boost
                } else {
                    enabled = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    var currentBoostGainMb: Int = 0

    var activeAudioSessionId: Int = 0

    fun setVolumeBoostGain(gainMb: Int) {
        currentBoostGainMb = gainMb.coerceIn(0, 2000)
        try {
            val sId = mediaPlayer?.audioSessionId ?: activeAudioSessionId
            if (loudnessEnhancer == null && sId != 0 && sId != C.AUDIO_SESSION_ID_UNSET) {
                loudnessEnhancer = LoudnessEnhancer(sId)
            }
            loudnessEnhancer?.let {
                if (currentBoostGainMb > 0 || isDialogueBoostEnabled) {
                    it.enabled = true
                    val totalGain = (if (isDialogueBoostEnabled) 600 else 0) + currentBoostGainMb
                    it.setTargetGain(totalGain)
                } else {
                    it.enabled = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun release() {
        try {
            equalizer?.release()
        } catch (e: Exception) {}
        equalizer = null

        try {
            virtualizer?.release()
        } catch (e: Exception) {}
        virtualizer = null

        try {
            bassBoost?.release()
        } catch (e: Exception) {}
        bassBoost = null

        try {
            loudnessEnhancer?.release()
        } catch (e: Exception) {}
        loudnessEnhancer = null

        mediaPlayer?.let {
            try {
                it.stop()
            } catch (e: Exception) {}
            try {
                it.release()
            } catch (e: Exception) {}
        }
        mediaPlayer = null

        currentPfd?.let {
            try {
                it.close()
            } catch (e: Exception) {}
        }
        currentPfd = null
    }
}
