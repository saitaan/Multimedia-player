package com.cleanplayer.app

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import java.io.File
import java.util.Locale

object PlayerHolder {
    private const val PREFS_NAME = "multimedia_settings_prefs"

    var libVLC: LibVLC? = null
    var mediaPlayer: MediaPlayer? = null
    var currentUri: Uri? = null
    var currentPath: String? = null
    var currentTitle: String = "Media Track"
    var currentPfd: ParcelFileDescriptor? = null

    // Playback Session State
    var isAudioOnly: Boolean = false
    var currentPlaybackSpeed: Float = 1.0f
    var currentAudioDelayMs: Long = 0L
    var currentSpuDelayMs: Long = 0L

    // --- VIDEO QUALITY & COLOR ENHANCER ---
    // 0=Standard / Natural, 1=Vivid AMOLED Boost (Recommended), 2=Cinema HDR Effect, 3=Sharp & Crisp, 4=Custom
    var videoColorProfile: Int = 1
    var videoContrast: Float = 1.15f
    var videoBrightness: Float = 1.05f
    var videoSaturation: Float = 1.25f
    var videoGamma: Float = 1.0f
    var isWideColorGamutEnabled: Boolean = true
    var isDeblockingFilterEnabled: Boolean = true

    // --- INTEGRATED DOLBY, SPATIAL & EQUALIZER AUDIO SUITE ---
    var masterAudioProfile: Int = 0 // 0=Cinema, 1=Music, 2=Speech, 3=Pure, 4=Custom
    var dolbySpatialMode: Int = 1 // 0=Stereo, 1=Dolby 3D Headphone, 2=Dolby ProLogic, 3=Cinema 3D
    var currentEqualizerPreset: Int = 8 // Default Rock/Dynamic
    var isDialogueBoostEnabled: Boolean = true // Dynamic range compression
    var isDolbyPassthroughEnabled: Boolean = false // HDMI/SPDIF bitstream
    var audioOutputEngine: Int = 0 // 0=AudioTrack, 1=OpenSL ES, 2=AAudio
    var isHeadsetPauseEnabled: Boolean = true
    var isTimeStretchingEnabled: Boolean = true // Pitch lock

    // --- VIDEO SETTINGS ---
    var hwAccelerationMode: Int = 1 // 0=Disabled, 1=Automatic, 2=Decoding Only, 3=Full Acceleration
    var isHardwareDecoding: Boolean
        get() = hwAccelerationMode != 0
        set(value) { hwAccelerationMode = if (value) 1 else 0 }
    var backgroundPipMode: Int = 1 // 0=Stop, 1=Background Play, 2=Picture-in-Picture
    var isBackgroundPlayEnabled: Boolean
        get() = backgroundPipMode == 1
        set(value) { backgroundPipMode = if (value) 1 else 0 }
    var resumeMode: Int = 1 // 0=Never, 1=Ask, 2=Always
    var doubleTapSeekSeconds: Int = 10 // 5, 10, 20, 30
    var defaultAspectRatio: Int = 0 // 0=Best Fit, 1=Fit Screen, 2=Fill Screen, 3=16:9, 4=4:3
    var isAudioBoostEnabled: Boolean = true // Up to 200% volume

    // --- SUBTITLE SETTINGS ---
    var isSubAutoloadEnabled: Boolean = true
    var subFontSize: String = "18"
    var subFontColor: String = "16777215"
    var subBackgroundStyle: Int = 0
    var subFontStyle: Int = 1
    var subEncoding: String = "UTF-8"

    // --- GESTURES & CONTROLS ---
    var isVolumeGestureEnabled: Boolean = true
    var isBrightnessGestureEnabled: Boolean = true
    var isSeekGestureEnabled: Boolean = true
    var isFastSeekEnabled: Boolean = true

    // --- INTERFACE ---
    var appThemeMode: Int = 0 // 0=Pure Black OLED, 1=Dark Charcoal

    val equalizerPresets = arrayOf(
        "Flat (Off)", "Classical", "Club", "Dance", "Full Bass",
        "Full Treble", "Live", "Party", "Pop", "Rock", "Soft", "Techno", "Vocal"
    )

    val masterProfileNames = arrayOf(
        "Cinema 3D & Dolby (Immersive Movies)",
        "Music & Bass Boost (Concert Hall)",
        "Speech & Dialogue Clarity (Night Mode)",
        "Pure Studio (Flat & Natural)",
        "Custom Configuration"
    )

    val videoProfileNames = arrayOf(
        "Standard / Natural (Original)",
        "Vivid / AMOLED Boost (Vibrant & Punchy)",
        "Cinema / HDR Effect (Deep Contrast)",
        "Sharp & Crisp (Enhanced Details)",
        "Custom Tuning"
    )

    fun applyVideoColorProfile(profileIndex: Int) {
        videoColorProfile = profileIndex
        when (profileIndex) {
            0 -> { // Standard
                videoContrast = 1.0f
                videoBrightness = 1.0f
                videoSaturation = 1.0f
                videoGamma = 1.0f
            }
            1 -> { // Vivid AMOLED Boost
                videoContrast = 1.15f
                videoBrightness = 1.05f
                videoSaturation = 1.25f
                videoGamma = 1.0f
            }
            2 -> { // Cinema HDR Effect
                videoContrast = 1.20f
                videoBrightness = 1.02f
                videoSaturation = 1.18f
                videoGamma = 1.08f
            }
            3 -> { // Sharp & Crisp
                videoContrast = 1.10f
                videoBrightness = 1.0f
                videoSaturation = 1.10f
                videoGamma = 1.0f
            }
        }
    }

    fun applyMasterProfile(profileIndex: Int) {
        masterAudioProfile = profileIndex
        when (profileIndex) {
            0 -> {
                dolbySpatialMode = 1
                currentEqualizerPreset = 8
                isDialogueBoostEnabled = true
            }
            1 -> {
                dolbySpatialMode = 3
                currentEqualizerPreset = 3
                isDialogueBoostEnabled = false
            }
            2 -> {
                dolbySpatialMode = 2
                currentEqualizerPreset = 11
                isDialogueBoostEnabled = true
            }
            3 -> {
                dolbySpatialMode = 0
                currentEqualizerPreset = -1
                isDialogueBoostEnabled = false
            }
        }
    }

    fun loadPreferences(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // Video Color & Quality
        videoColorProfile = prefs.getInt("video_color_profile", 1)
        videoContrast = prefs.getFloat("video_contrast", 1.15f)
        videoBrightness = prefs.getFloat("video_brightness", 1.05f)
        videoSaturation = prefs.getFloat("video_saturation", 1.25f)
        videoGamma = prefs.getFloat("video_gamma", 1.0f)
        isWideColorGamutEnabled = prefs.getBoolean("wide_color_gamut", true)
        isDeblockingFilterEnabled = prefs.getBoolean("deblocking_filter", true)

        // Audio Profiles & Dolby
        masterAudioProfile = prefs.getInt("master_audio_profile", 0)
        dolbySpatialMode = prefs.getInt("dolby_spatial_mode", 1)
        currentEqualizerPreset = prefs.getInt("equalizer_preset", 8)
        isDialogueBoostEnabled = prefs.getBoolean("dialogue_boost", true)
        isDolbyPassthroughEnabled = prefs.getBoolean("dolby_passthrough", false)
        audioOutputEngine = prefs.getInt("audio_output_engine", 0)
        isHeadsetPauseEnabled = prefs.getBoolean("headset_pause", true)
        isTimeStretchingEnabled = prefs.getBoolean("time_stretching", true)

        // Video Settings
        hwAccelerationMode = prefs.getInt("hw_acceleration_mode", 1)
        backgroundPipMode = prefs.getInt("background_pip_mode", 1)
        resumeMode = prefs.getInt("resume_mode", 1)
        doubleTapSeekSeconds = prefs.getInt("double_tap_seek", 10)
        defaultAspectRatio = prefs.getInt("default_aspect_ratio", 0)
        isAudioBoostEnabled = prefs.getBoolean("audio_boost", true)

        // Subtitles
        isSubAutoloadEnabled = prefs.getBoolean("sub_autoload", true)
        subFontSize = prefs.getString("sub_font_size", "18") ?: "18"
        subFontColor = prefs.getString("sub_font_color", "16777215") ?: "16777215"
        subBackgroundStyle = prefs.getInt("sub_background_style", 0)
        subFontStyle = prefs.getInt("sub_font_style", 1)
        subEncoding = prefs.getString("sub_encoding", "UTF-8") ?: "UTF-8"

        // Gestures
        isVolumeGestureEnabled = prefs.getBoolean("gesture_volume", true)
        isBrightnessGestureEnabled = prefs.getBoolean("gesture_brightness", true)
        isSeekGestureEnabled = prefs.getBoolean("gesture_seek", true)
        isFastSeekEnabled = prefs.getBoolean("fast_seek", true)

        appThemeMode = prefs.getInt("app_theme_mode", 0)
    }

    fun savePreferences(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().apply {
            putInt("video_color_profile", videoColorProfile)
            putFloat("video_contrast", videoContrast)
            putFloat("video_brightness", videoBrightness)
            putFloat("video_saturation", videoSaturation)
            putFloat("video_gamma", videoGamma)
            putBoolean("wide_color_gamut", isWideColorGamutEnabled)
            putBoolean("deblocking_filter", isDeblockingFilterEnabled)

            putInt("master_audio_profile", masterAudioProfile)
            putInt("dolby_spatial_mode", dolbySpatialMode)
            putInt("equalizer_preset", currentEqualizerPreset)
            putBoolean("dialogue_boost", isDialogueBoostEnabled)
            putBoolean("dolby_passthrough", isDolbyPassthroughEnabled)
            putInt("audio_output_engine", audioOutputEngine)
            putBoolean("headset_pause", isHeadsetPauseEnabled)
            putBoolean("time_stretching", isTimeStretchingEnabled)

            putInt("hw_acceleration_mode", hwAccelerationMode)
            putInt("background_pip_mode", backgroundPipMode)
            putInt("resume_mode", resumeMode)
            putInt("double_tap_seek", doubleTapSeekSeconds)
            putInt("default_aspect_ratio", defaultAspectRatio)
            putBoolean("audio_boost", isAudioBoostEnabled)

            putBoolean("sub_autoload", isSubAutoloadEnabled)
            putString("sub_font_size", subFontSize)
            putString("sub_font_color", subFontColor)
            putInt("sub_background_style", subBackgroundStyle)
            putInt("sub_font_style", subFontStyle)
            putString("sub_encoding", subEncoding)

            putBoolean("gesture_volume", isVolumeGestureEnabled)
            putBoolean("gesture_brightness", isBrightnessGestureEnabled)
            putBoolean("gesture_seek", isSeekGestureEnabled)
            putBoolean("fast_seek", isFastSeekEnabled)

            putInt("app_theme_mode", appThemeMode)
            apply()
        }
    }

    fun resetPreferences(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().apply()
        loadPreferences(context)
    }

    private fun getOrCreateLibVLC(context: Context): LibVLC {
        val existing = libVLC
        if (existing != null && !existing.isReleased) {
            return existing
        }

        val options = ArrayList<String>().apply {
            // Video & Decoding Performance (Multi-threaded & Zero-lag)
            add("--avcodec-threads=0") // Automatic core threading
            add("--file-caching=2000") // 2000ms buffer for stutter-free local playback
            add("--network-caching=2000")
            add("--live-caching=1500")

            // Studio High-Fidelity Audio Resampler (32-bit floating point precision)
            add("--audio-resampler=soxr")

            // Time stretching (Pitch preservation)
            if (isTimeStretchingEnabled) {
                add("--audio-time-stretch")
            } else {
                add("--no-audio-time-stretch")
            }

            // Low-Latency Audio Rendering Output
            when (audioOutputEngine) {
                1 -> add("--aout=opensles")
                2 -> add("--aout=aaudio")
                else -> {} // Default AudioTrack
            }

            // Audio Filters Pipeline
            val audioFilters = mutableListOf<String>()

            // 1. Dialogue Boost & Dynamic Range Compression (Normvol)
            if (isDialogueBoostEnabled) {
                audioFilters.add("normvol")
                add("--norm-buff-size=10")
                add("--norm-max-level=1.6")
            }

            // 2. Dolby & Spatial Virtualizer Processing
            when (dolbySpatialMode) {
                1 -> {
                    add("--stereo-mode=2") // Headphones 3D Binaural
                    audioFilters.add("headphone")
                }
                2 -> {
                    add("--stereo-mode=3") // Dolby Surround Matrix
                }
                3 -> {
                    audioFilters.add("spatializer")
                    add("--spatializer-roomsize=1.1")
                    add("--spatializer-width=10.0")
                    add("--spatializer-wet=3.0")
                    add("--spatializer-dry=2.0")
                    add("--spatializer-damp=0.2")
                }
                else -> {
                    add("--stereo-mode=1") // Standard Stereo
                }
            }

            if (audioFilters.isNotEmpty()) {
                add("--audio-filter=${audioFilters.joinToString(",")}")
            }

            // Digital Audio Bitstream Passthrough (HDMI / S/PDIF)
            if (isDolbyPassthroughEnabled) {
                add("--spdif")
            }

            // Video Color & Visual Enhancement Pipeline
            if (videoColorProfile != 0 || videoContrast != 1.0f || videoSaturation != 1.0f || videoBrightness != 1.0f || videoGamma != 1.0f) {
                add("--video-filter=adjust")
                add(String.format(Locale.US, "--contrast=%.2f", videoContrast))
                add(String.format(Locale.US, "--brightness=%.2f", videoBrightness))
                add(String.format(Locale.US, "--saturation=%.2f", videoSaturation))
                add(String.format(Locale.US, "--gamma=%.2f", videoGamma))
            }

            // High-Quality Visual Post-Processing & Deblocking
            if (isDeblockingFilterEnabled) {
                add("--postproc-q=6") // Maximum in-loop deblocking filter
                add("--avcodec-skiploopfilter=0") // Full deblocking
                add("--swscale-mode=2") // Bicubic high quality scaling
            } else {
                add("--swscale-mode=0") // Fast bilinear
            }

            // Fast seek (Keyframes)
            if (isFastSeekEnabled) {
                add("--fast-seek")
            } else {
                add("--no-fast-seek")
            }

            // Subtitle Options
            if (isSubAutoloadEnabled) {
                add("--sub-autodetect-file")
                add("--sub-autodetect-fuzzy=3")
            } else {
                add("--no-sub-autodetect-file")
            }
            add("--subsdec-encoding=$subEncoding")
            add("--freetype-fontsize=$subFontSize")
            add("--freetype-color=$subFontColor")

            // Subtitle Background Style
            when (subBackgroundStyle) {
                1 -> add("--freetype-background-opacity=128")
                2 -> add("--freetype-background-opacity=255")
                else -> add("--freetype-background-opacity=0")
            }

            // Subtitle Font Style
            if (subFontStyle == 1) {
                add("--freetype-bold")
            } else {
                add("--no-freetype-bold")
            }
        }

        val instance = LibVLC(context.applicationContext, options)
        libVLC = instance
        return instance
    }

    fun initPlayer(context: Context, uri: Uri, path: String?, hwDecode: Boolean): MediaPlayer {
        release()
        currentUri = uri
        currentPath = path
        currentTitle = uri.lastPathSegment?.substringAfterLast('/') ?: "Media Track"

        val vlc = getOrCreateLibVLC(context)
        val player = MediaPlayer(vlc)
        mediaPlayer = player

        val media: Media = try {
            if (!path.isNullOrEmpty() && File(path).canRead()) {
                Media(vlc, path)
            } else if (uri.scheme == "content") {
                val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                currentPfd = pfd
                if (pfd != null) {
                    Media(vlc, pfd.fileDescriptor)
                } else {
                    Media(vlc, uri)
                }
            } else {
                Media(vlc, uri)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Media(vlc, uri)
        }

        // Apply Hardware Acceleration Mode safely
        when (hwAccelerationMode) {
            0 -> media.setHWDecoderEnabled(false, false)
            1 -> media.setHWDecoderEnabled(true, false)
            2 -> media.setHWDecoderEnabled(true, false)
            3 -> media.setHWDecoderEnabled(true, true)
            else -> media.setHWDecoderEnabled(hwDecode, false)
        }

        player.media = media
        media.release()

        // Apply Speed
        if (currentPlaybackSpeed != 1.0f) {
            player.rate = currentPlaybackSpeed
        }

        // Apply Audio Delay
        if (currentAudioDelayMs != 0L) {
            player.setAudioDelay(currentAudioDelayMs * 1000L)
        }

        // Apply Subtitle Delay
        if (currentSpuDelayMs != 0L) {
            player.setSpuDelay(currentSpuDelayMs * 1000L)
        }

        // Apply Integrated Equalizer
        applyEqualizerToPlayer(player)

        return player
    }

    fun applyEqualizerToPlayer(player: MediaPlayer) {
        try {
            if (currentEqualizerPreset >= 0 && currentEqualizerPreset < MediaPlayer.Equalizer.getPresetCount()) {
                val eq = MediaPlayer.Equalizer.createFromPreset(currentEqualizerPreset)
                player.setEqualizer(eq)
            } else {
                player.setEqualizer(null)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun release() {
        currentPfd?.let {
            try {
                it.close()
            } catch (e: Exception) {}
        }
        currentPfd = null

        mediaPlayer?.let {
            try {
                it.stop()
            } catch (e: Exception) {}
            try {
                it.detachViews()
            } catch (e: Exception) {}
            try {
                it.release()
            } catch (e: Exception) {}
        }
        mediaPlayer = null
        try {
            libVLC?.release()
        } catch (e: Exception) {}
        libVLC = null
    }
}
